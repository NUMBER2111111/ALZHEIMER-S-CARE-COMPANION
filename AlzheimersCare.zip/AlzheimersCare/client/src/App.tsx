import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Landing from "@/pages/landing";
import FamilyOnboarding from "@/pages/family-onboarding";
import AdminDashboard from "@/pages/admin-dashboard";
import PatientCompanion from "@/pages/patient-companion";

import PhotoMemoryDemo from "@/pages/photo-memory-demo";
import AdvancedVoiceDemo from "@/pages/advanced-voice-demo";
import PredictiveHealthAnalytics from "@/pages/predictive-health-analytics";
import HolographicCompanion from "@/pages/holographic-companion";
import CognitiveRecoveryProtocols from "@/pages/cognitive-recovery-protocols";
import NeuralInterfaceRecovery from "@/pages/neural-interface-recovery";
import BlockchainMedicalRecords from "@/pages/blockchain-medical-records";
import QuantumConsciousnessInterface from "@/pages/quantum-consciousness-interface";
import NanoGeneticTherapy from "@/pages/nano-genetic-therapy";
import TemporalSpatialReality from "@/pages/temporal-spatial-reality";
import MolecularBrainRepair from "@/pages/molecular-brain-repair";
import BioQuantumFieldTherapy from "@/pages/bio-quantum-field-therapy";
import FeaturesShowcase from "@/pages/features-showcase";
import DeviceConnection from "@/pages/device-connection";
import SecurityDashboard from "@/pages/security-dashboard";
import Subscription from "@/pages/subscription";
import AITelemedicine from "@/pages/ai-telemedicine";
import SmartMedicationDosing from "@/pages/smart-medication-dosing";
import AINutritionOptimization from "@/pages/ai-nutrition-optimization";
import InvisibleCognitiveStrategies from "@/pages/invisible-cognitive-strategies";
import InsuranceVerification from "@/pages/insurance-verification";
import InsuranceCoverageWizard from "@/pages/insurance-coverage-wizard";
import AtHomeCareCenter from "@/pages/at-home-care-center";
import AudioExperienceGuide from "@/pages/audio-experience-guide";
import VoiceSetupOptions from "@/pages/voice-setup-options";
import AlexaIntegration from "@/pages/alexa-integration";
import MultilingualSupport from "@/pages/multilingual-support";
import MoodTracking from "@/pages/mood-tracking";
import AirTagMapping from "@/pages/airtag-mapping";
import TrialSignup from "@/pages/trial-signup-simple";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Landing} />
      <Route path="/family-onboarding" component={FamilyOnboarding} />
      <Route path="/admin-dashboard/:facilityId?" component={(props) => <AdminDashboard facilityId={props.params.facilityId} />} />
      <Route path="/patient-companion/:patientId?" component={(props) => <PatientCompanion patientId={props.params.patientId} />} />
      <Route path="/photo-memory-demo/:patientId?" component={(props) => <PhotoMemoryDemo patientId={props.params.patientId ? parseInt(props.params.patientId) : 1} />} />
      <Route path="/advanced-voice-demo" component={AdvancedVoiceDemo} />
      <Route path="/predictive-analytics" component={PredictiveHealthAnalytics} />
      <Route path="/holographic-companion" component={HolographicCompanion} />
      <Route path="/cognitive-recovery" component={CognitiveRecoveryProtocols} />
      <Route path="/neural-interface" component={NeuralInterfaceRecovery} />
      <Route path="/blockchain-records" component={BlockchainMedicalRecords} />
      <Route path="/quantum-consciousness" component={QuantumConsciousnessInterface} />
      <Route path="/nano-genetic-therapy" component={NanoGeneticTherapy} />
      <Route path="/temporal-spatial-reality" component={TemporalSpatialReality} />
      <Route path="/molecular-brain-repair" component={MolecularBrainRepair} />
      <Route path="/bio-quantum-field-therapy" component={BioQuantumFieldTherapy} />
      <Route path="/features-showcase" component={FeaturesShowcase} />
      <Route path="/device-connection" component={DeviceConnection} />
      <Route path="/security-dashboard" component={SecurityDashboard} />
      <Route path="/subscription" component={Subscription} />
      <Route path="/ai-telemedicine" component={AITelemedicine} />
      <Route path="/smart-medication-dosing" component={SmartMedicationDosing} />
      <Route path="/ai-nutrition-optimization" component={AINutritionOptimization} />
      <Route path="/invisible-cognitive-strategies" component={InvisibleCognitiveStrategies} />
      <Route path="/insurance-verification" component={InsuranceVerification} />
      <Route path="/insurance-coverage-wizard" component={InsuranceCoverageWizard} />
      <Route path="/at-home-care-center" component={AtHomeCareCenter} />
      <Route path="/audio-experience-guide" component={AudioExperienceGuide} />
      <Route path="/audio-setup-guide" component={AudioExperienceGuide} />
      <Route path="/voice-setup-options" component={VoiceSetupOptions} />
      <Route path="/alexa-integration" component={AlexaIntegration} />
      <Route path="/multilingual-support" component={MultilingualSupport} />
      <Route path="/mood-tracking" component={MoodTracking} />
      <Route path="/airtag-mapping" component={AirTagMapping} />
      <Route path="/trial-signup" component={TrialSignup} />

      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
