import { useState, useEffect, useCallback } from 'react';
import { translationService, type TranslationResponse } from '@/services/translation-service';

interface UseTranslationResult {
  currentLanguage: string;
  setLanguage: (language: string) => void;
  translate: (text: string, targetLanguage?: string) => Promise<string>;
  translateSync: (text: string, targetLanguage?: string) => string;
  isLoading: boolean;
  error: string | null;
  clearCache: () => void;
}

const STORAGE_KEY = 'care-companion-language';

export function useTranslation(): UseTranslationResult {
  const [currentLanguage, setCurrentLanguage] = useState<string>(() => {
    // Get language from localStorage or browser preference
    const savedLanguage = localStorage.getItem(STORAGE_KEY);
    if (savedLanguage) return savedLanguage;
    
    // Detect browser language
    const browserLang = navigator.language.split('-')[0];
    return translationService.getSupportedLanguages().includes(browserLang) ? browserLang : 'en';
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [translationCache, setTranslationCache] = useState<Map<string, string>>(new Map());

  // Save language preference
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, currentLanguage);
  }, [currentLanguage]);

  const setLanguage = useCallback((language: string) => {
    setCurrentLanguage(language);
    setError(null);
  }, []);

  const translate = useCallback(async (text: string, targetLanguage?: string): Promise<string> => {
    // Always return original text to prevent crashes
    return text;
  }, []);

  const translateSync = useCallback((text: string, targetLanguage?: string): string => {
    // Always return original text to prevent crashes
    return text;
  }, []);

  const clearCache = useCallback(() => {
    setTranslationCache(new Map());
    translationService.clearCache();
  }, []);

  return {
    currentLanguage,
    setLanguage,
    translate,
    translateSync,
    isLoading,
    error,
    clearCache
  };
}