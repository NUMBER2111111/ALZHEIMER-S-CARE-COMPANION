/**
 * ElevenLabs Voice Hook
 * Professional voice synthesis for Care Companion AI
 */

import { useState, useRef, useCallback } from 'react';
import { apiRequest } from '@/lib/queryClient';

export interface VoiceOptions {
  voiceId?: string;
  stability?: number;
  similarityBoost?: number;
  style?: number;
  useSpeakerBoost?: boolean;
}

export interface VoiceState {
  isSpeaking: boolean;
  isLoading: boolean;
  error: string | null;
  usage: {
    charactersUsed: number;
    charactersLimit: number;
    nextResetDate?: number;
  } | null;
}

export function useElevenLabsVoice() {
  const [state, setState] = useState<VoiceState>({
    isSpeaking: false,
    isLoading: false,
    error: null,
    usage: null,
  });

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Browser speech synthesis fallback
  const useBrowserSpeech = useCallback((
    text: string, 
    emotionalContext?: 'calm' | 'encouraging' | 'concerned' | 'emergency'
  ) => {
    if ('speechSynthesis' in window) {
      setState(prev => ({ ...prev, isLoading: false, isSpeaking: true }));
      
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.pitch = 1.0;
      utterance.volume = 0.8;
      
      // Adjust voice characteristics based on emotional context
      if (emotionalContext === 'emergency') {
        utterance.rate = 1.1;
        utterance.pitch = 1.1;
      } else if (emotionalContext === 'encouraging') {
        utterance.pitch = 1.05;
      }
      
      utterance.onend = () => {
        setState(prev => ({ ...prev, isSpeaking: false }));
      };
      
      utterance.onerror = () => {
        setState(prev => ({ 
          ...prev, 
          isSpeaking: false, 
          error: 'Browser speech synthesis failed' 
        }));
      };
      
      window.speechSynthesis.speak(utterance);
    } else {
      setState(prev => ({ 
        ...prev, 
        isLoading: false,
        error: 'Speech synthesis not supported' 
      }));
    }
  }, []);

  const speak = useCallback(async (
    text: string, 
    options?: {
      voiceOptions?: VoiceOptions;
      emotionalContext?: 'calm' | 'encouraging' | 'concerned' | 'emergency';
    }
  ) => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }));

      // Stop any current playback
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }

      // Cancel any ongoing request
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }

      abortControllerRef.current = new AbortController();

      const response = await fetch('/api/voice/synthesize', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text,
          voiceOptions: options?.voiceOptions,
          emotionalContext: options?.emotionalContext,
        }),
        signal: abortControllerRef.current.signal,
      });

      if (!response.ok) {
        const errorData = await response.json();
        
        // If fallback is suggested, use browser speech synthesis
        if (errorData.fallback) {
          console.warn('ElevenLabs API unavailable, using browser fallback');
          useBrowserSpeech(text, options?.emotionalContext);
          return;
        }
        
        throw new Error(errorData.error || 'Voice synthesis failed');
      }

      const audioBlob = await response.blob();
      const audioUrl = URL.createObjectURL(audioBlob);
      
      const audio = new Audio(audioUrl);
      audioRef.current = audio;

      setState(prev => ({ ...prev, isLoading: false, isSpeaking: true }));

      audio.onended = () => {
        setState(prev => ({ ...prev, isSpeaking: false }));
        URL.revokeObjectURL(audioUrl);
        audioRef.current = null;
      };

      audio.onerror = () => {
        setState(prev => ({ 
          ...prev, 
          isSpeaking: false, 
          error: 'Audio playback failed' 
        }));
        URL.revokeObjectURL(audioUrl);
        audioRef.current = null;
      };

      await audio.play();

    } catch (error: any) {
      if (error.name === 'AbortError') {
        return; // Request was cancelled, ignore
      }

      console.error('Voice synthesis error:', error);
      setState(prev => ({ 
        ...prev, 
        isLoading: false, 
        isSpeaking: false, 
        error: error.message || 'Voice synthesis failed' 
      }));
    }
  }, []);

  const stop = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }

    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    setState(prev => ({ ...prev, isSpeaking: false, isLoading: false }));
  }, []);

  const getVoices = useCallback(async () => {
    try {
      const response = await fetch('/api/voice/healthcare-voices');
      const data = await response.json();
      return data.voices || [];
    } catch (error) {
      console.error('Failed to fetch voices:', error);
      return [];
    }
  }, []);

  const checkUsage = useCallback(async () => {
    try {
      const response = await fetch('/api/voice/usage');
      const data = await response.json();
      setState(prev => ({ ...prev, usage: data.usage }));
      return data.usage;
    } catch (error) {
      console.error('Failed to check usage:', error);
      return null;
    }
  }, []);

  // Fallback to browser speech synthesis if ElevenLabs fails
  const speakWithFallback = useCallback(async (
    text: string,
    options?: {
      voiceOptions?: VoiceOptions;
      emotionalContext?: 'calm' | 'encouraging' | 'concerned' | 'emergency';
    }
  ) => {
    try {
      await speak(text, options);
    } catch (error) {
      console.warn('ElevenLabs failed, falling back to browser TTS:', error);
      
      // Fallback to browser speech synthesis
      if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.9;
        utterance.pitch = 1.0;
        utterance.volume = 0.8;
        
        // Adjust voice characteristics based on emotional context
        if (options?.emotionalContext === 'emergency') {
          utterance.rate = 1.1;
          utterance.pitch = 1.1;
        } else if (options?.emotionalContext === 'encouraging') {
          utterance.pitch = 1.05;
        }
        
        window.speechSynthesis.speak(utterance);
      }
    }
  }, [speak]);

  return {
    state,
    speak,
    speakWithFallback,
    stop,
    getVoices,
    checkUsage,
  };
}