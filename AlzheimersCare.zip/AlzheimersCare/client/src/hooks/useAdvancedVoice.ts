import { useState, useEffect, useRef, useCallback } from 'react';
import { useSpeechRecognition } from './useSpeechRecognition';
import { useSpeechSynthesis } from './useSpeechSynthesis';

interface VoicePersonality {
  name: string;
  rate: number;
  pitch: number;
  volume: number;
  voiceName?: string;
  emotionalTone: 'calm' | 'cheerful' | 'caring' | 'professional';
}

interface AdvancedVoiceConfig {
  enableEmotionalAnalysis: boolean;
  adaptToUserTone: boolean;
  personalizedResponses: boolean;
  voicePersonality: VoicePersonality;
  wakePhrases: string[];
  continuousListening: boolean;
}

interface EmotionalContext {
  sentiment: 'positive' | 'negative' | 'neutral';
  energy: 'high' | 'medium' | 'low';
  urgency: 'urgent' | 'normal' | 'relaxed';
  confidence: number;
}

interface AdvancedVoiceHook {
  // Core functionality
  isListening: boolean;
  isSpeaking: boolean;
  transcript: string;
  emotionalContext: EmotionalContext | null;
  
  // Controls
  startAdvancedListening: () => void;
  stopAdvancedListening: () => void;
  speakWithEmotion: (text: string, emotion?: EmotionalContext) => void;
  adjustPersonality: (personality: Partial<VoicePersonality>) => void;
  
  // Configuration
  config: AdvancedVoiceConfig;
  updateConfig: (newConfig: Partial<AdvancedVoiceConfig>) => void;
  
  // State
  isWakeWordActive: boolean;
  conversationHistory: Array<{ user: string; ai: string; timestamp: Date; emotion?: EmotionalContext }>;
  
  // Callbacks
  onTranscriptReady: (transcript: string, emotion: EmotionalContext) => void;
  onWakeWordDetected: () => void;
}

const defaultPersonality: VoicePersonality = {
  name: 'Caring Companion',
  rate: 0.9,
  pitch: 1.1,
  volume: 0.8,
  emotionalTone: 'caring'
};

const defaultConfig: AdvancedVoiceConfig = {
  enableEmotionalAnalysis: true,
  adaptToUserTone: true,
  personalizedResponses: true,
  voicePersonality: defaultPersonality,
  wakePhrases: ['hey companion', 'hello companion', 'companion'],
  continuousListening: false
};

export function useAdvancedVoice(): AdvancedVoiceHook {
  const [config, setConfig] = useState<AdvancedVoiceConfig>(defaultConfig);
  const [emotionalContext, setEmotionalContext] = useState<EmotionalContext | null>(null);
  const [isWakeWordActive, setIsWakeWordActive] = useState(false);
  const [conversationHistory, setConversationHistory] = useState<Array<{ user: string; ai: string; timestamp: Date; emotion?: EmotionalContext }>>([]);
  
  const recognitionTimeoutRef = useRef<NodeJS.Timeout>();
  const lastTranscriptRef = useRef<string>('');
  
  // Use base speech hooks
  const speechRecognition = useSpeechRecognition();
  const speechSynthesis = useSpeechSynthesis();

  // Analyze emotional context from transcript
  const analyzeEmotionalContext = useCallback((transcript: string): EmotionalContext => {
    const text = transcript.toLowerCase();
    
    // Simple sentiment analysis
    const positiveWords = ['good', 'great', 'happy', 'wonderful', 'love', 'excellent', 'amazing', 'fantastic'];
    const negativeWords = ['bad', 'sad', 'terrible', 'hate', 'awful', 'horrible', 'pain', 'hurt', 'worried'];
    const urgentWords = ['help', 'emergency', 'urgent', 'quickly', 'now', 'immediate', 'pain'];
    const energyWords = ['excited', 'tired', 'sleepy', 'energetic', 'exhausted', 'alert'];
    
    let sentiment: 'positive' | 'negative' | 'neutral' = 'neutral';
    let energy: 'high' | 'medium' | 'low' = 'medium';
    let urgency: 'urgent' | 'normal' | 'relaxed' = 'normal';
    
    const positiveCount = positiveWords.filter(word => text.includes(word)).length;
    const negativeCount = negativeWords.filter(word => text.includes(word)).length;
    const urgentCount = urgentWords.filter(word => text.includes(word)).length;
    
    if (positiveCount > negativeCount) sentiment = 'positive';
    else if (negativeCount > positiveCount) sentiment = 'negative';
    
    if (urgentCount > 0) urgency = 'urgent';
    else if (text.includes('calm') || text.includes('relax')) urgency = 'relaxed';
    
    if (text.includes('tired') || text.includes('sleepy')) energy = 'low';
    else if (text.includes('excited') || text.includes('energetic')) energy = 'high';
    
    const confidence = Math.min(1, (positiveCount + negativeCount + urgentCount) / 3);
    
    return { sentiment, energy, urgency, confidence };
  }, []);

  // Check for wake words
  const detectWakeWord = useCallback((transcript: string): boolean => {
    const text = transcript.toLowerCase();
    return config.wakePhrases.some(phrase => text.includes(phrase.toLowerCase()));
  }, [config.wakePhrases]);

  // Advanced speaking with emotional adaptation
  const speakWithEmotion = useCallback((text: string, emotion?: EmotionalContext) => {
    if (!speechSynthesis.isSupported) return;
    
    const currentEmotion = emotion || emotionalContext;
    let voiceConfig = { ...config.voicePersonality };
    
    // Adapt voice based on emotional context
    if (currentEmotion && config.adaptToUserTone) {
      switch (currentEmotion.sentiment) {
        case 'positive':
          voiceConfig.rate = Math.min(1.2, voiceConfig.rate + 0.1);
          voiceConfig.pitch = Math.min(1.5, voiceConfig.pitch + 0.1);
          break;
        case 'negative':
          voiceConfig.rate = Math.max(0.6, voiceConfig.rate - 0.1);
          voiceConfig.pitch = Math.max(0.8, voiceConfig.pitch - 0.1);
          voiceConfig.volume = Math.max(0.6, voiceConfig.volume - 0.1);
          break;
      }
      
      switch (currentEmotion.urgency) {
        case 'urgent':
          voiceConfig.rate = Math.min(1.3, voiceConfig.rate + 0.2);
          voiceConfig.volume = Math.min(1.0, voiceConfig.volume + 0.1);
          break;
        case 'relaxed':
          voiceConfig.rate = Math.max(0.7, voiceConfig.rate - 0.1);
          break;
      }
      
      switch (currentEmotion.energy) {
        case 'low':
          voiceConfig.rate = Math.max(0.7, voiceConfig.rate - 0.1);
          voiceConfig.volume = Math.max(0.6, voiceConfig.volume - 0.1);
          break;
        case 'high':
          voiceConfig.rate = Math.min(1.2, voiceConfig.rate + 0.1);
          voiceConfig.volume = Math.min(1.0, voiceConfig.volume + 0.1);
          break;
      }
    }
    
    // Add emotional markers to text for more natural speech
    let enhancedText = text;
    if (currentEmotion?.urgency === 'urgent') {
      enhancedText = `${text}. Let me help you right away.`;
    } else if (currentEmotion?.sentiment === 'negative') {
      enhancedText = `I understand. ${text}`;
    } else if (currentEmotion?.sentiment === 'positive') {
      enhancedText = `That's wonderful! ${text}`;
    }
    
    speechSynthesis.speak(enhancedText, voiceConfig);
  }, [speechSynthesis, emotionalContext, config]);

  // Process transcript with advanced analysis
  const processTranscript = useCallback((transcript: string) => {
    if (!transcript || transcript === lastTranscriptRef.current) return;
    
    lastTranscriptRef.current = transcript;
    
    // Analyze emotional context
    const emotion = config.enableEmotionalAnalysis ? analyzeEmotionalContext(transcript) : null;
    setEmotionalContext(emotion);
    
    // Check for wake words
    if (detectWakeWord(transcript)) {
      setIsWakeWordActive(true);
      onWakeWordDetected();
    }
    
    // Trigger callback with enhanced data
    onTranscriptReady(transcript, emotion!);
  }, [config.enableEmotionalAnalysis, analyzeEmotionalContext, detectWakeWord]);

  // Advanced listening with continuous mode
  const startAdvancedListening = useCallback(() => {
    speechRecognition.startListening();
    
    if (config.continuousListening) {
      // Set up continuous listening with timeout reset
      const resetTimeout = () => {
        if (recognitionTimeoutRef.current) {
          clearTimeout(recognitionTimeoutRef.current);
        }
        recognitionTimeoutRef.current = setTimeout(() => {
          if (speechRecognition.isListening) {
            speechRecognition.stopListening();
            setTimeout(startAdvancedListening, 1000); // Restart after 1 second
          }
        }, 30000); // 30 second timeout
      };
      
      resetTimeout();
    }
  }, [speechRecognition, config.continuousListening]);

  const stopAdvancedListening = useCallback(() => {
    speechRecognition.stopListening();
    if (recognitionTimeoutRef.current) {
      clearTimeout(recognitionTimeoutRef.current);
    }
  }, [speechRecognition]);

  // Process transcript changes
  useEffect(() => {
    if (speechRecognition.transcript && !speechRecognition.isListening) {
      processTranscript(speechRecognition.transcript);
    }
  }, [speechRecognition.transcript, speechRecognition.isListening, processTranscript]);

  // Cleanup timeouts
  useEffect(() => {
    return () => {
      if (recognitionTimeoutRef.current) {
        clearTimeout(recognitionTimeoutRef.current);
      }
    };
  }, []);

  // Default callbacks (can be overridden)
  const onTranscriptReady = useCallback((transcript: string, emotion: EmotionalContext) => {
    console.log('Advanced Voice Transcript:', { transcript, emotion });
  }, []);

  const onWakeWordDetected = useCallback(() => {
    console.log('Wake word detected!');
  }, []);

  const adjustPersonality = useCallback((personality: Partial<VoicePersonality>) => {
    setConfig(prev => ({
      ...prev,
      voicePersonality: { ...prev.voicePersonality, ...personality }
    }));
  }, []);

  const updateConfig = useCallback((newConfig: Partial<AdvancedVoiceConfig>) => {
    setConfig(prev => ({ ...prev, ...newConfig }));
  }, []);

  return {
    // Core functionality
    isListening: speechRecognition.isListening,
    isSpeaking: speechSynthesis.isSpeaking,
    transcript: speechRecognition.transcript,
    emotionalContext,
    
    // Controls
    startAdvancedListening,
    stopAdvancedListening,
    speakWithEmotion,
    adjustPersonality,
    
    // Configuration
    config,
    updateConfig,
    
    // State
    isWakeWordActive,
    conversationHistory,
    
    // Callbacks
    onTranscriptReady,
    onWakeWordDetected
  };
}