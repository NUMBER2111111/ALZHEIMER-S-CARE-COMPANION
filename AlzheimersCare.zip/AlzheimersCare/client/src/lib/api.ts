import { apiRequest } from "./queryClient";

export interface CreateUserRequest {
  email?: string;
  firstName?: string;
  lastName?: string;
  userType: string;
}

export interface CreatePatientRequest {
  firstName: string;
  lastName: string;
  dateOfBirth?: Date;
  medicalInfo?: any;
  emergencyInfo?: any;
  facilityId?: number;
}

export interface CreateFamilyMemoryRequest {
  patientId: number;
  familyMemberId: number;
  memoryType: string;
  title?: string;
  description?: string;
  content?: any;
}

export interface CreateActivitySessionRequest {
  patientId: number;
  activityId: number;
}

export interface CompleteActivitySessionRequest {
  responseData: any;
  successRate: number;
}

export class CareCompanionAPI {
  static async createUser(data: CreateUserRequest) {
    const response = await apiRequest("POST", "/api/users", data);
    return response.json();
  }

  static async getUser(id: number) {
    const response = await apiRequest("GET", `/api/users/${id}`);
    return response.json();
  }

  static async createPatient(data: CreatePatientRequest) {
    const response = await apiRequest("POST", "/api/patients", data);
    return response.json();
  }

  static async getPatient(id: number) {
    const response = await apiRequest("GET", `/api/patients/${id}`);
    return response.json();
  }

  static async getFacilities() {
    const response = await apiRequest("GET", "/api/facilities");
    return response.json();
  }

  static async createFacility(data: any) {
    const response = await apiRequest("POST", "/api/facilities", data);
    return response.json();
  }

  static async createFamilyRelationship(data: any) {
    const response = await apiRequest("POST", "/api/family-relationships", data);
    return response.json();
  }

  static async getFamilyRelationships(patientId: number) {
    const response = await apiRequest("GET", `/api/family-relationships/patient/${patientId}`);
    return response.json();
  }

  static async createFamilyMemory(data: CreateFamilyMemoryRequest, file?: File) {
    const formData = new FormData();
    formData.append('data', JSON.stringify(data));
    if (file) {
      formData.append('file', file);
    }

    const response = await fetch("/api/family-memories", {
      method: "POST",
      body: formData,
      credentials: "include",
    });

    if (!response.ok) {
      throw new Error(`${response.status}: ${response.statusText}`);
    }

    return response.json();
  }

  static async getFamilyMemories(patientId: number) {
    const response = await apiRequest("GET", `/api/family-memories/patient/${patientId}`);
    return response.json();
  }

  static async generateCognitiveActivities(patientId: number, activityType?: string) {
    const response = await apiRequest("POST", `/api/generate-activities/${patientId}`, {
      activityType
    });
    return response.json();
  }

  static async getCognitiveActivities(patientId: number) {
    const response = await apiRequest("GET", `/api/cognitive-activities/patient/${patientId}`);
    return response.json();
  }

  static async createActivitySession(data: CreateActivitySessionRequest) {
    const response = await apiRequest("POST", "/api/activity-sessions", data);
    return response.json();
  }

  static async completeActivitySession(sessionId: number, data: CompleteActivitySessionRequest) {
    const response = await apiRequest("PATCH", `/api/activity-sessions/${sessionId}/complete`, data);
    return response.json();
  }

  static async getCognitiveProgress(patientId: number) {
    const response = await apiRequest("GET", `/api/cognitive-progress/patient/${patientId}`);
    return response.json();
  }

  static async getLatestCognitiveProgress(patientId: number) {
    const response = await apiRequest("GET", `/api/cognitive-progress/patient/${patientId}/latest`);
    return response.json();
  }

  static async getAdminAnalytics(facilityId: number) {
    const response = await apiRequest("GET", `/api/admin/analytics/${facilityId}`);
    return response.json();
  }
}
