import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { CreditCard, Shield, Clock, CheckCircle, AlertCircle, Heart, Brain } from 'lucide-react';
import { useLocation } from 'wouter';
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

// Form validation schema
const trialSignupSchema = z.object({
  firstName: z.string().min(2, 'First name must be at least 2 characters'),
  lastName: z.string().min(2, 'Last name must be at least 2 characters'),
  email: z.string().email('Please enter a valid email address'),
  phone: z.string().min(10, 'Please enter a valid phone number'),
  acceptTerms: z.boolean().refine(val => val === true, 'You must accept the terms and conditions')
});

type TrialSignupForm = z.infer<typeof trialSignupSchema>;

export default function TrialSignup() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  
  const form = useForm<TrialSignupForm>({
    resolver: zodResolver(trialSignupSchema),
    defaultValues: {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      acceptTerms: false
    }
  });

  const handleSubmit = async (data: TrialSignupForm) => {
    setIsProcessing(true);
    
    try {
      // Create Square customer and start trial
      const response = await apiRequest('POST', '/api/square/create-trial-customer', {
        ...data,
        trialDays: 14,
        subscriptionAmount: 4999 // $49.99 per month
      });

      if (response.ok) {
        toast({
          title: "Trial Started Successfully!",
          description: "Your 14-day free trial has begun. Welcome to Care Companion!",
        });
        navigate('/family-onboarding');
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to create trial account');
      }
    } catch (error) {
      console.error('Trial signup error:', error);
      toast({
        title: "Trial Setup Failed",
        description: error instanceof Error ? error.message : "Unable to start trial. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <div className="w-12 h-12 care-gradient rounded-xl flex items-center justify-center">
              <Heart className="text-white h-6 w-6" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900">Start Your Free Trial</h1>
          </div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Begin your 14-day free trial of Care Companion's AI-powered Alzheimer's care platform
          </p>
        </div>

        {/* Trial Benefits */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="text-center">
            <CardContent className="pt-6">
              <Clock className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">14-Day Free Trial</h3>
              <p className="text-sm text-gray-600">Full access to all premium features</p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="pt-6">
              <Brain className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">AI Companion</h3>
              <p className="text-sm text-gray-600">Personalized cognitive training</p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="pt-6">
              <Shield className="h-12 w-12 text-purple-600 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Family Dashboard</h3>
              <p className="text-sm text-gray-600">Real-time monitoring and insights</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Form */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                Contact Information
              </CardTitle>
              <CardDescription>
                We'll use this information to set up your account and send trial updates
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      {...form.register('firstName')}
                      className="mt-1"
                    />
                    {form.formState.errors.firstName && (
                      <p className="text-sm text-red-600 mt-1">
                        {form.formState.errors.firstName.message}
                      </p>
                    )}
                  </div>
                  <div>
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      {...form.register('lastName')}
                      className="mt-1"
                    />
                    {form.formState.errors.lastName && (
                      <p className="text-sm text-red-600 mt-1">
                        {form.formState.errors.lastName.message}
                      </p>
                    )}
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    {...form.register('email')}
                    className="mt-1"
                  />
                  {form.formState.errors.email && (
                    <p className="text-sm text-red-600 mt-1">
                      {form.formState.errors.email.message}
                    </p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    {...form.register('phone')}
                    className="mt-1"
                  />
                  {form.formState.errors.phone && (
                    <p className="text-sm text-red-600 mt-1">
                      {form.formState.errors.phone.message}
                    </p>
                  )}
                </div>

                {/* Credit Card Information */}
                <div className="pt-4 border-t">
                  <div className="flex items-center gap-2 mb-4">
                    <CreditCard className="h-5 w-5 text-blue-600" />
                    <Label className="text-base font-semibold">Payment Information</Label>
                  </div>
                  
                  <Alert className="mb-4">
                    <Shield className="h-4 w-4" />
                    <AlertDescription>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-green-700">🔒 Bank-Level Security</span>
                        </div>
                        <div className="text-sm text-gray-600">
                          • Payment data encrypted with 256-bit SSL encryption
                          • PCI DSS Level 1 compliant processing via Square
                          • No card details stored on our servers
                          • Fraud protection and monitoring included
                        </div>
                      </div>
                    </AlertDescription>
                  </Alert>

                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <Label htmlFor="cardNumber">Card Number</Label>
                      <Input
                        id="cardNumber"
                        placeholder="1234 5678 9012 3456"
                        className="mt-1"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="expiry">Expiry Date</Label>
                        <Input
                          id="expiry"
                          placeholder="MM/YY"
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="cvv">CVV</Label>
                        <Input
                          id="cvv"
                          placeholder="123"
                          className="mt-1"
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="billingZip">Billing ZIP Code</Label>
                      <Input
                        id="billingZip"
                        placeholder="12345"
                        className="mt-1"
                      />
                    </div>
                  </div>

                  <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-start gap-2">
                      <Shield className="h-4 w-4 text-blue-600 mt-0.5" />
                      <div className="text-sm">
                        <div className="font-medium text-blue-900">Why we need your card:</div>
                        <div className="text-blue-700 mt-1">
                          Your card secures your 14-day free trial. You won't be charged until 
                          the trial ends. Cancel anytime during the trial period at no cost.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Terms and Conditions */}
                <div className="flex items-start space-x-3">
                  <input
                    type="checkbox"
                    id="acceptTerms"
                    {...form.register('acceptTerms')}
                    className="mt-1"
                  />
                  <Label htmlFor="acceptTerms" className="text-sm leading-5">
                    I agree to the Terms of Service and Privacy Policy. I understand that my trial 
                    will convert to a $49.99/month subscription after 14 days unless I cancel.
                  </Label>
                </div>
                {form.formState.errors.acceptTerms && (
                  <p className="text-sm text-red-600">
                    {form.formState.errors.acceptTerms.message}
                  </p>
                )}

                {/* Money-Back Guarantee */}
                <Alert className="bg-green-50 border-green-200">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertDescription>
                    <div className="space-y-1">
                      <div className="font-semibold text-green-800">100% Money-Back Guarantee</div>
                      <div className="text-sm text-green-700">
                        Cancel anytime during your 14-day free trial with zero charges. 
                        Even after your trial, we offer a 30-day money-back guarantee if you're not satisfied.
                      </div>
                    </div>
                  </AlertDescription>
                </Alert>

                {/* Submit Button */}
                <Button 
                  type="submit" 
                  className="w-full bg-blue-600 hover:bg-blue-700 py-3 text-lg"
                  disabled={isProcessing}
                >
                  {isProcessing ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Processing Securely...
                    </div>
                  ) : (
                    <>
                      <Shield className="h-5 w-5 mr-2" />
                      Start Free Trial - $0 Today
                    </>
                  )}
                </Button>

                {/* Additional Security Assurance */}
                <div className="text-center text-sm text-gray-600 pt-2">
                  <div className="flex items-center justify-center gap-1">
                    <Shield className="h-3 w-3 text-green-600" />
                    <span>This transaction is secured by 256-bit SSL encryption</span>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Trial Summary */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5 text-green-600" />
                  Trial Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center py-2 border-b">
                    <span>Monthly Subscription</span>
                    <span className="font-semibold">$49.99/month</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b">
                    <span>Free Trial Period</span>
                    <Badge className="bg-green-100 text-green-800">14 Days</Badge>
                  </div>
                  <div className="flex justify-between items-center py-2">
                    <span className="font-semibold">Today's Charge</span>
                    <span className="font-bold text-green-600">$0.00</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Alert>
              <Shield className="h-4 w-4" />
              <AlertDescription>
                <div className="space-y-2">
                  <div className="font-semibold">Trial Details:</div>
                  <ul className="text-sm space-y-1">
                    <li>• 14-day free trial starts immediately</li>
                    <li>• Full access to all premium features</li>
                    <li>• Cancel anytime during trial period</li>
                    <li>• $49.99/month after trial if not cancelled</li>
                  </ul>
                </div>
              </AlertDescription>
            </Alert>

            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription className="text-sm">
                <strong>Insurance Coverage:</strong> Many insurance plans cover up to 80-100% 
                of Care Companion costs under Medicare Part B Remote Patient Monitoring benefits.
              </AlertDescription>
            </Alert>

            {/* Security Trust Badges */}
            <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
              <CardContent className="pt-6">
                <div className="text-center space-y-4">
                  <div className="flex items-center justify-center gap-2">
                    <Shield className="h-6 w-6 text-green-600" />
                    <span className="font-semibold text-green-800">Trusted & Secure</span>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span>256-bit SSL Encryption</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span>PCI DSS Compliant</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span>HIPAA Certified</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span>Fraud Protection</span>
                    </div>
                  </div>

                  <div className="text-xs text-gray-600 pt-2 border-t border-green-200">
                    <strong>Square Payment Processing:</strong> Your payment is processed by Square, 
                    the same trusted platform used by millions of businesses worldwide.
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}