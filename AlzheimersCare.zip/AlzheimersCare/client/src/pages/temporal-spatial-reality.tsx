import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Clock, MapPin, Eye, Layers, Compass, Calendar, Home, Users } from 'lucide-react';

interface TemporalAnchor {
  id: string;
  era: string;
  significance: string;
  memoryStrength: number;
  spatialLocation: string;
  emotionalResonance: number;
  accessibilityLevel: 'high' | 'medium' | 'low';
  lastAccessed: string;
  triggers: string[];
}

interface SpatialEnvironment {
  id: string;
  name: string;
  type: 'childhood_home' | 'workplace' | 'vacation_spot' | 'social_gathering';
  familiarity: number;
  emotionalValence: 'positive' | 'neutral' | 'negative';
  sensoryDetails: {
    visual: string[];
    auditory: string[];
    olfactory: string[];
    tactile: string[];
  };
  navigationAids: string[];
  safetyLevel: number;
}

interface RealityLayer {
  id: string;
  name: string;
  opacity: number;
  type: 'memory_overlay' | 'navigation_aid' | 'emotional_support' | 'cognitive_prompt';
  active: boolean;
  adaptiveLevel: number;
  personalizedContent: string[];
}

interface MemoryPalace {
  id: string;
  name: string;
  roomCount: number;
  memoryCapacity: number;
  currentOccupancy: number;
  stabilityIndex: number;
  accessMethod: 'visual_walk' | 'narrative_journey' | 'emotional_pathway';
  lastMaintenance: string;
}

export default function TemporalSpatialReality() {
  const [temporalAnchors, setTemporalAnchors] = useState<TemporalAnchor[]>([
    {
      id: 'anchor_001',
      era: '1960s Childhood',
      significance: 'First day of school - foundational memory',
      memoryStrength: 94,
      spatialLocation: 'Elementary School Classroom',
      emotionalResonance: 87,
      accessibilityLevel: 'high',
      lastAccessed: '2 hours ago',
      triggers: ['school bell sound', 'chalk on blackboard', 'fresh pencils']
    },
    {
      id: 'anchor_002',
      era: '1980s Young Adult',
      significance: 'Wedding day - peak emotional memory',
      memoryStrength: 98,
      spatialLocation: 'St. Mary\'s Church',
      emotionalResonance: 96,
      accessibilityLevel: 'high',
      lastAccessed: '4 hours ago',
      triggers: ['wedding march music', 'white flowers', 'formal wear']
    },
    {
      id: 'anchor_003',
      era: '1990s Career Peak',
      significance: 'Job promotion celebration',
      memoryStrength: 76,
      spatialLocation: 'Downtown Office Building',
      emotionalResonance: 82,
      accessibilityLevel: 'medium',
      lastAccessed: '1 day ago',
      triggers: ['elevator ding', 'coffee aroma', 'formal handshake']
    },
    {
      id: 'anchor_004',
      era: '2000s Family Life',
      significance: 'Children\'s graduation',
      memoryStrength: 89,
      spatialLocation: 'High School Auditorium',
      emotionalResonance: 94,
      accessibilityLevel: 'high',
      lastAccessed: '6 hours ago',
      triggers: ['applause', 'cap and gown', 'proud tears']
    }
  ]);

  const [spatialEnvironments, setSpatialEnvironments] = useState<SpatialEnvironment[]>([
    {
      id: 'env_001',
      name: 'Childhood Home',
      type: 'childhood_home',
      familiarity: 96,
      emotionalValence: 'positive',
      sensoryDetails: {
        visual: ['wooden front porch', 'red brick exterior', 'large oak tree'],
        auditory: ['screen door creaking', 'birds chirping', 'lawn mower'],
        olfactory: ['mother\'s cooking', 'fresh laundry', 'garden flowers'],
        tactile: ['smooth banister', 'soft carpet', 'warm sunlight']
      },
      navigationAids: ['front porch entrance', 'kitchen sounds', 'staircase location'],
      safetyLevel: 98
    },
    {
      id: 'env_002',
      name: 'First Workplace',
      type: 'workplace',
      familiarity: 84,
      emotionalValence: 'positive',
      sensoryDetails: {
        visual: ['glass windows', 'grey filing cabinets', 'fluorescent lights'],
        auditory: ['typewriter keys', 'office chatter', 'phone ringing'],
        olfactory: ['coffee brewing', 'paper smell', 'cleaning supplies'],
        tactile: ['leather chair', 'smooth desk surface', 'cool air conditioning']
      },
      navigationAids: ['elevator sounds', 'reception desk', 'coffee station'],
      safetyLevel: 92
    },
    {
      id: 'env_003',
      name: 'Family Vacation Cabin',
      type: 'vacation_spot',
      familiarity: 78,
      emotionalValence: 'positive',
      sensoryDetails: {
        visual: ['log cabin exterior', 'lake view', 'pine trees'],
        auditory: ['water lapping', 'wind in trees', 'crackling fire'],
        olfactory: ['pine needles', 'campfire smoke', 'fresh air'],
        tactile: ['rough wood texture', 'cool lake water', 'warm fire']
      },
      navigationAids: ['lake shoreline', 'cabin front door', 'fire pit area'],
      safetyLevel: 95
    }
  ]);

  const [realityLayers, setRealityLayers] = useState<RealityLayer[]>([
    {
      id: 'layer_001',
      name: 'Memory Navigation Overlay',
      opacity: 0.85,
      type: 'navigation_aid',
      active: true,
      adaptiveLevel: 92,
      personalizedContent: ['directional arrows', 'familiar landmarks', 'safety indicators']
    },
    {
      id: 'layer_002',
      name: 'Emotional Comfort Layer',
      opacity: 0.45,
      type: 'emotional_support',
      active: true,
      adaptiveLevel: 88,
      personalizedContent: ['family photos', 'comforting messages', 'familiar faces']
    },
    {
      id: 'layer_003',
      name: 'Cognitive Prompting System',
      opacity: 0.60,
      type: 'cognitive_prompt',
      active: false,
      adaptiveLevel: 76,
      personalizedContent: ['task reminders', 'name labels', 'time indicators']
    },
    {
      id: 'layer_004',
      name: 'Historical Memory Overlay',
      opacity: 0.70,
      type: 'memory_overlay',
      active: true,
      adaptiveLevel: 94,
      personalizedContent: ['past experiences', 'contextual memories', 'temporal markers']
    }
  ]);

  const [memoryPalaces, setMemoryPalaces] = useState<MemoryPalace[]>([
    {
      id: 'palace_001',
      name: 'Childhood Home Palace',
      roomCount: 12,
      memoryCapacity: 240,
      currentOccupancy: 189,
      stabilityIndex: 94,
      accessMethod: 'visual_walk',
      lastMaintenance: '3 days ago'
    },
    {
      id: 'palace_002',
      name: 'Career Journey Palace',
      roomCount: 8,
      memoryCapacity: 160,
      currentOccupancy: 134,
      stabilityIndex: 87,
      accessMethod: 'narrative_journey',
      lastMaintenance: '1 week ago'
    },
    {
      id: 'palace_003',
      name: 'Family Moments Palace',
      roomCount: 15,
      memoryCapacity: 300,
      currentOccupancy: 267,
      stabilityIndex: 91,
      accessMethod: 'emotional_pathway',
      lastMaintenance: '2 days ago'
    }
  ]);

  const [currentAnchor, setCurrentAnchor] = useState<TemporalAnchor | null>(null);
  const [isCalibrating, setIsCalibrating] = useState(false);
  const [realityMode, setRealityMode] = useState('enhanced');

  useEffect(() => {
    // Simulate real-time temporal-spatial updates
    const interval = setInterval(() => {
      setTemporalAnchors(prev => prev.map(anchor => ({
        ...anchor,
        memoryStrength: Math.max(60, Math.min(100, anchor.memoryStrength + (Math.random() - 0.5) * 2)),
        emotionalResonance: Math.max(50, Math.min(100, anchor.emotionalResonance + (Math.random() - 0.5) * 3))
      })));

      setSpatialEnvironments(prev => prev.map(env => ({
        ...env,
        familiarity: Math.max(70, Math.min(100, env.familiarity + (Math.random() - 0.5) * 1)),
        safetyLevel: Math.max(80, Math.min(100, env.safetyLevel + (Math.random() - 0.5) * 0.5))
      })));

      setMemoryPalaces(prev => prev.map(palace => ({
        ...palace,
        stabilityIndex: Math.max(75, Math.min(100, palace.stabilityIndex + (Math.random() - 0.5) * 1.5))
      })));
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  const calibrateReality = async () => {
    setIsCalibrating(true);
    
    // Simulate reality calibration process
    setTimeout(() => {
      setRealityLayers(prev => prev.map(layer => ({
        ...layer,
        adaptiveLevel: Math.min(100, layer.adaptiveLevel + 10),
        opacity: layer.active ? Math.min(1.0, layer.opacity + 0.1) : layer.opacity
      })));
      
      setMemoryPalaces(prev => prev.map(palace => ({
        ...palace,
        stabilityIndex: Math.min(100, palace.stabilityIndex + 8)
      })));
      
      setIsCalibrating(false);
    }, 6000);
  };

  const toggleLayer = (layerId: string) => {
    setRealityLayers(prev => prev.map(layer => 
      layer.id === layerId ? { ...layer, active: !layer.active } : layer
    ));
  };

  const getAccessibilityColor = (level: string) => {
    switch (level) {
      case 'high': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getEmotionalColor = (valence: string) => {
    switch (valence) {
      case 'positive': return 'text-green-400';
      case 'neutral': return 'text-yellow-400';
      case 'negative': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getEnvironmentIcon = (type: string) => {
    switch (type) {
      case 'childhood_home': return <Home className="h-4 w-4" />;
      case 'workplace': return <MapPin className="h-4 w-4" />;
      case 'vacation_spot': return <Compass className="h-4 w-4" />;
      case 'social_gathering': return <Users className="h-4 w-4" />;
      default: return <MapPin className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-900 via-purple-900 to-indigo-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-violet-500 to-purple-600 rounded-xl flex items-center justify-center">
              <Layers className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-white">Temporal-Spatial Reality Augmentation</h1>
          </div>
          <p className="text-xl text-violet-200 max-w-4xl mx-auto">
            Advanced reality layering technology that anchors patients in familiar temporal and spatial contexts, 
            enhancing memory recall and reducing disorientation through personalized environmental reconstruction.
          </p>
        </div>

        {/* System Overview */}
        <Card className="bg-black/30 backdrop-blur-md border-violet-500/30 shadow-2xl">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-violet-400">{temporalAnchors.length}</div>
                <div className="text-violet-200">Temporal Anchors</div>
                <div className="mt-2 flex items-center justify-center gap-2">
                  <div className="w-2 h-2 bg-violet-400 rounded-full animate-pulse"></div>
                  <span className="text-sm text-violet-300">Active</span>
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-400">{spatialEnvironments.length}</div>
                <div className="text-violet-200">Spatial Environments</div>
                <div className="mt-2">
                  <Badge className="bg-purple-500/20 text-purple-300 border-purple-400">
                    Mapped
                  </Badge>
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-indigo-400">{realityLayers.filter(l => l.active).length}</div>
                <div className="text-violet-200">Active Layers</div>
                <div className="mt-2">
                  <Badge className="bg-indigo-500/20 text-indigo-300 border-indigo-400">
                    Overlayed
                  </Badge>
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-pink-400">
                  {Math.round(memoryPalaces.reduce((acc, p) => acc + p.stabilityIndex, 0) / memoryPalaces.length)}%
                </div>
                <div className="text-violet-200">Memory Stability</div>
                <div className="mt-2">
                  <Badge className="bg-pink-500/20 text-pink-300 border-pink-400">
                    Optimal
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Calibration Status */}
        {isCalibrating && (
          <Card className="bg-gradient-to-r from-violet-600/20 to-purple-600/20 backdrop-blur-md border-violet-400/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-violet-400 rounded-full animate-pulse"></div>
                  <div>
                    <h3 className="text-xl font-bold text-white">Reality Calibration in Progress</h3>
                    <p className="text-violet-200">Synchronizing temporal anchors and spatial environments...</p>
                  </div>
                </div>
                <div className="text-right text-white">
                  <div className="text-2xl font-bold">🔄 Calibrating</div>
                  <p className="text-violet-200">ETA: 6 minutes</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="anchors" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-black/30 backdrop-blur-md border-violet-500/30">
            <TabsTrigger value="anchors" className="text-violet-200 data-[state=active]:text-white">Temporal Anchors</TabsTrigger>
            <TabsTrigger value="environments" className="text-violet-200 data-[state=active]:text-white">Spatial Environments</TabsTrigger>
            <TabsTrigger value="layers" className="text-violet-200 data-[state=active]:text-white">Reality Layers</TabsTrigger>
            <TabsTrigger value="palaces" className="text-violet-200 data-[state=active]:text-white">Memory Palaces</TabsTrigger>
          </TabsList>

          <TabsContent value="anchors" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">Temporal Memory Anchors</h2>
              <Button 
                onClick={calibrateReality}
                disabled={isCalibrating}
                className="bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700"
              >
                <Clock className="mr-2 h-4 w-4" />
                {isCalibrating ? 'Calibrating...' : 'Calibrate Reality'}
              </Button>
            </div>

            <div className="space-y-4">
              {temporalAnchors.map((anchor) => (
                <Card 
                  key={anchor.id} 
                  className="bg-black/30 backdrop-blur-md border-violet-500/30 hover:border-violet-400/50 transition-all duration-300 cursor-pointer"
                  onClick={() => setCurrentAnchor(anchor)}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4">
                        <div className="flex items-center justify-center w-12 h-12 bg-violet-600/30 rounded-lg">
                          <Clock className="h-6 w-6 text-violet-300" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-lg font-bold text-white">{anchor.era}</h3>
                            <Badge className={getAccessibilityColor(anchor.accessibilityLevel)}>
                              {anchor.accessibilityLevel} access
                            </Badge>
                          </div>
                          <p className="text-violet-200 text-sm mb-2">{anchor.significance}</p>
                          <p className="text-violet-300 text-sm">
                            Location: <span className="text-white">{anchor.spatialLocation}</span>
                          </p>
                          <p className="text-violet-300 text-sm">
                            Last accessed: <span className="text-white">{anchor.lastAccessed}</span>
                          </p>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-violet-300">Memory:</span>
                            <p className="text-white font-medium">{anchor.memoryStrength.toFixed(0)}%</p>
                          </div>
                          <div>
                            <span className="text-violet-300">Emotional:</span>
                            <p className="text-white font-medium">{anchor.emotionalResonance.toFixed(0)}%</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <h4 className="text-violet-300 text-sm mb-2">Memory Triggers:</h4>
                      <div className="flex flex-wrap gap-2">
                        {anchor.triggers.map((trigger, index) => (
                          <Badge key={index} className="bg-violet-500/20 text-violet-300 border-violet-400">
                            {trigger}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="environments" className="space-y-6">
            <h2 className="text-2xl font-bold text-white">Spatial Environment Mapping</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {spatialEnvironments.map((env) => (
                <Card key={env.id} className="bg-black/30 backdrop-blur-md border-violet-500/30">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-white flex items-center gap-2">
                          {getEnvironmentIcon(env.type)}
                          {env.name}
                        </CardTitle>
                        <p className="text-violet-200 text-sm capitalize">{env.type.replace('_', ' ')}</p>
                      </div>
                      <div className={`text-lg font-bold ${getEmotionalColor(env.emotionalValence)}`}>
                        {env.emotionalValence}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <span className="text-violet-300 text-sm">Familiarity</span>
                          <div className="text-lg font-bold text-white">{env.familiarity}%</div>
                        </div>
                        <div>
                          <span className="text-violet-300 text-sm">Safety</span>
                          <div className="text-lg font-bold text-green-400">{env.safetyLevel}%</div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-violet-300 text-sm mb-2">Sensory Details:</h4>
                        <div className="space-y-1 text-xs">
                          <div className="text-violet-200">
                            <span className="text-violet-300">Visual:</span> {env.sensoryDetails.visual.join(', ')}
                          </div>
                          <div className="text-violet-200">
                            <span className="text-violet-300">Audio:</span> {env.sensoryDetails.auditory.join(', ')}
                          </div>
                          <div className="text-violet-200">
                            <span className="text-violet-300">Scent:</span> {env.sensoryDetails.olfactory.join(', ')}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="layers" className="space-y-6">
            <h2 className="text-2xl font-bold text-white">Augmented Reality Layers</h2>
            
            <div className="space-y-4">
              {realityLayers.map((layer) => (
                <Card key={layer.id} className="bg-black/30 backdrop-blur-md border-violet-500/30">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="flex items-center justify-center w-12 h-12 bg-violet-600/30 rounded-lg">
                          <Layers className="h-6 w-6 text-violet-300" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-lg font-bold text-white">{layer.name}</h3>
                            <Badge className={layer.active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                              {layer.active ? 'Active' : 'Inactive'}
                            </Badge>
                          </div>
                          <p className="text-violet-200 text-sm capitalize">{layer.type.replace('_', ' ')}</p>
                          <p className="text-violet-300 text-sm">
                            Opacity: {(layer.opacity * 100).toFixed(0)}% | Adaptive Level: {layer.adaptiveLevel}%
                          </p>
                        </div>
                      </div>
                      
                      <Button
                        onClick={() => toggleLayer(layer.id)}
                        variant={layer.active ? "destructive" : "default"}
                        size="sm"
                      >
                        {layer.active ? 'Deactivate' : 'Activate'}
                      </Button>
                    </div>
                    
                    <div className="mt-4">
                      <h4 className="text-violet-300 text-sm mb-2">Personalized Content:</h4>
                      <div className="flex flex-wrap gap-2">
                        {layer.personalizedContent.map((content, index) => (
                          <Badge key={index} className="bg-violet-500/20 text-violet-300 border-violet-400">
                            {content}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="palaces" className="space-y-6">
            <h2 className="text-2xl font-bold text-white">Memory Palace Architecture</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {memoryPalaces.map((palace) => (
                <Card key={palace.id} className="bg-black/30 backdrop-blur-md border-violet-500/30">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Home className="h-5 w-5" />
                      {palace.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <span className="text-violet-300 text-sm">Rooms</span>
                          <div className="text-lg font-bold text-white">{palace.roomCount}</div>
                        </div>
                        <div>
                          <span className="text-violet-300 text-sm">Stability</span>
                          <div className="text-lg font-bold text-green-400">{palace.stabilityIndex.toFixed(0)}%</div>
                        </div>
                      </div>
                      
                      <div>
                        <span className="text-violet-300 text-sm">Memory Occupancy</span>
                        <div className="flex items-center gap-2 mt-1">
                          <div className="w-full bg-violet-900/30 rounded-full h-2">
                            <div 
                              className="bg-gradient-to-r from-violet-500 to-purple-500 h-2 rounded-full transition-all duration-1000"
                              style={{ width: `${(palace.currentOccupancy / palace.memoryCapacity) * 100}%` }}
                            ></div>
                          </div>
                          <span className="text-white text-sm">{palace.currentOccupancy}/{palace.memoryCapacity}</span>
                        </div>
                      </div>
                      
                      <div className="text-sm">
                        <div className="text-violet-300">Access Method:</div>
                        <div className="text-white capitalize">{palace.accessMethod.replace('_', ' ')}</div>
                      </div>
                      
                      <div className="text-sm">
                        <div className="text-violet-300">Last Maintenance:</div>
                        <div className="text-white">{palace.lastMaintenance}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}