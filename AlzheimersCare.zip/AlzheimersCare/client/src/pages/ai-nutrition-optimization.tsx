import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Apple, Brain, Heart, Droplets, Zap, Target, TrendingUp, Camera, Scale, Clock, ChefHat, ShoppingCart } from 'lucide-react';

export default function AINutritionOptimization() {
  const [nutritionScore, setNutritionScore] = useState(78);
  const [cognitiveImpact, setCognitiveImpact] = useState(82);
  
  const currentNutrition = {
    calories: 1847,
    protein: 72,
    carbs: 195,
    fat: 68,
    fiber: 28,
    omega3: 1.2,
    antioxidants: 4200,
    vitamins: {
      b12: 85,
      d3: 92,
      e: 78,
      folate: 89
    }
  };

  const brainBoostingFoods = [
    {
      name: "Wild Salmon",
      benefit: "Omega-3 DHA for memory",
      cognitiveScore: 95,
      servings: "2-3 per week",
      nutrients: ["DHA", "EPA", "Vitamin D"],
      preparation: "Grilled or baked"
    },
    {
      name: "Blueberries",
      benefit: "Anthocyanins for neuroprotection",
      cognitiveScore: 92,
      servings: "1 cup daily",
      nutrients: ["Anthocyanins", "Vitamin C", "Fiber"],
      preparation: "Fresh or frozen"
    },
    {
      name: "Walnuts",
      benefit: "Alpha-linolenic acid for brain health",
      cognitiveScore: 89,
      servings: "1 oz daily",
      nutrients: ["ALA", "Vitamin E", "Magnesium"],
      preparation: "Raw or lightly toasted"
    },
    {
      name: "Dark Leafy Greens",
      benefit: "Folate and vitamin K for cognition",
      cognitiveScore: 87,
      servings: "2 cups daily",
      nutrients: ["Folate", "Vitamin K", "Lutein"],
      preparation: "Steamed or sautéed"
    },
    {
      name: "Turmeric",
      benefit: "Curcumin reduces inflammation",
      cognitiveScore: 85,
      servings: "1 tsp daily",
      nutrients: ["Curcumin", "Piperine"],
      preparation: "With black pepper and oil"
    }
  ];

  const mealPlan = [
    {
      meal: "Breakfast",
      time: "7:30 AM",
      items: [
        "Oatmeal with blueberries and walnuts",
        "Green tea",
        "Vitamin D3 supplement"
      ],
      cognitiveScore: 88,
      calories: 420
    },
    {
      meal: "Mid-Morning",
      time: "10:00 AM",
      items: [
        "Greek yogurt with almonds",
        "Brain-boost smoothie"
      ],
      cognitiveScore: 82,
      calories: 280
    },
    {
      meal: "Lunch",
      time: "12:30 PM",
      items: [
        "Spinach salad with salmon",
        "Quinoa with vegetables",
        "Olive oil dressing"
      ],
      cognitiveScore: 94,
      calories: 580
    },
    {
      meal: "Afternoon",
      time: "3:30 PM",
      items: [
        "Dark chocolate (70% cacao)",
        "Green tea",
        "Mixed berries"
      ],
      cognitiveScore: 79,
      calories: 180
    },
    {
      meal: "Dinner",
      time: "6:30 PM",
      items: [
        "Grilled chicken with turmeric",
        "Roasted Brussels sprouts",
        "Sweet potato"
      ],
      cognitiveScore: 86,
      calories: 520
    }
  ];

  const supplements = [
    {
      name: "Omega-3 DHA/EPA",
      dosage: "1000mg daily",
      timing: "With breakfast",
      benefit: "Memory and cognitive function",
      evidence: "Strong clinical evidence",
      interaction: "None with current medications"
    },
    {
      name: "Vitamin D3",
      dosage: "2000 IU daily",
      timing: "With breakfast",
      benefit: "Neuroprotection and mood",
      evidence: "Moderate evidence",
      interaction: "Monitor with calcium supplements"
    },
    {
      name: "B-Complex",
      dosage: "High potency daily",
      timing: "With breakfast",
      benefit: "Energy metabolism and cognition",
      evidence: "Strong evidence for B12/folate",
      interaction: "None known"
    },
    {
      name: "Curcumin",
      dosage: "500mg with piperine",
      timing: "With dinner",
      benefit: "Anti-inflammatory for brain",
      evidence: "Emerging research",
      interaction: "May affect blood thinners"
    }
  ];

  const nutritionInsights = [
    {
      category: "Cognitive Enhancement",
      score: 85,
      recommendation: "Increase omega-3 rich foods and antioxidants",
      priority: "High"
    },
    {
      category: "Anti-Inflammatory",
      score: 72,
      recommendation: "Add more turmeric, ginger, and green tea",
      priority: "Medium"
    },
    {
      category: "Neuroprotection",
      score: 88,
      recommendation: "Excellent variety of brain-protective nutrients",
      priority: "Maintain"
    },
    {
      category: "Energy & Focus",
      score: 79,
      recommendation: "Balance blood sugar with protein and complex carbs",
      priority: "Medium"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            AI Nutrition Optimization for Cognitive Health
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            Personalized nutrition planning for optimal brain function and Alzheimer's prevention
          </p>
        </div>

        {/* Nutrition Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <Apple className="h-12 w-12 mx-auto mb-4 text-green-600" />
                <div className="text-3xl font-bold text-green-700 dark:text-green-400">
                  {nutritionScore}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  Overall Nutrition Score
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <Brain className="h-12 w-12 mx-auto mb-4 text-blue-600" />
                <div className="text-3xl font-bold text-blue-700 dark:text-blue-400">
                  {cognitiveImpact}%
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  Cognitive Impact
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <Target className="h-12 w-12 mx-auto mb-4 text-purple-600" />
                <div className="text-3xl font-bold text-purple-700 dark:text-purple-400">
                  94%
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  Daily Goals Met
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <TrendingUp className="h-12 w-12 mx-auto mb-4 text-orange-600" />
                <div className="text-3xl font-bold text-orange-700 dark:text-orange-400">
                  +12%
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  Improvement This Week
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="daily" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="daily">Daily Nutrition</TabsTrigger>
            <TabsTrigger value="brain-foods">Brain Foods</TabsTrigger>
            <TabsTrigger value="meal-plan">Meal Planning</TabsTrigger>
            <TabsTrigger value="supplements">Supplements</TabsTrigger>
            <TabsTrigger value="insights">AI Insights</TabsTrigger>
          </TabsList>

          <TabsContent value="daily" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5" />
                    Macronutrient Balance
                  </CardTitle>
                  <CardDescription>Optimized for cognitive function</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span>Calories</span>
                      <span className="font-bold">{currentNutrition.calories}</span>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Protein</span>
                        <span>{currentNutrition.protein}g</span>
                      </div>
                      <Progress value={85} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Carbohydrates</span>
                        <span>{currentNutrition.carbs}g</span>
                      </div>
                      <Progress value={70} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Healthy Fats</span>
                        <span>{currentNutrition.fat}g</span>
                      </div>
                      <Progress value={92} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Fiber</span>
                        <span>{currentNutrition.fiber}g</span>
                      </div>
                      <Progress value={95} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5" />
                    Brain-Specific Nutrients
                  </CardTitle>
                  <CardDescription>Key nutrients for cognitive health</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Omega-3 DHA/EPA</span>
                        <span>{currentNutrition.omega3}g</span>
                      </div>
                      <Progress value={80} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Antioxidants (ORAC)</span>
                        <span>{currentNutrition.antioxidants}</span>
                      </div>
                      <Progress value={88} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Vitamin B12</span>
                        <span>{currentNutrition.vitamins.b12}%</span>
                      </div>
                      <Progress value={currentNutrition.vitamins.b12} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Vitamin D3</span>
                        <span>{currentNutrition.vitamins.d3}%</span>
                      </div>
                      <Progress value={currentNutrition.vitamins.d3} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Folate</span>
                        <span>{currentNutrition.vitamins.folate}%</span>
                      </div>
                      <Progress value={currentNutrition.vitamins.folate} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="brain-foods" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Apple className="h-5 w-5" />
                  Top Brain-Boosting Foods
                </CardTitle>
                <CardDescription>Foods scientifically proven to enhance cognitive function</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {brainBoostingFoods.map((food, index) => (
                    <Card key={index} className="border-l-4 border-l-green-500">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg">{food.name}</CardTitle>
                        <CardDescription>{food.benefit}</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Cognitive Score</span>
                          <Badge variant="default">{food.cognitiveScore}/100</Badge>
                        </div>
                        
                        <div>
                          <div className="text-sm font-medium mb-1">Recommended Serving:</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">
                            {food.servings}
                          </div>
                        </div>

                        <div>
                          <div className="text-sm font-medium mb-2">Key Nutrients:</div>
                          <div className="flex flex-wrap gap-1">
                            {food.nutrients.map((nutrient, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">
                                {nutrient}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div>
                          <div className="text-sm font-medium mb-1">Best Preparation:</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">
                            {food.preparation}
                          </div>
                        </div>

                        <Button size="sm" className="w-full">
                          <ShoppingCart className="h-4 w-4 mr-2" />
                          Add to Shopping List
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="meal-plan" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ChefHat className="h-5 w-5" />
                  AI-Optimized Daily Meal Plan
                </CardTitle>
                <CardDescription>Personalized meal timing and combinations for cognitive enhancement</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mealPlan.map((meal, index) => (
                    <Card key={index} className="border-l-4 border-l-blue-500">
                      <CardContent className="pt-6">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h3 className="font-semibold text-lg">{meal.meal}</h3>
                            <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                              <Clock className="h-4 w-4" />
                              {meal.time}
                            </div>
                          </div>
                          <div className="text-right">
                            <Badge variant="secondary">
                              Score: {meal.cognitiveScore}
                            </Badge>
                            <div className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                              {meal.calories} calories
                            </div>
                          </div>
                        </div>
                        
                        <div className="space-y-2">
                          {meal.items.map((item, idx) => (
                            <div key={idx} className="flex items-center gap-2 text-sm">
                              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                              {item}
                            </div>
                          ))}
                        </div>

                        <div className="flex gap-2 mt-4">
                          <Button size="sm" variant="outline" className="flex-1">
                            <Camera className="h-4 w-4 mr-2" />
                            Log Meal
                          </Button>
                          <Button size="sm" variant="outline" className="flex-1">
                            Modify
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="supplements" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Droplets className="h-5 w-5" />
                  Targeted Cognitive Supplements
                </CardTitle>
                <CardDescription>Evidence-based supplements for brain health</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {supplements.map((supplement, index) => (
                    <Card key={index} className="border">
                      <CardHeader className="pb-4">
                        <CardTitle className="text-lg">{supplement.name}</CardTitle>
                        <CardDescription>{supplement.dosage}</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div>
                          <div className="text-sm font-medium">Benefit:</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">
                            {supplement.benefit}
                          </div>
                        </div>
                        
                        <div>
                          <div className="text-sm font-medium">Best Time:</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">
                            {supplement.timing}
                          </div>
                        </div>

                        <div>
                          <div className="text-sm font-medium">Evidence Level:</div>
                          <Badge variant={supplement.evidence.includes('Strong') ? 'default' : 'secondary'}>
                            {supplement.evidence}
                          </Badge>
                        </div>

                        <div>
                          <div className="text-sm font-medium">Interactions:</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">
                            {supplement.interaction}
                          </div>
                        </div>

                        <Button size="sm" className="w-full">
                          Add to Regimen
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="insights" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  AI Nutrition Insights
                </CardTitle>
                <CardDescription>Personalized recommendations based on cognitive goals</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {nutritionInsights.map((insight, index) => (
                    <div key={index} className="space-y-3">
                      <div className="flex justify-between items-center">
                        <h3 className="font-semibold">{insight.category}</h3>
                        <Badge variant={insight.priority === 'High' ? 'destructive' : 
                                       insight.priority === 'Medium' ? 'secondary' : 'default'}>
                          {insight.priority} Priority
                        </Badge>
                      </div>
                      <Progress value={insight.score} className="h-3" />
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {insight.recommendation}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-8 p-6 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-lg">
                  <h3 className="font-semibold text-lg mb-4">Weekly Nutrition Goals</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Omega-3 intake</span>
                        <span className="font-medium">8.4g / 10g</span>
                      </div>
                      <Progress value={84} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Antioxidant foods</span>
                        <span className="font-medium">6 / 7 days</span>
                      </div>
                      <Progress value={86} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Brain-boosting meals</span>
                        <span className="font-medium">18 / 21 meals</span>
                      </div>
                      <Progress value={86} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Hydration target</span>
                        <span className="font-medium">52 / 56 cups</span>
                      </div>
                      <Progress value={93} className="h-2" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}