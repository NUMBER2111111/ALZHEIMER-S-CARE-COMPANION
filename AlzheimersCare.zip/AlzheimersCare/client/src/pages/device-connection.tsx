import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { 
  Bluetooth, 
  Wifi, 
  Brain, 
  Heart, 
  Camera, 
  Mic, 
  Speaker, 
  Watch, 
  Smartphone,
  Monitor,
  CheckCircle,
  AlertCircle,
  Loader2,
  Settings,
  RefreshCw,
  ShoppingCart,
  Star,
  ExternalLink
} from 'lucide-react';

interface Device {
  id: string;
  name: string;
  type: 'neural' | 'vital' | 'audio' | 'visual' | 'wearable' | 'sensor';
  status: 'connected' | 'disconnected' | 'connecting' | 'error';
  batteryLevel?: number;
  lastSync?: Date;
  capabilities: string[];
  required: boolean;
  icon: any;
}

interface ConnectionStatus {
  bluetooth: boolean;
  wifi: boolean;
  webrtc: boolean;
  speechAPI: boolean;
  camera: boolean;
  microphone: boolean;
}

interface RecommendedDevice {
  id: string;
  name: string;
  brand: string;
  model: string;
  category: 'neural' | 'vital' | 'audio' | 'visual' | 'wearable' | 'sensor';
  price: string;
  rating: number;
  features: string[];
  compatibility: string[];
  description: string;
  imageUrl?: string;
  purchaseUrl?: string;
  inStock: boolean;
  recommended: boolean;
}

export default function DeviceConnection() {
  const [devices, setDevices] = useState<Device[]>([
    {
      id: 'neural-headset',
      name: 'Neural Interface Headset',
      type: 'neural',
      status: 'disconnected',
      batteryLevel: 85,
      capabilities: ['EEG monitoring', 'Brainwave analysis', 'Cognitive assessment'],
      required: true,
      icon: Brain
    },
    {
      id: 'holographic-projector',
      name: 'Holographic Display Unit',
      type: 'visual',
      status: 'disconnected',
      capabilities: ['3D projection', 'Spatial mapping', 'Gesture recognition'],
      required: false,
      icon: Monitor
    },
    {
      id: 'spatial-audio',
      name: 'Spatial Audio System',
      type: 'audio',
      status: 'connected',
      batteryLevel: 92,
      capabilities: ['360° audio', 'Directional sound', 'Noise cancellation'],
      required: true,
      icon: Speaker
    },
    {
      id: 'vitals-monitor',
      name: 'Health Monitor Watch',
      type: 'wearable',
      status: 'connected',
      batteryLevel: 67,
      lastSync: new Date(Date.now() - 300000),
      capabilities: ['Heart rate', 'Blood pressure', 'Activity tracking'],
      required: true,
      icon: Watch
    },
    {
      id: 'smart-camera',
      name: 'AI Vision Camera',
      type: 'visual',
      status: 'disconnected',
      capabilities: ['Face recognition', 'Object detection', 'Movement tracking'],
      required: false,
      icon: Camera
    }
  ]);

  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>({
    bluetooth: false,
    wifi: true,
    webrtc: false,
    speechAPI: false,
    camera: false,
    microphone: false
  });

  const [scanning, setScanning] = useState(false);
  const { toast } = useToast();

  const [recommendedDevices] = useState<RecommendedDevice[]>([
    {
      id: 'muse-s',
      name: 'Muse S (Gen 2)',
      brand: 'Muse',
      model: 'MU-03-01',
      category: 'neural',
      price: '$399.99',
      rating: 4.6,
      features: ['EEG monitoring', 'Sleep tracking', 'Meditation guidance', 'Real-time brainwave feedback'],
      compatibility: ['iOS', 'Android', 'Bluetooth 5.0'],
      description: 'Advanced meditation headband with multi-sensor EEG for cognitive monitoring and brain training.',
      inStock: true,
      recommended: true
    },
    {
      id: 'apple-watch-ultra',
      name: 'Apple Watch Ultra 2',
      brand: 'Apple',
      model: 'MR863LL/A',
      category: 'wearable',
      price: '$799.00',
      rating: 4.8,
      features: ['ECG', 'Blood oxygen', 'Heart rate', 'Fall detection', 'Emergency SOS'],
      compatibility: ['iOS', 'HealthKit', 'Bluetooth 5.3'],
      description: 'Premium health monitoring smartwatch with comprehensive vital signs tracking.',
      inStock: true,
      recommended: true
    },
    {
      id: 'garmin-vivosmart-5',
      name: 'Garmin Vivosmart 5',
      brand: 'Garmin',
      model: '010-02645-01',
      category: 'wearable',
      price: '$149.99',
      rating: 4.3,
      features: ['24/7 health monitoring', 'Stress tracking', 'Sleep score', 'Safe for swimming'],
      compatibility: ['iOS', 'Android', 'Garmin Connect'],
      description: 'Affordable fitness tracker with essential health monitoring capabilities.',
      inStock: true,
      recommended: false
    },
    {
      id: 'sonos-era-300',
      name: 'Sonos Era 300',
      brand: 'Sonos',
      model: 'ERA300US1',
      category: 'audio',
      price: '$449.00',
      rating: 4.7,
      features: ['Spatial audio', '360-degree sound', 'Dolby Atmos', 'Voice control'],
      compatibility: ['WiFi', 'Bluetooth', 'AirPlay 2', 'Sonos app'],
      description: 'Premium spatial audio speaker for immersive holographic companion experience.',
      inStock: true,
      recommended: true
    },
    {
      id: 'logitech-brio',
      name: 'Logitech Brio 4K',
      brand: 'Logitech',
      model: '960-001105',
      category: 'visual',
      price: '$199.99',
      rating: 4.4,
      features: ['4K Ultra HD', 'HDR', 'Face recognition', 'Auto-focus', 'Privacy shutter'],
      compatibility: ['USB 3.0', 'Windows Hello', 'Mac', 'Chrome OS'],
      description: 'Professional 4K webcam with advanced face recognition for AI companion interaction.',
      inStock: true,
      recommended: true
    },
    {
      id: 'emotiv-epoc-x',
      name: 'EMOTIV EPOC X',
      brand: 'EMOTIV',
      model: 'EP-X-11-05',
      category: 'neural',
      price: '$849.00',
      rating: 4.2,
      features: ['14-channel EEG', 'Wireless', 'Motion sensors', 'Real-time brain activity'],
      compatibility: ['Windows', 'Mac', 'Linux', 'Mobile apps'],
      description: 'Professional-grade EEG headset for advanced neural interface and cognitive research.',
      inStock: false,
      recommended: true
    },
    {
      id: 'oura-ring-gen3',
      name: 'Oura Ring Gen 3',
      brand: 'Oura',
      model: 'OURA-GEN3',
      category: 'wearable',
      price: '$299.00',
      rating: 4.1,
      features: ['Sleep analysis', 'Heart rate variability', 'Body temperature', 'Activity tracking'],
      compatibility: ['iOS', 'Android', 'Bluetooth 5.0'],
      description: 'Discreet health tracking ring with advanced sleep and recovery analytics.',
      inStock: true,
      recommended: false
    },
    {
      id: 'microsoft-hololens-2',
      name: 'Microsoft HoloLens 2',
      brand: 'Microsoft',
      model: 'HL2-DEV-US',
      category: 'visual',
      price: '$3,500.00',
      rating: 4.0,
      features: ['Mixed reality', 'Holographic display', 'Hand tracking', 'Eye tracking'],
      compatibility: ['Windows 10/11', 'Azure', 'Custom apps'],
      description: 'Enterprise mixed reality headset for advanced holographic companion projection.',
      inStock: false,
      recommended: true
    }
  ]);

  useEffect(() => {
    checkBrowserCapabilities();
  }, []);

  const checkBrowserCapabilities = async () => {
    const status: ConnectionStatus = {
      bluetooth: 'bluetooth' in navigator,
      wifi: navigator.onLine,
      webrtc: 'RTCPeerConnection' in window,
      speechAPI: 'speechSynthesis' in window && 'webkitSpeechRecognition' in window,
      camera: false,
      microphone: false
    };

    // Check camera and microphone permissions
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: true, 
        audio: true 
      });
      status.camera = true;
      status.microphone = true;
      stream.getTracks().forEach(track => track.stop());
    } catch (error) {
      console.log('Media devices not available:', error);
    }

    setConnectionStatus(status);
  };

  const scanForDevices = async () => {
    setScanning(true);
    
    try {
      // Simulate device scanning
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Update some devices as found
      setDevices(prev => prev.map(device => {
        if (device.id === 'neural-headset' || device.id === 'smart-camera') {
          return { ...device, status: 'disconnected' };
        }
        return device;
      }));

      toast({
        title: "Device Scan Complete",
        description: "Found 2 new devices nearby",
      });
    } catch (error) {
      toast({
        title: "Scan Failed",
        description: "Unable to scan for devices. Check Bluetooth permissions.",
        variant: "destructive"
      });
    } finally {
      setScanning(false);
    }
  };

  const connectDevice = async (deviceId: string) => {
    setDevices(prev => prev.map(device => 
      device.id === deviceId 
        ? { ...device, status: 'connecting' }
        : device
    ));

    try {
      // Simulate connection process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setDevices(prev => prev.map(device => 
        device.id === deviceId 
          ? { ...device, status: 'connected', lastSync: new Date() }
          : device
      ));

      toast({
        title: "Device Connected",
        description: `Successfully connected to ${devices.find(d => d.id === deviceId)?.name}`,
      });
    } catch (error) {
      setDevices(prev => prev.map(device => 
        device.id === deviceId 
          ? { ...device, status: 'error' }
          : device
      ));

      toast({
        title: "Connection Failed",
        description: "Unable to connect to device. Please try again.",
        variant: "destructive"
      });
    }
  };

  const disconnectDevice = (deviceId: string) => {
    setDevices(prev => prev.map(device => 
      device.id === deviceId 
        ? { ...device, status: 'disconnected' }
        : device
    ));

    toast({
      title: "Device Disconnected",
      description: `Disconnected from ${devices.find(d => d.id === deviceId)?.name}`,
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected': return 'bg-green-500';
      case 'connecting': return 'bg-yellow-500';
      case 'error': return 'bg-red-500';
      default: return 'bg-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected': return CheckCircle;
      case 'connecting': return Loader2;
      case 'error': return AlertCircle;
      default: return AlertCircle;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold text-gray-900">Device Connection Center</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Connect and manage your healthcare devices for enhanced AI companion experience
          </p>
        </div>

        {/* System Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              System Capabilities
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              <div className="text-center">
                <div className={`mx-auto w-12 h-12 rounded-full flex items-center justify-center ${connectionStatus.bluetooth ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-400'}`}>
                  <Bluetooth className="h-6 w-6" />
                </div>
                <div className="mt-2 text-sm font-medium">Bluetooth</div>
                <Badge variant={connectionStatus.bluetooth ? "default" : "secondary"}>
                  {connectionStatus.bluetooth ? "Available" : "Unavailable"}
                </Badge>
              </div>
              
              <div className="text-center">
                <div className={`mx-auto w-12 h-12 rounded-full flex items-center justify-center ${connectionStatus.wifi ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'}`}>
                  <Wifi className="h-6 w-6" />
                </div>
                <div className="mt-2 text-sm font-medium">WiFi</div>
                <Badge variant={connectionStatus.wifi ? "default" : "secondary"}>
                  {connectionStatus.wifi ? "Connected" : "Disconnected"}
                </Badge>
              </div>

              <div className="text-center">
                <div className={`mx-auto w-12 h-12 rounded-full flex items-center justify-center ${connectionStatus.camera ? 'bg-purple-100 text-purple-600' : 'bg-gray-100 text-gray-400'}`}>
                  <Camera className="h-6 w-6" />
                </div>
                <div className="mt-2 text-sm font-medium">Camera</div>
                <Badge variant={connectionStatus.camera ? "default" : "secondary"}>
                  {connectionStatus.camera ? "Ready" : "No Access"}
                </Badge>
              </div>

              <div className="text-center">
                <div className={`mx-auto w-12 h-12 rounded-full flex items-center justify-center ${connectionStatus.microphone ? 'bg-orange-100 text-orange-600' : 'bg-gray-100 text-gray-400'}`}>
                  <Mic className="h-6 w-6" />
                </div>
                <div className="mt-2 text-sm font-medium">Microphone</div>
                <Badge variant={connectionStatus.microphone ? "default" : "secondary"}>
                  {connectionStatus.microphone ? "Ready" : "No Access"}
                </Badge>
              </div>

              <div className="text-center">
                <div className={`mx-auto w-12 h-12 rounded-full flex items-center justify-center ${connectionStatus.speechAPI ? 'bg-teal-100 text-teal-600' : 'bg-gray-100 text-gray-400'}`}>
                  <Speaker className="h-6 w-6" />
                </div>
                <div className="mt-2 text-sm font-medium">Speech API</div>
                <Badge variant={connectionStatus.speechAPI ? "default" : "secondary"}>
                  {connectionStatus.speechAPI ? "Available" : "Unavailable"}
                </Badge>
              </div>

              <div className="text-center">
                <div className={`mx-auto w-12 h-12 rounded-full flex items-center justify-center ${connectionStatus.webrtc ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-100 text-gray-400'}`}>
                  <Smartphone className="h-6 w-6" />
                </div>
                <div className="mt-2 text-sm font-medium">WebRTC</div>
                <Badge variant={connectionStatus.webrtc ? "default" : "secondary"}>
                  {connectionStatus.webrtc ? "Supported" : "Unsupported"}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Device Management */}
        <Tabs defaultValue="devices" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="devices">Connected Devices</TabsTrigger>
            <TabsTrigger value="recommendations">Recommended Devices</TabsTrigger>
            <TabsTrigger value="setup">Device Setup</TabsTrigger>
          </TabsList>

          <TabsContent value="devices" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Healthcare Devices</h2>
              <Button 
                onClick={scanForDevices} 
                disabled={scanning}
                className="flex items-center gap-2"
              >
                {scanning ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <RefreshCw className="h-4 w-4" />
                )}
                {scanning ? "Scanning..." : "Scan for Devices"}
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {devices.map((device) => {
                const StatusIcon = getStatusIcon(device.status);
                const DeviceIcon = device.icon;
                
                return (
                  <Card key={device.id} className="relative">
                    {device.required && (
                      <Badge className="absolute top-2 right-2 bg-red-100 text-red-800">
                        Required
                      </Badge>
                    )}
                    
                    <CardHeader className="pb-3">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-blue-100 rounded-lg">
                          <DeviceIcon className="h-6 w-6 text-blue-600" />
                        </div>
                        <div className="flex-1">
                          <CardTitle className="text-lg">{device.name}</CardTitle>
                          <div className="flex items-center gap-2 mt-1">
                            <div className={`w-2 h-2 rounded-full ${getStatusColor(device.status)}`} />
                            <span className="text-sm text-gray-600 capitalize">{device.status}</span>
                          </div>
                        </div>
                        <StatusIcon className={`h-5 w-5 ${
                          device.status === 'connected' ? 'text-green-600' :
                          device.status === 'connecting' ? 'text-yellow-600 animate-spin' :
                          device.status === 'error' ? 'text-red-600' : 'text-gray-400'
                        }`} />
                      </div>
                    </CardHeader>

                    <CardContent className="space-y-4">
                      {device.batteryLevel && (
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Battery</span>
                            <span>{device.batteryLevel}%</span>
                          </div>
                          <Progress value={device.batteryLevel} className="h-2" />
                        </div>
                      )}

                      {device.lastSync && (
                        <div className="text-sm text-gray-600">
                          Last sync: {device.lastSync.toLocaleTimeString()}
                        </div>
                      )}

                      <div>
                        <div className="text-sm font-medium mb-2">Capabilities:</div>
                        <div className="flex flex-wrap gap-1">
                          {device.capabilities.map((capability, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {capability}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div className="flex gap-2">
                        {device.status === 'connected' ? (
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => disconnectDevice(device.id)}
                            className="flex-1"
                          >
                            Disconnect
                          </Button>
                        ) : (
                          <Button 
                            size="sm" 
                            onClick={() => connectDevice(device.id)}
                            disabled={device.status === 'connecting'}
                            className="flex-1"
                          >
                            {device.status === 'connecting' ? 'Connecting...' : 'Connect'}
                          </Button>
                        )}
                        <Button variant="ghost" size="sm">
                          <Settings className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="recommendations" className="space-y-6">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold">Recommended Healthcare Devices</h2>
                <div className="flex gap-2">
                  <Badge variant="outline">Curated for AI Companion</Badge>
                  <Badge variant="outline">Medical Grade Certified</Badge>
                </div>
              </div>

              <Alert>
                <ShoppingCart className="h-4 w-4" />
                <AlertDescription>
                  These devices are specifically tested and optimized for our AI healthcare platform. Prices and availability may vary.
                </AlertDescription>
              </Alert>

              {/* Filter Tabs */}
              <div className="flex flex-wrap gap-2 mb-6">
                <Button variant="outline" size="sm">All Categories</Button>
                <Button variant="ghost" size="sm">Neural Interface</Button>
                <Button variant="ghost" size="sm">Health Monitoring</Button>
                <Button variant="ghost" size="sm">Audio & Visual</Button>
                <Button variant="ghost" size="sm">Wearables</Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {recommendedDevices.map((device) => (
                  <Card key={device.id} className={`relative ${device.recommended ? 'border-blue-500 border-2' : ''}`}>
                    {device.recommended && (
                      <Badge className="absolute top-3 right-3 bg-blue-500 text-white">
                        Recommended
                      </Badge>
                    )}
                    
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-lg">{device.name}</CardTitle>
                          <div className="text-sm text-gray-600 mt-1">
                            {device.brand} • {device.model}
                          </div>
                          <div className="flex items-center gap-2 mt-2">
                            <div className="flex items-center gap-1">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`h-4 w-4 ${
                                    i < Math.floor(device.rating)
                                      ? 'text-yellow-400 fill-current'
                                      : 'text-gray-300'
                                  }`}
                                />
                              ))}
                            </div>
                            <span className="text-sm text-gray-600">({device.rating})</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-xl font-bold text-blue-600">{device.price}</div>
                          <Badge variant={device.inStock ? "default" : "secondary"}>
                            {device.inStock ? "In Stock" : "Out of Stock"}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent className="space-y-4">
                      <p className="text-sm text-gray-600">{device.description}</p>

                      <div>
                        <div className="text-sm font-medium mb-2">Key Features:</div>
                        <div className="flex flex-wrap gap-1">
                          {device.features.slice(0, 4).map((feature, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {feature}
                            </Badge>
                          ))}
                          {device.features.length > 4 && (
                            <Badge variant="outline" className="text-xs">
                              +{device.features.length - 4} more
                            </Badge>
                          )}
                        </div>
                      </div>

                      <div>
                        <div className="text-sm font-medium mb-2">Compatibility:</div>
                        <div className="flex flex-wrap gap-1">
                          {device.compatibility.map((comp, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {comp}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div className="flex gap-2 pt-2">
                        <Button 
                          size="sm" 
                          className="flex-1"
                          disabled={!device.inStock}
                        >
                          <ShoppingCart className="h-4 w-4 mr-2" />
                          {device.inStock ? "Buy Now" : "Notify When Available"}
                        </Button>
                        <Button variant="ghost" size="sm">
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </div>

                      {device.category === 'neural' && (
                        <div className="bg-purple-50 p-3 rounded-lg mt-3">
                          <div className="text-xs font-medium text-purple-800 mb-1">Neural Interface Benefits</div>
                          <div className="text-xs text-purple-700">
                            Enables advanced cognitive monitoring and brain-computer interaction for enhanced AI companion experience.
                          </div>
                        </div>
                      )}

                      {device.category === 'visual' && device.price.includes('3,500') && (
                        <div className="bg-blue-50 p-3 rounded-lg mt-3">
                          <div className="text-xs font-medium text-blue-800 mb-1">Holographic Technology</div>
                          <div className="text-xs text-blue-700">
                            Professional-grade mixed reality for immersive holographic family member projections.
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Device Comparison */}
              <Card className="mt-8">
                <CardHeader>
                  <CardTitle>Device Category Comparison</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="text-center p-4 bg-purple-50 rounded-lg">
                      <Brain className="h-8 w-8 mx-auto mb-2 text-purple-600" />
                      <div className="font-medium">Neural Interface</div>
                      <div className="text-sm text-gray-600 mt-1">$400 - $850</div>
                      <div className="text-xs text-gray-500 mt-2">
                        EEG monitoring, cognitive assessment, brain training
                      </div>
                    </div>
                    
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <Heart className="h-8 w-8 mx-auto mb-2 text-green-600" />
                      <div className="font-medium">Health Monitoring</div>
                      <div className="text-sm text-gray-600 mt-1">$150 - $800</div>
                      <div className="text-xs text-gray-500 mt-2">
                        Vital signs, emergency detection, activity tracking
                      </div>
                    </div>
                    
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <Speaker className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                      <div className="font-medium">Audio & Visual</div>
                      <div className="text-sm text-gray-600 mt-1">$200 - $3,500</div>
                      <div className="text-xs text-gray-500 mt-2">
                        Spatial audio, holographic display, AI interaction
                      </div>
                    </div>
                    
                    <div className="text-center p-4 bg-orange-50 rounded-lg">
                      <Watch className="h-8 w-8 mx-auto mb-2 text-orange-600" />
                      <div className="font-medium">Wearables</div>
                      <div className="text-sm text-gray-600 mt-1">$150 - $800</div>
                      <div className="text-xs text-gray-500 mt-2">
                        24/7 monitoring, sleep analysis, medication reminders
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="setup" className="space-y-6">
            <div className="space-y-4">
              <h2 className="text-2xl font-bold">Device Setup Guide</h2>
              
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  For optimal AI companion experience, ensure all required devices are connected and permissions are granted.
                </AlertDescription>
              </Alert>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Brain className="h-5 w-5" />
                      Neural Interface Setup
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-sm text-gray-600">
                      1. Power on your neural interface headset
                    </div>
                    <div className="text-sm text-gray-600">
                      2. Enable Bluetooth on this device
                    </div>
                    <div className="text-sm text-gray-600">
                      3. Click "Scan for Devices" to detect the headset
                    </div>
                    <div className="text-sm text-gray-600">
                      4. Follow pairing instructions on the headset display
                    </div>
                    <Button className="w-full mt-4">
                      Start Neural Setup
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Heart className="h-5 w-5" />
                      Health Monitor Setup
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-sm text-gray-600">
                      1. Wear your health monitor watch
                    </div>
                    <div className="text-sm text-gray-600">
                      2. Open the companion app on your phone
                    </div>
                    <div className="text-sm text-gray-600">
                      3. Grant health data sharing permissions
                    </div>
                    <div className="text-sm text-gray-600">
                      4. Sync with our platform for real-time monitoring
                    </div>
                    <Button className="w-full mt-4">
                      Setup Health Monitor
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}