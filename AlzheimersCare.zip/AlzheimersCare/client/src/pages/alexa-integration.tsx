import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Volume2, 
  Mic, 
  Settings, 
  CheckCircle, 
  AlertCircle,
  ArrowLeft,
  Zap,
  Shield,
  Heart,
  Brain,
  Smartphone,
  Wifi,
  Speaker
} from 'lucide-react';
import { Link } from 'wouter';

export default function AlexaIntegration() {
  const [setupStep, setSetupStep] = useState(1);
  const [alexaConnected, setAlexaConnected] = useState(false);
  const [skillEnabled, setSkillEnabled] = useState(false);
  const [activeTab, setActiveTab] = useState('setup');

  const setupSteps = [
    {
      title: "Download Amazon Alexa App",
      description: "Install the Alexa app on your smartphone or tablet",
      action: "Download from App Store or Google Play",
      completed: setupStep > 1
    },
    {
      title: "Enable Care Companion Skill",
      description: "Search for and enable the Care Companion skill in the Alexa app",
      action: "Search 'Care Companion' in Skills & Games",
      completed: setupStep > 2
    },
    {
      title: "Link Your Account",
      description: "Connect your Care Companion account to Alexa",
      action: "Use your login credentials to link accounts",
      completed: setupStep > 3
    },
    {
      title: "Test Voice Commands",
      description: "Try basic commands to ensure everything works",
      action: "Say 'Alexa, ask Care Companion how I'm doing'",
      completed: setupStep > 4
    }
  ];

  const voiceCommands = [
    {
      category: "Health Monitoring",
      commands: [
        "Alexa, ask Care Companion how I'm feeling today",
        "Alexa, tell Care Companion my blood pressure is 120 over 80",
        "Alexa, ask Care Companion about my medications",
        "Alexa, tell Care Companion I took my morning pills"
      ]
    },
    {
      category: "Memory & Cognitive Training",
      commands: [
        "Alexa, ask Care Companion to start a memory game",
        "Alexa, tell Care Companion to show me family photos",
        "Alexa, ask Care Companion to tell me a story from my past",
        "Alexa, start a brain training session with Care Companion"
      ]
    },
    {
      category: "Family Communication",
      commands: [
        "Alexa, ask Care Companion to call my daughter",
        "Alexa, tell Care Companion to send a message to my family",
        "Alexa, ask Care Companion if I have any messages",
        "Alexa, record a voice message with Care Companion"
      ]
    },
    {
      category: "Emergency & Safety",
      commands: [
        "Alexa, tell Care Companion I need help",
        "Alexa, ask Care Companion to call for emergency assistance",
        "Alexa, tell Care Companion I fell down",
        "Alexa, ask Care Companion to contact my emergency contacts"
      ]
    }
  ];

  const benefits = [
    {
      icon: <Volume2 className="h-6 w-6 text-blue-500" />,
      title: "Hands-Free Operation",
      description: "No need to touch buttons or screens - just speak naturally"
    },
    {
      icon: <Speaker className="h-6 w-6 text-green-500" />,
      title: "Crystal Clear Audio",
      description: "Professional-grade speakers and microphones built into Alexa devices"
    },
    {
      icon: <Wifi className="h-6 w-6 text-purple-500" />,
      title: "Always Connected",
      description: "24/7 connection to Care Companion AI through your home Wi-Fi"
    },
    {
      icon: <Settings className="h-6 w-6 text-orange-500" />,
      title: "Easy Setup",
      description: "Simple voice-guided setup process that takes just minutes"
    }
  ];

  const nextStep = () => {
    if (setupStep < 4) {
      setSetupStep(setupStep + 1);
    } else {
      setAlexaConnected(true);
      setSkillEnabled(true);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="max-w-6xl mx-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="outline" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Alexa Integration</h1>
              <p className="text-gray-600 mt-1">Replace headphones and microphone with Amazon Alexa</p>
            </div>
          </div>
          <Badge className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <Speaker className="h-4 w-4 mr-2" />
            Voice-First Platform
          </Badge>
        </div>

        {/* Status Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="border-blue-200">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Alexa Connection</p>
                <p className={`font-semibold ${alexaConnected ? 'text-green-600' : 'text-gray-400'}`}>
                  {alexaConnected ? 'Connected' : 'Not Connected'}
                </p>
              </div>
              {alexaConnected ? (
                <CheckCircle className="h-8 w-8 text-green-500" />
              ) : (
                <AlertCircle className="h-8 w-8 text-gray-400" />
              )}
            </CardContent>
          </Card>

          <Card className="border-green-200">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Care Companion Skill</p>
                <p className={`font-semibold ${skillEnabled ? 'text-green-600' : 'text-gray-400'}`}>
                  {skillEnabled ? 'Enabled' : 'Not Enabled'}
                </p>
              </div>
              {skillEnabled ? (
                <CheckCircle className="h-8 w-8 text-green-500" />
              ) : (
                <AlertCircle className="h-8 w-8 text-gray-400" />
              )}
            </CardContent>
          </Card>

          <Card className="border-purple-200">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Voice Commands</p>
                <p className="font-semibold text-purple-600">40+ Available</p>
              </div>
              <Volume2 className="h-8 w-8 text-purple-500" />
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="setup">Setup Guide</TabsTrigger>
            <TabsTrigger value="commands">Voice Commands</TabsTrigger>
            <TabsTrigger value="benefits">Benefits</TabsTrigger>
            <TabsTrigger value="troubleshooting">Support</TabsTrigger>
          </TabsList>

          <TabsContent value="setup" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Alexa Setup for Care Companion</CardTitle>
                <p className="text-gray-600">Follow these steps to connect your Alexa device</p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  {setupSteps.map((step, index) => (
                    <div
                      key={index}
                      className={`border rounded-lg p-4 ${
                        step.completed ? 'bg-green-50 border-green-200' : 
                        setupStep === index + 1 ? 'bg-blue-50 border-blue-200' : 
                        'bg-gray-50 border-gray-200'
                      }`}
                    >
                      <div className="flex items-start gap-4">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          step.completed ? 'bg-green-500' :
                          setupStep === index + 1 ? 'bg-blue-500' :
                          'bg-gray-300'
                        }`}>
                          {step.completed ? (
                            <CheckCircle className="h-5 w-5 text-white" />
                          ) : (
                            <span className="text-white font-semibold">{index + 1}</span>
                          )}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900 mb-1">{step.title}</h3>
                          <p className="text-gray-600 mb-2">{step.description}</p>
                          <p className="text-sm font-medium text-blue-600">{step.action}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex justify-between items-center">
                  <div className="flex-1">
                    <Progress value={(setupStep / 4) * 100} className="h-2" />
                    <p className="text-sm text-gray-600 mt-2">Step {setupStep} of 4</p>
                  </div>
                  <Button onClick={nextStep} className="ml-4">
                    {setupStep < 4 ? 'Next Step' : 'Complete Setup'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="commands" className="space-y-6">
            <div className="space-y-6">
              {voiceCommands.map((category, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Mic className="h-5 w-5 text-blue-500" />
                      {category.category}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {category.commands.map((command, cmdIndex) => (
                        <div
                          key={cmdIndex}
                          className="bg-gray-50 rounded-lg p-3 border border-gray-200"
                        >
                          <code className="text-sm text-gray-800">{command}</code>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="benefits" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {benefits.map((benefit, index) => (
                <Card key={index} className="border-gray-200">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="p-3 bg-gray-100 rounded-lg">
                        {benefit.icon}
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-2">{benefit.title}</h3>
                        <p className="text-gray-600">{benefit.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
              <CardContent className="p-6">
                <div className="flex items-center gap-4 mb-4">
                  <Heart className="h-8 w-8 text-red-500" />
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">Perfect for Seniors</h3>
                    <p className="text-gray-600">Designed with elderly users in mind</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <Volume2 className="h-6 w-6 text-blue-600" />
                    </div>
                    <p className="font-semibold text-gray-900">Large Buttons</p>
                    <p className="text-sm text-gray-600">Voice control eliminates small buttons</p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <Brain className="h-6 w-6 text-green-600" />
                    </div>
                    <p className="font-semibold text-gray-900">Memory-Friendly</p>
                    <p className="text-sm text-gray-600">Simple voice commands are easy to remember</p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <Shield className="h-6 w-6 text-purple-600" />
                    </div>
                    <p className="font-semibold text-gray-900">Always Available</p>
                    <p className="text-sm text-gray-600">24/7 access to help and support</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="troubleshooting" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Common Issues & Solutions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-lg text-gray-900 mb-2">Alexa doesn't respond to Care Companion commands</h3>
                    <ul className="space-y-1 text-gray-700">
                      <li>• Make sure the Care Companion skill is enabled</li>
                      <li>• Check your internet connection</li>
                      <li>• Try saying "Alexa, rediscover my devices"</li>
                      <li>• Restart your Alexa device</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-lg text-gray-900 mb-2">Voice commands not recognized properly</h3>
                    <ul className="space-y-1 text-gray-700">
                      <li>• Speak clearly and at normal pace</li>
                      <li>• Reduce background noise in the room</li>
                      <li>• Move closer to the Alexa device</li>
                      <li>• Try rephrasing your command</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-lg text-gray-900 mb-2">Account linking issues</h3>
                    <ul className="space-y-1 text-gray-700">
                      <li>• Disable and re-enable the Care Companion skill</li>
                      <li>• Check your Care Companion account credentials</li>
                      <li>• Clear the Alexa app cache and restart</li>
                      <li>• Contact our support team for assistance</li>
                    </ul>
                  </div>
                </div>

                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    For additional support, contact our Care Companion team at support@carecompanion.com or 
                    call 1-800-CARE-AI1 (1-800-227-3241).
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}