import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Video, Phone, MessageSquare, Heart, Brain, Eye, Stethoscope, Activity, Calendar, Clock, Users, Shield } from 'lucide-react';

export default function AITelemedicine() {
  const [activeSession, setActiveSession] = useState<string | null>(null);
  const [vitalSigns, setVitalSigns] = useState({
    heartRate: 72,
    bloodPressure: "120/80",
    oxygenSat: 98,
    temperature: 98.6,
    respiratoryRate: 16
  });

  const doctorProfiles = [
    {
      id: 1,
      name: "Dr. Sarah Chen",
      specialty: "Neurologist",
      availability: "Available Now",
      rating: 4.9,
      experience: "15 years",
      languages: ["English", "Mandarin"],
      expertise: ["Alzheimer's Care", "Cognitive Assessment", "Memory Disorders"]
    },
    {
      id: 2,
      name: "Dr. Michael Rodriguez",
      specialty: "Geriatrician",
      availability: "Available in 15 min",
      rating: 4.8,
      experience: "12 years",
      languages: ["English", "Spanish"],
      expertise: ["Senior Care", "Medication Management", "Chronic Conditions"]
    },
    {
      id: 3,
      name: "Dr. Emily Johnson",
      specialty: "Psychiatrist",
      availability: "Next Available: 2:30 PM",
      rating: 4.9,
      experience: "18 years",
      languages: ["English", "French"],
      expertise: ["Dementia Care", "Behavioral Health", "Family Support"]
    }
  ];

  const upcomingAppointments = [
    {
      id: 1,
      doctor: "Dr. Sarah Chen",
      date: "Today",
      time: "2:00 PM",
      type: "Cognitive Assessment",
      priority: "High"
    },
    {
      id: 2,
      doctor: "Dr. Michael Rodriguez",
      date: "Tomorrow",
      time: "10:30 AM",
      type: "Medication Review",
      priority: "Medium"
    },
    {
      id: 3,
      doctor: "Dr. Emily Johnson",
      date: "Friday",
      time: "3:15 PM",
      type: "Family Consultation",
      priority: "Medium"
    }
  ];

  const aiInsights = [
    {
      category: "Vital Signs",
      status: "Normal",
      confidence: 94,
      details: "All vital signs within healthy range for age group"
    },
    {
      category: "Cognitive Patterns",
      status: "Slight Decline",
      confidence: 87,
      details: "Memory recall showing 12% decrease from baseline - recommend consultation"
    },
    {
      category: "Medication Adherence",
      status: "Good",
      confidence: 91,
      details: "98% adherence rate maintained over past 30 days"
    },
    {
      category: "Activity Levels",
      status: "Below Target",
      confidence: 89,
      details: "Physical activity 23% below recommended levels"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            AI-Powered Telemedicine Center
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            Advanced remote healthcare with AI-assisted diagnostics and real-time monitoring
          </p>
        </div>

        {/* Emergency Quick Access */}
        <Card className="mb-8 border-red-200 bg-red-50 dark:bg-red-900/10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-700 dark:text-red-400">
              <Heart className="h-6 w-6" />
              Emergency Medical Access
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4">
              <Button variant="destructive" size="lg" className="flex items-center gap-2">
                <Phone className="h-5 w-5" />
                Call 911
              </Button>
              <Button variant="outline" size="lg" className="flex items-center gap-2 border-red-300">
                <Video className="h-5 w-5" />
                Emergency Video Call
              </Button>
              <Button variant="outline" size="lg" className="flex items-center gap-2 border-red-300">
                <MessageSquare className="h-5 w-5" />
                Crisis Text Line
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Real-time Vitals */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Real-time Vitals
              </CardTitle>
              <CardDescription>AI-monitored health indicators</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <Heart className="h-6 w-6 mx-auto mb-2 text-green-600" />
                  <div className="text-2xl font-bold text-green-700 dark:text-green-400">
                    {vitalSigns.heartRate}
                  </div>
                  <div className="text-sm text-green-600">BPM</div>
                </div>
                <div className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <Stethoscope className="h-6 w-6 mx-auto mb-2 text-blue-600" />
                  <div className="text-2xl font-bold text-blue-700 dark:text-blue-400">
                    {vitalSigns.bloodPressure}
                  </div>
                  <div className="text-sm text-blue-600">mmHg</div>
                </div>
                <div className="text-center p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                  <Eye className="h-6 w-6 mx-auto mb-2 text-purple-600" />
                  <div className="text-2xl font-bold text-purple-700 dark:text-purple-400">
                    {vitalSigns.oxygenSat}%
                  </div>
                  <div className="text-sm text-purple-600">O2 Sat</div>
                </div>
                <div className="text-center p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                  <Brain className="h-6 w-6 mx-auto mb-2 text-orange-600" />
                  <div className="text-2xl font-bold text-orange-700 dark:text-orange-400">
                    {vitalSigns.temperature}°F
                  </div>
                  <div className="text-sm text-orange-600">Temp</div>
                </div>
              </div>
              <Button className="w-full" variant="outline">
                View Detailed Analytics
              </Button>
            </CardContent>
          </Card>

          {/* AI Health Insights */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                AI Health Insights
              </CardTitle>
              <CardDescription>Machine learning health analysis</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {aiInsights.map((insight, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">{insight.category}</span>
                    <Badge variant={insight.status === 'Normal' ? 'default' : 
                                   insight.status === 'Good' ? 'secondary' : 'destructive'}>
                      {insight.status}
                    </Badge>
                  </div>
                  <Progress value={insight.confidence} className="h-2" />
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {insight.details}
                  </p>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Upcoming Appointments */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Upcoming Appointments
              </CardTitle>
              <CardDescription>Scheduled consultations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {upcomingAppointments.map((appointment) => (
                <div key={appointment.id} className="p-3 border rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="font-medium">{appointment.doctor}</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {appointment.type}
                      </div>
                    </div>
                    <Badge variant={appointment.priority === 'High' ? 'destructive' : 'secondary'}>
                      {appointment.priority}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                    <Clock className="h-4 w-4" />
                    {appointment.date} at {appointment.time}
                  </div>
                </div>
              ))}
              <Button className="w-full" variant="outline">
                Schedule New Appointment
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Available Doctors */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Available Specialists
            </CardTitle>
            <CardDescription>Connect with healthcare professionals specialized in cognitive care</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {doctorProfiles.map((doctor) => (
                <Card key={doctor.id} className="border-l-4 border-l-blue-500">
                  <CardHeader className="pb-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{doctor.name}</CardTitle>
                        <CardDescription>{doctor.specialty}</CardDescription>
                      </div>
                      <Badge variant={doctor.availability.includes('Available Now') ? 'default' : 'secondary'}>
                        {doctor.availability.includes('Available Now') ? 'Online' : 'Busy'}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">Rating</span>
                        <span className="font-medium">⭐ {doctor.rating}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">Experience</span>
                        <span className="font-medium">{doctor.experience}</span>
                      </div>
                    </div>
                    
                    <div>
                      <div className="text-sm text-gray-600 dark:text-gray-400 mb-2">Expertise:</div>
                      <div className="flex flex-wrap gap-1">
                        {doctor.expertise.map((skill, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <div className="text-sm text-gray-600 dark:text-gray-400 mb-2">Languages:</div>
                      <div className="text-sm">{doctor.languages.join(', ')}</div>
                    </div>

                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        className="flex-1 flex items-center gap-2"
                        disabled={!doctor.availability.includes('Available Now')}
                        onClick={() => setActiveSession(doctor.name)}
                      >
                        <Video className="h-4 w-4" />
                        Video Call
                      </Button>
                      <Button size="sm" variant="outline" className="flex items-center gap-2">
                        <MessageSquare className="h-4 w-4" />
                        Message
                      </Button>
                    </div>
                    
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      {doctor.availability}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Active Session Modal */}
        {activeSession && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <Card className="w-full max-w-4xl">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Video className="h-5 w-5" />
                    Video Session with {activeSession}
                  </span>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setActiveSession(null)}
                  >
                    End Session
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="aspect-video bg-gray-900 rounded-lg flex items-center justify-center mb-4">
                  <div className="text-white text-center">
                    <Video className="h-16 w-16 mx-auto mb-4 opacity-50" />
                    <p>Video session would be active here</p>
                    <p className="text-sm opacity-75">Secure, encrypted connection established</p>
                  </div>
                </div>
                <div className="flex justify-center gap-4">
                  <Button variant="outline" size="sm">
                    <Phone className="h-4 w-4 mr-2" />
                    Mute
                  </Button>
                  <Button variant="outline" size="sm">
                    <Video className="h-4 w-4 mr-2" />
                    Camera
                  </Button>
                  <Button variant="outline" size="sm">
                    <Shield className="h-4 w-4 mr-2" />
                    Share Screen
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}