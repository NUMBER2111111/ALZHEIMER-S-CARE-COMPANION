import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { MapPin, Search, Plus, Battery, Signal, Clock, AlertTriangle, CheckCircle } from 'lucide-react';

interface LostItem {
  id: number;
  patientId: number;
  itemName: string;
  itemType: string;
  itemDescription?: string;
  airtagId?: string;
  isAirtagConnected: boolean;
  lastKnownLocation?: {
    lat: number;
    lng: number;
    address?: string;
    timestamp?: string;
  };
  currentLocation?: {
    lat: number;
    lng: number;
    address?: string;
    timestamp?: string;
  };
  itemStatus: 'active' | 'lost' | 'found' | 'inactive';
  lostDate?: string;
  foundDate?: string;
  searchRadius: number;
  notificationEnabled: boolean;
  familyNotified: boolean;
  itemImage?: string;
  itemValue?: number;
  priority: 'low' | 'medium' | 'high' | 'critical';
  createdAt: string;
  updatedAt: string;
}

interface ItemLocationHistory {
  id: number;
  itemId: number;
  location: {
    lat: number;
    lng: number;
    address?: string;
    accuracy?: number;
  };
  batteryLevel?: number;
  signalStrength?: number;
  detectedBy: string;
  movementSpeed?: number;
  isStationary: boolean;
  recordedAt: string;
}

interface SearchAnalytics {
  totalSearches: number;
  successfulSearches: number;
  averageSearchTime: number;
  topLostItems: string[];
}

const ITEM_TYPES = [
  'keys', 'wallet', 'phone', 'medication', 'glasses', 'jewelry', 'clothing', 'documents', 'other'
];

const PRIORITY_COLORS = {
  low: 'bg-gray-100 text-gray-800',
  medium: 'bg-blue-100 text-blue-800',
  high: 'bg-orange-100 text-orange-800',
  critical: 'bg-red-100 text-red-800',
};

const STATUS_COLORS = {
  active: 'bg-green-100 text-green-800',
  lost: 'bg-red-100 text-red-800',
  found: 'bg-blue-100 text-blue-800',
  inactive: 'bg-gray-100 text-gray-800',
};

export default function AirTagMapping() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedPatientId] = useState(1); // Default patient ID
  const [showAddItem, setShowAddItem] = useState(false);
  const [selectedItem, setSelectedItem] = useState<LostItem | null>(null);
  const [showLocationHistory, setShowLocationHistory] = useState(false);

  // Form states
  const [newItem, setNewItem] = useState({
    itemName: '',
    itemType: '',
    itemDescription: '',
    airtagId: '',
    searchRadius: 100,
    priority: 'medium' as const,
    itemValue: 0,
  });

  // Fetch patient items
  const { data: itemsData, isLoading: itemsLoading } = useQuery({
    queryKey: [`/api/patients/${selectedPatientId}/items`],
    enabled: !!selectedPatientId,
  });

  // Fetch lost items
  const { data: lostItemsData, isLoading: lostItemsLoading } = useQuery({
    queryKey: [`/api/patients/${selectedPatientId}/lost-items`],
    enabled: !!selectedPatientId,
  });

  // Fetch search analytics
  const { data: analyticsData } = useQuery({
    queryKey: [`/api/patients/${selectedPatientId}/search-analytics`],
    enabled: !!selectedPatientId,
  });

  // Fetch location history for selected item
  const { data: locationHistoryData } = useQuery({
    queryKey: [`/api/items/${selectedItem?.id}/location-history`],
    enabled: !!selectedItem && showLocationHistory,
  });

  // Register new item mutation
  const registerItemMutation = useMutation({
    mutationFn: async (itemData: any) => {
      return apiRequest('POST', '/api/items/register', {
        ...itemData,
        patientId: selectedPatientId,
      });
    },
    onSuccess: () => {
      toast({
        title: "Item Registered",
        description: "Item has been successfully registered for tracking.",
      });
      setShowAddItem(false);
      setNewItem({
        itemName: '',
        itemType: '',
        itemDescription: '',
        airtagId: '',
        searchRadius: 100,
        priority: 'medium',
        itemValue: 0,
      });
      queryClient.invalidateQueries({ queryKey: [`/api/patients/${selectedPatientId}/items`] });
    },
    onError: (error: any) => {
      toast({
        title: "Registration Failed",
        description: error.message || "Failed to register item",
        variant: "destructive",
      });
    },
  });

  // Mark item as lost mutation
  const markLostMutation = useMutation({
    mutationFn: async ({ itemId, lastKnownLocation }: { itemId: number; lastKnownLocation?: any }) => {
      return apiRequest('PATCH', `/api/items/${itemId}/mark-lost`, { lastKnownLocation });
    },
    onSuccess: () => {
      toast({
        title: "Item Marked as Lost",
        description: "Search has been initiated and family will be notified.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/patients/${selectedPatientId}/items`] });
      queryClient.invalidateQueries({ queryKey: [`/api/patients/${selectedPatientId}/lost-items`] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Mark as Lost",
        description: error.message || "Failed to update item status",
        variant: "destructive",
      });
    },
  });

  // Mark item as found mutation
  const markFoundMutation = useMutation({
    mutationFn: async ({ itemId, foundLocation }: { itemId: number; foundLocation: any }) => {
      return apiRequest('PATCH', `/api/items/${itemId}/mark-found`, { foundLocation });
    },
    onSuccess: () => {
      toast({
        title: "Item Found!",
        description: "Item has been marked as found and search completed.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/patients/${selectedPatientId}/items`] });
      queryClient.invalidateQueries({ queryKey: [`/api/patients/${selectedPatientId}/lost-items`] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Mark as Found",
        description: error.message || "Failed to update item status",
        variant: "destructive",
      });
    },
  });

  // Initiate search mutation
  const initiateSearchMutation = useMutation({
    mutationFn: async ({ itemId, options }: { itemId: number; options: any }) => {
      return apiRequest('POST', `/api/items/${itemId}/search`, {
        searchedBy: 1, // Current user ID
        options: {
          notifyFamily: true,
          searchType: 'manual',
          ...options,
        },
      });
    },
    onSuccess: () => {
      toast({
        title: "Search Initiated",
        description: "Family members have been notified and search is active.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Search Failed",
        description: error.message || "Failed to initiate search",
        variant: "destructive",
      });
    },
  });

  const items = itemsData?.items || [];
  const lostItems = lostItemsData?.lostItems || [];
  const analytics = analyticsData?.analytics as SearchAnalytics;
  const locationHistory = locationHistoryData?.history || [];

  const handleRegisterItem = () => {
    if (!newItem.itemName.trim() || !newItem.itemType) {
      toast({
        title: "Missing Information",
        description: "Please provide item name and type.",
        variant: "destructive",
      });
      return;
    }

    registerItemMutation.mutate(newItem);
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'critical':
        return <AlertTriangle className="h-4 w-4 text-red-600" />;
      case 'high':
        return <AlertTriangle className="h-4 w-4 text-orange-600" />;
      default:
        return <Clock className="h-4 w-4 text-gray-600" />;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'lost':
        return <Search className="h-4 w-4 text-red-600" />;
      case 'found':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'active':
        return <MapPin className="h-4 w-4 text-blue-600" />;
      default:
        return <Clock className="h-4 w-4 text-gray-600" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-green-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-gray-900">AirTag Item Mapping</h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Advanced item tracking system with Apple AirTag integration for comprehensive location monitoring and lost item recovery.
          </p>
        </div>

        {/* Analytics Overview */}
        {analytics && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Search className="h-5 w-5 text-blue-600" />
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Searches</p>
                    <p className="text-2xl font-bold text-gray-900">{analytics.totalSearches}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <div>
                    <p className="text-sm font-medium text-gray-600">Success Rate</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {analytics.totalSearches > 0 
                        ? Math.round((analytics.successfulSearches / analytics.totalSearches) * 100)
                        : 0}%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Clock className="h-5 w-5 text-orange-600" />
                  <div>
                    <p className="text-sm font-medium text-gray-600">Avg Search Time</p>
                    <p className="text-2xl font-bold text-gray-900">{analytics.averageSearchTime}m</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <MapPin className="h-5 w-5 text-purple-600" />
                  <div>
                    <p className="text-sm font-medium text-gray-600">Items Tracked</p>
                    <p className="text-2xl font-bold text-gray-900">{items.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        <Tabs defaultValue="all-items" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="all-items">All Items</TabsTrigger>
            <TabsTrigger value="lost-items">Lost Items</TabsTrigger>
            <TabsTrigger value="add-item">Add New Item</TabsTrigger>
          </TabsList>

          {/* All Items Tab */}
          <TabsContent value="all-items" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900">All Tracked Items</h2>
              <Button 
                onClick={() => setShowAddItem(true)}
                className="bg-teal-600 hover:bg-teal-700"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Item
              </Button>
            </div>

            {itemsLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin w-8 h-8 border-4 border-teal-600 border-t-transparent rounded-full mx-auto" />
                <p className="mt-2 text-gray-600">Loading items...</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {items.map((item: LostItem) => (
                  <Card key={item.id} className="cursor-pointer hover:shadow-md transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{item.itemName}</CardTitle>
                        <div className="flex space-x-1">
                          {getPriorityIcon(item.priority)}
                          {getStatusIcon(item.itemStatus)}
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Badge className={STATUS_COLORS[item.itemStatus]}>
                          {item.itemStatus}
                        </Badge>
                        <Badge className={PRIORITY_COLORS[item.priority]}>
                          {item.priority}
                        </Badge>
                        {item.isAirtagConnected && (
                          <Badge variant="outline" className="text-blue-600">
                            AirTag Connected
                          </Badge>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="text-sm text-gray-600">
                        <p><strong>Type:</strong> {item.itemType}</p>
                        {item.itemDescription && (
                          <p><strong>Description:</strong> {item.itemDescription}</p>
                        )}
                        {item.airtagId && (
                          <p><strong>AirTag ID:</strong> {item.airtagId}</p>
                        )}
                      </div>

                      {item.currentLocation && (
                        <div className="text-sm text-gray-600">
                          <p className="flex items-center">
                            <MapPin className="h-3 w-3 mr-1" />
                            Last seen: {item.currentLocation.address || 
                              `${item.currentLocation.lat.toFixed(4)}, ${item.currentLocation.lng.toFixed(4)}`}
                          </p>
                        </div>
                      )}

                      <div className="flex space-x-2">
                        {item.itemStatus === 'active' && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => markLostMutation.mutate({ 
                              itemId: item.id, 
                              lastKnownLocation: item.currentLocation 
                            })}
                            className="flex-1"
                          >
                            Mark as Lost
                          </Button>
                        )}
                        {item.itemStatus === 'lost' && (
                          <>
                            <Button
                              size="sm"
                              onClick={() => initiateSearchMutation.mutate({ 
                                itemId: item.id, 
                                options: { radius: item.searchRadius } 
                              })}
                              className="flex-1 bg-orange-600 hover:bg-orange-700"
                            >
                              Start Search
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => markFoundMutation.mutate({ 
                                itemId: item.id, 
                                foundLocation: item.currentLocation || { lat: 0, lng: 0 }
                              })}
                              className="flex-1"
                            >
                              Mark Found
                            </Button>
                          </>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            setSelectedItem(item);
                            setShowLocationHistory(true);
                          }}
                        >
                          History
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Lost Items Tab */}
          <TabsContent value="lost-items" className="space-y-4">
            <h2 className="text-2xl font-bold text-red-600">Currently Lost Items</h2>

            {lostItemsLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin w-8 h-8 border-4 border-red-600 border-t-transparent rounded-full mx-auto" />
                <p className="mt-2 text-gray-600">Loading lost items...</p>
              </div>
            ) : lostItems.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8">
                  <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-4" />
                  <p className="text-lg font-medium text-gray-900">No Lost Items</p>
                  <p className="text-gray-600">All items are currently accounted for.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {lostItems.map((item: LostItem) => (
                  <Card key={item.id} className="border-red-200">
                    <CardHeader className="pb-3">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg text-red-600">{item.itemName}</CardTitle>
                        <Badge className="bg-red-100 text-red-800">LOST</Badge>
                      </div>
                      {item.lostDate && (
                        <p className="text-sm text-gray-600">
                          Lost: {new Date(item.lostDate).toLocaleDateString()}
                        </p>
                      )}
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {item.lastKnownLocation && (
                        <div className="text-sm text-gray-600">
                          <p className="flex items-center">
                            <MapPin className="h-3 w-3 mr-1" />
                            Last known: {item.lastKnownLocation.address || 
                              `${item.lastKnownLocation.lat.toFixed(4)}, ${item.lastKnownLocation.lng.toFixed(4)}`}
                          </p>
                        </div>
                      )}

                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          onClick={() => initiateSearchMutation.mutate({ 
                            itemId: item.id, 
                            options: { radius: item.searchRadius, priority: item.priority } 
                          })}
                          className="flex-1 bg-orange-600 hover:bg-orange-700"
                        >
                          <Search className="h-3 w-3 mr-1" />
                          Search Now
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => markFoundMutation.mutate({ 
                            itemId: item.id, 
                            foundLocation: { lat: 0, lng: 0 } // Would use actual location
                          })}
                          className="flex-1"
                        >
                          Mark Found
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Add Item Tab */}
          <TabsContent value="add-item" className="space-y-4">
            <Card className="max-w-2xl mx-auto">
              <CardHeader>
                <CardTitle>Register New Item for Tracking</CardTitle>
                <p className="text-gray-600">Add an item to the tracking system with optional AirTag integration.</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="itemName">Item Name *</Label>
                    <Input
                      id="itemName"
                      value={newItem.itemName}
                      onChange={(e) => setNewItem({...newItem, itemName: e.target.value})}
                      placeholder="e.g., House Keys"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="itemType">Item Type *</Label>
                    <Select 
                      value={newItem.itemType} 
                      onValueChange={(value) => setNewItem({...newItem, itemType: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        {ITEM_TYPES.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type.charAt(0).toUpperCase() + type.slice(1)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Input
                    id="description"
                    value={newItem.itemDescription}
                    onChange={(e) => setNewItem({...newItem, itemDescription: e.target.value})}
                    placeholder="Additional details about the item"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="airtagId">AirTag ID (Optional)</Label>
                    <Input
                      id="airtagId"
                      value={newItem.airtagId}
                      onChange={(e) => setNewItem({...newItem, airtagId: e.target.value})}
                      placeholder="e.g., AT-123456"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="priority">Priority Level</Label>
                    <Select 
                      value={newItem.priority} 
                      onValueChange={(value: any) => setNewItem({...newItem, priority: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="searchRadius">Search Radius (meters)</Label>
                    <Input
                      id="searchRadius"
                      type="number"
                      value={newItem.searchRadius}
                      onChange={(e) => setNewItem({...newItem, searchRadius: parseInt(e.target.value) || 100})}
                      min="50"
                      max="5000"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="itemValue">Estimated Value ($)</Label>
                    <Input
                      id="itemValue"
                      type="number"
                      value={newItem.itemValue}
                      onChange={(e) => setNewItem({...newItem, itemValue: parseInt(e.target.value) || 0})}
                      min="0"
                    />
                  </div>
                </div>

                <Button 
                  onClick={handleRegisterItem}
                  disabled={registerItemMutation.isPending}
                  className="w-full bg-teal-600 hover:bg-teal-700"
                >
                  {registerItemMutation.isPending ? 'Registering...' : 'Register Item'}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Location History Dialog */}
        <Dialog open={showLocationHistory} onOpenChange={setShowLocationHistory}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>Location History: {selectedItem?.itemName}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              {locationHistory.length === 0 ? (
                <p className="text-center text-gray-600 py-8">No location history available</p>
              ) : (
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {locationHistory.map((record: ItemLocationHistory) => (
                    <div key={record.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <MapPin className="h-4 w-4 text-blue-600" />
                        <div>
                          <p className="font-medium">
                            {record.location.address || 
                              `${record.location.lat.toFixed(4)}, ${record.location.lng.toFixed(4)}`}
                          </p>
                          <p className="text-sm text-gray-600">
                            {new Date(record.recordedAt).toLocaleString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        {record.batteryLevel && (
                          <div className="flex items-center space-x-1">
                            <Battery className="h-3 w-3" />
                            <span>{record.batteryLevel}%</span>
                          </div>
                        )}
                        {record.signalStrength && (
                          <div className="flex items-center space-x-1">
                            <Signal className="h-3 w-3" />
                            <span>{record.signalStrength}%</span>
                          </div>
                        )}
                        <Badge variant="outline">{record.detectedBy}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}