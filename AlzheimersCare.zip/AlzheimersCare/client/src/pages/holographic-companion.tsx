import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, Volume2, Eye, Hand, Zap, Brain, Camera, Mic, Settings } from 'lucide-react';

interface HologramSettings {
  opacity: number;
  brightness: number;
  spatialAudio: boolean;
  gestureRecognition: boolean;
  emotionalResponse: boolean;
  familyMemberMode: 'live' | 'memory' | 'ai-generated';
}

interface FamilyMember {
  id: number;
  name: string;
  relationship: string;
  lastVisit: string;
  hologramAvailable: boolean;
  voiceCloned: boolean;
  personalityMapped: boolean;
}

export default function HolographicCompanion() {
  const [isHologramActive, setIsHologramActive] = useState(false);
  const [currentFamily, setCurrentFamily] = useState<FamilyMember | null>(null);
  const [hologramSettings, setHologramSettings] = useState<HologramSettings>({
    opacity: 85,
    brightness: 70,
    spatialAudio: true,
    gestureRecognition: true,
    emotionalResponse: true,
    familyMemberMode: 'memory'
  });
  const [isCalibrating, setIsCalibrating] = useState(false);
  const hologramRef = useRef<HTMLDivElement>(null);

  const familyMembers: FamilyMember[] = [
    {
      id: 1,
      name: "Sarah Williams",
      relationship: "Daughter",
      lastVisit: "2 days ago",
      hologramAvailable: true,
      voiceCloned: true,
      personalityMapped: true
    },
    {
      id: 2,
      name: "Michael Williams",
      relationship: "Son",
      lastVisit: "1 week ago",
      hologramAvailable: true,
      voiceCloned: true,
      personalityMapped: false
    },
    {
      id: 3,
      name: "Emma Williams",
      relationship: "Granddaughter",
      lastVisit: "3 days ago",
      hologramAvailable: false,
      voiceCloned: false,
      personalityMapped: false
    }
  ];

  const activateHologram = async (member: FamilyMember) => {
    setIsCalibrating(true);
    setCurrentFamily(member);
    
    // Simulate hologram initialization
    setTimeout(() => {
      setIsHologramActive(true);
      setIsCalibrating(false);
    }, 3000);
  };

  const deactivateHologram = () => {
    setIsHologramActive(false);
    setCurrentFamily(null);
  };

  useEffect(() => {
    // Simulate spatial audio positioning
    if (isHologramActive && hologramSettings.spatialAudio) {
      // In production, this would control actual spatial audio hardware
      console.log('Spatial audio activated with directional positioning');
    }
  }, [isHologramActive, hologramSettings.spatialAudio]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center">
              <Eye className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900">Holographic Companion</h1>
          </div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Revolutionary 3D holographic projection technology bringing family members 
            directly into the patient's room with spatial audio and gesture recognition.
          </p>
        </div>

        {/* Hologram Display Area */}
        <Card className="bg-black border-2 border-purple-400 shadow-2xl overflow-hidden">
          <CardContent className="p-0 relative h-96">
            <div 
              ref={hologramRef}
              className="w-full h-full bg-gradient-to-br from-purple-900/20 to-blue-900/20 flex items-center justify-center relative overflow-hidden"
            >
              {isCalibrating && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center text-white">
                    <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-purple-400 mx-auto mb-4"></div>
                    <p className="text-lg font-medium">Calibrating Holographic Projectors...</p>
                    <p className="text-sm text-purple-200">Scanning room dimensions and lighting</p>
                  </div>
                </div>
              )}
              
              {isHologramActive && currentFamily && !isCalibrating && (
                <div className="relative">
                  {/* Holographic effect simulation */}
                  <div 
                    className="relative animate-pulse"
                    style={{
                      opacity: hologramSettings.opacity / 100,
                      filter: `brightness(${hologramSettings.brightness}%)`
                    }}
                  >
                    <div className="w-64 h-80 bg-gradient-to-b from-blue-400/60 to-purple-600/60 rounded-lg relative">
                      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-pulse"></div>
                      <div className="absolute top-4 left-4 right-4">
                        <div className="text-center text-white">
                          <div className="w-16 h-16 bg-white/30 rounded-full mx-auto mb-2"></div>
                          <h3 className="font-bold text-lg">{currentFamily.name}</h3>
                          <p className="text-sm text-blue-200">{currentFamily.relationship}</p>
                        </div>
                      </div>
                      
                      {/* Holographic scan lines */}
                      <div className="absolute inset-0 opacity-30">
                        {[...Array(20)].map((_, i) => (
                          <div 
                            key={i}
                            className="w-full h-px bg-cyan-400 animate-pulse"
                            style={{
                              top: `${i * 5}%`,
                              animationDelay: `${i * 0.1}s`
                            }}
                          ></div>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  {/* Spatial audio indicators */}
                  {hologramSettings.spatialAudio && (
                    <div className="absolute -inset-8">
                      <div className="absolute top-0 left-1/2 transform -translate-x-1/2">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-ping"></div>
                      </div>
                      <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-ping" style={{animationDelay: '0.5s'}}></div>
                      </div>
                      <div className="absolute left-0 top-1/2 transform -translate-y-1/2">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-ping" style={{animationDelay: '1s'}}></div>
                      </div>
                      <div className="absolute right-0 top-1/2 transform -translate-y-1/2">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-ping" style={{animationDelay: '1.5s'}}></div>
                      </div>
                    </div>
                  )}
                </div>
              )}
              
              {!isHologramActive && !isCalibrating && (
                <div className="text-center text-gray-400">
                  <Eye className="h-24 w-24 mx-auto mb-4 opacity-30" />
                  <h3 className="text-xl font-medium mb-2">Holographic Display Ready</h3>
                  <p className="text-sm">Select a family member to begin holographic projection</p>
                </div>
              )}
            </div>
            
            {/* Status indicators */}
            <div className="absolute top-4 right-4 flex gap-2">
              {isHologramActive && (
                <>
                  {hologramSettings.spatialAudio && (
                    <Badge className="bg-green-500/20 text-green-300 border-green-400">
                      <Volume2 className="h-3 w-3 mr-1" />
                      Spatial Audio
                    </Badge>
                  )}
                  {hologramSettings.gestureRecognition && (
                    <Badge className="bg-blue-500/20 text-blue-300 border-blue-400">
                      <Hand className="h-3 w-3 mr-1" />
                      Gesture Tracking
                    </Badge>
                  )}
                </>
              )}
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="family-selection" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-white/70 backdrop-blur-sm">
            <TabsTrigger value="family-selection">Family Selection</TabsTrigger>
            <TabsTrigger value="hologram-settings">Hologram Settings</TabsTrigger>
            <TabsTrigger value="interaction-modes">Interaction Modes</TabsTrigger>
            <TabsTrigger value="technical-specs">Technical Specs</TabsTrigger>
          </TabsList>

          <TabsContent value="family-selection" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {familyMembers.map((member) => (
                <Card key={member.id} className="bg-white/70 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{member.name}</CardTitle>
                        <p className="text-sm text-gray-600">{member.relationship}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-gray-500">Last visit</p>
                        <p className="text-sm font-medium">{member.lastVisit}</p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-sm">
                        <span>Hologram Ready</span>
                        <Badge variant={member.hologramAvailable ? "default" : "secondary"}>
                          {member.hologramAvailable ? "Available" : "Pending"}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span>Voice Cloned</span>
                        <Badge variant={member.voiceCloned ? "default" : "secondary"}>
                          {member.voiceCloned ? "Ready" : "Processing"}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span>Personality Mapped</span>
                        <Badge variant={member.personalityMapped ? "default" : "secondary"}>
                          {member.personalityMapped ? "Complete" : "Learning"}
                        </Badge>
                      </div>
                      
                      <Button 
                        className="w-full mt-4"
                        onClick={() => activateHologram(member)}
                        disabled={!member.hologramAvailable || isHologramActive || isCalibrating}
                      >
                        {currentFamily?.id === member.id && isHologramActive ? (
                          <>
                            <Eye className="mr-2 h-4 w-4" />
                            Active Hologram
                          </>
                        ) : (
                          <>
                            <Zap className="mr-2 h-4 w-4" />
                            Activate Hologram
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            {isHologramActive && (
              <Card className="bg-red-50 border-red-200">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                      <span className="font-medium">Hologram Session Active</span>
                      <Badge variant="outline" className="bg-red-100 text-red-700">
                        {currentFamily?.name}
                      </Badge>
                    </div>
                    <Button variant="outline" onClick={deactivateHologram}>
                      End Session
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="hologram-settings" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Visual Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Opacity: {hologramSettings.opacity}%</label>
                    <Slider
                      value={[hologramSettings.opacity]}
                      onValueChange={(value) => setHologramSettings({...hologramSettings, opacity: value[0]})}
                      max={100}
                      min={20}
                      step={5}
                      className="w-full"
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium mb-2 block">Brightness: {hologramSettings.brightness}%</label>
                    <Slider
                      value={[hologramSettings.brightness]}
                      onValueChange={(value) => setHologramSettings({...hologramSettings, brightness: value[0]})}
                      max={100}
                      min={30}
                      step={5}
                      className="w-full"
                    />
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Spatial Audio</span>
                      <Button
                        variant={hologramSettings.spatialAudio ? "default" : "outline"}
                        size="sm"
                        onClick={() => setHologramSettings({...hologramSettings, spatialAudio: !hologramSettings.spatialAudio})}
                      >
                        {hologramSettings.spatialAudio ? "Enabled" : "Disabled"}
                      </Button>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Gesture Recognition</span>
                      <Button
                        variant={hologramSettings.gestureRecognition ? "default" : "outline"}
                        size="sm"
                        onClick={() => setHologramSettings({...hologramSettings, gestureRecognition: !hologramSettings.gestureRecognition})}
                      >
                        {hologramSettings.gestureRecognition ? "Enabled" : "Disabled"}
                      </Button>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Emotional Response</span>
                      <Button
                        variant={hologramSettings.emotionalResponse ? "default" : "outline"}
                        size="sm"
                        onClick={() => setHologramSettings({...hologramSettings, emotionalResponse: !hologramSettings.emotionalResponse})}
                      >
                        {hologramSettings.emotionalResponse ? "Enabled" : "Disabled"}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5" />
                    AI Enhancement
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Family Member Mode</label>
                    <div className="grid grid-cols-1 gap-2">
                      {(['live', 'memory', 'ai-generated'] as const).map((mode) => (
                        <Button
                          key={mode}
                          variant={hologramSettings.familyMemberMode === mode ? "default" : "outline"}
                          size="sm"
                          onClick={() => setHologramSettings({...hologramSettings, familyMemberMode: mode})}
                          className="justify-start"
                        >
                          {mode === 'live' && 'Live Video Call'}
                          {mode === 'memory' && 'Memory Recreation'}
                          {mode === 'ai-generated' && 'AI Companion'}
                        </Button>
                      ))}
                    </div>
                  </div>
                  
                  <div className="pt-4 border-t">
                    <h4 className="font-medium mb-2">Advanced Features</h4>
                    <div className="space-y-2 text-sm text-gray-600">
                      <div className="flex items-center gap-2">
                        <Camera className="h-4 w-4" />
                        <span>Real-time facial expression mapping</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Mic className="h-4 w-4" />
                        <span>Voice synthesis with emotional inflection</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Hand className="h-4 w-4" />
                        <span>Haptic feedback integration</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="interaction-modes" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="bg-gradient-to-br from-blue-50 to-indigo-100 border-0 shadow-lg">
                <CardContent className="p-6 text-center">
                  <Volume2 className="h-12 w-12 mx-auto mb-4 text-blue-600" />
                  <h3 className="text-lg font-bold mb-2">Voice Interaction</h3>
                  <p className="text-sm text-gray-600 mb-4">
                    Natural conversation with cloned family member voices and personality patterns
                  </p>
                  <Badge className="bg-blue-100 text-blue-700">Active</Badge>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-green-50 to-emerald-100 border-0 shadow-lg">
                <CardContent className="p-6 text-center">
                  <Hand className="h-12 w-12 mx-auto mb-4 text-green-600" />
                  <h3 className="text-lg font-bold mb-2">Gesture Control</h3>
                  <p className="text-sm text-gray-600 mb-4">
                    Hand gestures for interaction, waving, reaching out for virtual touch
                  </p>
                  <Badge className="bg-green-100 text-green-700">Learning</Badge>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-purple-50 to-violet-100 border-0 shadow-lg">
                <CardContent className="p-6 text-center">
                  <Eye className="h-12 w-12 mx-auto mb-4 text-purple-600" />
                  <h3 className="text-lg font-bold mb-2">Eye Tracking</h3>
                  <p className="text-sm text-gray-600 mb-4">
                    Hologram responds to patient's gaze and maintains natural eye contact
                  </p>
                  <Badge className="bg-purple-100 text-purple-700">Beta</Badge>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="technical-specs" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Hardware Requirements</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Holographic Projectors</span>
                      <span className="font-medium">4K Ultra-HD (4 units)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Spatial Audio System</span>
                      <span className="font-medium">360° Surround (8 speakers)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Gesture Sensors</span>
                      <span className="font-medium">Ultra-wide field tracking</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Processing Unit</span>
                      <span className="font-medium">AI-optimized GPU cluster</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Room Coverage</span>
                      <span className="font-medium">15ft × 15ft × 10ft</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Performance Metrics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Hologram Resolution</span>
                      <span className="font-medium">4K × 4 projectors</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Refresh Rate</span>
                      <span className="font-medium">120 FPS</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Audio Latency</span>
                      <span className="font-medium">&lt; 20ms</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Gesture Response</span>
                      <span className="font-medium">&lt; 50ms</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Power Consumption</span>
                      <span className="font-medium">2.4 kW (peak)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}