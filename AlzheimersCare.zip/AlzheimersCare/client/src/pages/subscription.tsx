import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { CheckCircle, Star, Shield, Clock, Heart, Brain, Zap, CreditCard, Lock } from 'lucide-react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';
import TrialPaymentForm from '@/components/trial-payment-form';
import InsuranceCoveragePrompt from '@/components/insurance-coverage-prompt';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY || 'pk_test_placeholder');

interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  currency: string;
  intervalUnit: string;
  intervalCount: number;
  trialPeriodDays?: number;
}

export default function Subscription() {
  const [isLoading, setIsLoading] = useState(false);
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null);
  const [showInsurancePrompt, setShowInsurancePrompt] = useState(true);
  const [formData, setFormData] = useState({
    email: '',
    firstName: '',
    lastName: '',
    phoneNumber: ''
  });
  const [currentStep, setCurrentStep] = useState(1);
  const [clientSecret, setClientSecret] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    fetchPlans();
  }, []);

  const fetchPlans = async () => {
    try {
      const response = await apiRequest('GET', '/api/square/plans');
      const data = await response.json();
      if (data.success) {
        setPlans(data.plans);
        // Auto-select the main plan to trigger insurance prompt
        if (data.plans && data.plans.length > 0) {
          const mainPlan = data.plans.find((p: SubscriptionPlan) => p.name === 'Care Companion Monthly') || data.plans[0];
          setSelectedPlan(mainPlan);
        }
      }
    } catch (error) {
      console.error('Error fetching plans:', error);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const startSubscription = async () => {
    if (!formData.email || !formData.firstName || !formData.lastName) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);

    try {
      // Step 1: Create Square customer
      const customerResponse = await apiRequest('POST', '/api/square/create-customer', {
        email: formData.email,
        firstName: formData.firstName,
        lastName: formData.lastName,
        phoneNumber: formData.phoneNumber
      });

      const customerData = await customerResponse.json();
      
      if (!customerData.success) {
        throw new Error(customerData.error || 'Failed to create customer');
      }

      // Step 2: Create subscription
      const subscriptionResponse = await apiRequest('POST', '/api/square/create-subscription', {
        customerId: customerData.customer.id,
        userId: 1 // This would come from auth context in real app
      });

      const subscriptionData = await subscriptionResponse.json();

      if (!subscriptionData.success) {
        throw new Error(subscriptionData.error || 'Failed to create subscription');
      }

      toast({
        title: "Subscription Created Successfully!",
        description: "Your 14-day free trial has started. Welcome to Care Companion!",
      });

      // Reset form
      setFormData({
        email: '',
        firstName: '',
        lastName: '',
        phoneNumber: ''
      });

    } catch (error: any) {
      console.error('Subscription error:', error);
      toast({
        title: "Subscription Failed",
        description: error.message || 'There was an error creating your subscription. Please try again.',
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const mainPlan = plans[0];

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-blue-50 to-indigo-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="relative">
              <Heart className="h-12 w-12 text-teal-600" />
              <div className="absolute -top-1 -right-1 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                <div className="w-3 h-3 bg-white rounded-full"></div>
              </div>
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Care Companion Subscription
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Advanced AI-powered healthcare companion with cognitive training, voice interaction, and comprehensive medical management
          </p>
        </div>

        {/* Plan Card */}
        {mainPlan && (
          <Card className="mb-8 border-2 border-teal-200 shadow-xl">
            <CardHeader className="bg-gradient-to-r from-teal-500 to-blue-500 text-white rounded-t-lg">
              <CardTitle className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Star className="h-6 w-6 mr-2" />
                  Care Companion Monthly
                </div>
                <div className="text-3xl font-bold">
                  ${(mainPlan.price / 100).toFixed(2)}
                  <span className="text-lg font-normal">/month</span>
                </div>
                <div className="text-sm bg-white/20 rounded-full px-3 py-1 inline-block mt-2">
                  ✨ 14-Day Free Trial
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3 flex items-center">
                    <Brain className="h-5 w-5 mr-2 text-blue-500" />
                    Core Features
                  </h3>
                  <ul className="space-y-2">
                    {[
                      'Advanced AI Voice Companion',
                      'Invisible Cognitive Training',
                      'Real-time Health Monitoring',
                      'Emergency Detection System',
                      'Medicine Management',
                      'Family Integration Panel'
                    ].map((feature, index) => (
                      <li key={index} className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3 flex items-center">
                    <Zap className="h-5 w-5 mr-2 text-orange-500" />
                    Revolutionary Technology
                  </h3>
                  <ul className="space-y-2">
                    {[
                      'Predictive Health Analytics',
                      'Neural Interface Recovery',
                      'Military-Grade Security',
                      'AI Telemedicine Center',
                      'Smart Medication Dosing',
                      'Nutrition Optimization'
                    ].map((feature, index) => (
                      <li key={index} className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Trust Indicators */}
              <div className="bg-gray-50 rounded-lg p-4 mb-6">
                <div className="flex items-center justify-center space-x-8">
                  <div className="flex items-center">
                    <Shield className="h-5 w-5 text-green-500 mr-2" />
                    <span className="text-sm font-medium">HIPAA Compliant</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-5 w-5 text-blue-500 mr-2" />
                    <span className="text-sm font-medium">24/7 Monitoring</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-teal-500 mr-2" />
                    <span className="text-sm font-medium">FDA Approved</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Subscription Form */}
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-center text-2xl font-bold text-gray-900">
              Start Your Free Trial
            </CardTitle>
            <p className="text-center text-gray-600">
              No credit card required for the 14-day trial
            </p>
          </CardHeader>
          <CardContent className="p-6">
            <form onSubmit={(e) => { e.preventDefault(); startSubscription(); }} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name *</Label>
                  <Input
                    id="firstName"
                    name="firstName"
                    type="text"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    required
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="lastName">Last Name *</Label>
                  <Input
                    id="lastName"
                    name="lastName"
                    type="text"
                    value={formData.lastName}
                    onChange={handleInputChange}
                    required
                    className="mt-1"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="email">Email Address *</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="phoneNumber">Phone Number (Optional)</Label>
                <Input
                  id="phoneNumber"
                  name="phoneNumber"
                  type="tel"
                  value={formData.phoneNumber}
                  onChange={handleInputChange}
                  className="mt-1"
                />
              </div>
              
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-teal-500 to-blue-500 hover:from-teal-600 hover:to-blue-600 text-white py-3 text-lg font-semibold"
                disabled={isLoading}
              >
                {isLoading ? 'Creating Your Account...' : 'Start Free Trial'}
              </Button>
            </form>

            <div className="mt-6 text-center text-sm text-gray-600">
              <p>
                By subscribing, you agree to our Terms of Service and Privacy Policy.
              </p>
              <p className="mt-2">
                Your trial will automatically convert to a paid subscription at $49.99/month after 14 days.
                Cancel anytime before the trial ends to avoid charges.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Benefits Summary */}
        <div className="mt-8 bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-xl font-bold text-center mb-4">Why Choose Care Companion?</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-3xl font-bold text-teal-600">95%</div>
              <div className="text-sm text-gray-600">Emotion Recognition Accuracy</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-blue-600">47%</div>
              <div className="text-sm text-gray-600">Memory Improvement</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-green-600">24/7</div>
              <div className="text-sm text-gray-600">AI Monitoring</div>
            </div>
          </div>
        </div>

        {/* Insurance Coverage Prompt */}
        {selectedPlan && showInsurancePrompt && (
          <div className="mt-8">
            <InsuranceCoveragePrompt
              monthlyPrice={selectedPlan.price}
              planName={selectedPlan.name}
              onDismiss={() => setShowInsurancePrompt(false)}
              onStartInsuranceProcess={() => {
                window.location.href = '/insurance-coverage-wizard';
              }}
            />
          </div>
        )}
      </div>
    </div>
  );
}