import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import RealTimeLocationTracker from '@/components/real-time-location-tracker';
import { 
  Heart, 
  Activity, 
  Thermometer, 
  Droplets,
  Brain,
  Pill,
  AlertTriangle,
  Shield,
  MapPin,
  Clock,
  Phone,
  TrendingUp,
  TrendingDown,
  Calendar,
  Bell,
  Star,
  Crown,
  Zap,
  Lock,
  CheckCircle,
  XCircle,
  Timer
} from 'lucide-react';

interface VitalSigns {
  heartRate: number;
  bloodPressure: { systolic: number; diastolic: number };
  oxygenSaturation: number;
  temperature: number;
  timestamp: string;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
}

interface MedicationStatus {
  name: string;
  nextDose: string;
  taken: boolean;
  adherenceRate: number;
}

interface EmergencyAlert {
  id: number;
  type: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  timestamp: string;
  acknowledged: boolean;
}

interface CognitiveMetrics {
  memoryScore: number;
  attentionScore: number;
  executiveScore: number;
  lastAssessment: string;
  trend: 'improving' | 'stable' | 'declining';
}

interface PatientInfo {
  id: number;
  name: string;
  age: number;
  condition: string;
  riskLevel: string;
  lastActivity: string;
}

export default function FamilyDashboard() {
  const [selectedPatient, setSelectedPatient] = useState<number>(1);
  const [showLocationTracker, setShowLocationTracker] = useState(false);
  const [subscriptionTier, setSubscriptionTier] = useState<'basic' | 'premium' | 'enterprise'>('basic');
  const { toast } = useToast();

  // Mock data - in real app, fetch from API
  const patientInfo: PatientInfo = {
    id: 1,
    name: "Eleanor Thompson",
    age: 78,
    condition: "Early Stage Alzheimer's",
    riskLevel: "medium",
    lastActivity: "2 minutes ago"
  };

  const vitalSigns: VitalSigns = {
    heartRate: 72,
    bloodPressure: { systolic: 128, diastolic: 82 },
    oxygenSaturation: 98,
    temperature: 98.6,
    timestamp: new Date().toISOString(),
    riskLevel: 'low'
  };

  const medications: MedicationStatus[] = [
    { name: "Donepezil", nextDose: "8:00 AM", taken: true, adherenceRate: 95 },
    { name: "Memantine", nextDose: "2:00 PM", taken: false, adherenceRate: 88 },
    { name: "Vitamin D", nextDose: "6:00 PM", taken: false, adherenceRate: 92 }
  ];

  const emergencyAlerts: EmergencyAlert[] = [
    {
      id: 1,
      type: "Medication Missed",
      severity: "medium",
      description: "Afternoon medication not taken",
      timestamp: "1 hour ago",
      acknowledged: false
    }
  ];

  const cognitiveMetrics: CognitiveMetrics = {
    memoryScore: 78,
    attentionScore: 82,
    executiveScore: 75,
    lastAssessment: "2 hours ago",
    trend: "stable"
  };

  const getVitalStatusColor = (value: number, type: string) => {
    switch (type) {
      case 'heartRate':
        if (value < 60 || value > 100) return 'text-red-600';
        if (value < 70 || value > 90) return 'text-yellow-600';
        return 'text-green-600';
      case 'oxygen':
        if (value < 95) return 'text-red-600';
        if (value < 98) return 'text-yellow-600';
        return 'text-green-600';
      case 'temperature':
        if (value < 97 || value > 99.5) return 'text-red-600';
        if (value < 97.5 || value > 99) return 'text-yellow-600';
        return 'text-green-600';
      default:
        return 'text-gray-600';
    }
  };

  const getRiskBadgeColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'critical': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const PremiumFeatureCard = ({ title, description, features, onUpgrade }: {
    title: string;
    description: string;
    features: string[];
    onUpgrade: () => void;
  }) => (
    <Card className="border-2 border-orange-200 bg-gradient-to-br from-orange-50 to-yellow-50">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Crown className="h-5 w-5 text-orange-600" />
          <CardTitle className="text-orange-900">{title}</CardTitle>
          <Badge className="bg-orange-600 text-white">Premium</Badge>
        </div>
        <p className="text-sm text-orange-700">{description}</p>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="space-y-2">
          {features.map((feature, index) => (
            <div key={index} className="flex items-center gap-2 text-sm">
              <Star className="h-4 w-4 text-orange-600" />
              <span className="text-orange-800">{feature}</span>
            </div>
          ))}
        </div>
        <Button onClick={onUpgrade} className="w-full bg-orange-600 hover:bg-orange-700">
          <Zap className="h-4 w-4 mr-2" />
          Upgrade to Premium
        </Button>
      </CardContent>
    </Card>
  );

  const handleUpgrade = () => {
    window.location.href = '/subscription';
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Family Care Dashboard</h1>
            <p className="text-gray-600">Real-time monitoring for {patientInfo.name}</p>
          </div>
          <div className="flex items-center gap-3">
            <Badge className={getRiskBadgeColor(patientInfo.riskLevel)}>
              {patientInfo.riskLevel.toUpperCase()} RISK
            </Badge>
            <div className="text-right">
              <p className="text-sm text-gray-600">Last Activity</p>
              <p className="font-medium">{patientInfo.lastActivity}</p>
            </div>
          </div>
        </div>

        {/* Emergency Alerts */}
        {emergencyAlerts.length > 0 && (
          <Alert className="border-red-200 bg-red-50">
            <AlertTriangle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">
              <strong>Active Alert:</strong> {emergencyAlerts[0].description}
              <Button size="sm" variant="outline" className="ml-3">
                Acknowledge
              </Button>
            </AlertDescription>
          </Alert>
        )}

        {/* Critical Metrics Row */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          
          {/* Heart Rate */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Heart Rate</p>
                  <p className={`text-2xl font-bold ${getVitalStatusColor(vitalSigns.heartRate, 'heartRate')}`}>
                    {vitalSigns.heartRate}
                  </p>
                  <p className="text-xs text-gray-500">bpm</p>
                </div>
                <Heart className={`h-8 w-8 ${getVitalStatusColor(vitalSigns.heartRate, 'heartRate')}`} />
              </div>
            </CardContent>
          </Card>

          {/* Blood Pressure */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Blood Pressure</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {vitalSigns.bloodPressure.systolic}/{vitalSigns.bloodPressure.diastolic}
                  </p>
                  <p className="text-xs text-gray-500">mmHg</p>
                </div>
                <Activity className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          {/* Oxygen Saturation */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Oxygen Sat</p>
                  <p className={`text-2xl font-bold ${getVitalStatusColor(vitalSigns.oxygenSaturation, 'oxygen')}`}>
                    {vitalSigns.oxygenSaturation}%
                  </p>
                  <p className="text-xs text-gray-500">SpO2</p>
                </div>
                <Droplets className={`h-8 w-8 ${getVitalStatusColor(vitalSigns.oxygenSaturation, 'oxygen')}`} />
              </div>
            </CardContent>
          </Card>

          {/* Temperature */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Temperature</p>
                  <p className={`text-2xl font-bold ${getVitalStatusColor(vitalSigns.temperature, 'temperature')}`}>
                    {vitalSigns.temperature}°F
                  </p>
                  <p className="text-xs text-gray-500">Body temp</p>
                </div>
                <Thermometer className={`h-8 w-8 ${getVitalStatusColor(vitalSigns.temperature, 'temperature')}`} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          
          {/* Medication Status */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Pill className="h-5 w-5" />
                Medication Status
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {medications.map((med, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium">{med.name}</p>
                    <p className="text-sm text-gray-600">Next: {med.nextDose}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    {med.taken ? (
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-600" />
                    )}
                    <Badge variant="outline">{med.adherenceRate}%</Badge>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Cognitive Health */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                Cognitive Health
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm">
                    <span>Memory</span>
                    <span>{cognitiveMetrics.memoryScore}%</span>
                  </div>
                  <Progress value={cognitiveMetrics.memoryScore} className="h-2" />
                </div>
                
                <div>
                  <div className="flex justify-between text-sm">
                    <span>Attention</span>
                    <span>{cognitiveMetrics.attentionScore}%</span>
                  </div>
                  <Progress value={cognitiveMetrics.attentionScore} className="h-2" />
                </div>
                
                <div>
                  <div className="flex justify-between text-sm">
                    <span>Executive Function</span>
                    <span>{cognitiveMetrics.executiveScore}%</span>
                  </div>
                  <Progress value={cognitiveMetrics.executiveScore} className="h-2" />
                </div>
              </div>
              
              <div className="flex items-center justify-between pt-3 border-t">
                <span className="text-sm text-gray-600">Trend</span>
                <div className="flex items-center gap-1">
                  {cognitiveMetrics.trend === 'improving' && <TrendingUp className="h-4 w-4 text-green-600" />}
                  {cognitiveMetrics.trend === 'stable' && <div className="w-4 h-1 bg-blue-600 rounded" />}
                  {cognitiveMetrics.trend === 'declining' && <TrendingDown className="h-4 w-4 text-red-600" />}
                  <span className="text-sm capitalize">{cognitiveMetrics.trend}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Premium Location Tracking */}
          {subscriptionTier === 'basic' ? (
            <PremiumFeatureCard
              title="Real-Time Location Tracking"
              description="Advanced GPS monitoring with intelligent geofencing for wandering prevention"
              features={[
                "Live GPS tracking with 1-meter accuracy",
                "Customizable safety zone boundaries",
                "Instant alerts when patient leaves safe area",
                "Location history and pattern analysis",
                "Emergency contact auto-notification",
                "Integration with local emergency services"
              ]}
              onUpgrade={handleUpgrade}
            />
          ) : (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  Location Status
                  <Badge className="bg-green-600 text-white">Premium</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-3 bg-green-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-green-600" />
                      <span className="text-sm font-medium text-green-800">Within Safe Zone</span>
                    </div>
                    <p className="text-xs text-green-600 mt-1">Home - Last update: 2 min ago</p>
                  </div>
                  
                  <Button
                    onClick={() => setShowLocationTracker(true)}
                    className="w-full"
                    variant="outline"
                  >
                    <MapPin className="h-4 w-4 mr-2" />
                    View Live Map
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Safety Score */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Safety Score
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center space-y-4">
                <div className="relative w-24 h-24 mx-auto">
                  <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 36 36">
                    <path
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke="#e5e7eb"
                      strokeWidth="3"
                    />
                    <path
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke="#10b981"
                      strokeWidth="3"
                      strokeDasharray="85, 100"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-2xl font-bold text-green-600">85</span>
                  </div>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Overall Safety</p>
                  <p className="font-medium text-green-600">Excellent</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Emergency Contacts */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Phone className="h-5 w-5" />
                Emergency Contacts
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button className="w-full bg-red-600 hover:bg-red-700">
                <Phone className="h-4 w-4 mr-2" />
                Call 911
              </Button>
              
              <div className="space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  <Phone className="h-4 w-4 mr-2" />
                  Dr. Smith (Primary)
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Phone className="h-4 w-4 mr-2" />
                  Sarah (Daughter)
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Phone className="h-4 w-4 mr-2" />
                  Care Facility
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Premium AI Insights */}
          {subscriptionTier === 'basic' ? (
            <PremiumFeatureCard
              title="AI Health Insights"
              description="Advanced predictive analytics and personalized health recommendations"
              features={[
                "48-72 hour health event prediction",
                "Personalized risk assessments",
                "Medication optimization suggestions",
                "Behavioral pattern analysis",
                "Family caregiver guidance",
                "Integration with medical records"
              ]}
              onUpgrade={handleUpgrade}
            />
          ) : (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  AI Insights
                  <Badge className="bg-purple-600 text-white">Premium</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-blue-50 rounded-lg">
                  <p className="text-sm font-medium text-blue-800">Health Prediction</p>
                  <p className="text-xs text-blue-600">92% stable for next 48 hours</p>
                </div>
                
                <div className="p-3 bg-green-50 rounded-lg">
                  <p className="text-sm font-medium text-green-800">Recommendation</p>
                  <p className="text-xs text-green-600">Consider afternoon walk routine</p>
                </div>
                
                <div className="p-3 bg-yellow-50 rounded-lg">
                  <p className="text-sm font-medium text-yellow-800">Alert</p>
                  <p className="text-xs text-yellow-600">Sleep pattern change detected</p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Premium Location Tracker Modal */}
        {showLocationTracker && subscriptionTier !== 'basic' && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-2xl font-bold">Real-Time Location Tracking</h2>
                  <Button
                    variant="outline"
                    onClick={() => setShowLocationTracker(false)}
                  >
                    Close
                  </Button>
                </div>
                <RealTimeLocationTracker
                  patientId={patientInfo.id}
                  patientName={patientInfo.name}
                  familyMemberId={1}
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}