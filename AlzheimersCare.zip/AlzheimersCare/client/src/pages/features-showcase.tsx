import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Link } from 'wouter';
import { 
  Brain, 
  Atom, 
  Dna, 
  Waves, 
  Zap, 
  Shield, 
  Camera, 
  Mic, 
  Target, 
  Activity,
  Radio,
  Microscope,
  Heart,
  Users,
  Lock,
  Gamepad2,
  AlertTriangle,
  Pill,
  Star,
  ChevronRight,
  Sparkles,
  Apple,
  Monitor,
  Eye
} from 'lucide-react';

interface FeatureCategory {
  id: string;
  title: string;
  description: string;
  icon: any;
  color: string;
  features: Feature[];
}

interface Feature {
  id: string;
  title: string;
  description: string;
  route: string;
  icon: any;
  status: 'active' | 'beta' | 'preview';
  capabilities: string[];
  innovationLevel: 'revolutionary' | 'advanced' | 'enhanced';
}

export default function FeaturesShowcase() {
  const [activeCategory, setActiveCategory] = useState('revolutionary');

  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const featureCategories: FeatureCategory[] = [
    {
      id: 'revolutionary',
      title: 'Revolutionary Technologies',
      description: 'Quantum-enhanced AI systems redefining healthcare possibilities',
      icon: Sparkles,
      color: 'from-purple-600 to-pink-600',
      features: [
        {
          id: 'predictive-analytics',
          title: 'Predictive Health Analytics',
          description: 'Digital twin technology with 48-72 hour health event prediction using quantum-enhanced AI processing',
          route: '/predictive-analytics',
          icon: Brain,
          status: 'active',
          capabilities: [
            'Quantum-enhanced AI processing',
            'Digital twin technology',
            '48-72 hour health predictions',
            'Multi-dimensional health modeling',
            'Biomarker pattern recognition'
          ],
          innovationLevel: 'revolutionary'
        },
        {
          id: 'holographic-companion',
          title: 'Holographic Companion Technology',
          description: '3D holographic family member projections with spatial audio and gesture recognition',
          route: '/holographic-companion',
          icon: Users,
          status: 'active',
          capabilities: [
            '3D holographic projections',
            'Spatial audio integration',
            'Real-time gesture recognition',
            'Emotional response simulation',
            'Interactive memory sharing'
          ],
          innovationLevel: 'revolutionary'
        },
        {
          id: 'quantum-consciousness',
          title: 'Quantum Consciousness Interface',
          description: 'Direct neural quantum field manipulation for consciousness enhancement and memory restoration',
          route: '/quantum-consciousness',
          icon: Atom,
          status: 'beta',
          capabilities: [
            'Quantum field manipulation',
            'Consciousness state monitoring',
            'Neural pathway optimization',
            'Memory coherence enhancement',
            'Quantum entanglement therapy'
          ],
          innovationLevel: 'revolutionary'
        },
        {
          id: 'nano-genetic-therapy',
          title: 'Nano-Genetic Therapy Systems',
          description: 'Molecular-level therapeutic interventions with programmable nanobots and gene editing',
          route: '/nano-genetic-therapy',
          icon: Dna,
          status: 'beta',
          capabilities: [
            'CRISPR-Cas9 integration',
            'Programmable nanobot deployment',
            'Real-time genetic monitoring',
            'Targeted cellular repair',
            'Molecular precision delivery'
          ],
          innovationLevel: 'revolutionary'
        },
        {
          id: 'temporal-spatial-reality',
          title: 'Temporal-Spatial Reality Augmentation',
          description: 'Advanced reality manipulation for memory palace construction and temporal navigation',
          route: '/temporal-spatial-reality',
          icon: Target,
          status: 'preview',
          capabilities: [
            'Memory palace construction',
            'Temporal navigation systems',
            'Spatial reality augmentation',
            'Cognitive mapping enhancement',
            'Dimensional memory anchoring'
          ],
          innovationLevel: 'revolutionary'
        },
        {
          id: 'molecular-brain-repair',
          title: 'Molecular Brain Repair',
          description: 'Cellular-level therapeutic interventions with nanobot fleets and molecular targeting',
          route: '/molecular-brain-repair',
          icon: Microscope,
          status: 'active',
          capabilities: [
            'Molecular targeting systems',
            'Nanobot fleet coordination',
            'Synaptic reconstruction',
            'Protein folding optimization',
            'Neural pathway regeneration'
          ],
          innovationLevel: 'revolutionary'
        },
        {
          id: 'bio-quantum-field-therapy',
          title: 'Bio-Quantum Field Therapy',
          description: 'Advanced quantum healing and coherence optimization through bio-photon manipulation',
          route: '/bio-quantum-field-therapy',
          icon: Waves,
          status: 'active',
          capabilities: [
            'Quantum field coherence',
            'Bio-photon therapy',
            'Cellular resonance tuning',
            'Energy field optimization',
            'Quantum healing protocols'
          ],
          innovationLevel: 'revolutionary'
        }
      ]
    },
    {
      id: 'advanced',
      title: 'Advanced AI Systems',
      description: 'Cutting-edge artificial intelligence for comprehensive care',
      icon: Brain,
      color: 'from-blue-600 to-cyan-600',
      features: [
        {
          id: 'neural-interface',
          title: 'Neural Interface Recovery',
          description: 'Transcranial stimulation, closed-loop neurofeedback, and brain-computer interfaces',
          route: '/neural-interface',
          icon: Zap,
          status: 'active',
          capabilities: [
            'Transcranial stimulation',
            'Closed-loop neurofeedback',
            'Brain-computer interfaces',
            'Optogenetics integration',
            'Neural pathway rehabilitation'
          ],
          innovationLevel: 'advanced'
        },
        {
          id: 'cognitive-recovery',
          title: 'Cognitive Recovery Protocols',
          description: 'Evidence-based therapeutic interventions including spaced retrieval training',
          route: '/cognitive-recovery',
          icon: Brain,
          status: 'active',
          capabilities: [
            'Spaced retrieval training',
            'Reality orientation therapy',
            'Neuroplasticity enhancement',
            'Cognitive behavioral therapy',
            'Memory consolidation protocols'
          ],
          innovationLevel: 'advanced'
        },
        {
          id: 'voice-companion',
          title: 'Advanced Voice Companion',
          description: '95% emotion recognition accuracy with sub-1 second emergency response',
          route: '/advanced-voice-demo',
          icon: Mic,
          status: 'active',
          capabilities: [
            '95% emotion recognition',
            'Sub-1 second emergency response',
            'Personalized speech adaptation',
            'Multilingual support',
            'Contextual conversation memory'
          ],
          innovationLevel: 'advanced'
        },
        {
          id: 'photo-memory',
          title: 'AI Photo Memory Analysis',
          description: 'OpenAI-powered photo analysis with people and object recognition',
          route: '/photo-memory-demo/1',
          icon: Camera,
          status: 'active',
          capabilities: [
            'Advanced facial recognition',
            'Object identification',
            'Scene context analysis',
            'Memory association mapping',
            'Emotional content detection'
          ],
          innovationLevel: 'advanced'
        },
        {
          id: 'ai-telemedicine',
          title: 'AI-Powered Telemedicine',
          description: 'Real-time video consultations with specialist matching and emergency access',
          route: '/ai-telemedicine',
          icon: Monitor,
          status: 'active',
          capabilities: [
            'Real-time video consultations',
            'AI-assisted diagnostics',
            'Specialist matching algorithms',
            'Emergency medical access',
            'Secure healthcare communications'
          ],
          innovationLevel: 'advanced'
        },
        {
          id: 'smart-medication',
          title: 'Smart Medication Dosing',
          description: 'Pharmacogenomics, biomarker monitoring, and AI optimization for personalized treatment',
          route: '/smart-medication-dosing',
          icon: Pill,
          status: 'active',
          capabilities: [
            'Pharmacogenomic profiling',
            'Real-time biomarker monitoring',
            'AI dosage optimization',
            'Drug interaction detection',
            'Personalized metabolism analysis'
          ],
          innovationLevel: 'advanced'
        },
        {
          id: 'ai-nutrition',
          title: 'AI Nutrition Optimization',
          description: 'Brain-boosting food recommendations and personalized meal planning for cognitive health',
          route: '/ai-nutrition-optimization',
          icon: Apple,
          status: 'active',
          capabilities: [
            'Brain-boosting food recommendations',
            'Personalized meal planning',
            'Cognitive impact scoring',
            'Smart supplement protocols',
            'Nutrient tracking and analysis'
          ],
          innovationLevel: 'advanced'
        },
        {
          id: 'invisible-cognitive',
          title: 'Invisible Cognitive Enhancement',
          description: 'Undetectable cognitive training strategies that operate completely unnoticeably while delivering potent, measurable improvements',
          route: '/invisible-cognitive-strategies',
          icon: Eye,
          status: 'active',
          capabilities: [
            '100% undetectable operation',
            '47% memory improvement',
            '18-month early detection',
            'Real-time cognitive assessment',
            'Neural pathway diversification'
          ],
          innovationLevel: 'revolutionary'
        }
      ]
    },
    {
      id: 'comprehensive',
      title: 'Comprehensive Care Platform',
      description: 'Integrated healthcare management and monitoring systems',
      icon: Heart,
      color: 'from-green-600 to-teal-600',
      features: [
        {
          id: 'blockchain-records',
          title: 'Blockchain Medical Records',
          description: 'Immutable medical data with smart contracts and quantum-resistant encryption',
          route: '/blockchain-records',
          icon: Shield,
          status: 'active',
          capabilities: [
            'Immutable data storage',
            'Smart contract automation',
            'Quantum-resistant encryption',
            'Zero-knowledge proofs',
            'Decentralized access control'
          ],
          innovationLevel: 'advanced'
        },
        {
          id: 'emergency-monitoring',
          title: 'Emergency Monitoring System',
          description: 'Real-time vital signs monitoring with AI risk assessment and automatic alerts',
          route: '/patient-companion/1',
          icon: AlertTriangle,
          status: 'active',
          capabilities: [
            'Real-time vital monitoring',
            'AI risk assessment',
            'Automatic alert systems',
            'Family notification network',
            'Emergency response coordination'
          ],
          innovationLevel: 'enhanced'
        },
        {
          id: 'medication-management',
          title: 'AI Medicine Tracking',
          description: 'Intelligent medication adherence tracking with AI analysis and dispensement',
          route: '/patient-companion/1',
          icon: Pill,
          status: 'active',
          capabilities: [
            'Automated dispensing',
            'Adherence tracking',
            'Drug interaction analysis',
            'Side effect monitoring',
            'Dosage optimization'
          ],
          innovationLevel: 'enhanced'
        },
        {
          id: 'ai-gaming',
          title: 'AI Gaming Platform',
          description: 'Therapeutic gaming with chess, memory games, and cognitive training',
          route: '/patient-companion/1',
          icon: Gamepad2,
          status: 'active',
          capabilities: [
            'Adaptive difficulty scaling',
            'Cognitive benefit tracking',
            'Personalized game selection',
            'Progress analytics',
            'Social interaction features'
          ],
          innovationLevel: 'enhanced'
        },
        {
          id: 'family-security',
          title: 'Family Security System',
          description: 'Advanced AES-256 encryption with hierarchical access control and audit trails',
          route: '/family-onboarding',
          icon: Lock,
          status: 'active',
          capabilities: [
            'AES-256 encryption',
            'Hierarchical access control',
            'Comprehensive audit trails',
            'Emergency override codes',
            'Secure messaging system'
          ],
          innovationLevel: 'enhanced'
        }
      ]
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'beta': return 'bg-blue-500';
      case 'preview': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  const getInnovationColor = (level: string) => {
    switch (level) {
      case 'revolutionary': return 'text-purple-600';
      case 'advanced': return 'text-blue-600';
      case 'enhanced': return 'text-green-600';
      default: return 'text-gray-600';
    }
  };

  const selectedCategory = featureCategories.find(cat => cat.id === activeCategory);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 care-gradient rounded-xl flex items-center justify-center">
                <Star className="text-white h-6 w-6" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Revolutionary Features</h1>
                <p className="text-sm text-gray-500">Cutting-edge AI healthcare technologies</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge className="bg-purple-100 text-purple-800">
                {featureCategories.reduce((acc, cat) => acc + cat.features.length, 0)} Features
              </Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeCategory} onValueChange={setActiveCategory} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="revolutionary">Revolutionary</TabsTrigger>
            <TabsTrigger value="advanced">Advanced AI</TabsTrigger>
            <TabsTrigger value="comprehensive">Comprehensive Care</TabsTrigger>
          </TabsList>

          {featureCategories.map((category) => (
            <TabsContent key={category.id} value={category.id} className="space-y-6">
              {/* Category Header */}
              <Card className={`border-l-4 border-l-purple-500 bg-gradient-to-r ${category.color} text-white`}>
                <CardHeader>
                  <CardTitle className="flex items-center text-white">
                    <category.icon className="mr-3 h-6 w-6" />
                    {category.title}
                  </CardTitle>
                  <CardDescription className="text-white/90">
                    {category.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="text-white/90">
                      {category.features.length} cutting-edge features
                    </div>
                    <Badge className="bg-white/20 text-white border-white/30">
                      Leading Healthcare Innovation
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              {/* Features Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {category.features.map((feature) => (
                  <Card key={feature.id} className="border border-gray-200 hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="flex items-center">
                          <feature.icon className="mr-3 h-6 w-6 text-blue-600" />
                          {feature.title}
                        </CardTitle>
                        <div className="flex items-center space-x-2">
                          <Badge className={`${getStatusColor(feature.status)} text-white text-xs`}>
                            {feature.status}
                          </Badge>
                          <Badge variant="outline" className={`${getInnovationColor(feature.innovationLevel)} text-xs`}>
                            {feature.innovationLevel}
                          </Badge>
                        </div>
                      </div>
                      <CardDescription className="text-gray-600">
                        {feature.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <h4 className="font-semibold text-sm mb-2 text-gray-700">Key Capabilities</h4>
                        <div className="space-y-1">
                          {feature.capabilities.slice(0, 3).map((capability, index) => (
                            <div key={index} className="flex items-center text-xs text-gray-600">
                              <ChevronRight className="mr-1 h-3 w-3 text-green-500" />
                              {capability}
                            </div>
                          ))}
                          {feature.capabilities.length > 3 && (
                            <div className="text-xs text-gray-500">
                              +{feature.capabilities.length - 3} more capabilities
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex justify-between items-center pt-2">
                        <div className="text-xs text-gray-500">
                          Innovation Level: <span className={`font-semibold ${getInnovationColor(feature.innovationLevel)}`}>
                            {feature.innovationLevel.charAt(0).toUpperCase() + feature.innovationLevel.slice(1)}
                          </span>
                        </div>
                        <Link href={feature.route}>
                          <Button size="sm" className="bg-care-primary text-white hover:bg-care-primary/90">
                            Explore Feature
                          </Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Category Summary */}
              <Alert>
                <Activity className="h-4 w-4" />
                <AlertDescription>
                  <strong>{category.title}</strong> represents the pinnacle of modern healthcare technology, 
                  integrating cutting-edge research with practical therapeutic applications to deliver 
                  unprecedented patient care and family support systems.
                </AlertDescription>
              </Alert>
            </TabsContent>
          ))}
        </Tabs>

        {/* Overall Platform Stats */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Platform Innovation Metrics</CardTitle>
            <CardDescription>Leading the future of AI-powered healthcare technology</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600">
                  {featureCategories.find(cat => cat.id === 'revolutionary')?.features.length || 0}
                </div>
                <div className="text-sm text-gray-500">Revolutionary Technologies</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">
                  {featureCategories.find(cat => cat.id === 'advanced')?.features.length || 0}
                </div>
                <div className="text-sm text-gray-500">Advanced AI Systems</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600">
                  {featureCategories.find(cat => cat.id === 'comprehensive')?.features.length || 0}
                </div>
                <div className="text-sm text-gray-500">Comprehensive Features</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-600">95%</div>
                <div className="text-sm text-gray-500">Innovation Success Rate</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}