import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CognitiveActivityCard } from "@/components/cognitive-activity-card";
import { EmergencyMonitor } from "@/components/emergency-monitor";
import { MedicineTracker } from "@/components/medicine-tracker";
import { AIGaming } from "@/components/ai-gaming";
import { VoiceCompanion } from "@/components/voice-companion";
import { CareCompanionAPI } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { 
  Heart, 
  Brain, 
  Calendar,
  Pill,
  Gamepad2,
  AlertTriangle, 
  Trophy, 
  Users, 
  Camera,
  Play,
  Pause,
  RotateCcw,
  Star,
  TrendingUp
} from "lucide-react";

interface PatientCompanionProps {
  patientId?: string;
}

export default function PatientCompanion({ patientId: routePatientId }: PatientCompanionProps) {
  const params = useParams();
  const patientId = routePatientId || params.patientId || "1";
  const { toast } = useToast();
  
  const [currentActivity, setCurrentActivity] = useState<any>(null);
  const [activitySession, setActivitySession] = useState<any>(null);
  const [responses, setResponses] = useState<any[]>([]);
  const [timeOfDay, setTimeOfDay] = useState("");

  useEffect(() => {
    const hour = new Date().getHours();
    if (hour < 12) setTimeOfDay("Good morning");
    else if (hour < 17) setTimeOfDay("Good afternoon");
    else setTimeOfDay("Good evening");
  }, []);

  // Query patient data
  const { data: patient, isLoading: patientLoading } = useQuery({
    queryKey: ['/api/patients', patientId],
    enabled: !!patientId,
  });

  // Query latest cognitive progress
  const { data: latestProgress } = useQuery({
    queryKey: ['/api/patients', patientId, 'latest-cognitive-progress'],
    enabled: !!patientId,
  });

  if (patientLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" aria-label="Loading"/>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      {/* Care Crystal Overlay */}
      <div className="fixed top-5 left-5 w-24 h-36 z-50">
        <div className="care-crystal w-full h-full rounded-[15px_15px_50%_50%] flex items-center justify-center cursor-pointer">
          <Heart className="text-white h-8 w-8" />
        </div>
        <div className="text-center mt-2">
          <p className="text-xs text-gray-600 font-medium">Your Care Companion</p>
        </div>
      </div>

      {/* Weather Widget */}
      <div className="fixed top-5 right-5 bg-white/15 backdrop-blur-sm rounded-2xl p-4 border border-white/20 text-gray-800 min-w-[180px] z-50">
        <div className="text-sm opacity-80 mb-1">Today</div>
        <div className="text-2xl font-semibold mb-1">72°F</div>
        <div className="text-xs opacity-80">Partly Cloudy</div>
      </div>

      {/* Main Content */}
      <div className="pt-20 pb-8">
        {/* Welcome Header */}
        <div className="text-center mb-12 px-4">
          <h1 className="text-4xl md:text-5xl font-light text-gray-800 mb-4">
            {timeOfDay}, {patient?.firstName || 'there'}
          </h1>
          <p className="text-xl text-gray-600 mb-6">
            {new Date().toLocaleDateString('en-US', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </p>
          
          {latestProgress && (
            <div className="inline-flex items-center space-x-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full">
              <TrendingUp className="h-4 w-4 text-care-secondary" />
              <span className="text-sm font-medium text-gray-700">
                Overall Progress: {Math.round(latestProgress.overallScore || 0)}%
              </span>
            </div>
          )}
        </div>

        <div className="max-w-6xl mx-auto px-4">
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-5 bg-white/80 backdrop-blur-sm">
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <Heart className="h-4 w-4" />
                Overview
              </TabsTrigger>
              <TabsTrigger value="cognitive" className="flex items-center gap-2">
                <Brain className="h-4 w-4" />
                Cognitive Training
              </TabsTrigger>
              <TabsTrigger value="emergency" className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4" />
                Health Monitor
              </TabsTrigger>
              <TabsTrigger value="medicine" className="flex items-center gap-2">
                <Pill className="h-4 w-4" />
                Medicine
              </TabsTrigger>
              <TabsTrigger value="gaming" className="flex items-center gap-2">
                <Gamepad2 className="h-4 w-4" />
                AI Gaming
              </TabsTrigger>
            </TabsList>

            {/* Overview Tab with ElevenLabs Voice Companion */}
            <TabsContent value="overview" className="space-y-6">
              {/* ElevenLabs Professional Voice Companion */}
              <VoiceCompanion 
                patientId={patientId} 
                patientName={patient?.firstName || ''} 
              />

              <Card className="bg-white/95 backdrop-blur-sm border border-white/20 shadow-xl">
                <CardHeader>
                  <CardTitle className="text-2xl font-bold text-gray-900">Daily Overview</CardTitle>
                  <p className="text-gray-600">Your health and activity summary for today</p>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">85%</div>
                      <p className="text-sm text-gray-600">Health Score</p>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">4/4</div>
                      <p className="text-sm text-gray-600">Medications Today</p>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-600">12</div>
                      <p className="text-sm text-gray-600">Activities Completed</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Cognitive Training Tab */}
            <TabsContent value="cognitive" className="space-y-6">
              <CognitiveActivityCard patientId={patientId} />
            </TabsContent>

            {/* Emergency Monitor Tab */}
            <TabsContent value="emergency" className="space-y-6">
              <EmergencyMonitor patientId={patientId} />
            </TabsContent>

            {/* Medicine Tab */}
            <TabsContent value="medicine" className="space-y-6">
              <MedicineTracker patientId={patientId} />
            </TabsContent>

            {/* AI Gaming Tab */}
            <TabsContent value="gaming" className="space-y-6">
              <AIGaming patientId={patientId} />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}