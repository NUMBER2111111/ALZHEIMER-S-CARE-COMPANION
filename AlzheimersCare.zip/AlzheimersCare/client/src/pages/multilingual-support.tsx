import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { LanguageSelector, SUPPORTED_LANGUAGES } from "@/components/language-selector";
import { useTranslation } from "@/hooks/use-translation";
import { Globe, Volume2, Mic, MessageSquare, Brain, Users, Heart, CheckCircle, Loader, AlertTriangle } from "lucide-react";

export default function MultilingualSupport() {
  const { currentLanguage, setLanguage, translate, translateSync, isLoading, error } = useTranslation();
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [testTranslations, setTestTranslations] = useState<{ [key: string]: string }>({});
  const [translationProgress, setTranslationProgress] = useState(0);

  const testPhrases = [
    "Welcome to Care Companion",
    "Your health and safety are our priority",
    "AI-powered cognitive training",
    "Family memory sharing",
    "Emergency assistance available",
    "Medication reminder active",
    "Voice companion ready",
    "Translation services enabled"
  ];

  useEffect(() => {
    // Test translations for current language
    if (currentLanguage !== 'en') {
      translateTestPhrases();
    }
  }, [currentLanguage]);

  const translateTestPhrases = async () => {
    setTranslationProgress(0);
    const translations: { [key: string]: string } = {};
    
    for (let i = 0; i < testPhrases.length; i++) {
      const phrase = testPhrases[i];
      try {
        const translated = await translate(phrase);
        translations[phrase] = translated;
        setTranslationProgress(((i + 1) / testPhrases.length) * 100);
      } catch (error) {
        console.warn(`Failed to translate: ${phrase}`, error);
        translations[phrase] = phrase; // Fallback to original
      }
    }
    
    setTestTranslations(translations);
  };

  const handleLanguageChange = (language: string) => {
    setLanguage(language);
    setTestTranslations({}); // Clear previous translations
  };

  const speakText = async (text: string) => {
    if (!voiceEnabled) return;
    
    try {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = currentLanguage;
      utterance.rate = 0.8;
      speechSynthesis.speak(utterance);
    } catch (error) {
      console.warn('Text-to-speech failed:', error);
    }
  };

  const currentLangInfo = SUPPORTED_LANGUAGES.find(lang => lang.code === currentLanguage) || SUPPORTED_LANGUAGES[0];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 care-gradient rounded-xl flex items-center justify-center">
              <Globe className="text-white h-6 w-6" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900">
              {translateSync("Multilingual Support Center")}
            </h1>
          </div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {translateSync("Experience Care Companion in your preferred language with real-time translation and voice support")}
          </p>
        </div>

        {/* Language Selector */}
        <div className="flex justify-center mb-8">
          <LanguageSelector
            currentLanguage={currentLanguage}
            onLanguageChange={handleLanguageChange}
            showVoiceOptions={true}
            onVoiceToggle={setVoiceEnabled}
            voiceEnabled={voiceEnabled}
            className="mx-auto"
          />
        </div>

        {/* Current Language Status */}
        <Card className="mb-8 border-2 border-primary/20">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <span className="text-4xl">{currentLangInfo.flag}</span>
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">
                    {currentLangInfo.nativeName}
                  </h3>
                  <p className="text-gray-600">{currentLangInfo.name}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="default" className="bg-green-100 text-green-800">
                  <CheckCircle className="h-4 w-4 mr-1" />
                  {translateSync("Active")}
                </Badge>
                {voiceEnabled && (
                  <Badge variant="outline" className="border-blue-500 text-blue-700">
                    <Volume2 className="h-4 w-4 mr-1" />
                    {translateSync("Voice Enabled")}
                  </Badge>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Translation Test */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-primary" />
                {translateSync("Translation Test")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {currentLanguage === 'en' ? (
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    Select a different language to test translation capabilities
                  </AlertDescription>
                </Alert>
              ) : (
                <div className="space-y-4">
                  {isLoading && (
                    <div className="space-y-2">
                      <Progress value={translationProgress} className="w-full" />
                      <p className="text-sm text-gray-600 flex items-center gap-2">
                        <Loader className="h-4 w-4 animate-spin" />
                        {translateSync("Translating content...")}
                      </p>
                    </div>
                  )}
                  
                  {error && (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  <div className="space-y-3">
                    {testPhrases.map((phrase, index) => (
                      <div key={index} className="bg-gray-50 p-3 rounded-lg">
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <p className="text-sm text-gray-500">English:</p>
                            <p className="font-medium text-gray-900">{phrase}</p>
                            <p className="text-sm text-gray-500">{currentLangInfo.nativeName}:</p>
                            <p className="font-medium text-primary">
                              {testTranslations[phrase] || translateSync(phrase)}
                            </p>
                          </div>
                          {voiceEnabled && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => speakText(testTranslations[phrase] || translateSync(phrase))}
                            >
                              <Volume2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Feature Coverage */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5 text-primary" />
                {translateSync("Multilingual Features")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <div>
                    <h4 className="font-medium text-gray-900">
                      {translateSync("Real-time Interface Translation")}
                    </h4>
                    <p className="text-sm text-gray-600">
                      {translateSync("All buttons, menus, and text automatically translated")}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <div>
                    <h4 className="font-medium text-gray-900">
                      {translateSync("Voice Assistant Multilingual")}
                    </h4>
                    <p className="text-sm text-gray-600">
                      {translateSync("AI companion speaks and understands your language")}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <div>
                    <h4 className="font-medium text-gray-900">
                      {translateSync("Family Communication")}
                    </h4>
                    <p className="text-sm text-gray-600">
                      {translateSync("Messages and memories translated for all family members")}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <div>
                    <h4 className="font-medium text-gray-900">
                      {translateSync("Emergency Alerts")}
                    </h4>
                    <p className="text-sm text-gray-600">
                      {translateSync("Critical health alerts delivered in preferred language")}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <div>
                    <h4 className="font-medium text-gray-900">
                      {translateSync("Medication Instructions")}
                    </h4>
                    <p className="text-sm text-gray-600">
                      {translateSync("Clear medication guidance in your native language")}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                  <Mic className="h-5 w-5 text-blue-600" />
                  <div>
                    <h4 className="font-medium text-gray-900">
                      {translateSync("Voice-to-Voice Translation")}
                    </h4>
                    <p className="text-sm text-gray-600">
                      {translateSync("Speak in any language, get responses in your preferred language")}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Supported Languages */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              {translateSync("Supported Languages")} ({SUPPORTED_LANGUAGES.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {SUPPORTED_LANGUAGES.map((lang) => (
                <div
                  key={lang.code}
                  className={`p-3 rounded-lg border-2 cursor-pointer transition-all hover:scale-105 ${
                    currentLanguage === lang.code
                      ? 'border-primary bg-primary/10'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => handleLanguageChange(lang.code)}
                >
                  <div className="text-center">
                    <div className="text-2xl mb-1">{lang.flag}</div>
                    <div className="text-sm font-medium text-gray-900">{lang.nativeName}</div>
                    <div className="text-xs text-gray-600">{lang.name}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Call to Action */}
        <div className="text-center mt-8">
          <Card className="bg-gradient-to-r from-primary/10 to-care-secondary/10 border-2 border-primary/20">
            <CardContent className="p-8">
              <Heart className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                {translateSync("Experience Care Companion in Your Language")}
              </h3>
              <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
                {translateSync("Join thousands of families worldwide who trust Care Companion for multilingual Alzheimer's care support")}
              </p>
              <div className="flex gap-4 justify-center">
                <Button size="lg" className="bg-primary hover:bg-primary/90">
                  {translateSync("Start Free Trial")}
                </Button>
                <Button variant="outline" size="lg">
                  {translateSync("Contact Support")}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}