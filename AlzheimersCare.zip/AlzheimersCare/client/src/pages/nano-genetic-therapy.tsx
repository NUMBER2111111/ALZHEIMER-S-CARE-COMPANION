import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dna, Microscope, Target, Zap, Shield, Activity, Bot, Atom } from 'lucide-react';

interface NanoBot {
  id: string;
  type: 'repair' | 'delivery' | 'monitoring' | 'cleanup';
  location: string;
  status: 'active' | 'deploying' | 'completed' | 'recharging';
  batteryLevel: number;
  mission: string;
  efficacy: number;
}

interface GeneTherapy {
  id: string;
  targetGene: string;
  therapyType: 'CRISPR-Cas9' | 'Base-Editing' | 'Prime-Editing' | 'Epigenetic';
  deliveryMethod: 'AAV' | 'Lentiviral' | 'Nanoparticle' | 'Lipofection';
  progress: number;
  status: 'preparation' | 'delivery' | 'integration' | 'expression' | 'complete';
  targetCells: string[];
  efficacy: number;
}

interface BiochemicalMarker {
  name: string;
  current: number;
  optimal: number;
  trend: 'improving' | 'stable' | 'declining';
  nanoIntervention: boolean;
}

interface CellularRepair {
  tissueType: string;
  damageLevel: number;
  repairProgress: number;
  nanoBotsDeployed: number;
  estimatedCompletion: string;
  methodology: string;
}

export default function NanoGeneticTherapy() {
  const [nanoBots, setNanoBots] = useState<NanoBot[]>([
    {
      id: 'nano_001',
      type: 'repair',
      location: 'Hippocampus - CA1 Region',
      status: 'active',
      batteryLevel: 89,
      mission: 'Amyloid plaque removal and synaptic repair',
      efficacy: 94.2
    },
    {
      id: 'nano_002',
      type: 'delivery',
      location: 'Prefrontal Cortex',
      status: 'deploying',
      batteryLevel: 95,
      mission: 'BDNF gene therapy delivery to neurons',
      efficacy: 87.6
    },
    {
      id: 'nano_003',
      type: 'monitoring',
      location: 'Blood-Brain Barrier',
      status: 'active',
      batteryLevel: 72,
      mission: 'Real-time biomarker analysis and toxin detection',
      efficacy: 96.8
    },
    {
      id: 'nano_004',
      type: 'cleanup',
      location: 'Temporal Lobe',
      status: 'completed',
      batteryLevel: 45,
      mission: 'Tau protein aggregate clearance',
      efficacy: 91.5
    }
  ]);

  const [geneTherapies, setGeneTherapies] = useState<GeneTherapy[]>([
    {
      id: 'gene_001',
      targetGene: 'APOE4 → APOE2',
      therapyType: 'Base-Editing',
      deliveryMethod: 'AAV',
      progress: 78,
      status: 'integration',
      targetCells: ['Neurons', 'Astrocytes', 'Microglia'],
      efficacy: 89.4
    },
    {
      id: 'gene_002',
      targetGene: 'BDNF Upregulation',
      therapyType: 'CRISPR-Cas9',
      deliveryMethod: 'Nanoparticle',
      progress: 92,
      status: 'expression',
      targetCells: ['Hippocampal Neurons', 'Cortical Neurons'],
      efficacy: 95.7
    },
    {
      id: 'gene_003',
      targetGene: 'APP Processing Enhancement',
      therapyType: 'Prime-Editing',
      deliveryMethod: 'Lentiviral',
      progress: 45,
      status: 'delivery',
      targetCells: ['Cortical Neurons', 'Pyramidal Cells'],
      efficacy: 82.1
    }
  ]);

  const [biomarkers, setBiomarkers] = useState<BiochemicalMarker[]>([
    {
      name: 'Amyloid-β 42',
      current: 145,
      optimal: 120,
      trend: 'improving',
      nanoIntervention: true
    },
    {
      name: 'Tau Protein',
      current: 89,
      optimal: 65,
      trend: 'improving',
      nanoIntervention: true
    },
    {
      name: 'BDNF Levels',
      current: 234,
      optimal: 280,
      trend: 'improving',
      nanoIntervention: false
    },
    {
      name: 'Neuroinflammation',
      current: 67,
      optimal: 40,
      trend: 'stable',
      nanoIntervention: true
    }
  ]);

  const [cellularRepairs, setCellularRepairs] = useState<CellularRepair[]>([
    {
      tissueType: 'Neural Dendrites',
      damageLevel: 34,
      repairProgress: 78,
      nanoBotsDeployed: 847,
      estimatedCompletion: '14 hours',
      methodology: 'Molecular scaffolding with protein synthesis enhancement'
    },
    {
      tissueType: 'Synaptic Connections',
      damageLevel: 52,
      repairProgress: 61,
      nanoBotsDeployed: 1203,
      estimatedCompletion: '28 hours',
      methodology: 'Neurotransmitter pathway reconstruction'
    },
    {
      tissueType: 'Myelin Sheaths',
      damageLevel: 28,
      repairProgress: 89,
      nanoBotsDeployed: 654,
      estimatedCompletion: '6 hours',
      methodology: 'Oligodendrocyte stimulation and lipid membrane repair'
    }
  ]);

  const [isDeployingNanos, setIsDeployingNanos] = useState(false);
  const [systemStatus, setSystemStatus] = useState('optimal');

  useEffect(() => {
    // Simulate real-time nano-bot and gene therapy updates
    const interval = setInterval(() => {
      setNanoBots(prev => prev.map(bot => ({
        ...bot,
        batteryLevel: Math.max(20, bot.batteryLevel - Math.random() * 2),
        efficacy: Math.max(70, Math.min(100, bot.efficacy + (Math.random() - 0.5) * 5))
      })));

      setGeneTherapies(prev => prev.map(therapy => ({
        ...therapy,
        progress: therapy.status !== 'complete' 
          ? Math.min(100, therapy.progress + Math.random() * 2)
          : 100,
        efficacy: Math.max(75, Math.min(100, therapy.efficacy + (Math.random() - 0.5) * 3))
      })));

      setBiomarkers(prev => prev.map(marker => {
        const change = marker.nanoIntervention ? -Math.random() * 2 : Math.random() - 0.5;
        const newValue = Math.max(0, marker.current + change);
        return {
          ...marker,
          current: newValue,
          trend: newValue < marker.current ? 'improving' : 
                 newValue > marker.current ? 'declining' : 'stable'
        };
      }));

      setCellularRepairs(prev => prev.map(repair => ({
        ...repair,
        repairProgress: Math.min(100, repair.repairProgress + Math.random() * 1.5),
        damageLevel: Math.max(0, repair.damageLevel - Math.random() * 1.2)
      })));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const deployNanoBots = async () => {
    setIsDeployingNanos(true);
    
    // Simulate nano-bot deployment
    setTimeout(() => {
      setNanoBots(prev => [
        ...prev,
        {
          id: `nano_${Date.now()}`,
          type: 'repair',
          location: 'Cerebellum',
          status: 'deploying',
          batteryLevel: 100,
          mission: 'Motor function enhancement and coordination repair',
          efficacy: 88.3
        }
      ]);
      setIsDeployingNanos(false);
    }, 5000);
  };

  const getNanoBotStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'deploying': return 'bg-yellow-100 text-yellow-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      case 'recharging': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTherapyStatusColor = (status: string) => {
    switch (status) {
      case 'preparation': return 'bg-yellow-100 text-yellow-800';
      case 'delivery': return 'bg-blue-100 text-blue-800';
      case 'integration': return 'bg-purple-100 text-purple-800';
      case 'expression': return 'bg-green-100 text-green-800';
      case 'complete': return 'bg-emerald-100 text-emerald-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'improving': return 'text-green-400';
      case 'stable': return 'text-yellow-400';
      case 'declining': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getNanoBotIcon = (type: string) => {
    switch (type) {
      case 'repair': return <Zap className="h-4 w-4" />;
      case 'delivery': return <Target className="h-4 w-4" />;
      case 'monitoring': return <Activity className="h-4 w-4" />;
      case 'cleanup': return <Shield className="h-4 w-4" />;
      default: return <Bot className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-900 via-teal-900 to-cyan-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center">
              <Dna className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-white">Nano-Genetic Therapy Platform</h1>
          </div>
          <p className="text-xl text-emerald-200 max-w-4xl mx-auto">
            Revolutionary molecular-level therapy combining CRISPR gene editing, programmable nano-robots, 
            and real-time cellular repair for comprehensive Alzheimer's treatment at the genetic level.
          </p>
        </div>

        {/* System Status */}
        <Card className="bg-black/30 backdrop-blur-md border-emerald-500/30 shadow-2xl">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-emerald-400">{nanoBots.length}</div>
                <div className="text-emerald-200">Active Nano-Bots</div>
                <div className="mt-2 flex items-center justify-center gap-2">
                  <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                  <span className="text-sm text-emerald-300">Operational</span>
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-teal-400">{geneTherapies.length}</div>
                <div className="text-emerald-200">Gene Therapies</div>
                <div className="mt-2">
                  <Badge className="bg-teal-500/20 text-teal-300 border-teal-400">
                    CRISPR Active
                  </Badge>
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-cyan-400">
                  {Math.round(biomarkers.reduce((acc, m) => acc + (m.optimal - Math.abs(m.current - m.optimal)) / m.optimal, 0) / biomarkers.length * 100)}%
                </div>
                <div className="text-emerald-200">Biomarker Health</div>
                <div className="mt-2">
                  <Badge className="bg-cyan-500/20 text-cyan-300 border-cyan-400">
                    Improving
                  </Badge>
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-400">
                  {Math.round(cellularRepairs.reduce((acc, r) => acc + r.repairProgress, 0) / cellularRepairs.length)}%
                </div>
                <div className="text-emerald-200">Cellular Repair</div>
                <div className="mt-2">
                  <Badge className="bg-green-500/20 text-green-300 border-green-400">
                    Regenerating
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Deployment Status */}
        {isDeployingNanos && (
          <Card className="bg-gradient-to-r from-emerald-600/20 to-teal-600/20 backdrop-blur-md border-emerald-400/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-emerald-400 rounded-full animate-pulse"></div>
                  <div>
                    <h3 className="text-xl font-bold text-white">Nano-Bot Deployment in Progress</h3>
                    <p className="text-emerald-200">Initializing molecular assembly and cellular targeting systems...</p>
                  </div>
                </div>
                <div className="text-right text-white">
                  <div className="text-2xl font-bold">🤖 Deploying</div>
                  <p className="text-emerald-200">ETA: 5 minutes</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="nanobots" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-black/30 backdrop-blur-md border-emerald-500/30">
            <TabsTrigger value="nanobots" className="text-emerald-200 data-[state=active]:text-white">Nano-Bots</TabsTrigger>
            <TabsTrigger value="genetherapy" className="text-emerald-200 data-[state=active]:text-white">Gene Therapy</TabsTrigger>
            <TabsTrigger value="biomarkers" className="text-emerald-200 data-[state=active]:text-white">Biomarkers</TabsTrigger>
            <TabsTrigger value="repair" className="text-emerald-200 data-[state=active]:text-white">Cellular Repair</TabsTrigger>
          </TabsList>

          <TabsContent value="nanobots" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">Nano-Robot Fleet</h2>
              <Button 
                onClick={deployNanoBots}
                disabled={isDeployingNanos}
                className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
              >
                <Bot className="mr-2 h-4 w-4" />
                {isDeployingNanos ? 'Deploying...' : 'Deploy New Nano-Bots'}
              </Button>
            </div>

            <div className="space-y-4">
              {nanoBots.map((bot) => (
                <Card key={bot.id} className="bg-black/30 backdrop-blur-md border-emerald-500/30">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-start gap-4">
                        <div className="flex items-center justify-center w-12 h-12 bg-emerald-600/30 rounded-lg">
                          {getNanoBotIcon(bot.type)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-lg font-bold text-white">{bot.id}</h3>
                            <Badge className={getNanoBotStatusColor(bot.status)}>
                              {bot.status}
                            </Badge>
                            <Badge className="bg-gray-100 text-gray-800 capitalize">
                              {bot.type}
                            </Badge>
                          </div>
                          <p className="text-emerald-200 text-sm mb-1">
                            Location: <span className="text-white">{bot.location}</span>
                          </p>
                          <p className="text-emerald-200 text-sm">
                            Mission: <span className="text-white">{bot.mission}</span>
                          </p>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-emerald-300">Battery:</span>
                            <div className="flex items-center gap-2">
                              <div className="w-20 bg-emerald-900/30 rounded-full h-2">
                                <div 
                                  className="bg-gradient-to-r from-emerald-500 to-green-500 h-2 rounded-full transition-all duration-1000"
                                  style={{ width: `${bot.batteryLevel}%` }}
                                ></div>
                              </div>
                              <span className="text-white font-medium">{bot.batteryLevel.toFixed(0)}%</span>
                            </div>
                          </div>
                          <div>
                            <span className="text-emerald-300">Efficacy:</span>
                            <p className="text-white font-medium">{bot.efficacy.toFixed(1)}%</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="genetherapy" className="space-y-6">
            <h2 className="text-2xl font-bold text-white">CRISPR Gene Therapy Protocols</h2>
            
            <div className="space-y-4">
              {geneTherapies.map((therapy) => (
                <Card key={therapy.id} className="bg-black/30 backdrop-blur-md border-emerald-500/30">
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-lg font-bold text-white">{therapy.targetGene}</h3>
                            <Badge className={getTherapyStatusColor(therapy.status)}>
                              {therapy.status}
                            </Badge>
                          </div>
                          <div className="space-y-1 text-sm">
                            <p className="text-emerald-200">
                              Method: <span className="text-white">{therapy.therapyType}</span> via <span className="text-white">{therapy.deliveryMethod}</span>
                            </p>
                            <p className="text-emerald-200">
                              Target Cells: <span className="text-white">{therapy.targetCells.join(', ')}</span>
                            </p>
                            <p className="text-emerald-200">
                              Efficacy: <span className="text-white">{therapy.efficacy.toFixed(1)}%</span>
                            </p>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          <div className="text-2xl font-bold text-emerald-400">{therapy.progress.toFixed(0)}%</div>
                          <div className="text-emerald-300 text-sm">Complete</div>
                        </div>
                      </div>
                      
                      <div className="w-full bg-emerald-900/30 rounded-full h-3">
                        <div 
                          className="bg-gradient-to-r from-emerald-500 to-teal-500 h-3 rounded-full transition-all duration-1000"
                          style={{ width: `${therapy.progress}%` }}
                        ></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="biomarkers" className="space-y-6">
            <h2 className="text-2xl font-bold text-white">Real-Time Biomarker Analysis</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {biomarkers.map((marker, index) => (
                <Card key={index} className="bg-black/30 backdrop-blur-md border-emerald-500/30">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center justify-between">
                      <span>{marker.name}</span>
                      {marker.nanoIntervention && (
                        <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-400">
                          <Bot className="mr-1 h-3 w-3" />
                          Nano-Enhanced
                        </Badge>
                      )}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <div className="text-2xl font-bold text-white">{marker.current.toFixed(1)}</div>
                          <div className="text-emerald-300 text-sm">Current Level</div>
                        </div>
                        <div className="text-right">
                          <div className="text-lg text-emerald-200">{marker.optimal}</div>
                          <div className="text-emerald-300 text-sm">Optimal</div>
                        </div>
                      </div>
                      
                      <div className="w-full bg-emerald-900/30 rounded-full h-2">
                        <div 
                          className="bg-gradient-to-r from-emerald-500 to-teal-500 h-2 rounded-full transition-all duration-1000"
                          style={{ 
                            width: `${Math.min(100, (marker.current / marker.optimal) * 100)}%` 
                          }}
                        ></div>
                      </div>
                      
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-emerald-300">Trend:</span>
                        <span className={`font-medium capitalize ${getTrendColor(marker.trend)}`}>
                          {marker.trend}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="repair" className="space-y-6">
            <h2 className="text-2xl font-bold text-white">Cellular Repair Operations</h2>
            
            <div className="space-y-4">
              {cellularRepairs.map((repair, index) => (
                <Card key={index} className="bg-black/30 backdrop-blur-md border-emerald-500/30">
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="text-lg font-bold text-white">{repair.tissueType}</h3>
                          <p className="text-emerald-200 text-sm">{repair.methodology}</p>
                        </div>
                        <div className="text-right">
                          <div className="text-emerald-400 font-bold">ETA: {repair.estimatedCompletion}</div>
                          <div className="text-emerald-300 text-sm">{repair.nanoBotsDeployed.toLocaleString()} nano-bots</div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-emerald-300 text-sm">Repair Progress</span>
                            <span className="text-white font-medium">{repair.repairProgress.toFixed(0)}%</span>
                          </div>
                          <div className="w-full bg-emerald-900/30 rounded-full h-2">
                            <div 
                              className="bg-gradient-to-r from-emerald-500 to-green-500 h-2 rounded-full transition-all duration-1000"
                              style={{ width: `${repair.repairProgress}%` }}
                            ></div>
                          </div>
                        </div>
                        
                        <div>
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-emerald-300 text-sm">Damage Level</span>
                            <span className="text-red-400 font-medium">{repair.damageLevel.toFixed(0)}%</span>
                          </div>
                          <div className="w-full bg-emerald-900/30 rounded-full h-2">
                            <div 
                              className="bg-gradient-to-r from-red-500 to-orange-500 h-2 rounded-full transition-all duration-1000"
                              style={{ width: `${repair.damageLevel}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}