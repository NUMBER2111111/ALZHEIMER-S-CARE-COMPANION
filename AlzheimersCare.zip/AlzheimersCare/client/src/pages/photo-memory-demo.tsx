import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { AIPhotoIdentification } from '@/components/ai-photo-identification';
import AudioSetupPrompt from '@/components/audio-setup-prompt';
import { Camera, Brain, Users, Heart, ArrowLeft } from 'lucide-react';
import { Link } from 'wouter';

interface PhotoMemoryDemoProps {
  patientId?: number;
}

export default function PhotoMemoryDemo({ patientId = 1 }: PhotoMemoryDemoProps) {
  const [processedPhotos, setProcessedPhotos] = useState<any[]>([]);
  const [audioSetupComplete, setAudioSetupComplete] = useState(false);

  const handlePhotoProcessed = (analysis: any) => {
    setProcessedPhotos(prev => [analysis, ...prev]);
  };

  const sampleMemories = [
    {
      id: 1,
      title: "Family Christmas Dinner",
      peopleIdentified: ["Sarah", "Michael", "Grandma Rose"],
      objectsDetected: ["Christmas tree", "dining table", "presents"],
      emotionalContext: "Joyful family gathering with warm lighting",
      memoryTriggers: ["holiday traditions", "family togetherness", "festive atmosphere"],
      aiConfidence: 0.92
    },
    {
      id: 2,
      title: "Beach Vacation with Grandchildren",
      peopleIdentified: ["Emma", "Jake", "Mom"],
      objectsDetected: ["ocean", "sandcastle", "beach toys"],
      emotionalContext: "Playful and relaxing outdoor activity",
      memoryTriggers: ["summer memories", "grandparent bonding", "childhood play"],
      aiConfidence: 0.87
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-blue-50 p-6">
      {/* Audio Setup Prompt */}
      {!audioSetupComplete && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="max-w-lg w-full">
            <AudioSetupPrompt 
              onSetupComplete={() => setAudioSetupComplete(true)}
              onClose={() => setAudioSetupComplete(true)}
              showMinimal={true}
            />
          </div>
        </div>
      )}
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="outline" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <Heart className="h-8 w-8 text-teal-600" />
                AI Photo Memory Analysis
              </h1>
              <p className="text-gray-600 mt-2">
                Preserve precious memories with AI-powered photo identification and context analysis
              </p>
            </div>
          </div>
          <Badge variant="secondary" className="text-lg px-4 py-2">
            Patient ID: {patientId}
          </Badge>
        </div>

        <Tabs defaultValue="upload" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="upload" className="flex items-center gap-2">
              <Camera className="h-4 w-4" />
              Upload Photos
            </TabsTrigger>
            <TabsTrigger value="analysis" className="flex items-center gap-2">
              <Brain className="h-4 w-4" />
              AI Analysis
            </TabsTrigger>
            <TabsTrigger value="memories" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Memory Collection
            </TabsTrigger>
          </TabsList>

          {/* Photo Upload Tab */}
          <TabsContent value="upload" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Camera className="h-5 w-5 text-teal-600" />
                  Upload and Analyze Photos
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Upload family photos and let AI identify people, objects, and meaningful contexts to preserve memories
                </p>
              </CardHeader>
              <CardContent>
                <AIPhotoIdentification 
                  patientId={patientId}
                  onPhotoProcessed={handlePhotoProcessed}
                />
              </CardContent>
            </Card>
          </TabsContent>

          {/* AI Analysis Tab */}
          <TabsContent value="analysis" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-blue-600" />
                    Recent Analysis Results
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {processedPhotos.length > 0 ? (
                    <div className="space-y-4">
                      {processedPhotos.map((photo, index) => (
                        <div key={index} className="border rounded-lg p-4 space-y-3">
                          <div className="flex items-center justify-between">
                            <h4 className="font-semibold">{photo.fileName}</h4>
                            <Badge variant={photo.aiConfidence > 0.8 ? "default" : "secondary"}>
                              {Math.round(photo.aiConfidence * 100)}% confidence
                            </Badge>
                          </div>
                          
                          <div className="space-y-2">
                            <div>
                              <p className="text-sm font-medium">People Identified:</p>
                              <div className="flex flex-wrap gap-1 mt-1">
                                {[...photo.peopleIdentified, ...photo.userInputPeople]
                                  .filter(Boolean)
                                  .map((person, i) => (
                                  <Badge key={i} variant="secondary" className="text-xs">
                                    {person}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                            
                            <div>
                              <p className="text-sm font-medium">Context:</p>
                              <p className="text-sm text-muted-foreground">
                                {photo.contextDescription}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <Brain className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>No photos analyzed yet</p>
                      <p className="text-sm">Upload photos in the Upload tab to see AI analysis results</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>AI Analysis Features</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <Users className="h-5 w-5 text-teal-600 mt-0.5" />
                      <div>
                        <h4 className="font-medium">People Recognition</h4>
                        <p className="text-sm text-muted-foreground">
                          Identifies individuals in photos and learns from your input
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <Brain className="h-5 w-5 text-blue-600 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Context Analysis</h4>
                        <p className="text-sm text-muted-foreground">
                          Understands settings, activities, and emotional contexts
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <Heart className="h-5 w-5 text-red-500 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Memory Triggers</h4>
                        <p className="text-sm text-muted-foreground">
                          Identifies elements that help trigger positive memories
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Memory Collection Tab */}
          <TabsContent value="memories" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-purple-600" />
                  Preserved Memory Collection
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Explore analyzed photos and their contextual memories
                </p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {sampleMemories.map((memory) => (
                    <Card key={memory.id} className="border-l-4 border-l-teal-500">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg">{memory.title}</CardTitle>
                        <Badge variant="outline" className="w-fit">
                          {Math.round(memory.aiConfidence * 100)}% AI Confidence
                        </Badge>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <h4 className="font-medium text-sm mb-2">People Present:</h4>
                          <div className="flex flex-wrap gap-1">
                            {memory.peopleIdentified.map((person, i) => (
                              <Badge key={i} variant="secondary" className="text-xs">
                                {person}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <h4 className="font-medium text-sm mb-2">Scene Elements:</h4>
                          <div className="flex flex-wrap gap-1">
                            {memory.objectsDetected.map((object, i) => (
                              <Badge key={i} variant="outline" className="text-xs">
                                {object}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <h4 className="font-medium text-sm mb-1">Emotional Context:</h4>
                          <p className="text-sm text-muted-foreground">
                            {memory.emotionalContext}
                          </p>
                        </div>
                        
                        <div>
                          <h4 className="font-medium text-sm mb-2">Memory Triggers:</h4>
                          <div className="flex flex-wrap gap-1">
                            {memory.memoryTriggers.map((trigger, i) => (
                              <Badge key={i} className="text-xs bg-blue-100 text-blue-800">
                                {trigger}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                
                {processedPhotos.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground border-t mt-6">
                    <p className="text-sm">Upload and analyze new photos to add to this collection</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}