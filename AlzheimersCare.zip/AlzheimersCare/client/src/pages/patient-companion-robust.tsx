import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { EmergencyMonitor } from '@/components/emergency-monitor-robust';
import { MedicineTracker } from '@/components/medicine-tracker-robust';
import { AIGaming } from '@/components/ai-gaming-robust';
import { useSpeechRecognition } from '@/hooks/useSpeechRecognition';
import { useSpeechSynthesis } from '@/hooks/useSpeechSynthesis';
import { Heart, User, Activity, Brain, MessageCircle, Mic, MicOff } from 'lucide-react';

interface Patient {
  id: number;
  firstName: string;
  lastName: string;
  dateOfBirth: string | null;
  medicalInfo: any;
  emergencyInfo: any;
  facilityId: number | null;
}

interface CognitiveProgress {
  id: number;
  memoryRecall: string;
  recognition: string;
  attention: string;
  overallScore: string;
  notes: string | null;
  assessmentDate: string;
}

export default function PatientCompanionRobust() {
  const patientId = 1; // For demo purposes
  const [showCompanion, setShowCompanion] = useState(false);
  const [companionMessage, setCompanionMessage] = useState("Hello! I'm here to help you today. How are you feeling?");
  const [activeTab, setActiveTab] = useState("overview");

  // Voice interaction hooks
  const { 
    isListening, 
    transcript, 
    startListening, 
    stopListening, 
    resetTranscript, 
    isSupported: speechRecognitionSupported,
    error: speechError
  } = useSpeechRecognition();

  const { 
    speak, 
    cancel: cancelSpeech, 
    isSpeaking, 
    isSupported: speechSynthesisSupported 
  } = useSpeechSynthesis();

  // Robust patient data fetching with comprehensive error handling
  const { data: patient, isLoading: patientLoading, error: patientError } = useQuery({
    queryKey: ['/api/patients', patientId],
    retry: 3,
    retryDelay: 1000,
    staleTime: 300000, // 5 minutes
  });

  const { data: latestProgress, isLoading: progressLoading } = useQuery({
    queryKey: ['/api/patients', patientId, 'cognitive-progress', 'latest'],
    retry: 2,
    staleTime: 60000, // 1 minute
  });

  const { data: activities = [], isLoading: activitiesLoading } = useQuery({
    queryKey: ['/api/patients', patientId, 'cognitive-activities'],
    retry: 2,
  });

  const { data: familyMemories = [], isLoading: memoriesLoading } = useQuery({
    queryKey: ['/api/patients', patientId, 'family-memories'],
    retry: 2,
  });

  // AI Companion interaction with error handling
  const companionInteractionMutation = useMutation({
    mutationFn: async (message: string) => {
      try {
        const response = await apiRequest('POST', `/api/patients/${patientId}/companion/interact`, {
          message,
          context: 'general_conversation',
          timestamp: new Date().toISOString(),
        });
        return response.json();
      } catch (error) {
        console.error('Companion interaction failed:', error);
        return { message: "I'm having trouble connecting right now. Please try again in a moment." };
      }
    },
    onSuccess: (data) => {
      if (data && data.message) {
        setCompanionMessage(data.message);
      }
    },
    onError: (error) => {
      console.error('Companion interaction error:', error);
      setCompanionMessage("I'm having some technical difficulties. Let me know if you need immediate assistance.");
    },
  });

  // Start cognitive activity with validation
  const startActivityMutation = useMutation({
    mutationFn: async (activityId: number) => {
      try {
        if (!activityId) {
          throw new Error('Activity ID is required');
        }
        return await apiRequest('POST', `/api/patients/${patientId}/activity-sessions`, {
          cognitiveActivityId: activityId,
          startTime: new Date().toISOString(),
        });
      } catch (error) {
        console.error('Failed to start activity:', error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'cognitive-activities'] });
    },
  });

  // Voice interaction handling with Web Speech API
  const handleVoiceInteraction = () => {
    if (!speechRecognitionSupported) {
      setCompanionMessage("Voice recognition is not supported in this browser. Please use a modern browser like Chrome or Edge.");
      return;
    }

    if (!isListening) {
      setCompanionMessage("I'm listening... Please speak now.");
      resetTranscript();
      startListening();
    } else {
      stopListening();
      setCompanionMessage("Processing what you said...");
    }
  };

  // Handle voice response when AI companion responds
  const speakResponse = (message: string) => {
    if (speechSynthesisSupported && message) {
      // Cancel any ongoing speech first
      cancelSpeech();
      
      // Speak the response with a friendly voice
      speak(message, {
        rate: 0.9,
        pitch: 1.1,
        volume: 0.8
      });
    }
  };

  // Process speech transcript when user finishes speaking
  useEffect(() => {
    if (transcript && !isListening) {
      // Send the transcript to the AI companion
      setCompanionMessage("Let me think about that...");
      companionInteractionMutation.mutate(transcript);
      resetTranscript();
    }
  }, [transcript, isListening]);

  // Speak AI responses aloud
  useEffect(() => {
    if (companionMessage && !isListening && !isSpeaking) {
      // Don't speak system messages or status updates
      if (!companionMessage.includes("listening") && 
          !companionMessage.includes("Processing") && 
          !companionMessage.includes("think about")) {
        speakResponse(companionMessage);
      }
    }
  }, [companionMessage, isListening, isSpeaking]);

  // Handle companion crystal interaction
  const handleCompanionClick = () => {
    setShowCompanion(!showCompanion);
    if (!showCompanion) {
      const greetings = [
        "Hello! How can I help you today?",
        "I'm here for you. What would you like to do?",
        "Good to see you! How are you feeling?",
        "Let's work on something together. What interests you?",
      ];
      setCompanionMessage(greetings[Math.floor(Math.random() * greetings.length)]);
    }
  };

  // Render patient information with null safety
  const renderPatientInfo = () => {
    if (patientLoading) {
      return <div className="text-sm text-gray-500">Loading patient information...</div>;
    }

    if (patientError) {
      return (
        <Alert className="border-red-200 bg-red-50">
          <AlertDescription className="text-red-700">
            Unable to load patient information. Please refresh the page or contact support.
          </AlertDescription>
        </Alert>
      );
    }

    if (!patient || typeof patient !== 'object') {
      return <div className="text-sm text-gray-500">Patient information unavailable</div>;
    }

    const patientData = patient as Patient;

    return (
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-teal-400 to-green-500 rounded-full flex items-center justify-center">
            <User className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-semibold">
              {patientData.firstName || 'Unknown'} {patientData.lastName || 'Patient'}
            </h2>
            <p className="text-sm text-gray-500">
              {patientData.dateOfBirth ? 
                `Born: ${new Date(patientData.dateOfBirth).toLocaleDateString()}` : 
                'Date of birth not available'
              }
            </p>
          </div>
        </div>
      </div>
    );
  };

  // Render cognitive progress with error handling
  const renderCognitiveProgress = () => {
    if (progressLoading) {
      return <div className="text-sm text-gray-500">Loading cognitive progress...</div>;
    }

    if (!latestProgress || typeof latestProgress !== 'object') {
      return <div className="text-sm text-gray-500">No recent cognitive assessments</div>;
    }

    const progress = latestProgress as CognitiveProgress;
    const memoryScore = parseFloat(progress.memoryRecall) || 0;
    const recognitionScore = parseFloat(progress.recognition) || 0;
    const attentionScore = parseFloat(progress.attention) || 0;
    const overallScore = parseFloat(progress.overallScore) || 0;

    return (
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium">Memory Recall</span>
              <span className="text-sm">{Math.round(memoryScore)}%</span>
            </div>
            <Progress value={memoryScore} className="h-2" />
          </div>
          
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium">Recognition</span>
              <span className="text-sm">{Math.round(recognitionScore)}%</span>
            </div>
            <Progress value={recognitionScore} className="h-2" />
          </div>
          
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium">Attention</span>
              <span className="text-sm">{Math.round(attentionScore)}%</span>
            </div>
            <Progress value={attentionScore} className="h-2" />
          </div>
          
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium">Overall Score</span>
              <span className="text-sm">{Math.round(overallScore)}%</span>
            </div>
            <Progress value={overallScore} className="h-2" />
          </div>
        </div>
        
        {progress.assessmentDate && (
          <div className="text-xs text-gray-500">
            Last assessment: {new Date(progress.assessmentDate).toLocaleDateString()}
          </div>
        )}
      </div>
    );
  };

  // Render cognitive activities with error handling
  const renderCognitiveActivities = () => {
    if (activitiesLoading) {
      return <div className="text-sm text-gray-500">Loading activities...</div>;
    }

    if (!Array.isArray(activities) || activities.length === 0) {
      return <div className="text-sm text-gray-500">No cognitive activities available</div>;
    }

    return activities.slice(0, 3).map((activity: any, index: number) => {
      if (!activity || typeof activity !== 'object') {
        return <div key={index} className="text-sm text-gray-400">Invalid activity data</div>;
      }

      return (
        <Card key={activity.id || index} className="cursor-pointer hover:bg-gray-50">
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <h4 className="font-medium text-sm">{activity.title || 'Untitled Activity'}</h4>
                <p className="text-xs text-gray-500 mt-1">
                  {activity.description || 'No description available'}
                </p>
                <div className="flex gap-2 mt-2">
                  <Badge variant="outline" className="text-xs">
                    {activity.activityType || 'Unknown'}
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    {activity.difficulty || 'Unknown'}
                  </Badge>
                </div>
              </div>
              <Button
                size="sm"
                onClick={() => startActivityMutation.mutate(activity.id)}
                disabled={startActivityMutation.isPending}
              >
                {startActivityMutation.isPending ? 'Starting...' : 'Start'}
              </Button>
            </div>
          </CardContent>
        </Card>
      );
    });
  };

  // Render family memories with error handling
  const renderFamilyMemories = () => {
    if (memoriesLoading) {
      return <div className="text-sm text-gray-500">Loading memories...</div>;
    }

    if (!Array.isArray(familyMemories) || familyMemories.length === 0) {
      return <div className="text-sm text-gray-500">No family memories shared yet</div>;
    }

    return familyMemories.slice(0, 2).map((memory: any, index: number) => {
      if (!memory || typeof memory !== 'object') {
        return <div key={index} className="text-sm text-gray-400">Invalid memory data</div>;
      }

      return (
        <Card key={memory.id || index} className="border-l-4 border-l-pink-400">
          <CardContent className="p-4">
            <h4 className="font-medium text-sm mb-2">{memory.title || 'Untitled Memory'}</h4>
            <p className="text-xs text-gray-600 mb-2">
              {memory.description || 'No description available'}
            </p>
            {memory.createdAt && (
              <div className="text-xs text-gray-400">
                Shared: {new Date(memory.createdAt).toLocaleDateString()}
              </div>
            )}
          </CardContent>
        </Card>
      );
    });
  };

  if (patientLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Heart className="h-12 w-12 mx-auto text-care-primary mb-4" />
          <p className="text-gray-600">Loading your care companion...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      {/* Care Crystal Overlay */}
      <div className="fixed top-5 left-5 w-8 h-32 z-50">
        <div 
          className={`care-crystal w-full h-full cursor-pointer transition-all duration-500 relative ${
            isListening ? 'animate-pulse' : ''
          }`}
          onClick={handleCompanionClick}
          style={{
            clipPath: 'polygon(50% 0%, 80% 25%, 100% 50%, 80% 75%, 50% 100%, 20% 75%, 0% 50%, 20% 25%)'
          }}
        >
          {/* Main crystal body */}
          <div className="absolute inset-0 bg-gradient-to-b from-teal-200/30 via-emerald-300/40 to-teal-400/50"></div>
          
          {/* Inner diamond facets */}
          <div className="absolute inset-1 bg-gradient-to-br from-white/20 via-transparent to-teal-200/30"
               style={{
                 clipPath: 'polygon(50% 5%, 75% 28%, 95% 50%, 75% 72%, 50% 95%, 25% 72%, 5% 50%, 25% 28%)'
               }}>
          </div>
          
          {/* Central diamond highlight */}
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-1 h-1 bg-white/80 rounded-full"></div>
          
          {/* Top diamond facet */}
          <div className="absolute top-2 left-1/2 transform -translate-x-1/2 w-3 h-6 bg-gradient-to-b from-white/40 to-transparent"
               style={{
                 clipPath: 'polygon(50% 0%, 80% 100%, 20% 100%)'
               }}>
          </div>
          
          {/* Right facet highlight */}
          <div className="absolute top-6 right-2 w-0.5 h-32 bg-gradient-to-b from-white/40 via-white/20 to-transparent transform skew-y-6"></div>
          
          {/* Heart icon in center */}
          <div className="absolute inset-0 flex items-center justify-center">
            <Heart className={`text-white/80 h-6 w-6 drop-shadow-lg ${showCompanion ? 'animate-bounce' : ''}`} />
          </div>
        </div>
        <div className="text-center mt-2">
          <p className="text-xs text-gray-600 font-medium">Care Crystal</p>
        </div>
      </div>

      {/* AI Companion Dialog */}
      {showCompanion && (
        <div className="fixed top-5 left-24 w-80 bg-white/95 backdrop-blur-sm rounded-2xl p-6 border border-white/40 shadow-xl z-50">
          <div className="flex items-start space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-teal-400 to-green-500 rounded-full flex items-center justify-center">
              <MessageCircle className="h-6 w-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-gray-800 mb-2">Your AI Companion</h3>
              <p className="text-sm text-gray-600 mb-4">{companionMessage}</p>
              
              {/* Voice interaction status */}
              {transcript && (
                <div className="mb-3 p-2 bg-blue-50 rounded-lg">
                  <p className="text-xs text-blue-600 font-medium">You said:</p>
                  <p className="text-sm text-blue-800">"{transcript}"</p>
                </div>
              )}
              
              {speechError && (
                <div className="mb-3 p-2 bg-red-50 rounded-lg">
                  <p className="text-xs text-red-600 font-medium">Speech Error:</p>
                  <p className="text-sm text-red-800">{speechError}</p>
                </div>
              )}
              
              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={handleVoiceInteraction}
                  disabled={companionInteractionMutation.isPending}
                  className={`flex-1 ${isListening ? 'bg-red-500 hover:bg-red-600' : 'bg-teal-500 hover:bg-teal-600'}`}
                >
                  {isListening ? <MicOff className="h-4 w-4 mr-1" /> : <Mic className="h-4 w-4 mr-1" />}
                  {isListening ? 'Stop Listening' : 'Talk to Me'}
                </Button>
                
                {isSpeaking && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={cancelSpeech}
                    className="bg-orange-50 hover:bg-orange-100"
                  >
                    Stop Speaking
                  </Button>
                )}
                
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setShowCompanion(false)}
                >
                  Close
                </Button>
              </div>
              
              {!speechRecognitionSupported && (
                <p className="text-xs text-amber-600 mt-2">
                  Voice recognition requires Chrome, Edge, or Safari browser
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <div className="mb-8">
          {renderPatientInfo()}
        </div>

        {/* Main Dashboard */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="health">Health Monitor</TabsTrigger>
            <TabsTrigger value="medicine">Medicine</TabsTrigger>
            <TabsTrigger value="games">AI Games</TabsTrigger>
            <TabsTrigger value="memories">Memories</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Quick Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Brain className="h-5 w-5" />
                    Cognitive Progress
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {renderCognitiveProgress()}
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Today's Activities
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {renderCognitiveActivities()}
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Family Memories</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {renderFamilyMemories()}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="health">
            <EmergencyMonitor patientId={patientId} />
          </TabsContent>

          <TabsContent value="medicine">
            <MedicineTracker patientId={patientId} />
          </TabsContent>

          <TabsContent value="games">
            <AIGaming patientId={patientId} />
          </TabsContent>

          <TabsContent value="memories">
            <Card>
              <CardHeader>
                <CardTitle>Family Memories & Stories</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {renderFamilyMemories()}
                <Button className="w-full" variant="outline">
                  Add New Memory
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}