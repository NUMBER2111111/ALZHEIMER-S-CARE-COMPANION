import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { 
  Shield, 
  User, 
  FileText, 
  Upload, 
  Send, 
  CheckCircle, 
  ArrowRight, 
  ArrowLeft,
  Heart,
  Clock,
  DollarSign,
  Phone,
  Mail,
  MapPin,
  Calendar,
  AlertCircle,
  Download,
  Star
} from 'lucide-react';

interface InsuranceFormData {
  // Personal Information
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  ssn: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;

  // Insurance Information
  insuranceType: 'medicare' | 'medicaid' | 'private' | 'other';
  insuranceCarrier: string;
  policyNumber: string;
  groupNumber: string;
  subscriberName: string;

  // Medical Information
  primaryDiagnosis: string;
  diagnosisDate: string;
  primaryPhysician: string;
  physicianPhone: string;
  currentMedications: string;
  medicalHistory: string;

  // Care Information
  caregiverName: string;
  caregiverRelation: string;
  caregiverPhone: string;
  emergencyContact: string;
  emergencyPhone: string;

  // Additional Information
  additionalNotes: string;
}

export default function InsuranceCoverageWizard() {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<InsuranceFormData>({
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    ssn: '',
    phone: '',
    email: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    insuranceType: 'medicare',
    insuranceCarrier: '',
    policyNumber: '',
    groupNumber: '',
    subscriberName: '',
    primaryDiagnosis: '',
    diagnosisDate: '',
    primaryPhysician: '',
    physicianPhone: '',
    currentMedications: '',
    medicalHistory: '',
    caregiverName: '',
    caregiverRelation: '',
    caregiverPhone: '',
    emergencyContact: '',
    emergencyPhone: '',
    additionalNotes: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [estimatedCoverage, setEstimatedCoverage] = useState<number | null>(null);
  const { toast } = useToast();

  const totalSteps = 5;
  const progressPercentage = (currentStep / totalSteps) * 100;

  const updateFormData = (field: keyof InsuranceFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const calculateEstimatedCoverage = () => {
    let coverage = 0;
    const monthlyPrice = 49.99;

    switch (formData.insuranceType) {
      case 'medicare':
        coverage = 0.85; // 85% average
        break;
      case 'medicaid':
        coverage = 0.90; // 90% average
        break;
      case 'private':
        coverage = 0.70; // 70% average
        break;
      default:
        coverage = 0.60; // 60% average
    }

    const estimatedAmount = monthlyPrice * coverage;
    setEstimatedCoverage(estimatedAmount);
    return estimatedAmount;
  };

  const submitInsuranceApplication = async () => {
    setIsSubmitting(true);
    
    try {
      const response = await apiRequest('POST', '/api/insurance/submit-application', {
        formData,
        estimatedCoverage: calculateEstimatedCoverage(),
        submissionDate: new Date().toISOString()
      });

      const data = await response.json();

      if (data.success) {
        toast({
          title: "Application Submitted Successfully!",
          description: "Your insurance coverage application has been submitted. You'll receive a confirmation email within 24 hours.",
        });
        setCurrentStep(totalSteps + 1); // Go to success page
      } else {
        throw new Error(data.message);
      }
    } catch (error: any) {
      toast({
        title: "Submission Failed",
        description: error.message || "Failed to submit insurance application. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold mb-2">Personal Information</h2>
              <p className="text-gray-600">Let's start with your basic information</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName">First Name *</Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) => updateFormData('firstName', e.target.value)}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="lastName">Last Name *</Label>
                <Input
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) => updateFormData('lastName', e.target.value)}
                  required
                />
              </div>

              <div>
                <Label htmlFor="dateOfBirth">Date of Birth *</Label>
                <Input
                  id="dateOfBirth"
                  type="date"
                  value={formData.dateOfBirth}
                  onChange={(e) => updateFormData('dateOfBirth', e.target.value)}
                  required
                />
              </div>

              <div>
                <Label htmlFor="ssn">Social Security Number *</Label>
                <Input
                  id="ssn"
                  value={formData.ssn}
                  onChange={(e) => updateFormData('ssn', e.target.value)}
                  placeholder="XXX-XX-XXXX"
                  required
                />
              </div>

              <div>
                <Label htmlFor="phone">Phone Number *</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => updateFormData('phone', e.target.value)}
                  placeholder="(555) 123-4567"
                  required
                />
              </div>

              <div>
                <Label htmlFor="email">Email Address *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => updateFormData('email', e.target.value)}
                  required
                />
              </div>

              <div className="md:col-span-2">
                <Label htmlFor="address">Address *</Label>
                <Input
                  id="address"
                  value={formData.address}
                  onChange={(e) => updateFormData('address', e.target.value)}
                  required
                />
              </div>

              <div>
                <Label htmlFor="city">City *</Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => updateFormData('city', e.target.value)}
                  required
                />
              </div>

              <div>
                <Label htmlFor="state">State *</Label>
                <Input
                  id="state"
                  value={formData.state}
                  onChange={(e) => updateFormData('state', e.target.value)}
                  required
                />
              </div>

              <div>
                <Label htmlFor="zipCode">ZIP Code *</Label>
                <Input
                  id="zipCode"
                  value={formData.zipCode}
                  onChange={(e) => updateFormData('zipCode', e.target.value)}
                  required
                />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold mb-2">Insurance Information</h2>
              <p className="text-gray-600">Tell us about your current insurance coverage</p>
            </div>

            <div className="space-y-4">
              <div>
                <Label>Insurance Type *</Label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-2">
                  {[
                    { value: 'medicare', label: 'Medicare', description: '85% avg coverage' },
                    { value: 'medicaid', label: 'Medicaid', description: '90% avg coverage' },
                    { value: 'private', label: 'Private Insurance', description: '70% avg coverage' },
                    { value: 'other', label: 'Other', description: '60% avg coverage' }
                  ].map((type) => (
                    <button
                      key={type.value}
                      type="button"
                      onClick={() => updateFormData('insuranceType', type.value as any)}
                      className={`p-3 border-2 rounded-lg text-center transition-all ${
                        formData.insuranceType === type.value 
                          ? 'border-blue-600 bg-blue-50' 
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="font-medium">{type.label}</div>
                      <div className="text-xs text-gray-600">{type.description}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="insuranceCarrier">Insurance Carrier *</Label>
                  <Input
                    id="insuranceCarrier"
                    value={formData.insuranceCarrier}
                    onChange={(e) => updateFormData('insuranceCarrier', e.target.value)}
                    placeholder="e.g., Blue Cross Blue Shield, Aetna, UnitedHealth"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="policyNumber">Policy Number *</Label>
                  <Input
                    id="policyNumber"
                    value={formData.policyNumber}
                    onChange={(e) => updateFormData('policyNumber', e.target.value)}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="groupNumber">Group Number</Label>
                  <Input
                    id="groupNumber"
                    value={formData.groupNumber}
                    onChange={(e) => updateFormData('groupNumber', e.target.value)}
                  />
                </div>

                <div>
                  <Label htmlFor="subscriberName">Subscriber Name</Label>
                  <Input
                    id="subscriberName"
                    value={formData.subscriberName}
                    onChange={(e) => updateFormData('subscriberName', e.target.value)}
                    placeholder="If different from patient"
                  />
                </div>
              </div>

              {formData.insuranceType && (
                <Alert className="border-green-200 bg-green-50">
                  <DollarSign className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-800">
                    <strong>Estimated Coverage:</strong> Based on your insurance type, you may be eligible for 
                    {formData.insuranceType === 'medicare' && ' 80-90% coverage (approximately $40-45/month)'}
                    {formData.insuranceType === 'medicaid' && ' 85-95% coverage (approximately $42-47/month)'}
                    {formData.insuranceType === 'private' && ' 60-80% coverage (approximately $30-40/month)'}
                    {formData.insuranceType === 'other' && ' 50-70% coverage (approximately $25-35/month)'}
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold mb-2">Medical Information</h2>
              <p className="text-gray-600">Help us understand your medical needs</p>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="primaryDiagnosis">Primary Diagnosis *</Label>
                  <Input
                    id="primaryDiagnosis"
                    value={formData.primaryDiagnosis}
                    onChange={(e) => updateFormData('primaryDiagnosis', e.target.value)}
                    placeholder="e.g., Alzheimer's Disease, Dementia"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="diagnosisDate">Date of Diagnosis</Label>
                  <Input
                    id="diagnosisDate"
                    type="date"
                    value={formData.diagnosisDate}
                    onChange={(e) => updateFormData('diagnosisDate', e.target.value)}
                  />
                </div>

                <div>
                  <Label htmlFor="primaryPhysician">Primary Care Physician *</Label>
                  <Input
                    id="primaryPhysician"
                    value={formData.primaryPhysician}
                    onChange={(e) => updateFormData('primaryPhysician', e.target.value)}
                    placeholder="Dr. Name, Practice Name"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="physicianPhone">Physician Phone Number</Label>
                  <Input
                    id="physicianPhone"
                    value={formData.physicianPhone}
                    onChange={(e) => updateFormData('physicianPhone', e.target.value)}
                    placeholder="(555) 123-4567"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="currentMedications">Current Medications</Label>
                <Textarea
                  id="currentMedications"
                  value={formData.currentMedications}
                  onChange={(e) => updateFormData('currentMedications', e.target.value)}
                  placeholder="List all current medications, dosages, and frequencies"
                  rows={4}
                />
              </div>

              <div>
                <Label htmlFor="medicalHistory">Relevant Medical History</Label>
                <Textarea
                  id="medicalHistory"
                  value={formData.medicalHistory}
                  onChange={(e) => updateFormData('medicalHistory', e.target.value)}
                  placeholder="Previous treatments, hospitalizations, other relevant medical conditions"
                  rows={4}
                />
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold mb-2">Care & Emergency Contacts</h2>
              <p className="text-gray-600">Who should we contact for care coordination?</p>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="caregiverName">Primary Caregiver Name *</Label>
                  <Input
                    id="caregiverName"
                    value={formData.caregiverName}
                    onChange={(e) => updateFormData('caregiverName', e.target.value)}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="caregiverRelation">Relationship to Patient *</Label>
                  <Input
                    id="caregiverRelation"
                    value={formData.caregiverRelation}
                    onChange={(e) => updateFormData('caregiverRelation', e.target.value)}
                    placeholder="e.g., Spouse, Daughter, Son"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="caregiverPhone">Caregiver Phone Number *</Label>
                  <Input
                    id="caregiverPhone"
                    value={formData.caregiverPhone}
                    onChange={(e) => updateFormData('caregiverPhone', e.target.value)}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="emergencyContact">Emergency Contact Name</Label>
                  <Input
                    id="emergencyContact"
                    value={formData.emergencyContact}
                    onChange={(e) => updateFormData('emergencyContact', e.target.value)}
                  />
                </div>

                <div>
                  <Label htmlFor="emergencyPhone">Emergency Contact Phone</Label>
                  <Input
                    id="emergencyPhone"
                    value={formData.emergencyPhone}
                    onChange={(e) => updateFormData('emergencyPhone', e.target.value)}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="additionalNotes">Additional Notes or Special Requirements</Label>
                <Textarea
                  id="additionalNotes"
                  value={formData.additionalNotes}
                  onChange={(e) => updateFormData('additionalNotes', e.target.value)}
                  placeholder="Any additional information that would help with your coverage application"
                  rows={4}
                />
              </div>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold mb-2">Review & Submit</h2>
              <p className="text-gray-600">Please review your information before submitting</p>
            </div>

            <div className="space-y-4">
              {/* Coverage Estimate */}
              <Alert className="border-green-200 bg-green-50">
                <DollarSign className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">
                  <div className="flex justify-between items-center">
                    <div>
                      <strong>Estimated Monthly Coverage: ${calculateEstimatedCoverage().toFixed(2)}</strong>
                      <br />
                      <span className="text-sm">Your estimated out-of-pocket: ${(49.99 - calculateEstimatedCoverage()).toFixed(2)}/month</span>
                    </div>
                    <Badge className="bg-green-600 text-white">
                      {Math.round((calculateEstimatedCoverage() / 49.99) * 100)}% Coverage
                    </Badge>
                  </div>
                </AlertDescription>
              </Alert>

              {/* Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <User className="h-5 w-5" />
                      Personal Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <p><strong>Name:</strong> {formData.firstName} {formData.lastName}</p>
                    <p><strong>DOB:</strong> {formData.dateOfBirth}</p>
                    <p><strong>Phone:</strong> {formData.phone}</p>
                    <p><strong>Email:</strong> {formData.email}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Shield className="h-5 w-5" />
                      Insurance Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <p><strong>Type:</strong> {formData.insuranceType}</p>
                    <p><strong>Carrier:</strong> {formData.insuranceCarrier}</p>
                    <p><strong>Policy:</strong> {formData.policyNumber}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Heart className="h-5 w-5" />
                      Medical Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <p><strong>Diagnosis:</strong> {formData.primaryDiagnosis}</p>
                    <p><strong>Physician:</strong> {formData.primaryPhysician}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Phone className="h-5 w-5" />
                      Care Contacts
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <p><strong>Caregiver:</strong> {formData.caregiverName}</p>
                    <p><strong>Relation:</strong> {formData.caregiverRelation}</p>
                    <p><strong>Phone:</strong> {formData.caregiverPhone}</p>
                  </CardContent>
                </Card>
              </div>

              {/* Submit Button */}
              <div className="text-center">
                <Button
                  onClick={submitInsuranceApplication}
                  disabled={isSubmitting}
                  className="w-full md:w-auto px-8 py-3 bg-blue-600 hover:bg-blue-700"
                >
                  {isSubmitting ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      Submitting Application...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4 mr-2" />
                      Submit Insurance Application
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        );

      default:
        return (
          <div className="text-center space-y-6">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle className="h-10 w-10 text-green-600" />
            </div>
            
            <div>
              <h2 className="text-2xl font-bold mb-2">Application Submitted Successfully!</h2>
              <p className="text-gray-600">Your insurance coverage application has been submitted.</p>
            </div>

            <Alert className="border-blue-200 bg-blue-50">
              <Clock className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-800">
                <strong>What happens next:</strong>
                <ul className="list-disc list-inside mt-2 space-y-1">
                  <li>You'll receive a confirmation email within 24 hours</li>
                  <li>Our insurance specialists will review your application (3-5 business days)</li>
                  <li>We'll contact your insurance provider for pre-authorization</li>
                  <li>You'll be notified of approval status within 7 business days</li>
                  <li>Coverage begins immediately upon approval</li>
                </ul>
              </AlertDescription>
            </Alert>

            <div className="flex justify-center gap-4">
              <Button onClick={() => window.location.href = '/subscription'}>
                Return to Subscription
              </Button>
              <Button variant="outline" onClick={() => window.location.href = '/family-dashboard'}>
                Go to Dashboard
              </Button>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Insurance Coverage Application</h1>
          <p className="text-gray-600">Get your Care Companion services covered by insurance</p>
        </div>

        {/* Progress Bar */}
        {currentStep <= totalSteps && (
          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm font-medium">Step {currentStep} of {totalSteps}</span>
                <span className="text-sm text-gray-600">{Math.round(progressPercentage)}% Complete</span>
              </div>
              <Progress value={progressPercentage} className="h-2" />
            </CardContent>
          </Card>
        )}

        {/* Main Content */}
        <Card className="mb-8">
          <CardContent className="p-8">
            {renderStep()}
          </CardContent>
        </Card>

        {/* Navigation */}
        {currentStep <= totalSteps && (
          <div className="flex justify-between">
            <Button
              onClick={prevStep}
              disabled={currentStep === 1}
              variant="outline"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Previous
            </Button>

            <Button
              onClick={nextStep}
              disabled={currentStep === totalSteps}
            >
              Next
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        )}

        {/* Support Information */}
        <Alert className="mt-8">
          <Phone className="h-4 w-4" />
          <AlertDescription>
            <strong>Need Help?</strong> Our insurance specialists are available to assist you.
            <br />
            Call: 1-800-CARE-INSURANCE | Email: insurance@carecompanion.com
          </AlertDescription>
        </Alert>
      </div>
    </div>
  );
}