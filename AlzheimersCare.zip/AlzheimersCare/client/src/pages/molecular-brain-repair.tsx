import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Brain, Dna, Zap, Activity, ShieldCheck, Target, Microscope, Atom } from 'lucide-react';

interface MolecularRepair {
  id: string;
  targetRegion: string;
  repairType: 'protein_folding' | 'synaptic_reconstruction' | 'neurogenesis' | 'myelin_repair';
  progress: number;
  molecularTargets: string[];
  biomarkers: {
    amyloidBeta: number;
    tau: number;
    neuroinflammation: number;
    synapticDensity: number;
  };
  therapeuticModalities: string[];
  efficacyScore: number;
}

interface NanoBot {
  id: string;
  type: 'targeting' | 'repair' | 'clearance' | 'monitoring';
  location: string;
  status: 'active' | 'deployed' | 'recharging' | 'completed';
  payload: string;
  batteryLevel: number;
  mission: string;
}

interface BrainRegion {
  name: string;
  healthScore: number;
  repairProgress: number;
  molecularActivity: number;
  targetedTherapies: number;
  neuroplasticityIndex: number;
}

export default function MolecularBrainRepair() {
  const [selectedPatient] = useState(1);
  const [repairSessions, setRepairSessions] = useState<MolecularRepair[]>([]);
  const [nanoBots, setNanoBots] = useState<NanoBot[]>([]);
  const [brainRegions, setBrainRegions] = useState<BrainRegion[]>([]);
  const [activeTab, setActiveTab] = useState('molecular-repair');

  useEffect(() => {
    // Initialize molecular repair data
    setRepairSessions([
      {
        id: 'repair-001',
        targetRegion: 'Hippocampus',
        repairType: 'synaptic_reconstruction',
        progress: 78,
        molecularTargets: ['AMPA receptors', 'NMDA receptors', 'Dendritic spines'],
        biomarkers: {
          amyloidBeta: 342,
          tau: 181,
          neuroinflammation: 23,
          synapticDensity: 87
        },
        therapeuticModalities: ['Targeted drug delivery', 'Gene therapy', 'Stem cell activation'],
        efficacyScore: 94
      },
      {
        id: 'repair-002',
        targetRegion: 'Prefrontal Cortex',
        repairType: 'protein_folding',
        progress: 65,
        molecularTargets: ['Misfolded proteins', 'Chaperone proteins', 'Proteasome system'],
        biomarkers: {
          amyloidBeta: 289,
          tau: 156,
          neuroinflammation: 18,
          synapticDensity: 82
        },
        therapeuticModalities: ['Molecular chaperones', 'Autophagy enhancement', 'Protein clearance'],
        efficacyScore: 89
      },
      {
        id: 'repair-003',
        targetRegion: 'Temporal Lobe',
        repairType: 'neurogenesis',
        progress: 42,
        molecularTargets: ['Neural stem cells', 'Growth factors', 'Signaling pathways'],
        biomarkers: {
          amyloidBeta: 412,
          tau: 203,
          neuroinflammation: 31,
          synapticDensity: 73
        },
        therapeuticModalities: ['Stem cell therapy', 'Growth factor delivery', 'Scaffolding proteins'],
        efficacyScore: 76
      }
    ]);

    setNanoBots([
      {
        id: 'nb-001',
        type: 'targeting',
        location: 'Blood-brain barrier',
        status: 'active',
        payload: 'Anti-amyloid antibodies',
        batteryLevel: 92,
        mission: 'Cross BBB and target amyloid plaques'
      },
      {
        id: 'nb-002',
        type: 'repair',
        location: 'Hippocampal CA1',
        status: 'deployed',
        payload: 'Synaptic repair proteins',
        batteryLevel: 78,
        mission: 'Reconstruct damaged synapses'
      },
      {
        id: 'nb-003',
        type: 'clearance',
        location: 'Cortical regions',
        status: 'active',
        payload: 'Proteolytic enzymes',
        batteryLevel: 85,
        mission: 'Clear protein aggregates'
      },
      {
        id: 'nb-004',
        type: 'monitoring',
        location: 'Cerebrospinal fluid',
        status: 'recharging',
        payload: 'Biosensors',
        batteryLevel: 23,
        mission: 'Monitor biomarker levels'
      }
    ]);

    setBrainRegions([
      {
        name: 'Hippocampus',
        healthScore: 73,
        repairProgress: 78,
        molecularActivity: 92,
        targetedTherapies: 5,
        neuroplasticityIndex: 85
      },
      {
        name: 'Prefrontal Cortex',
        healthScore: 68,
        repairProgress: 65,
        molecularActivity: 88,
        targetedTherapies: 4,
        neuroplasticityIndex: 79
      },
      {
        name: 'Temporal Lobe',
        healthScore: 61,
        repairProgress: 42,
        molecularActivity: 76,
        targetedTherapies: 3,
        neuroplasticityIndex: 71
      },
      {
        name: 'Parietal Lobe',
        healthScore: 75,
        repairProgress: 58,
        molecularActivity: 83,
        targetedTherapies: 3,
        neuroplasticityIndex: 82
      },
      {
        name: 'Occipital Lobe',
        healthScore: 81,
        repairProgress: 35,
        molecularActivity: 71,
        targetedTherapies: 2,
        neuroplasticityIndex: 77
      }
    ]);
  }, [selectedPatient]);

  const getRepairTypeColor = (type: string) => {
    switch (type) {
      case 'protein_folding': return 'bg-blue-500';
      case 'synaptic_reconstruction': return 'bg-green-500';
      case 'neurogenesis': return 'bg-purple-500';
      case 'myelin_repair': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  const getNanoBotStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-600';
      case 'deployed': return 'text-blue-600';
      case 'recharging': return 'text-yellow-600';
      case 'completed': return 'text-gray-600';
      default: return 'text-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 care-gradient rounded-xl flex items-center justify-center">
                <Atom className="text-white h-6 w-6" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Molecular Brain Repair</h1>
                <p className="text-sm text-gray-500">Advanced cellular-level therapeutic interventions</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-600">Patient ID: {selectedPatient}</p>
                <p className="text-xs text-gray-500">Molecular Therapy Session</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="molecular-repair">Molecular Repair</TabsTrigger>
            <TabsTrigger value="nanobots">NanoBot Fleet</TabsTrigger>
            <TabsTrigger value="brain-regions">Brain Regions</TabsTrigger>
            <TabsTrigger value="biomarkers">Biomarkers</TabsTrigger>
          </TabsList>

          {/* Molecular Repair Tab */}
          <TabsContent value="molecular-repair" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {repairSessions.map((session) => (
                <Card key={session.id} className="border-l-4 border-l-blue-500">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center">
                        <Brain className="mr-2 h-5 w-5 text-blue-600" />
                        {session.targetRegion}
                      </CardTitle>
                      <Badge className={`${getRepairTypeColor(session.repairType)} text-white`}>
                        {session.repairType.replace('_', ' ')}
                      </Badge>
                    </div>
                    <CardDescription>
                      Efficacy Score: {session.efficacyScore}%
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Repair Progress</span>
                        <span>{session.progress}%</span>
                      </div>
                      <Progress value={session.progress} className="h-2" />
                    </div>

                    <div>
                      <h4 className="font-semibold text-sm mb-2">Molecular Targets</h4>
                      <div className="flex flex-wrap gap-1">
                        {session.molecularTargets.map((target, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {target}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-sm mb-2">Therapeutic Modalities</h4>
                      <div className="space-y-1">
                        {session.therapeuticModalities.map((modality, index) => (
                          <div key={index} className="flex items-center text-xs">
                            <Target className="mr-1 h-3 w-3 text-green-500" />
                            {modality}
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Alert>
              <Microscope className="h-4 w-4" />
              <AlertDescription>
                Molecular repair protocols are targeting specific cellular dysfunction patterns 
                with precision delivery systems ensuring minimal off-target effects.
              </AlertDescription>
            </Alert>
          </TabsContent>

          {/* NanoBot Fleet Tab */}
          <TabsContent value="nanobots" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {nanoBots.map((bot) => (
                <Card key={bot.id} className="border-t-4 border-t-cyan-500">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center">
                      <Zap className="mr-2 h-4 w-4 text-cyan-600" />
                      {bot.id.toUpperCase()}
                    </CardTitle>
                    <CardDescription className="text-xs">
                      {bot.type.replace('_', ' ')}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>Battery Level</span>
                        <span>{bot.batteryLevel}%</span>
                      </div>
                      <Progress value={bot.batteryLevel} className="h-1" />
                    </div>

                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Status:</span>
                        <span className={`font-medium ${getNanoBotStatusColor(bot.status)}`}>
                          {bot.status}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Location:</span>
                        <span className="font-medium">{bot.location}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Payload:</span>
                        <span className="font-medium">{bot.payload}</span>
                      </div>
                    </div>

                    <div className="text-xs">
                      <span className="text-gray-500">Mission:</span>
                      <p className="mt-1 text-gray-800">{bot.mission}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Fleet Command Center</CardTitle>
                <CardDescription>Real-time nanobot coordination and mission control</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {nanoBots.filter(bot => bot.status === 'active').length}
                    </div>
                    <div className="text-sm text-gray-500">Active Bots</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      {nanoBots.filter(bot => bot.status === 'deployed').length}
                    </div>
                    <div className="text-sm text-gray-500">Deployed Bots</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-600">
                      {Math.round(nanoBots.reduce((acc, bot) => acc + bot.batteryLevel, 0) / nanoBots.length)}%
                    </div>
                    <div className="text-sm text-gray-500">Avg Battery</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Brain Regions Tab */}
          <TabsContent value="brain-regions" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {brainRegions.map((region, index) => (
                <Card key={index} className="border-l-4 border-l-purple-500">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span className="flex items-center">
                        <Brain className="mr-2 h-5 w-5 text-purple-600" />
                        {region.name}
                      </span>
                      <Badge variant={region.healthScore > 70 ? "default" : "destructive"}>
                        {region.healthScore}% Health
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-xs text-gray-500 mb-1">Repair Progress</div>
                        <div className="flex items-center">
                          <Progress value={region.repairProgress} className="h-2 flex-1 mr-2" />
                          <span className="text-xs font-medium">{region.repairProgress}%</span>
                        </div>
                      </div>
                      <div>
                        <div className="text-xs text-gray-500 mb-1">Molecular Activity</div>
                        <div className="flex items-center">
                          <Progress value={region.molecularActivity} className="h-2 flex-1 mr-2" />
                          <span className="text-xs font-medium">{region.molecularActivity}%</span>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div>
                        <div className="text-lg font-bold text-blue-600">{region.targetedTherapies}</div>
                        <div className="text-xs text-gray-500">Active Therapies</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-green-600">{region.neuroplasticityIndex}</div>
                        <div className="text-xs text-gray-500">Plasticity Index</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Biomarkers Tab */}
          <TabsContent value="biomarkers" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {repairSessions.map((session) => (
                <Card key={session.id} className="border-l-4 border-l-green-500">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Activity className="mr-2 h-5 w-5 text-green-600" />
                      {session.targetRegion} Biomarkers
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 bg-blue-50 rounded-lg">
                        <div className="text-lg font-bold text-blue-600">{session.biomarkers.amyloidBeta}</div>
                        <div className="text-xs text-gray-500">Amyloid-β (pg/mL)</div>
                      </div>
                      <div className="text-center p-3 bg-red-50 rounded-lg">
                        <div className="text-lg font-bold text-red-600">{session.biomarkers.tau}</div>
                        <div className="text-xs text-gray-500">Tau (pg/mL)</div>
                      </div>
                      <div className="text-center p-3 bg-orange-50 rounded-lg">
                        <div className="text-lg font-bold text-orange-600">{session.biomarkers.neuroinflammation}</div>
                        <div className="text-xs text-gray-500">Neuroinflammation</div>
                      </div>
                      <div className="text-center p-3 bg-green-50 rounded-lg">
                        <div className="text-lg font-bold text-green-600">{session.biomarkers.synapticDensity}</div>
                        <div className="text-xs text-gray-500">Synaptic Density</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Alert>
              <ShieldCheck className="h-4 w-4" />
              <AlertDescription>
                Biomarker levels are being continuously monitored through implanted nanosensors 
                providing real-time feedback on therapeutic efficacy and cellular health status.
              </AlertDescription>
            </Alert>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}