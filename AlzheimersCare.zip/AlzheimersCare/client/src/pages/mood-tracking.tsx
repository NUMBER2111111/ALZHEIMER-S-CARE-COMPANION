import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Heart, Brain, Users, Moon, Zap, Shield, MessageCircle, TrendingUp, Calendar, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

const moodStates = [
  { value: 'happy', label: 'Happy', color: 'bg-green-500', icon: '😊' },
  { value: 'content', label: 'Content', color: 'bg-blue-500', icon: '😌' },
  { value: 'neutral', label: 'Neutral', color: 'bg-gray-500', icon: '😐' },
  { value: 'sad', label: 'Sad', color: 'bg-blue-600', icon: '😢' },
  { value: 'anxious', label: 'Anxious', color: 'bg-yellow-500', icon: '😰' },
  { value: 'frustrated', label: 'Frustrated', color: 'bg-orange-500', icon: '😤' },
  { value: 'confused', label: 'Confused', color: 'bg-purple-500', icon: '😕' },
  { value: 'excited', label: 'Excited', color: 'bg-pink-500', icon: '🤗' },
];

interface MoodEntry {
  id: number;
  patientId: number;
  moodState: string;
  energyLevel: number;
  anxietyLevel: number;
  socialEngagement: number;
  cognitiveClarity: number;
  physicalComfort: number;
  notes?: string;
  contextualFactors?: any;
  createdAt: string;
}

interface CompanionResponse {
  id: number;
  moodEntryId: number;
  responseType: string;
  responseText: string;
  empathyLevel: number;
  suggestedActions?: string[];
  personalityTraits?: any;
  userReaction?: string;
  emergencyKeywordsDetected?: string[];
  confidenceScore: string;
  createdAt: string;
}

interface MoodTrend {
  id: number;
  patientId: number;
  trendPeriod: string;
  averageMoodScore: string;
  moodVariability: string;
  dominantMood: string;
  improvementAreas?: string[];
  wellnessRecommendations?: string[];
  trendsAnalysis?: string[];
  calculatedAt: string;
}

export default function MoodTracking() {
  const [selectedMood, setSelectedMood] = useState('');
  const [energyLevel, setEnergyLevel] = useState([5]);
  const [anxietyLevel, setAnxietyLevel] = useState([3]);
  const [socialEngagement, setSocialEngagement] = useState([5]);
  const [cognitiveClarity, setCognitiveClarity] = useState([7]);
  const [physicalComfort, setPhysicalComfort] = useState([6]);
  const [notes, setNotes] = useState('');
  const [activeTab, setActiveTab] = useState('entry');
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const patientId = 1; // Using demo patient ID

  // Fetch mood entries
  const { data: moodEntries = [], isLoading: loadingEntries } = useQuery({
    queryKey: [`/api/patients/${patientId}/mood-entries`],
    enabled: !!patientId
  });

  // Fetch mood trends
  const { data: moodTrends = [], isLoading: loadingTrends } = useQuery({
    queryKey: [`/api/patients/${patientId}/mood-trends`],
    enabled: !!patientId
  });

  // Create mood entry mutation
  const createMoodEntry = useMutation({
    mutationFn: async (moodData: any) => {
      return await apiRequest('POST', '/api/mood/entry', moodData);
    },
    onSuccess: (data) => {
      toast({
        title: "Mood Entry Recorded",
        description: "Your emotional state has been analyzed and a compassionate response is ready.",
        variant: "default",
      });
      
      // Reset form
      setSelectedMood('');
      setEnergyLevel([5]);
      setAnxietyLevel([3]);
      setSocialEngagement([5]);
      setCognitiveClarity([7]);
      setPhysicalComfort([6]);
      setNotes('');
      
      // Refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/patients/${patientId}/mood-entries`] });
      queryClient.invalidateQueries({ queryKey: [`/api/patients/${patientId}/mood-trends`] });
      
      // Switch to history tab to show the AI response
      setActiveTab('history');
    },
    onError: (error) => {
      toast({
        title: "Error Recording Mood",
        description: "Failed to save your mood entry. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Generate mood trends mutation
  const generateTrends = useMutation({
    mutationFn: async (period: string) => {
      return await apiRequest('POST', `/api/patients/${patientId}/mood-trends`, { period });
    },
    onSuccess: () => {
      toast({
        title: "Trends Updated",
        description: "Your mood patterns have been analyzed.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/patients/${patientId}/mood-trends`] });
    }
  });

  const handleSubmitMoodEntry = () => {
    if (!selectedMood) {
      toast({
        title: "Missing Information",
        description: "Please select your current mood state.",
        variant: "destructive",
      });
      return;
    }

    const moodData = {
      patientId,
      moodState: selectedMood,
      energyLevel: energyLevel[0],
      anxietyLevel: anxietyLevel[0],
      socialEngagement: socialEngagement[0],
      cognitiveClarity: cognitiveClarity[0],
      physicalComfort: physicalComfort[0],
      notes: notes.trim() || null,
      contextualFactors: {
        timeOfDay: new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 18 ? 'afternoon' : 'evening',
        dayOfWeek: new Date().toLocaleDateString('en-US', { weekday: 'long' }),
        inputMethod: 'manual'
      }
    };

    createMoodEntry.mutate(moodData);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getMoodColor = (mood: string) => {
    const moodState = moodStates.find(m => m.value === mood);
    return moodState?.color || 'bg-gray-500';
  };

  const getMoodIcon = (mood: string) => {
    const moodState = moodStates.find(m => m.value === mood);
    return moodState?.icon || '😐';
  };

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
          Mood & Emotional Wellness Tracker
        </h1>
        <p className="text-gray-600 dark:text-gray-300">
          Track your emotional state and receive compassionate AI companion feedback
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="entry" className="flex items-center gap-2">
            <Heart className="h-4 w-4" />
            Mood Entry
          </TabsTrigger>
          <TabsTrigger value="history" className="flex items-center gap-2">
            <MessageCircle className="h-4 w-4" />
            AI Companion
          </TabsTrigger>
          <TabsTrigger value="trends" className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Trends & Insights
          </TabsTrigger>
        </TabsList>

        <TabsContent value="entry" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="h-5 w-5 text-red-500" />
                How are you feeling right now?
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Mood State Selection */}
              <div>
                <Label className="text-base font-medium mb-4 block">Select your current mood</Label>
                <div className="grid grid-cols-4 gap-3">
                  {moodStates.map((mood) => (
                    <button
                      key={mood.value}
                      onClick={() => setSelectedMood(mood.value)}
                      className={`p-4 rounded-lg border-2 transition-all ${
                        selectedMood === mood.value
                          ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                          : 'border-gray-200 dark:border-gray-700 hover:border-gray-300'
                      }`}
                    >
                      <div className="text-2xl mb-2">{mood.icon}</div>
                      <div className="text-sm font-medium">{mood.label}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Wellness Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Zap className="h-4 w-4 text-yellow-500" />
                    <Label>Energy Level: {energyLevel[0]}/10</Label>
                  </div>
                  <Slider
                    value={energyLevel}
                    onValueChange={setEnergyLevel}
                    max={10}
                    min={1}
                    step={1}
                    className="w-full"
                  />
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Shield className="h-4 w-4 text-orange-500" />
                    <Label>Anxiety Level: {anxietyLevel[0]}/10</Label>
                  </div>
                  <Slider
                    value={anxietyLevel}
                    onValueChange={setAnxietyLevel}
                    max={10}
                    min={1}
                    step={1}
                    className="w-full"
                  />
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Users className="h-4 w-4 text-green-500" />
                    <Label>Social Connection: {socialEngagement[0]}/10</Label>
                  </div>
                  <Slider
                    value={socialEngagement}
                    onValueChange={setSocialEngagement}
                    max={10}
                    min={1}
                    step={1}
                    className="w-full"
                  />
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Brain className="h-4 w-4 text-purple-500" />
                    <Label>Mental Clarity: {cognitiveClarity[0]}/10</Label>
                  </div>
                  <Slider
                    value={cognitiveClarity}
                    onValueChange={setCognitiveClarity}
                    max={10}
                    min={1}
                    step={1}
                    className="w-full"
                  />
                </div>

                <div className="md:col-span-2">
                  <div className="flex items-center gap-2 mb-3">
                    <Moon className="h-4 w-4 text-blue-500" />
                    <Label>Physical Comfort: {physicalComfort[0]}/10</Label>
                  </div>
                  <Slider
                    value={physicalComfort}
                    onValueChange={setPhysicalComfort}
                    max={10}
                    min={1}
                    step={1}
                    className="w-full"
                  />
                </div>
              </div>

              {/* Notes */}
              <div>
                <Label htmlFor="notes" className="text-base font-medium mb-2 block">
                  Additional thoughts or feelings (optional)
                </Label>
                <Textarea
                  id="notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Describe what's on your mind, any specific concerns, or what's contributing to how you feel..."
                  className="min-h-[100px]"
                />
              </div>

              <Button 
                onClick={handleSubmitMoodEntry}
                disabled={createMoodEntry.isPending || !selectedMood}
                className="w-full"
                size="lg"
              >
                {createMoodEntry.isPending ? 'Recording & Analyzing...' : 'Record Mood Entry'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          {loadingEntries ? (
            <div className="text-center py-8">Loading mood history...</div>
          ) : moodEntries.length === 0 ? (
            <Card>
              <CardContent className="text-center py-8">
                <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 dark:text-gray-300">
                  No mood entries yet. Record your first mood to receive AI companion feedback.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {moodEntries.slice(0, 10).map((entry: MoodEntry) => (
                <MoodEntryCard key={entry.id} entry={entry} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="trends" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold">Mood Patterns & Insights</h3>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                onClick={() => generateTrends.mutate('weekly')}
                disabled={generateTrends.isPending}
              >
                Weekly Analysis
              </Button>
              <Button 
                variant="outline" 
                onClick={() => generateTrends.mutate('monthly')}
                disabled={generateTrends.isPending}
              >
                Monthly Analysis
              </Button>
            </div>
          </div>

          {loadingTrends ? (
            <div className="text-center py-8">Loading trends analysis...</div>
          ) : moodTrends.length === 0 ? (
            <Card>
              <CardContent className="text-center py-8">
                <TrendingUp className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  No trend analysis available yet. Record more mood entries to see patterns.
                </p>
                <Button onClick={() => generateTrends.mutate('weekly')}>
                  Generate Weekly Trends
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {moodTrends.map((trend: MoodTrend) => (
                <TrendCard key={trend.id} trend={trend} />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function MoodEntryCard({ entry }: { entry: MoodEntry }) {
  const [responses, setResponses] = useState<CompanionResponse[]>([]);
  const [loadingResponses, setLoadingResponses] = useState(false);

  useEffect(() => {
    const fetchResponses = async () => {
      setLoadingResponses(true);
      try {
        const result = await apiRequest('GET', `/api/mood-entries/${entry.id}/responses`);
        setResponses(result.responses || []);
      } catch (error) {
        console.error('Failed to fetch companion responses:', error);
      } finally {
        setLoadingResponses(false);
      }
    };

    fetchResponses();
  }, [entry.id]);

  const overallScore = Math.round(
    (entry.energyLevel + entry.socialEngagement + entry.cognitiveClarity + entry.physicalComfort - entry.anxietyLevel) / 4
  );

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="text-2xl">{getMoodIcon(entry.moodState)}</div>
            <div>
              <CardTitle className="capitalize">{entry.moodState}</CardTitle>
              <p className="text-sm text-gray-600 dark:text-gray-400 flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {formatDate(entry.createdAt)}
              </p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-lg font-semibold">Overall: {overallScore}/10</div>
            <Progress value={overallScore * 10} className="w-20" />
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Wellness Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-sm">
          <div className="flex items-center gap-2">
            <Zap className="h-3 w-3 text-yellow-500" />
            <span>Energy: {entry.energyLevel}/10</span>
          </div>
          <div className="flex items-center gap-2">
            <Shield className="h-3 w-3 text-orange-500" />
            <span>Anxiety: {entry.anxietyLevel}/10</span>
          </div>
          <div className="flex items-center gap-2">
            <Users className="h-3 w-3 text-green-500" />
            <span>Social: {entry.socialEngagement}/10</span>
          </div>
          <div className="flex items-center gap-2">
            <Brain className="h-3 w-3 text-purple-500" />
            <span>Clarity: {entry.cognitiveClarity}/10</span>
          </div>
          <div className="flex items-center gap-2">
            <Moon className="h-3 w-3 text-blue-500" />
            <span>Comfort: {entry.physicalComfort}/10</span>
          </div>
        </div>

        {entry.notes && (
          <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg">
            <p className="text-sm italic">"{entry.notes}"</p>
          </div>
        )}

        {/* AI Companion Responses */}
        {loadingResponses ? (
          <div className="text-center py-4 text-sm text-gray-600">Loading AI companion response...</div>
        ) : responses.length > 0 ? (
          <div className="space-y-3">
            {responses.map((response: CompanionResponse) => (
              <div key={response.id} className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border-l-4 border-blue-500">
                <div className="flex items-center gap-2 mb-2">
                  <MessageCircle className="h-4 w-4 text-blue-600" />
                  <span className="text-sm font-medium text-blue-800 dark:text-blue-300">
                    AI Companion Response
                  </span>
                  <Badge variant="outline" className="text-xs">
                    Empathy: {response.empathyLevel}/10
                  </Badge>
                </div>
                <p className="text-blue-900 dark:text-blue-100 mb-3">{response.responseText}</p>
                
                {response.suggestedActions && response.suggestedActions.length > 0 && (
                  <div className="space-y-1">
                    <p className="text-xs font-medium text-blue-800 dark:text-blue-300">Suggested Activities:</p>
                    <ul className="text-xs text-blue-700 dark:text-blue-200 space-y-1">
                      {response.suggestedActions.map((action, index) => (
                        <li key={index} className="flex items-center gap-1">
                          <span className="w-1 h-1 bg-blue-600 rounded-full"></span>
                          {action}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-4 text-sm text-gray-600">No AI companion response available</div>
        )}
      </CardContent>
    </Card>
  );
}

function TrendCard({ trend }: { trend: MoodTrend }) {
  const avgScore = parseFloat(trend.averageMoodScore);
  const variability = parseFloat(trend.moodVariability);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 capitalize">
          <Calendar className="h-5 w-5" />
          {trend.trendPeriod} Mood Analysis
        </CardTitle>
        <p className="text-sm text-gray-600 dark:text-gray-400">
          Calculated on {formatDate(trend.calculatedAt)}
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
            <div className="text-2xl font-bold text-green-700 dark:text-green-300">
              {avgScore.toFixed(1)}/10
            </div>
            <div className="text-sm text-green-600 dark:text-green-400">Average Mood</div>
          </div>
          <div className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <div className="text-2xl font-bold text-blue-700 dark:text-blue-300 capitalize">
              {trend.dominantMood}
            </div>
            <div className="text-sm text-blue-600 dark:text-blue-400">Dominant Mood</div>
          </div>
          <div className="text-center p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
            <div className="text-2xl font-bold text-purple-700 dark:text-purple-300">
              {variability < 2 ? 'Low' : variability < 4 ? 'Moderate' : 'High'}
            </div>
            <div className="text-sm text-purple-600 dark:text-purple-400">Variability</div>
          </div>
        </div>

        {trend.improvementAreas && trend.improvementAreas.length > 0 && (
          <div>
            <h4 className="font-medium mb-2 text-orange-700 dark:text-orange-300">Areas for Improvement</h4>
            <ul className="space-y-1">
              {trend.improvementAreas.map((area, index) => (
                <li key={index} className="text-sm flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-orange-500 rounded-full"></span>
                  {area}
                </li>
              ))}
            </ul>
          </div>
        )}

        {trend.wellnessRecommendations && trend.wellnessRecommendations.length > 0 && (
          <div>
            <h4 className="font-medium mb-2 text-green-700 dark:text-green-300">Wellness Recommendations</h4>
            <ul className="space-y-1">
              {trend.wellnessRecommendations.map((rec, index) => (
                <li key={index} className="text-sm flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
                  {rec}
                </li>
              ))}
            </ul>
          </div>
        )}

        {trend.trendsAnalysis && trend.trendsAnalysis.length > 0 && (
          <div>
            <h4 className="font-medium mb-2 text-blue-700 dark:text-blue-300">Key Insights</h4>
            <ul className="space-y-1">
              {trend.trendsAnalysis.map((insight, index) => (
                <li key={index} className="text-sm flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                  {insight}
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
}