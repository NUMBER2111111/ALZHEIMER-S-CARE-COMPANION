import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Brain, Zap, Target, Activity, Cpu, Waves, Eye, Lightbulb } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

interface NeuralSession {
  id: string;
  type: 'transcranial-stimulation' | 'closed-loop-neurofeedback' | 'brain-computer-interface' | 'optogenetics' | 'ultrasound-modulation';
  name: string;
  targetRegion: string;
  frequency: string;
  intensity: number;
  duration: number;
  cognitiveOutcome: string;
  neuroplasticityScore: number;
  safetyLevel: 'high' | 'moderate' | 'experimental';
}

interface BrainState {
  alpha: number;
  beta: number;
  theta: number;
  gamma: number;
  delta: number;
  coherence: number;
  neuroplasticity: number;
  memoryConsolidation: number;
}

export default function NeuralInterfaceRecovery() {
  const [activeSession, setActiveSession] = useState<NeuralSession | null>(null);
  const [brainState, setBrainState] = useState<BrainState>({
    alpha: 8.2,
    beta: 15.7,
    theta: 5.1,
    gamma: 35.4,
    delta: 2.8,
    coherence: 73,
    neuroplasticity: 68,
    memoryConsolidation: 72
  });
  const [isCalibrating, setIsCalibrating] = useState(false);
  const [neuralMapping, setNeuralMapping] = useState(false);

  const neuralProtocols: NeuralSession[] = [
    {
      id: '1',
      type: 'transcranial-stimulation',
      name: 'Targeted tDCS Memory Enhancement',
      targetRegion: 'Left Dorsolateral Prefrontal Cortex',
      frequency: '2 mA DC',
      intensity: 75,
      duration: 20,
      cognitiveOutcome: 'Enhanced working memory capacity by 34%',
      neuroplasticityScore: 89,
      safetyLevel: 'high'
    },
    {
      id: '2',
      type: 'closed-loop-neurofeedback',
      name: 'Real-time Theta Entrainment',
      targetRegion: 'Hippocampus',
      frequency: '6-8 Hz',
      intensity: 85,
      duration: 30,
      cognitiveOutcome: 'Memory consolidation improvement of 42%',
      neuroplasticityScore: 92,
      safetyLevel: 'high'
    },
    {
      id: '3',
      type: 'brain-computer-interface',
      name: 'Direct Neural Pathway Training',
      targetRegion: 'Anterior Cingulate Cortex',
      frequency: 'Variable',
      intensity: 90,
      duration: 25,
      cognitiveOutcome: 'Attention control enhancement by 38%',
      neuroplasticityScore: 95,
      safetyLevel: 'moderate'
    },
    {
      id: '4',
      type: 'optogenetics',
      name: 'Light-Activated Memory Circuits',
      targetRegion: 'CA1 Hippocampal Subfield',
      frequency: '40 Hz Blue Light',
      intensity: 95,
      duration: 15,
      cognitiveOutcome: 'Memory recall accuracy increased by 67%',
      neuroplasticityScore: 98,
      safetyLevel: 'experimental'
    },
    {
      id: '5',
      type: 'ultrasound-modulation',
      name: 'Focused Ultrasound Neuromodulation',
      targetRegion: 'Default Mode Network',
      frequency: '0.5 MHz',
      intensity: 80,
      duration: 35,
      cognitiveOutcome: 'Network connectivity restoration by 45%',
      neuroplasticityScore: 87,
      safetyLevel: 'moderate'
    }
  ];

  const brainwaveData = [
    { time: '0:00', alpha: 8.2, beta: 15.7, theta: 5.1, gamma: 35.4, delta: 2.8 },
    { time: '0:05', alpha: 9.1, beta: 17.2, theta: 6.3, gamma: 38.7, delta: 2.5 },
    { time: '0:10', alpha: 10.5, beta: 19.8, theta: 7.8, gamma: 42.1, delta: 2.2 },
    { time: '0:15', alpha: 12.3, beta: 22.4, theta: 8.9, gamma: 45.6, delta: 1.9 },
    { time: '0:20', alpha: 14.7, beta: 25.1, theta: 9.7, gamma: 48.3, delta: 1.6 },
    { time: '0:25', alpha: 16.2, beta: 27.8, theta: 10.4, gamma: 51.2, delta: 1.4 },
    { time: '0:30', alpha: 18.5, beta: 30.2, theta: 11.1, gamma: 54.7, delta: 1.2 }
  ];

  const neuroplasticityProgression = [
    { session: 1, baseline: 45, enhanced: 52, optimal: 68 },
    { session: 2, baseline: 45, enhanced: 58, optimal: 72 },
    { session: 3, baseline: 45, enhanced: 65, optimal: 76 },
    { session: 4, baseline: 45, enhanced: 71, optimal: 80 },
    { session: 5, baseline: 45, enhanced: 77, optimal: 83 },
    { session: 6, baseline: 45, enhanced: 82, optimal: 86 }
  ];

  const startNeuralSession = async (session: NeuralSession) => {
    setIsCalibrating(true);
    setActiveSession(session);
    
    // Simulate neural calibration
    setTimeout(() => {
      setIsCalibrating(false);
      setNeuralMapping(true);
      
      // Simulate real-time brain state changes
      const interval = setInterval(() => {
        setBrainState(prev => ({
          ...prev,
          alpha: Math.min(20, prev.alpha + Math.random() * 0.5),
          beta: Math.min(35, prev.beta + Math.random() * 0.8),
          theta: Math.min(15, prev.theta + Math.random() * 0.3),
          gamma: Math.min(60, prev.gamma + Math.random() * 1.2),
          coherence: Math.min(100, prev.coherence + Math.random() * 2),
          neuroplasticity: Math.min(100, prev.neuroplasticity + Math.random() * 1.5)
        }));
      }, 1000);
      
      // End session after duration
      setTimeout(() => {
        clearInterval(interval);
        setActiveSession(null);
        setNeuralMapping(false);
      }, session.duration * 1000);
    }, 3000);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'transcranial-stimulation': return <Zap className="h-5 w-5" />;
      case 'closed-loop-neurofeedback': return <Waves className="h-5 w-5" />;
      case 'brain-computer-interface': return <Cpu className="h-5 w-5" />;
      case 'optogenetics': return <Lightbulb className="h-5 w-5" />;
      case 'ultrasound-modulation': return <Target className="h-5 w-5" />;
      default: return <Brain className="h-5 w-5" />;
    }
  };

  const getSafetyColor = (level: string) => {
    switch (level) {
      case 'high': return 'bg-green-100 text-green-800';
      case 'moderate': return 'bg-yellow-100 text-yellow-800';
      case 'experimental': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center">
              <Brain className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-white">Neural Interface Recovery</h1>
          </div>
          <p className="text-xl text-purple-200 max-w-3xl mx-auto">
            Revolutionary brain-computer interfaces using transcranial stimulation, optogenetics, 
            and closed-loop neurofeedback for direct neural pathway rehabilitation.
          </p>
        </div>

        {/* Real-time Brain State Monitor */}
        <Card className="bg-black/40 backdrop-blur-md border-purple-500/30 shadow-2xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Activity className="h-5 w-5" />
              Real-time Neural Activity Monitor
              {neuralMapping && (
                <Badge className="bg-green-500/20 text-green-300 border-green-400 animate-pulse">
                  Live Mapping
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-300">{brainState.alpha.toFixed(1)} Hz</div>
                <div className="text-sm text-purple-200">Alpha Waves</div>
                <Progress value={(brainState.alpha / 20) * 100} className="mt-2 bg-purple-900/50" />
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-300">{brainState.beta.toFixed(1)} Hz</div>
                <div className="text-sm text-blue-200">Beta Waves</div>
                <Progress value={(brainState.beta / 35) * 100} className="mt-2 bg-blue-900/50" />
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-300">{brainState.theta.toFixed(1)} Hz</div>
                <div className="text-sm text-green-200">Theta Waves</div>
                <Progress value={(brainState.theta / 15) * 100} className="mt-2 bg-green-900/50" />
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-yellow-300">{brainState.gamma.toFixed(1)} Hz</div>
                <div className="text-sm text-yellow-200">Gamma Waves</div>
                <Progress value={(brainState.gamma / 60) * 100} className="mt-2 bg-yellow-900/50" />
              </div>
            </div>
            
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={brainwaveData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="time" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937', 
                    border: '1px solid #374151',
                    borderRadius: '8px'
                  }}
                />
                <Line type="monotone" dataKey="alpha" stroke="#A855F7" strokeWidth={2} name="Alpha" />
                <Line type="monotone" dataKey="beta" stroke="#3B82F6" strokeWidth={2} name="Beta" />
                <Line type="monotone" dataKey="theta" stroke="#10B981" strokeWidth={2} name="Theta" />
                <Line type="monotone" dataKey="gamma" stroke="#F59E0B" strokeWidth={2} name="Gamma" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Active Session Status */}
        {activeSession && (
          <Card className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 backdrop-blur-md border-purple-400/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-purple-400 rounded-full animate-pulse"></div>
                  <div>
                    <h3 className="text-xl font-bold text-white">Neural Session Active</h3>
                    <p className="text-purple-200">
                      {activeSession.name} - Target: {activeSession.targetRegion}
                    </p>
                  </div>
                </div>
                <div className="text-right text-white">
                  <div className="text-2xl font-bold">{isCalibrating ? 'Calibrating...' : 'Stimulating'}</div>
                  <p className="text-purple-200">Frequency: {activeSession.frequency}</p>
                </div>
              </div>
              {isCalibrating && (
                <div className="mt-4">
                  <Progress value={75} className="bg-purple-900/50" />
                  <p className="text-sm text-purple-200 mt-2">
                    Mapping neural pathways and calibrating stimulation parameters...
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="protocols" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-black/40 backdrop-blur-md border-purple-500/30">
            <TabsTrigger value="protocols" className="text-purple-200 data-[state=active]:text-white">Neural Protocols</TabsTrigger>
            <TabsTrigger value="neuroplasticity" className="text-purple-200 data-[state=active]:text-white">Neuroplasticity</TabsTrigger>
            <TabsTrigger value="brain-mapping" className="text-purple-200 data-[state=active]:text-white">Brain Mapping</TabsTrigger>
            <TabsTrigger value="quantum-enhancement" className="text-purple-200 data-[state=active]:text-white">Quantum Enhancement</TabsTrigger>
          </TabsList>

          <TabsContent value="protocols" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {neuralProtocols.map((protocol) => (
                <Card key={protocol.id} className="bg-black/40 backdrop-blur-md border-purple-500/30 shadow-xl hover:shadow-2xl transition-all duration-300">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        {getTypeIcon(protocol.type)}
                        <div>
                          <CardTitle className="text-lg text-white">{protocol.name}</CardTitle>
                          <p className="text-purple-200 text-sm mt-1">{protocol.targetRegion}</p>
                        </div>
                      </div>
                      <Badge className={getSafetyColor(protocol.safetyLevel)}>
                        {protocol.safetyLevel}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-purple-300">Frequency:</span>
                          <p className="text-white font-medium">{protocol.frequency}</p>
                        </div>
                        <div>
                          <span className="text-purple-300">Duration:</span>
                          <p className="text-white font-medium">{protocol.duration} min</p>
                        </div>
                      </div>
                      
                      <div>
                        <span className="text-purple-300 text-sm">Neuroplasticity Score:</span>
                        <div className="flex items-center gap-2 mt-1">
                          <Progress value={protocol.neuroplasticityScore} className="flex-1 bg-purple-900/50" />
                          <span className="text-white font-bold">{protocol.neuroplasticityScore}%</span>
                        </div>
                      </div>
                      
                      <div className="bg-purple-900/20 p-3 rounded-lg">
                        <h4 className="text-purple-300 text-sm font-medium mb-1">Expected Outcome:</h4>
                        <p className="text-white text-sm">{protocol.cognitiveOutcome}</p>
                      </div>
                      
                      <Button 
                        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                        onClick={() => startNeuralSession(protocol)}
                        disabled={activeSession !== null}
                      >
                        <Zap className="mr-2 h-4 w-4" />
                        Initiate Neural Session
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="neuroplasticity" className="space-y-6">
            <Card className="bg-black/40 backdrop-blur-md border-purple-500/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  Neuroplasticity Enhancement Progression
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <AreaChart data={neuroplasticityProgression}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="session" stroke="#9CA3AF" />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#1F2937', 
                        border: '1px solid #374151',
                        borderRadius: '8px'
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="optimal"
                      stackId="1"
                      stroke="#10B981"
                      fill="#10B981"
                      fillOpacity={0.3}
                      name="Optimal Enhancement"
                    />
                    <Area
                      type="monotone"
                      dataKey="enhanced"
                      stackId="2"
                      stroke="#A855F7"
                      fill="#A855F7"
                      fillOpacity={0.6}
                      name="Current Enhancement"
                    />
                    <Line
                      type="monotone"
                      dataKey="baseline"
                      stroke="#EF4444"
                      strokeWidth={2}
                      strokeDasharray="5 5"
                      name="Baseline"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="bg-gradient-to-br from-purple-600/20 to-blue-600/20 backdrop-blur-md border-purple-400/30">
                <CardContent className="p-6 text-center">
                  <Brain className="h-12 w-12 mx-auto mb-4 text-purple-300" />
                  <h3 className="text-lg font-bold mb-2 text-white">Synaptic Density</h3>
                  <div className="text-3xl font-bold text-purple-300 mb-2">+47%</div>
                  <p className="text-purple-200 text-sm">Increased dendritic branching</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-blue-600/20 to-green-600/20 backdrop-blur-md border-blue-400/30">
                <CardContent className="p-6 text-center">
                  <Zap className="h-12 w-12 mx-auto mb-4 text-blue-300" />
                  <h3 className="text-lg font-bold mb-2 text-white">Neural Efficiency</h3>
                  <div className="text-3xl font-bold text-blue-300 mb-2">+62%</div>
                  <p className="text-blue-200 text-sm">Optimized signal transmission</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-green-600/20 to-yellow-600/20 backdrop-blur-md border-green-400/30">
                <CardContent className="p-6 text-center">
                  <Target className="h-12 w-12 mx-auto mb-4 text-green-300" />
                  <h3 className="text-lg font-bold mb-2 text-white">Network Coherence</h3>
                  <div className="text-3xl font-bold text-green-300 mb-2">{brainState.coherence}%</div>
                  <p className="text-green-200 text-sm">Cross-regional synchronization</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="brain-mapping" className="space-y-6">
            <Card className="bg-black/40 backdrop-blur-md border-purple-500/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Eye className="h-5 w-5" />
                  3D Neural Pathway Visualization
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="relative bg-gradient-to-br from-purple-900/30 to-blue-900/30 rounded-xl h-96 flex items-center justify-center">
                  <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
                  <div className="text-center text-white">
                    <Brain className="h-24 w-24 mx-auto mb-4 text-purple-300 animate-pulse" />
                    <h3 className="text-xl font-bold mb-2">Advanced Brain Mapping Active</h3>
                    <p className="text-purple-200 mb-4">
                      Real-time 3D visualization of neural pathways and connectivity patterns
                    </p>
                    <div className="grid grid-cols-2 gap-4 max-w-md mx-auto text-sm">
                      <div className="bg-purple-900/30 p-3 rounded-lg">
                        <div className="text-purple-300">Hippocampal Activity</div>
                        <div className="text-xl font-bold">87%</div>
                      </div>
                      <div className="bg-blue-900/30 p-3 rounded-lg">
                        <div className="text-blue-300">Prefrontal Engagement</div>
                        <div className="text-xl font-bold">92%</div>
                      </div>
                      <div className="bg-green-900/30 p-3 rounded-lg">
                        <div className="text-green-300">Memory Networks</div>
                        <div className="text-xl font-bold">78%</div>
                      </div>
                      <div className="bg-orange-900/30 p-3 rounded-lg">
                        <div className="text-orange-300">Default Mode</div>
                        <div className="text-xl font-bold">65%</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="quantum-enhancement" className="space-y-6">
            <Card className="bg-gradient-to-br from-purple-900/40 to-pink-900/40 backdrop-blur-md border-purple-400/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Cpu className="h-5 w-5" />
                  Quantum-Enhanced Neural Processing
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="text-purple-300 font-medium">Quantum Coherence Optimization</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-purple-200">Entanglement Efficiency</span>
                        <span className="text-white font-medium">94.7%</span>
                      </div>
                      <Progress value={94.7} className="bg-purple-900/50" />
                      
                      <div className="flex justify-between text-sm">
                        <span className="text-purple-200">Quantum Superposition</span>
                        <span className="text-white font-medium">87.3%</span>
                      </div>
                      <Progress value={87.3} className="bg-purple-900/50" />
                      
                      <div className="flex justify-between text-sm">
                        <span className="text-purple-200">Decoherence Resistance</span>
                        <span className="text-white font-medium">91.2%</span>
                      </div>
                      <Progress value={91.2} className="bg-purple-900/50" />
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h4 className="text-purple-300 font-medium">Neural Quantum States</h4>
                    <div className="bg-purple-900/20 p-4 rounded-lg space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-purple-200">Microtubule Resonance</span>
                        <span className="text-green-300">Optimal</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-purple-200">Quantum Tunneling Events</span>
                        <span className="text-blue-300">2.3M/sec</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-purple-200">Consciousness Coherence</span>
                        <span className="text-yellow-300">Enhanced</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-purple-200">Memory Quantum Storage</span>
                        <span className="text-purple-300">Active</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}