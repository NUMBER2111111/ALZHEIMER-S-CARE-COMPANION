import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import AudioSetupPrompt from '@/components/audio-setup-prompt';
import { 
  Volume2, 
  Mic, 
  Headphones, 
  Speaker, 
  Settings, 
  CheckCircle, 
  AlertCircle,
  ArrowLeft,
  PlayCircle,
  Brain,
  Heart,
  Zap,
  Smartphone,
  Wifi,
  Star
} from 'lucide-react';
import { Link } from 'wouter';

export default function AudioExperienceGuide() {
  const [audioSetupComplete, setAudioSetupComplete] = useState(false);
  const [activeTab, setActiveTab] = useState('options');
  const [selectedOption, setSelectedOption] = useState('alexa');
  const [testResults, setTestResults] = useState({
    microphone: false,
    speakers: false,
    voiceRecognition: false
  });

  const handleAudioTest = async (type: 'microphone' | 'speakers' | 'voiceRecognition') => {
    try {
      if (type === 'microphone') {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        setTestResults(prev => ({ ...prev, microphone: true }));
        stream.getTracks().forEach(track => track.stop());
      } else if (type === 'speakers') {
        // Test speaker functionality
        const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvGMbBDOE1+zUfS0EKHzAytGBNAcNYrPl+q5YFgdCz96uYRUCHWfK5a5qHgYUHLPl8qhTEgdH++zPcy8FJH3H8+CQQwsVY7Pp6q5TFAlHm+D3vmEXAy2Dzu7TfTMELHfD8N+QQgkRXrHr7qJZHgOKPpzh+q1ZGgZBnN31wmUUBlKp4fqfOhAGWLLn6atT');
        audio.play().then(() => {
          setTestResults(prev => ({ ...prev, speakers: true }));
        });
      } else if (type === 'voiceRecognition') {
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
          setTestResults(prev => ({ ...prev, voiceRecognition: true }));
        }
      }
    } catch (error) {
      console.error(`${type} test failed:`, error);
    }
  };

  const requirements = [
    {
      icon: <Mic className="h-6 w-6 text-blue-600" />,
      title: "Microphone Access",
      description: "Enable microphone permissions for voice interaction with your AI companion",
      status: testResults.microphone ? "complete" : "pending",
      action: () => handleAudioTest('microphone')
    },
    {
      icon: <Speaker className="h-6 w-6 text-green-600" />,
      title: "Speaker Output",
      description: "Ensure speakers or headphones are connected for AI voice responses",
      status: testResults.speakers ? "complete" : "pending",
      action: () => handleAudioTest('speakers')
    },
    {
      icon: <Brain className="h-6 w-6 text-purple-600" />,
      title: "Voice Recognition",
      description: "Browser support for speech-to-text conversion",
      status: testResults.voiceRecognition ? "complete" : "pending",
      action: () => handleAudioTest('voiceRecognition')
    }
  ];

  const browserCompatibility = [
    { browser: "Chrome", supported: true, notes: "Full support for all voice features" },
    { browser: "Firefox", supported: true, notes: "Good support, some limitations" },
    { browser: "Safari", supported: true, notes: "Basic support, requires user interaction" },
    { browser: "Edge", supported: true, notes: "Full support for all voice features" }
  ];

  const troubleshootingSteps = [
    {
      issue: "Microphone not working",
      solutions: [
        "Check browser permissions in settings",
        "Ensure microphone is not muted",
        "Try refreshing the page",
        "Check system audio settings"
      ]
    },
    {
      issue: "No AI voice response",
      solutions: [
        "Check speaker/headphone connection",
        "Increase system volume",
        "Test audio with other applications",
        "Clear browser cache and cookies"
      ]
    },
    {
      issue: "Voice recognition errors",
      solutions: [
        "Speak clearly and at normal pace",
        "Reduce background noise",
        "Check internet connection",
        "Try using Chrome browser for best results"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Audio Setup Modal */}
      {!audioSetupComplete && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="max-w-lg w-full">
            <AudioSetupPrompt 
              onSetupComplete={() => setAudioSetupComplete(true)}
              onClose={() => setAudioSetupComplete(true)}
              showMinimal={false}
            />
          </div>
        </div>
      )}

      <div className="max-w-6xl mx-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="outline" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Immersive AI Voice Experience</h1>
              <p className="text-gray-600 mt-1">Enable Alexa connectivity for full voice-powered interaction with your AI companion</p>
            </div>
          </div>
          <Badge className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <Volume2 className="h-4 w-4 mr-2" />
            Voice-Enabled Platform
          </Badge>
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="setup">Audio Setup</TabsTrigger>
            <TabsTrigger value="testing">Testing</TabsTrigger>
            <TabsTrigger value="troubleshooting">Support</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Platform Overview */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-red-500" />
                  Voice-Powered AI Companion Platform
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700 leading-relaxed">
                  Your Care Companion platform is designed as a fully immersive, voice-driven experience. 
                  The AI companion responds to your voice, provides spoken feedback, and engages in natural 
                  conversation to support cognitive health and emotional well-being.
                </p>
                
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <Mic className="h-8 w-8 text-blue-600 mb-2" />
                    <h3 className="font-semibold text-blue-900">Voice Input</h3>
                    <p className="text-sm text-blue-700">Speak naturally to your AI companion</p>
                  </div>
                  <div className="p-4 bg-green-50 rounded-lg">
                    <Volume2 className="h-8 w-8 text-green-600 mb-2" />
                    <h3 className="font-semibold text-green-900">AI Responses</h3>
                    <p className="text-sm text-green-700">Receive spoken feedback and guidance</p>
                  </div>
                  <div className="p-4 bg-purple-50 rounded-lg">
                    <Brain className="h-8 w-8 text-purple-600 mb-2" />
                    <h3 className="font-semibold text-purple-900">Cognitive Training</h3>
                    <p className="text-sm text-purple-700">Invisible enhancement through conversation</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Requirements Overview */}
            <Card>
              <CardHeader>
                <CardTitle>Audio Requirements</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {requirements.map((req, index) => (
                    <div key={index} className="flex items-center gap-4 p-4 border rounded-lg">
                      {req.icon}
                      <div className="flex-1">
                        <h3 className="font-semibold">{req.title}</h3>
                        <p className="text-sm text-gray-600">{req.description}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        {req.status === "complete" ? (
                          <Badge className="bg-green-100 text-green-800">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Ready
                          </Badge>
                        ) : (
                          <Badge variant="outline">
                            <AlertCircle className="h-3 w-3 mr-1" />
                            Setup Required
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="setup" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Complete Audio Setup</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <Alert className="bg-gradient-to-r from-orange-50 to-blue-50 border-orange-200">
                  <Smartphone className="h-4 w-4 text-orange-600" />
                  <AlertDescription>
                    <strong>Recommended:</strong> Use Amazon Alexa devices for the best voice experience. 
                    Alexa provides superior voice recognition and eliminates audio feedback issues.
                  </AlertDescription>
                </Alert>

                <div className="p-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg">
                  <h3 className="font-semibold flex items-center gap-2 mb-2">
                    <Star className="h-5 w-5 text-yellow-300" />
                    Amazon Alexa Integration (Recommended)
                  </h3>
                  <p className="text-sm mb-3">
                    Connect your Amazon Alexa device for hands-free voice interaction with your AI companion. 
                    Perfect for seniors and provides the most reliable voice experience.
                  </p>
                  <Link href="/alexa-integration">
                    <Button className="bg-white text-blue-600 hover:bg-gray-100">
                      <Wifi className="h-4 w-4 mr-2" />
                      Setup Alexa Connection
                    </Button>
                  </Link>
                </div>

                <Alert>
                  <Headphones className="h-4 w-4" />
                  <AlertDescription>
                    Alternative: Use traditional microphone and speakers if Alexa is not available. 
                    External speakers or headphones help prevent audio feedback during voice interactions.
                  </AlertDescription>
                </Alert>

                <div className="space-y-4">
                  <Button 
                    onClick={() => setAudioSetupComplete(false)}
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white"
                  >
                    <Settings className="h-4 w-4 mr-2" />
                    Start Traditional Audio Setup Process
                  </Button>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-3">
                      <h3 className="font-semibold flex items-center gap-2">
                        <Mic className="h-4 w-4" />
                        Traditional Microphone Setup
                      </h3>
                      <ul className="text-sm space-y-1 text-gray-600">
                        <li>• Allow microphone access when prompted</li>
                        <li>• Position microphone 6-12 inches from mouth</li>
                        <li>• Test in quiet environment initially</li>
                        <li>• Speak clearly at normal volume</li>
                        <li>• Consider Alexa for better recognition</li>
                      </ul>
                    </div>
                    <div className="space-y-3">
                      <h3 className="font-semibold flex items-center gap-2">
                        <Speaker className="h-4 w-4" />
                        Traditional Speaker Setup
                      </h3>
                      <ul className="text-sm space-y-1 text-gray-600">
                        <li>• Use headphones to prevent feedback</li>
                        <li>• Set volume to comfortable level</li>
                        <li>• Test audio output before starting</li>
                        <li>• Ensure speakers are not muted</li>
                        <li>• Alexa devices eliminate these issues</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="testing" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Audio System Testing</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-4">
                  {requirements.map((req, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-3">
                        {req.icon}
                        <div>
                          <h3 className="font-semibold">{req.title}</h3>
                          <p className="text-sm text-gray-600">{req.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button 
                          onClick={req.action}
                          variant={req.status === "complete" ? "outline" : "default"}
                          size="sm"
                        >
                          <PlayCircle className="h-4 w-4 mr-1" />
                          Test
                        </Button>
                        {req.status === "complete" && (
                          <CheckCircle className="h-5 w-5 text-green-600" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {Object.values(testResults).every(Boolean) && (
                  <Alert>
                    <CheckCircle className="h-4 w-4" />
                    <AlertDescription>
                      All audio systems are working correctly! You're ready for the full voice-powered experience.
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>

            {/* Browser Compatibility */}
            <Card>
              <CardHeader>
                <CardTitle>Browser Compatibility</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {browserCompatibility.map((browser, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded">
                      <div className="flex items-center gap-3">
                        <div className={`h-3 w-3 rounded-full ${browser.supported ? 'bg-green-500' : 'bg-red-500'}`} />
                        <span className="font-medium">{browser.browser}</span>
                      </div>
                      <span className="text-sm text-gray-600">{browser.notes}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="troubleshooting" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Troubleshooting Guide</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {troubleshootingSteps.map((item, index) => (
                  <div key={index} className="space-y-3">
                    <h3 className="font-semibold text-lg">{item.issue}</h3>
                    <ul className="space-y-2">
                      {item.solutions.map((solution, sIndex) => (
                        <li key={sIndex} className="flex items-start gap-2">
                          <Zap className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                          <span className="text-gray-700">{solution}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}

                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    If you continue experiencing issues, try using Google Chrome for the best voice recognition support, 
                    or contact our support team for personalized assistance.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Quick Access Footer */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold">Ready to Experience Voice-Powered AI?</h3>
                <p className="text-sm text-gray-600">Complete the audio setup to unlock the full platform capabilities</p>
              </div>
              <div className="flex gap-2">
                <Link href="/patient-companion">
                  <Button>
                    <Brain className="h-4 w-4 mr-2" />
                    Start AI Companion
                  </Button>
                </Link>
                <Link href="/advanced-voice-demo">
                  <Button variant="outline">
                    <Volume2 className="h-4 w-4 mr-2" />
                    Voice Demo
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}