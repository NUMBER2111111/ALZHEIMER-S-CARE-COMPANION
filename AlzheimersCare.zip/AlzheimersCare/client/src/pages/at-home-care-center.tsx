import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Home, Shield, Clock, Phone, Heart, Brain, 
  Camera, Wifi, MapPin, Thermometer, Droplets,
  AlertTriangle, CheckCircle, Settings, Play,
  Moon, Sun, Utensils, Pill, Activity, Eye, Lock
} from 'lucide-react';
import AISecurityShowcase from '@/components/ai-security-showcase';
import { DeviceRequirementAlert, getDeviceSpecs, featureDeviceRequirements } from '@/components/device-requirement-alert';

const AtHomeCareCenter = () => {
  const [activeAlerts, setActiveAlerts] = useState(3);
  const [safetyScore, setSafetyScore] = useState(87);
  const [currentLocation, setCurrentLocation] = useState("Living Room");
  const [lastActivity, setLastActivity] = useState("5 minutes ago");

  const safetyFeatures = [
    {
      id: 'wandering-prevention',
      title: 'Smart Wandering Prevention',
      description: 'AI-powered movement tracking with gentle redirection',
      status: 'active',
      icon: MapPin,
      features: [
        'Door sensor alerts with gentle audio reminders',
        'Safe zone mapping with invisible boundaries',
        'Automatic family notifications if patient leaves safe areas',
        'GPS tracking for outdoor excursions with return guidance',
        'Customizable boundaries for different times of day'
      ]
    },
    {
      id: 'fall-detection',
      title: 'Advanced Fall Detection',
      description: 'Multi-sensor fall prevention and instant response',
      status: 'monitoring',
      icon: Shield,
      features: [
        'Computer vision analysis of movement patterns',
        'Wearable device integration for instant alerts',
        'Pre-fall detection with balance assistance prompts',
        'Automatic emergency contact notification',
        'Two-way communication for immediate assessment'
      ]
    },
    {
      id: 'medication-safety',
      title: 'Smart Medication Management',
      description: 'Automated dispensing with AI oversight',
      status: 'active',
      icon: Pill,
      features: [
        'Voice-guided medication reminders',
        'Smart pill dispenser with biometric locks',
        'Drug interaction monitoring and alerts',
        'Automatic refill coordination with pharmacy',
        'Family notification of missed doses'
      ]
    }
  ];

  const homeMonitoring = [
    {
      title: 'Environmental Safety',
      items: [
        { name: 'Temperature', value: '72°F', status: 'normal', icon: Thermometer },
        { name: 'Air Quality', value: 'Good', status: 'normal', icon: Activity },
        { name: 'Lighting', value: 'Optimal', status: 'normal', icon: Sun },
        { name: 'Humidity', value: '45%', status: 'normal', icon: Droplets }
      ]
    },
    {
      title: 'Activity Monitoring',
      items: [
        { name: 'Sleep Quality', value: '8.2/10', status: 'good', icon: Moon },
        { name: 'Daily Movement', value: '2,340 steps', status: 'normal', icon: Activity },
        { name: 'Nutrition', value: '3 meals', status: 'good', icon: Utensils },
        { name: 'Hydration', value: '6 glasses', status: 'normal', icon: Droplets }
      ]
    }
  ];

  const dailyRoutines = [
    {
      time: '7:00 AM',
      activity: 'Morning Routine',
      status: 'completed',
      details: 'Medication taken, breakfast consumed, vitals recorded'
    },
    {
      time: '10:00 AM',
      activity: 'Cognitive Exercise',
      status: 'in-progress',
      details: 'Memory game session - 15 minutes remaining'
    },
    {
      time: '12:00 PM',
      activity: 'Lunch & Social Time',
      status: 'upcoming',
      details: 'Video call with family scheduled'
    },
    {
      time: '3:00 PM',
      activity: 'Physical Activity',
      status: 'upcoming',
      details: 'Gentle exercise routine with AI guidance'
    },
    {
      time: '6:00 PM',
      activity: 'Evening Routine',
      status: 'upcoming',
      details: 'Dinner, medication, relaxation activities'
    }
  ];

  const emergencyContacts = [
    { name: 'Sarah (Daughter)', phone: '(555) 123-4567', type: 'Primary', response: '2 min' },
    { name: 'Dr. Johnson', phone: '(555) 987-6543', type: 'Medical', response: '5 min' },
    { name: 'Emergency Services', phone: '911', type: 'Emergency', response: 'Immediate' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <Home className="text-blue-600" />
              At-Home Care Center
            </h1>
            <p className="text-gray-600 mt-2">Comprehensive AI-powered home care monitoring and support</p>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-green-600">{safetyScore}%</div>
            <div className="text-sm text-gray-600">Safety Score</div>
          </div>
        </div>

        {/* Quick Status */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <div className="font-semibold">Safe & Secure</div>
                  <div className="text-sm text-gray-600">All systems normal</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <div className="font-semibold">{currentLocation}</div>
                  <div className="text-sm text-gray-600">Current location</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                  <Activity className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <div className="font-semibold">Active</div>
                  <div className="text-sm text-gray-600">{lastActivity}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <div className="font-semibold">{activeAlerts} Alerts</div>
                  <div className="text-sm text-gray-600">Routine reminders</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="safety" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="safety">Safety Features</TabsTrigger>
            <TabsTrigger value="monitoring">Home Monitoring</TabsTrigger>
            <TabsTrigger value="routines">Daily Routines</TabsTrigger>
            <TabsTrigger value="emergency">Emergency</TabsTrigger>
            <TabsTrigger value="insights">AI Insights</TabsTrigger>
          </TabsList>

          {/* Safety Features Tab */}
          <TabsContent value="safety" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {safetyFeatures.map((feature) => {
                const IconComponent = feature.icon;
                return (
                  <Card key={feature.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                            <IconComponent className="w-5 h-5 text-blue-600" />
                          </div>
                          <div>
                            <CardTitle className="text-lg">{feature.title}</CardTitle>
                            <Badge variant={feature.status === 'active' ? 'default' : 'secondary'}>
                              {feature.status}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <CardDescription>{feature.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {feature.features.map((item, index) => (
                          <li key={index} className="flex items-start gap-2 text-sm">
                            <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                      <Button className="w-full mt-4" variant="outline">
                        <Settings className="w-4 h-4 mr-2" />
                        Configure Settings
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          {/* Home Monitoring Tab */}
          <TabsContent value="monitoring" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {homeMonitoring.map((section, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle>{section.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {section.items.map((item, itemIndex) => {
                        const IconComponent = item.icon;
                        return (
                          <div key={itemIndex} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div className="flex items-center gap-3">
                              <IconComponent className="w-5 h-5 text-gray-600" />
                              <span className="font-medium">{item.name}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="font-semibold">{item.value}</span>
                              <div className={`w-3 h-3 rounded-full ${
                                item.status === 'normal' ? 'bg-green-500' :
                                item.status === 'good' ? 'bg-blue-500' : 'bg-yellow-500'
                              }`} />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Smart Home Integration</CardTitle>
                <CardDescription>Connected devices and automated systems</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <Camera className="w-8 h-8 mx-auto text-green-600 mb-2" />
                    <div className="font-medium">Smart Cameras</div>
                    <div className="text-sm text-gray-600">8 Active</div>
                  </div>
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <Wifi className="w-8 h-8 mx-auto text-blue-600 mb-2" />
                    <div className="font-medium">IoT Sensors</div>
                    <div className="text-sm text-gray-600">12 Connected</div>
                  </div>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <Heart className="w-8 h-8 mx-auto text-purple-600 mb-2" />
                    <div className="font-medium">Health Devices</div>
                    <div className="text-sm text-gray-600">5 Synced</div>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <Shield className="w-8 h-8 mx-auto text-orange-600 mb-2" />
                    <div className="font-medium">Security</div>
                    <div className="text-sm text-gray-600">All Secure</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Daily Routines Tab */}
          <TabsContent value="routines" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Today's Schedule</CardTitle>
                <CardDescription>AI-optimized daily routine for cognitive and physical health</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {dailyRoutines.map((routine, index) => (
                    <div key={index} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                      <div className="flex-shrink-0">
                        <div className="w-16 text-center">
                          <div className="font-semibold text-blue-600">{routine.time}</div>
                        </div>
                      </div>
                      <div className="flex-1">
                        <div className="font-medium">{routine.activity}</div>
                        <div className="text-sm text-gray-600">{routine.details}</div>
                      </div>
                      <div className="flex-shrink-0">
                        <Badge variant={
                          routine.status === 'completed' ? 'default' :
                          routine.status === 'in-progress' ? 'destructive' : 'secondary'
                        }>
                          {routine.status}
                        </Badge>
                      </div>
                      {routine.status === 'in-progress' && (
                        <Button size="sm" variant="outline">
                          <Play className="w-4 h-4 mr-2" />
                          Continue
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Routine Optimization</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Cognitive Activities</span>
                        <span>85%</span>
                      </div>
                      <Progress value={85} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Physical Exercise</span>
                        <span>72%</span>
                      </div>
                      <Progress value={72} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Social Interaction</span>
                        <span>91%</span>
                      </div>
                      <Progress value={91} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Rest & Recovery</span>
                        <span>88%</span>
                      </div>
                      <Progress value={88} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Personalization Insights</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Alert>
                      <Brain className="h-4 w-4" />
                      <AlertDescription>
                        Morning cognitive exercises show 23% better performance. Scheduling adjusted.
                      </AlertDescription>
                    </Alert>
                    <Alert>
                      <Heart className="h-4 w-4" />
                      <AlertDescription>
                        Afternoon rest periods improve evening alertness by 34%.
                      </AlertDescription>
                    </Alert>
                    <Alert>
                      <Clock className="h-4 w-4" />
                      <AlertDescription>
                        Optimal medication timing identified for better absorption.
                      </AlertDescription>
                    </Alert>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Emergency Tab */}
          <TabsContent value="emergency" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-red-600">Emergency Response System</CardTitle>
                <CardDescription>24/7 monitoring with instant family and medical notifications</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {emergencyContacts.map((contact, index) => (
                    <div key={index} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <div className="font-semibold">{contact.name}</div>
                        <Badge variant={contact.type === 'Emergency' ? 'destructive' : 'default'}>
                          {contact.type}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-600 mb-2">{contact.phone}</div>
                      <div className="text-sm">
                        <span className="text-gray-500">Response Time: </span>
                        <span className="font-medium">{contact.response}</span>
                      </div>
                      <Button className="w-full mt-3" variant="outline" size="sm">
                        <Phone className="w-4 h-4 mr-2" />
                        Call Now
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Emergency Protocols</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 p-3 bg-red-50 rounded-lg">
                      <AlertTriangle className="w-5 h-5 text-red-600" />
                      <div>
                        <div className="font-medium">Medical Emergency</div>
                        <div className="text-sm text-gray-600">Automatic 911 call, family alerts</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
                      <MapPin className="w-5 h-5 text-orange-600" />
                      <div>
                        <div className="font-medium">Wandering Alert</div>
                        <div className="text-sm text-gray-600">GPS tracking, guided return</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-yellow-50 rounded-lg">
                      <Clock className="w-5 h-5 text-yellow-600" />
                      <div>
                        <div className="font-medium">Missed Check-in</div>
                        <div className="text-sm text-gray-600">Escalating contact protocol</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 text-sm">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-gray-500">2:15 PM</span>
                      <span>Medication reminder acknowledged</span>
                    </div>
                    <div className="flex items-center gap-3 text-sm">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-gray-500">1:30 PM</span>
                      <span>Completed cognitive exercise session</span>
                    </div>
                    <div className="flex items-center gap-3 text-sm">
                      <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                      <span className="text-gray-500">12:45 PM</span>
                      <span>Video call with family ended</span>
                    </div>
                    <div className="flex items-center gap-3 text-sm">
                      <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                      <span className="text-gray-500">11:20 AM</span>
                      <span>Movement detected outside safe zone</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* AI Insights Tab */}
          <TabsContent value="insights" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Cognitive Health Trends</CardTitle>
                  <CardDescription>AI analysis of cognitive performance over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 bg-green-50 rounded-lg">
                      <div className="font-semibold text-green-800">Memory Performance</div>
                      <div className="text-2xl font-bold text-green-600">+12%</div>
                      <div className="text-sm text-green-700">Improvement over last month</div>
                    </div>
                    <div className="p-4 bg-blue-50 rounded-lg">
                      <div className="font-semibold text-blue-800">Attention Span</div>
                      <div className="text-2xl font-bold text-blue-600">47 min</div>
                      <div className="text-sm text-blue-700">Average focused time</div>
                    </div>
                    <div className="p-4 bg-purple-50 rounded-lg">
                      <div className="font-semibold text-purple-800">Daily Engagement</div>
                      <div className="text-2xl font-bold text-purple-600">94%</div>
                      <div className="text-sm text-purple-700">Activity completion rate</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Predictive Insights</CardTitle>
                  <CardDescription>AI-powered health predictions and recommendations</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Alert>
                      <Brain className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Cognitive Enhancement:</strong> Implementing new memory exercises could improve retention by 18%.
                      </AlertDescription>
                    </Alert>
                    <Alert>
                      <Heart className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Health Alert:</strong> Slight increase in resting heart rate detected. Consider gentle exercise.
                      </AlertDescription>
                    </Alert>
                    <Alert>
                      <Clock className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Sleep Optimization:</strong> Earlier bedtime could improve morning cognitive performance.
                      </AlertDescription>
                    </Alert>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Family Communication Hub</CardTitle>
                <CardDescription>Keep family informed with automated updates and insights</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 border rounded-lg">
                    <div className="font-semibold mb-2">Daily Summary</div>
                    <div className="text-sm text-gray-600 mb-3">Automated daily reports to family members</div>
                    <Button variant="outline" size="sm" className="w-full">
                      Send Now
                    </Button>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <div className="font-semibold mb-2">Video Updates</div>
                    <div className="text-sm text-gray-600 mb-3">Weekly video messages for family</div>
                    <Button variant="outline" size="sm" className="w-full">
                      Record
                    </Button>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <div className="font-semibold mb-2">Progress Reports</div>
                    <div className="text-sm text-gray-600 mb-3">Monthly comprehensive health updates</div>
                    <Button variant="outline" size="sm" className="w-full">
                      Generate
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AtHomeCareCenter;