import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Shield, Lock, Key, Database, Users, FileText, Zap, CheckCircle, AlertTriangle } from 'lucide-react';

interface BlockchainRecord {
  id: string;
  hash: string;
  previousHash: string;
  timestamp: number;
  recordType: 'medical' | 'consent' | 'access' | 'treatment' | 'medication';
  data: any;
  digitalSignature: string;
  validatorNodes: string[];
  encryptionLevel: 'AES-256' | 'Quantum-Resistant' | 'Homomorphic';
  immutable: boolean;
}

interface SmartContract {
  id: string;
  type: 'consent-management' | 'emergency-access' | 'data-sharing' | 'treatment-protocol';
  name: string;
  conditions: string[];
  autoExecute: boolean;
  active: boolean;
  gasPrice: number;
  executionCount: number;
}

interface DecentralizedNode {
  id: string;
  location: string;
  type: 'validator' | 'storage' | 'consensus' | 'backup';
  uptime: number;
  trust_score: number;
  stake: number;
  lastSeen: string;
}

export default function BlockchainMedicalRecords() {
  const [selectedRecord, setSelectedRecord] = useState<BlockchainRecord | null>(null);
  const [isCreatingBlock, setIsCreatingBlock] = useState(false);
  const [consensusStatus, setConsensusStatus] = useState('synced');
  const [networkHealth, setNetworkHealth] = useState(97.3);

  const blockchainRecords: BlockchainRecord[] = [
    {
      id: 'block_001',
      hash: '0x4a7b9c2d8e1f3a5b6c9d2e4f7a8b5c6d9e2f4a7b',
      previousHash: '0x1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b',
      timestamp: Date.now() - 86400000,
      recordType: 'medical',
      data: {
        type: 'Cognitive Assessment',
        mmse_score: 24,
        diagnosis: 'Mild Cognitive Impairment',
        physician: 'Dr. Sarah Wilson',
        facility: 'Memory Care Center'
      },
      digitalSignature: 'MEUCIQDxvKl7k2mF3nR8pQ9wX1yZ5tA4bC7dE8fG9hI0jK2lM3nO4pQ',
      validatorNodes: ['node_001', 'node_002', 'node_003'],
      encryptionLevel: 'Quantum-Resistant',
      immutable: true
    },
    {
      id: 'block_002',
      hash: '0x8f7e6d5c4b3a2910fedcba9876543210abcdef12',
      previousHash: '0x4a7b9c2d8e1f3a5b6c9d2e4f7a8b5c6d9e2f4a7b',
      timestamp: Date.now() - 43200000,
      recordType: 'consent',
      data: {
        type: 'Family Access Consent',
        grantor: 'John Smith',
        grantee: 'Sarah Smith (Daughter)',
        permissions: ['medical_records', 'treatment_decisions', 'emergency_contact'],
        expiration: '2025-12-31'
      },
      digitalSignature: 'MEQCIGxY2zA1bC3dE4fF5gG6hH7iI8jJ9kK0lL1mM2nN3oO4pP5q',
      validatorNodes: ['node_001', 'node_003', 'node_004'],
      encryptionLevel: 'AES-256',
      immutable: true
    },
    {
      id: 'block_003',
      hash: '0x3e4d5c6b7a8f9e0d1c2b3a4950fedcba987654321',
      previousHash: '0x8f7e6d5c4b3a2910fedcba9876543210abcdef12',
      timestamp: Date.now() - 3600000,
      recordType: 'medication',
      data: {
        type: 'Medication Administration',
        medication: 'Donepezil 10mg',
        administered_by: 'Nurse Jennifer Lopez',
        timestamp: new Date().toISOString(),
        patient_response: 'Positive - No adverse effects'
      },
      digitalSignature: 'MEQCIG1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s0t1u2v3w',
      validatorNodes: ['node_002', 'node_004', 'node_005'],
      encryptionLevel: 'Homomorphic',
      immutable: true
    }
  ];

  const smartContracts: SmartContract[] = [
    {
      id: 'contract_001',
      type: 'emergency-access',
      name: 'Emergency Medical Access Protocol',
      conditions: [
        'Vital signs indicate critical emergency',
        'Patient unable to provide consent',
        'Family member unavailable within 15 minutes'
      ],
      autoExecute: true,
      active: true,
      gasPrice: 0.00034,
      executionCount: 2
    },
    {
      id: 'contract_002',
      type: 'consent-management',
      name: 'Dynamic Consent Manager',
      conditions: [
        'Patient cognitive score above threshold',
        'Consent period not expired',
        'No revocation on record'
      ],
      autoExecute: true,
      active: true,
      gasPrice: 0.00021,
      executionCount: 147
    },
    {
      id: 'contract_003',
      type: 'data-sharing',
      name: 'Research Data Anonymization',
      conditions: [
        'Patient opted into research',
        'Data properly anonymized',
        'Institution approved by ethics board'
      ],
      autoExecute: false,
      active: true,
      gasPrice: 0.00056,
      executionCount: 23
    }
  ];

  const networkNodes: DecentralizedNode[] = [
    {
      id: 'node_001',
      location: 'San Francisco, CA',
      type: 'validator',
      uptime: 99.7,
      trust_score: 0.98,
      stake: 10000,
      lastSeen: '2 minutes ago'
    },
    {
      id: 'node_002',
      location: 'London, UK',
      type: 'storage',
      uptime: 99.2,
      trust_score: 0.96,
      stake: 8500,
      lastSeen: '1 minute ago'
    },
    {
      id: 'node_003',
      location: 'Tokyo, Japan',
      type: 'consensus',
      uptime: 99.9,
      trust_score: 0.99,
      stake: 12000,
      lastSeen: '30 seconds ago'
    },
    {
      id: 'node_004',
      location: 'Frankfurt, Germany',
      type: 'backup',
      uptime: 98.8,
      trust_score: 0.95,
      stake: 7500,
      lastSeen: '3 minutes ago'
    },
    {
      id: 'node_005',
      location: 'Sydney, Australia',
      type: 'validator',
      uptime: 99.5,
      trust_score: 0.97,
      stake: 9500,
      lastSeen: '1 minute ago'
    }
  ];

  const createNewBlock = async () => {
    setIsCreatingBlock(true);
    
    // Simulate blockchain mining process
    setTimeout(() => {
      setIsCreatingBlock(false);
      setConsensusStatus('pending');
      
      // Simulate consensus achievement
      setTimeout(() => {
        setConsensusStatus('synced');
      }, 3000);
    }, 5000);
  };

  const getRecordTypeIcon = (type: string) => {
    switch (type) {
      case 'medical': return <FileText className="h-4 w-4" />;
      case 'consent': return <Users className="h-4 w-4" />;
      case 'access': return <Key className="h-4 w-4" />;
      case 'treatment': return <Shield className="h-4 w-4" />;
      case 'medication': return <Database className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  const getEncryptionColor = (level: string) => {
    switch (level) {
      case 'AES-256': return 'bg-blue-100 text-blue-800';
      case 'Quantum-Resistant': return 'bg-purple-100 text-purple-800';
      case 'Homomorphic': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getNodeTypeColor = (type: string) => {
    switch (type) {
      case 'validator': return 'bg-green-100 text-green-800';
      case 'storage': return 'bg-blue-100 text-blue-800';
      case 'consensus': return 'bg-purple-100 text-purple-800';
      case 'backup': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  useEffect(() => {
    // Simulate real-time network health monitoring
    const interval = setInterval(() => {
      setNetworkHealth(prev => {
        const change = (Math.random() - 0.5) * 2;
        return Math.max(90, Math.min(100, prev + change));
      });
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
              <Database className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-white">Blockchain Medical Records</h1>
          </div>
          <p className="text-xl text-purple-200 max-w-3xl mx-auto">
            Immutable, decentralized medical record management with smart contracts for automated 
            consent handling and quantum-resistant encryption for ultimate data security.
          </p>
        </div>

        {/* Network Status */}
        <Card className="bg-black/30 backdrop-blur-md border-purple-500/30 shadow-2xl">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-400">{networkHealth.toFixed(1)}%</div>
                <div className="text-purple-200">Network Health</div>
                <div className="mt-2 flex items-center justify-center gap-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  <span className="text-sm text-green-300">Active</span>
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-400">{blockchainRecords.length}</div>
                <div className="text-purple-200">Total Blocks</div>
                <div className="mt-2">
                  <Badge className="bg-blue-500/20 text-blue-300 border-blue-400">
                    {consensusStatus}
                  </Badge>
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-400">{networkNodes.length}</div>
                <div className="text-purple-200">Network Nodes</div>
                <div className="mt-2">
                  <Badge className="bg-purple-500/20 text-purple-300 border-purple-400">
                    Distributed
                  </Badge>
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-yellow-400">{smartContracts.length}</div>
                <div className="text-purple-200">Smart Contracts</div>
                <div className="mt-2">
                  <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-400">
                    Auto-Execute
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Mining Status */}
        {isCreatingBlock && (
          <Card className="bg-gradient-to-r from-yellow-600/20 to-orange-600/20 backdrop-blur-md border-yellow-400/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-yellow-400 rounded-full animate-pulse"></div>
                  <div>
                    <h3 className="text-xl font-bold text-white">Mining New Block</h3>
                    <p className="text-yellow-200">Proof-of-Stake consensus in progress...</p>
                  </div>
                </div>
                <div className="text-right text-white">
                  <div className="text-2xl font-bold">⛏️ Mining</div>
                  <p className="text-yellow-200">Validators: 5/5</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="blockchain" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-black/30 backdrop-blur-md border-purple-500/30">
            <TabsTrigger value="blockchain" className="text-purple-200 data-[state=active]:text-white">Blockchain</TabsTrigger>
            <TabsTrigger value="smart-contracts" className="text-purple-200 data-[state=active]:text-white">Smart Contracts</TabsTrigger>
            <TabsTrigger value="network" className="text-purple-200 data-[state=active]:text-white">Network Nodes</TabsTrigger>
            <TabsTrigger value="encryption" className="text-purple-200 data-[state=active]:text-white">Quantum Security</TabsTrigger>
          </TabsList>

          <TabsContent value="blockchain" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">Medical Record Blockchain</h2>
              <Button 
                onClick={createNewBlock}
                disabled={isCreatingBlock}
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                <Zap className="mr-2 h-4 w-4" />
                {isCreatingBlock ? 'Mining Block...' : 'Create New Block'}
              </Button>
            </div>

            <div className="space-y-4">
              {blockchainRecords.map((record, index) => (
                <Card 
                  key={record.id} 
                  className="bg-black/30 backdrop-blur-md border-purple-500/30 hover:border-purple-400/50 transition-all duration-300 cursor-pointer"
                  onClick={() => setSelectedRecord(record)}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4">
                        <div className="flex items-center justify-center w-12 h-12 bg-purple-600/30 rounded-lg">
                          {getRecordTypeIcon(record.recordType)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-lg font-bold text-white">Block #{index + 1}</h3>
                            <Badge className={getEncryptionColor(record.encryptionLevel)}>
                              {record.encryptionLevel}
                            </Badge>
                            {record.immutable && (
                              <Badge className="bg-green-100 text-green-800">
                                <Lock className="mr-1 h-3 w-3" />
                                Immutable
                              </Badge>
                            )}
                          </div>
                          <p className="text-purple-200 text-sm mb-2">
                            Hash: <code className="bg-purple-900/30 px-2 py-1 rounded text-purple-300">{record.hash.substring(0, 20)}...</code>
                          </p>
                          <p className="text-purple-200 text-sm">
                            Type: {record.recordType} | Validators: {record.validatorNodes.length} | 
                            Time: {new Date(record.timestamp).toLocaleString()}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <CheckCircle className="h-6 w-6 text-green-400" />
                        <p className="text-green-300 text-sm mt-1">Verified</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Selected Record Details */}
            {selectedRecord && (
              <Card className="bg-gradient-to-br from-purple-900/40 to-blue-900/40 backdrop-blur-md border-purple-400/30">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Block Details
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-purple-300 font-medium mb-2">Block Information</h4>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-purple-200">Block ID:</span>
                            <span className="text-white font-mono">{selectedRecord.id}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-purple-200">Hash:</span>
                            <span className="text-white font-mono text-xs">{selectedRecord.hash.substring(0, 16)}...</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-purple-200">Previous Hash:</span>
                            <span className="text-white font-mono text-xs">{selectedRecord.previousHash.substring(0, 16)}...</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-purple-200">Timestamp:</span>
                            <span className="text-white">{new Date(selectedRecord.timestamp).toLocaleString()}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-purple-300 font-medium mb-2">Security</h4>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-purple-200">Encryption:</span>
                            <Badge className={getEncryptionColor(selectedRecord.encryptionLevel)}>
                              {selectedRecord.encryptionLevel}
                            </Badge>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-purple-200">Digital Signature:</span>
                            <span className="text-white font-mono text-xs">{selectedRecord.digitalSignature.substring(0, 16)}...</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-purple-200">Validators:</span>
                            <span className="text-white">{selectedRecord.validatorNodes.length} nodes</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="text-purple-300 font-medium mb-2">Record Data</h4>
                      <div className="bg-purple-900/20 p-4 rounded-lg">
                        <pre className="text-purple-100 text-sm overflow-x-auto">
                          {JSON.stringify(selectedRecord.data, null, 2)}
                        </pre>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="smart-contracts" className="space-y-6">
            <h2 className="text-2xl font-bold text-white">Smart Contract Automation</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {smartContracts.map((contract) => (
                <Card key={contract.id} className="bg-black/30 backdrop-blur-md border-purple-500/30">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-white text-lg">{contract.name}</CardTitle>
                        <p className="text-purple-200 text-sm capitalize">{contract.type.replace('-', ' ')}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        {contract.active && (
                          <Badge className="bg-green-100 text-green-800">Active</Badge>
                        )}
                        {contract.autoExecute && (
                          <Badge className="bg-blue-100 text-blue-800">Auto</Badge>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-purple-300 font-medium mb-2">Execution Conditions:</h4>
                        <div className="space-y-1">
                          {contract.conditions.map((condition, index) => (
                            <div key={index} className="flex items-start gap-2 text-sm">
                              <CheckCircle className="h-4 w-4 text-green-400 mt-0.5 flex-shrink-0" />
                              <span className="text-purple-200">{condition}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div className="pt-4 border-t border-purple-500/30">
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-purple-300">Gas Price:</span>
                            <p className="text-white font-medium">{contract.gasPrice} ETH</p>
                          </div>
                          <div>
                            <span className="text-purple-300">Executions:</span>
                            <p className="text-white font-medium">{contract.executionCount}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="network" className="space-y-6">
            <h2 className="text-2xl font-bold text-white">Decentralized Network Nodes</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {networkNodes.map((node) => (
                <Card key={node.id} className="bg-black/30 backdrop-blur-md border-purple-500/30">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-white text-lg">{node.id}</CardTitle>
                        <p className="text-purple-200 text-sm">{node.location}</p>
                      </div>
                      <Badge className={getNodeTypeColor(node.type)}>
                        {node.type}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <span className="text-purple-300 text-sm">Uptime</span>
                          <div className="flex items-center gap-2">
                            <div className="text-lg font-bold text-green-400">{node.uptime}%</div>
                            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                          </div>
                        </div>
                        <div>
                          <span className="text-purple-300 text-sm">Trust Score</span>
                          <div className="text-lg font-bold text-blue-400">{node.trust_score}</div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <span className="text-purple-300 text-sm">Stake</span>
                          <div className="text-lg font-bold text-yellow-400">{node.stake.toLocaleString()}</div>
                        </div>
                        <div>
                          <span className="text-purple-300 text-sm">Last Seen</span>
                          <div className="text-sm text-white">{node.lastSeen}</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="encryption" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-gradient-to-br from-purple-600/20 to-blue-600/20 backdrop-blur-md border-purple-400/30">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    Quantum-Resistant Encryption
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div>
                      <h4 className="text-purple-300 font-medium mb-2">Post-Quantum Cryptography</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-purple-200">Algorithm:</span>
                          <span className="text-white">CRYSTALS-Kyber</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-purple-200">Key Size:</span>
                          <span className="text-white">3,168 bits</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-purple-200">Security Level:</span>
                          <span className="text-green-300">NIST Level 3</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="text-purple-300 font-medium mb-2">Homomorphic Encryption</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-purple-200">Scheme:</span>
                          <span className="text-white">TFHE</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-purple-200">Operations:</span>
                          <span className="text-white">Fully Homomorphic</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-purple-200">Computation:</span>
                          <span className="text-blue-300">Encrypted Data</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-green-600/20 to-yellow-600/20 backdrop-blur-md border-green-400/30">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Key className="h-5 w-5" />
                    Zero-Knowledge Proofs
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div>
                      <h4 className="text-green-300 font-medium mb-2">zk-SNARKs Implementation</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-green-200">Proof System:</span>
                          <span className="text-white">Groth16</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-green-200">Verification:</span>
                          <span className="text-white">Constant Time</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-green-200">Privacy:</span>
                          <span className="text-green-300">Complete</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="text-green-300 font-medium mb-2">Use Cases</h4>
                      <div className="space-y-1 text-sm">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="h-3 w-3 text-green-400" />
                          <span className="text-green-200">Identity Verification</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="h-3 w-3 text-green-400" />
                          <span className="text-green-200">Medical Record Access</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="h-3 w-3 text-green-400" />
                          <span className="text-green-200">Prescription Validation</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}