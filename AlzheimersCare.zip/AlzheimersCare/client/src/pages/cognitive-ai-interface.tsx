import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { 
  Brain, 
  Target, 
  TrendingUp, 
  Clock, 
  Zap, 
  Eye,
  Archive,
  MessageCircle,
  Calendar,
  Award,
  BarChart3,
  Lightbulb,
  Puzzle,
  Users,
  Activity,
  CheckCircle,
  AlertTriangle,
  Play,
  Pause,
  RotateCcw,
  Star
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';

interface CognitiveSession {
  id: string;
  type: 'memory' | 'attention' | 'processing' | 'problem_solving' | 'verbal' | 'visual_spatial';
  title: string;
  description: string;
  difficulty: 'easy' | 'medium' | 'hard' | 'adaptive';
  duration: number; // minutes
  status: 'not_started' | 'in_progress' | 'completed' | 'paused';
  score?: number;
  accuracy?: number;
  completedAt?: Date;
  improvements: string[];
}

interface CognitiveMetrics {
  domain: string;
  current: number;
  baseline: number;
  target: number;
  trend: 'improving' | 'stable' | 'declining';
  sessions: number;
}

interface ProgressData {
  date: string;
  memory: number;
  attention: number;
  processing: number;
  problemSolving: number;
  verbal: number;
  visualSpatial: number;
  overall: number;
}

interface AIPersonality {
  name: string;
  style: 'encouraging' | 'challenging' | 'analytical' | 'compassionate';
  avatar: string;
  specialization: string[];
  currentMood: 'focused' | 'energetic' | 'patient' | 'determined';
}

export default function SubtleCognitiveEnhancer() {
  const [currentSession, setCurrentSession] = useState<CognitiveSession | null>(null);
  const [sessionActive, setSessionActive] = useState(false);
  const [sessionTime, setSessionTime] = useState(0);
  const [aiPersonality, setAIPersonality] = useState<AIPersonality>({
    name: 'Dr. Mira',
    style: 'encouraging',
    avatar: '🧠',
    specialization: ['Memory Enhancement', 'Cognitive Rehabilitation', 'Neuroplasticity'],
    currentMood: 'focused'
  });

  const [cognitiveMetrics, setCognitiveMetrics] = useState<CognitiveMetrics[]>([
    { domain: 'Memory', current: 72, baseline: 65, target: 85, trend: 'improving', sessions: 15 },
    { domain: 'Attention', current: 68, baseline: 60, target: 80, trend: 'improving', sessions: 12 },
    { domain: 'Processing Speed', current: 75, baseline: 70, target: 85, trend: 'stable', sessions: 18 },
    { domain: 'Problem Solving', current: 80, baseline: 75, target: 90, trend: 'improving', sessions: 10 },
    { domain: 'Verbal Skills', current: 85, baseline: 82, target: 92, trend: 'improving', sessions: 8 },
    { domain: 'Visual-Spatial', current: 70, baseline: 65, target: 82, trend: 'stable', sessions: 14 }
  ]);

  const [availableSessions, setAvailableSessions] = useState<CognitiveSession[]>([
    {
      id: 'mem-1',
      type: 'memory',
      title: 'Sequential Memory Challenge',
      description: 'Remember and recall sequences of numbers, colors, and patterns',
      difficulty: 'adaptive',
      duration: 15,
      status: 'not_started',
      improvements: ['Working memory', 'Sequential processing', 'Attention span']
    },
    {
      id: 'att-1',
      type: 'attention',
      title: 'Selective Attention Training',
      description: 'Focus on specific stimuli while filtering distractions',
      difficulty: 'medium',
      duration: 20,
      status: 'not_started',
      improvements: ['Sustained attention', 'Selective focus', 'Distraction resistance']
    },
    {
      id: 'proc-1',
      type: 'processing',
      title: 'Speed Processing Tasks',
      description: 'Quick decision-making and pattern recognition exercises',
      difficulty: 'hard',
      duration: 12,
      status: 'not_started',
      improvements: ['Processing speed', 'Decision making', 'Pattern recognition']
    },
    {
      id: 'prob-1',
      type: 'problem_solving',
      title: 'Logic Puzzle Series',
      description: 'Complex reasoning and abstract problem-solving challenges',
      difficulty: 'adaptive',
      duration: 25,
      status: 'not_started',
      improvements: ['Abstract reasoning', 'Logic skills', 'Strategic thinking']
    }
  ]);

  const [progressData, setProgressData] = useState<ProgressData[]>([
    { date: '2024-01-20', memory: 65, attention: 60, processing: 70, problemSolving: 75, verbal: 82, visualSpatial: 65, overall: 69 },
    { date: '2024-01-22', memory: 67, attention: 62, processing: 71, problemSolving: 76, verbal: 83, visualSpatial: 66, overall: 71 },
    { date: '2024-01-24', memory: 69, attention: 64, processing: 72, problemSolving: 77, verbal: 84, visualSpatial: 67, overall: 72 },
    { date: '2024-01-26', memory: 72, attention: 68, processing: 75, problemSolving: 80, verbal: 85, visualSpatial: 70, overall: 75 }
  ]);

  const [aiMessages, setAIMessages] = useState([
    {
      id: '1',
      content: "Hello! I'm Dr. Mira, your cognitive training companion. I've analyzed your recent progress and I'm impressed with your dedication. Your memory scores have improved by 11% this week!",
      timestamp: new Date(Date.now() - 300000),
      type: 'encouragement'
    },
    {
      id: '2',
      content: "I notice you perform best during morning sessions. Shall we schedule your next challenging task for tomorrow at 9 AM when your cognitive energy is at its peak?",
      timestamp: new Date(Date.now() - 180000),
      type: 'insight'
    },
    {
      id: '3',
      content: "Your attention span has increased from 8 minutes to 15 minutes over the past month. This neuroplasticity shows your brain is actively strengthening neural pathways!",
      timestamp: new Date(Date.now() - 60000),
      type: 'achievement'
    }
  ]);

  const { toast } = useToast();

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (sessionActive && currentSession) {
      interval = setInterval(() => {
        setSessionTime(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [sessionActive, currentSession]);

  const startSession = (session: CognitiveSession) => {
    setCurrentSession(session);
    setSessionActive(true);
    setSessionTime(0);
    
    setAvailableSessions(prev => 
      prev.map(s => s.id === session.id ? { ...s, status: 'in_progress' } : s)
    );

    toast({
      title: "Session Started",
      description: `Beginning ${session.title} - Stay focused and do your best!`,
    });

    // AI encouragement
    setAIMessages(prev => [...prev, {
      id: Date.now().toString(),
      content: getAIEncouragement(session),
      timestamp: new Date(),
      type: 'encouragement'
    }]);
  };

  const pauseSession = () => {
    setSessionActive(false);
    if (currentSession) {
      setAvailableSessions(prev => 
        prev.map(s => s.id === currentSession.id ? { ...s, status: 'paused' } : s)
      );
    }
  };

  const resumeSession = () => {
    setSessionActive(true);
    if (currentSession) {
      setAvailableSessions(prev => 
        prev.map(s => s.id === currentSession.id ? { ...s, status: 'in_progress' } : s)
      );
    }
  };

  const completeSession = () => {
    if (!currentSession) return;

    const score = Math.floor(Math.random() * 30) + 70; // Simulate score
    const accuracy = Math.floor(Math.random() * 20) + 80; // Simulate accuracy

    setAvailableSessions(prev => 
      prev.map(s => s.id === currentSession.id ? { 
        ...s, 
        status: 'completed',
        score,
        accuracy,
        completedAt: new Date()
      } : s)
    );

    // Update metrics based on session type
    setCognitiveMetrics(prev => 
      prev.map(metric => {
        if (metric.domain.toLowerCase().includes(currentSession.type)) {
          return { ...metric, current: Math.min(100, metric.current + 2) };
        }
        return metric;
      })
    );

    setSessionActive(false);
    setCurrentSession(null);
    setSessionTime(0);

    toast({
      title: "Session Completed!",
      description: `Great work! Score: ${score}/100, Accuracy: ${accuracy}%`,
    });

    // AI feedback
    setAIMessages(prev => [...prev, {
      id: Date.now().toString(),
      content: getAIFeedback(score, accuracy, currentSession.type),
      timestamp: new Date(),
      type: 'achievement'
    }]);
  };

  const getAIEncouragement = (session: CognitiveSession): string => {
    const encouragements = {
      memory: "Let's strengthen those neural pathways! Memory training creates lasting changes in your hippocampus.",
      attention: "Focus is like a muscle - the more we train it, the stronger it becomes. You've got this!",
      processing: "Speed isn't everything, but efficient processing helps in daily life. Take your time but stay alert!",
      problem_solving: "Each puzzle you solve creates new connections. Your brain loves these challenges!",
      verbal: "Language skills engage multiple brain regions. Feel those synapses firing!",
      visual_spatial: "Spatial reasoning is fundamental to navigation and problem-solving. Let's map those neural networks!"
    };
    return encouragements[session.type] || "Ready to challenge your brain? Every session makes you cognitively stronger!";
  };

  const getAIFeedback = (score: number, accuracy: number, type: string): string => {
    if (score >= 90) {
      return `Outstanding! ${score}% shows exceptional cognitive performance. Your ${type} skills are in the top tier. I'm seeing real neuroplasticity in action!`;
    } else if (score >= 80) {
      return `Excellent progress! ${score}% demonstrates solid improvement in ${type}. Your consistency is building lasting cognitive strength.`;
    } else if (score >= 70) {
      return `Good work! ${score}% shows steady growth. Remember, every challenge strengthens your cognitive reserves. Your effort is creating positive brain changes.`;
    } else {
      return `Don't be discouraged! ${score}% is part of the learning process. Neuroplasticity means your brain is adapting. Each attempt builds resilience and skill.`;
    }
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getMetricColor = (trend: string) => {
    switch (trend) {
      case 'improving': return 'text-green-600';
      case 'declining': return 'text-red-600';
      default: return 'text-yellow-600';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'improving': return TrendingUp;
      case 'declining': return AlertTriangle;
      default: return Activity;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-blue-50 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* AI Companion Header */}
        <Card className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="text-6xl">{aiPersonality.avatar}</div>
                <div>
                  <h1 className="text-3xl font-bold">{aiPersonality.name}</h1>
                  <p className="text-purple-100">Cognitive Enhancement AI • Neural Training Specialist</p>
                  <div className="flex gap-2 mt-2">
                    {aiPersonality.specialization.map((spec, index) => (
                      <Badge key={index} variant="secondary" className="bg-white/20 text-white border-0">
                        {spec}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-purple-100">Current Status</div>
                <div className="text-2xl font-bold capitalize">{aiPersonality.currentMood}</div>
                <div className="text-sm text-purple-100">Ready to enhance your cognition</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Active Session Monitor */}
        {currentSession && (
          <Card className="border-2 border-purple-500 bg-purple-50">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5 text-purple-600" />
                  Active Session: {currentSession.title}
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  <span className="font-mono text-lg">{formatTime(sessionTime)}</span>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <Progress 
                    value={(sessionTime / (currentSession.duration * 60)) * 100} 
                    className="mb-2" 
                  />
                  <p className="text-sm text-gray-600">{currentSession.description}</p>
                </div>
                <div className="flex gap-2 ml-4">
                  {sessionActive ? (
                    <Button onClick={pauseSession} variant="outline" size="sm">
                      <Pause className="h-4 w-4 mr-2" />
                      Pause
                    </Button>
                  ) : (
                    <Button onClick={resumeSession} variant="outline" size="sm">
                      <Play className="h-4 w-4 mr-2" />
                      Resume
                    </Button>
                  )}
                  <Button onClick={completeSession} size="sm">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Complete
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="sessions">Training Sessions</TabsTrigger>
            <TabsTrigger value="progress">Progress Tracking</TabsTrigger>
            <TabsTrigger value="ai-chat">AI Insights</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            {/* Cognitive Metrics Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {cognitiveMetrics.map((metric, index) => {
                const TrendIcon = getTrendIcon(metric.trend);
                const improvement = parseFloat(((metric.current - metric.baseline) / metric.baseline * 100).toFixed(1));
                const progressToTarget = ((metric.current - metric.baseline) / (metric.target - metric.baseline) * 100);

                return (
                  <Card key={index}>
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">{metric.domain}</CardTitle>
                        <TrendIcon className={`h-5 w-5 ${getMetricColor(metric.trend)}`} />
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-3xl font-bold text-purple-600">{metric.current}</span>
                          <Badge variant={metric.trend === 'improving' ? 'default' : 'secondary'}>
                            {improvement > 0 ? '+' : ''}{improvement}%
                          </Badge>
                        </div>
                        
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Progress to Target</span>
                            <span>{metric.target}</span>
                          </div>
                          <Progress value={Math.max(0, Math.min(100, progressToTarget))} className="h-2" />
                        </div>

                        <div className="text-sm text-gray-600">
                          {metric.sessions} sessions completed
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5" />
                  Quick Start Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-blue-50 rounded-lg cursor-pointer hover:bg-blue-100 transition-colors">
                    <div className="flex items-center gap-3 mb-2">
                      <Archive className="h-6 w-6 text-blue-600" />
                      <span className="font-medium">Memory Boost</span>
                    </div>
                    <p className="text-sm text-gray-600">15-minute session recommended for your peak performance time</p>
                    <Button size="sm" className="mt-3 w-full">Start Now</Button>
                  </div>

                  <div className="p-4 bg-green-50 rounded-lg cursor-pointer hover:bg-green-100 transition-colors">
                    <div className="flex items-center gap-3 mb-2">
                      <Target className="h-6 w-6 text-green-600" />
                      <span className="font-medium">Attention Training</span>
                    </div>
                    <p className="text-sm text-gray-600">Build focus strength with adaptive difficulty</p>
                    <Button size="sm" className="mt-3 w-full">Start Now</Button>
                  </div>

                  <div className="p-4 bg-purple-50 rounded-lg cursor-pointer hover:bg-purple-100 transition-colors">
                    <div className="flex items-center gap-3 mb-2">
                      <Puzzle className="h-6 w-6 text-purple-600" />
                      <span className="font-medium">Problem Solving</span>
                    </div>
                    <p className="text-sm text-gray-600">Challenge your reasoning with logic puzzles</p>
                    <Button size="sm" className="mt-3 w-full">Start Now</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="sessions" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {availableSessions.map((session) => (
                <Card key={session.id} className={`${session.status === 'completed' ? 'bg-green-50 border-green-200' : ''}`}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{session.title}</CardTitle>
                      <Badge variant={
                        session.status === 'completed' ? 'default' :
                        session.status === 'in_progress' ? 'secondary' : 'outline'
                      }>
                        {session.status.replace('_', ' ')}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600">{session.description}</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between text-sm">
                      <span>Duration: {session.duration} minutes</span>
                      <span>Difficulty: {session.difficulty}</span>
                    </div>

                    {session.score && (
                      <div className="bg-green-100 p-3 rounded-lg">
                        <div className="flex justify-between">
                          <span>Score: {session.score}/100</span>
                          <span>Accuracy: {session.accuracy}%</span>
                        </div>
                      </div>
                    )}

                    <div>
                      <div className="text-sm font-medium mb-2">Target Improvements:</div>
                      <div className="flex flex-wrap gap-1">
                        {session.improvements.map((improvement, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {improvement}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <Button 
                      onClick={() => startSession(session)}
                      disabled={session.status === 'in_progress' || session.status === 'completed'}
                      className="w-full"
                    >
                      {session.status === 'completed' ? 'Completed' :
                       session.status === 'in_progress' ? 'In Progress' :
                       'Start Session'}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="progress" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Cognitive Progress Over Time</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={progressData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis domain={[0, 100]} />
                    <Tooltip />
                    <Line type="monotone" dataKey="memory" stroke="#8B5CF6" strokeWidth={2} name="Memory" />
                    <Line type="monotone" dataKey="attention" stroke="#06B6D4" strokeWidth={2} name="Attention" />
                    <Line type="monotone" dataKey="processing" stroke="#10B981" strokeWidth={2} name="Processing" />
                    <Line type="monotone" dataKey="problemSolving" stroke="#F59E0B" strokeWidth={2} name="Problem Solving" />
                    <Line type="monotone" dataKey="overall" stroke="#EF4444" strokeWidth={3} name="Overall" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Cognitive Profile</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <RadarChart data={cognitiveMetrics}>
                      <PolarGrid />
                      <PolarAngleAxis dataKey="domain" />
                      <PolarRadiusAxis domain={[0, 100]} />
                      <Radar name="Current" dataKey="current" stroke="#8B5CF6" fill="#8B5CF6" fillOpacity={0.3} />
                      <Radar name="Target" dataKey="target" stroke="#06B6D4" fill="transparent" strokeDasharray="5 5" />
                    </RadarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Achievements</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-yellow-50 rounded-lg">
                    <Award className="h-6 w-6 text-yellow-600" />
                    <div>
                      <div className="font-medium">Memory Master</div>
                      <div className="text-sm text-gray-600">Completed 15 memory sessions</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                    <Star className="h-6 w-6 text-green-600" />
                    <div>
                      <div className="font-medium">Consistency Streak</div>
                      <div className="text-sm text-gray-600">7 days of training</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                    <TrendingUp className="h-6 w-6 text-blue-600" />
                    <div>
                      <div className="font-medium">Rapid Improvement</div>
                      <div className="text-sm text-gray-600">15% gain in processing speed</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="ai-chat" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="h-5 w-5" />
                  AI Cognitive Coach - Dr. Mira
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {aiMessages.map((message) => (
                    <div key={message.id} className="flex gap-3">
                      <div className="text-2xl">{aiPersonality.avatar}</div>
                      <div className="flex-1 bg-gray-50 p-3 rounded-lg">
                        <p className="text-sm">{message.content}</p>
                        <div className="text-xs text-gray-500 mt-2">
                          {message.timestamp.toLocaleTimeString()}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="mt-4 flex gap-2">
                  <input 
                    type="text" 
                    placeholder="Ask Dr. Mira about your cognitive training..."
                    className="flex-1 p-2 border rounded-lg"
                  />
                  <Button>Send</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Total Training Time</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-blue-600">47.5</div>
                  <div className="text-sm text-gray-600">hours completed</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Sessions Completed</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-green-600">89</div>
                  <div className="text-sm text-gray-600">across all domains</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Average Improvement</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-purple-600">+12.4%</div>
                  <div className="text-sm text-gray-600">cognitive performance</div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Neuroplasticity Indicators</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium mb-3">Learning Efficiency</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Speed of Acquisition</span>
                        <span className="font-medium">85%</span>
                      </div>
                      <Progress value={85} className="h-2" />
                      
                      <div className="flex justify-between">
                        <span className="text-sm">Retention Rate</span>
                        <span className="font-medium">92%</span>
                      </div>
                      <Progress value={92} className="h-2" />
                      
                      <div className="flex justify-between">
                        <span className="text-sm">Transfer to Daily Life</span>
                        <span className="font-medium">78%</span>
                      </div>
                      <Progress value={78} className="h-2" />
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-3">Brain Adaptability</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Neural Efficiency</span>
                        <span className="font-medium">88%</span>
                      </div>
                      <Progress value={88} className="h-2" />
                      
                      <div className="flex justify-between">
                        <span className="text-sm">Cognitive Flexibility</span>
                        <span className="font-medium">81%</span>
                      </div>
                      <Progress value={81} className="h-2" />
                      
                      <div className="flex justify-between">
                        <span className="text-sm">Processing Optimization</span>
                        <span className="font-medium">75%</span>
                      </div>
                      <Progress value={75} className="h-2" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}