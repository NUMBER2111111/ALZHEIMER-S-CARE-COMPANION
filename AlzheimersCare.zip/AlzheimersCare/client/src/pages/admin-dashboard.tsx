import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { ROIMetrics } from "@/components/roi-metrics";
import { CareCompanionAPI } from "@/lib/api";
import { 
  Hospital, 
  Users, 
  Brain, 
  TrendingUp, 
  Shield, 
  Download, 
  ChartLine,
  Heart,
  DollarSign,
  Calendar,
  Activity
} from "lucide-react";

interface AdminDashboardProps {
  facilityId?: string;
}

export default function AdminDashboard({ facilityId: routeFacilityId }: AdminDashboardProps) {
  const params = useParams();
  const facilityId = routeFacilityId || params.facilityId || "1";
  
  const [selectedTimeRange, setSelectedTimeRange] = useState("30d");

  const { data: analytics, isLoading: analyticsLoading } = useQuery({
    queryKey: ["/api/admin/analytics", facilityId],
    enabled: !!facilityId,
  });

  const { data: facilities, isLoading: facilitiesLoading } = useQuery({
    queryKey: ["/api/facilities"],
  });

  if (analyticsLoading || facilitiesLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 bg-care-primary rounded-full ai-pulse mx-auto mb-4"></div>
          <p className="text-gray-600">Loading analytics dashboard...</p>
        </div>
      </div>
    );
  }

  const facility = analytics?.facility;
  const benefitsAnalysis = analytics?.benefitsAnalysis;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 care-gradient rounded-lg flex items-center justify-center">
                <Hospital className="text-white h-6 w-6" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  {facility?.name || "Care Facility"} - Admin Dashboard
                </h1>
                <p className="text-gray-600">AI-Powered Alzheimer's Care Analytics & ROI</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-accent/10 px-3 py-1 rounded-full">
                <div className="w-2 h-2 bg-accent rounded-full ai-pulse"></div>
                <span className="text-sm font-medium text-accent">AI Analytics Active</span>
              </div>
              <Button className="bg-care-secondary text-white hover:bg-care-secondary/90">
                <Download className="mr-2 h-4 w-4" />
                Export Report
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="patients">Patient Analytics</TabsTrigger>
            <TabsTrigger value="roi">ROI & Benefits</TabsTrigger>
            <TabsTrigger value="insurance">Insurance Integration</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Patients</CardTitle>
                  <Users className="h-4 w-4 text-care-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{analytics?.patientCount || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    Active in Care Companion program
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Care Quality Score</CardTitle>
                  <Brain className="h-4 w-4 text-care-secondary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-care-secondary">
                    {benefitsAnalysis?.roiMetrics?.careQualityScore || 85}%
                  </div>
                  <p className="text-xs text-muted-foreground">
                    +23% improvement this quarter
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Annual ROI</CardTitle>
                  <DollarSign className="h-4 w-4 text-green-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">
                    ${benefitsAnalysis?.roiMetrics?.annualSavings || "3.2M"}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Insurance benefits + efficiency gains
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Family Satisfaction</CardTitle>
                  <Heart className="h-4 w-4 text-red-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-500">94%</div>
                  <p className="text-xs text-muted-foreground">
                    Based on family feedback surveys
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* ROI Metrics Component */}
            <ROIMetrics analytics={analytics} />

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Activity className="mr-2 h-5 w-5 text-care-primary" />
                  Recent AI-Generated Activities
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 ai-gradient rounded-lg flex items-center justify-center">
                          <Brain className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">Photo Recognition: Family Wedding</p>
                          <p className="text-sm text-gray-500">Generated for Patient #{i} • 2 hours ago</p>
                        </div>
                      </div>
                      <Badge className="bg-care-secondary text-white">85% Success Rate</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="patients" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Patient Cognitive Progress Analytics</CardTitle>
                <p className="text-gray-600">AI-tracked cognitive improvements across all patients</p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-care-secondary mb-2">78%</div>
                    <p className="text-sm text-gray-600">Average Memory Recall</p>
                    <Progress value={78} className="mt-2" />
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-care-primary mb-2">82%</div>
                    <p className="text-sm text-gray-600">Recognition Performance</p>
                    <Progress value={82} className="mt-2" />
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-accent mb-2">74%</div>
                    <p className="text-sm text-gray-600">Attention & Focus</p>
                    <Progress value={74} className="mt-2" />
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900">Top Performing Patients</h4>
                  {analytics?.patientOutcomes?.slice(0, 5).map((outcome: any, index: number) => (
                    <div key={index} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-care-primary/10 rounded-full flex items-center justify-center">
                          <Users className="h-5 w-5 text-care-primary" />
                        </div>
                        <div>
                          <p className="font-medium">Patient #{outcome.patientId}</p>
                          <p className="text-sm text-gray-500">{outcome.sessionCount} activities completed</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-care-secondary">
                          {Math.round(outcome.averageSuccessRate)}%
                        </div>
                        <p className="text-xs text-gray-500">Success Rate</p>
                      </div>
                    </div>
                  )) || []}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="roi" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="mr-2 h-5 w-5 text-care-secondary" />
                    Financial Impact Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-green-50 p-4 rounded-lg">
                      <p className="text-2xl font-bold text-green-600">$3.2M</p>
                      <p className="text-sm text-green-700">Annual Insurance Benefits</p>
                    </div>
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <p className="text-2xl font-bold text-care-primary">18%</p>
                      <p className="text-sm text-care-primary">Staff Efficiency Gain</p>
                    </div>
                    <div className="bg-purple-50 p-4 rounded-lg">
                      <p className="text-2xl font-bold text-accent">23%</p>
                      <p className="text-sm text-accent">Care Quality Improvement</p>
                    </div>
                    <div className="bg-yellow-50 p-4 rounded-lg">
                      <p className="text-2xl font-bold text-yellow-600">$890K</p>
                      <p className="text-sm text-yellow-700">Cost Reduction</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="font-semibold">Key Benefits</h4>
                    <ul className="space-y-2">
                      <li className="flex items-center">
                        <div className="w-2 h-2 bg-care-secondary rounded-full mr-3"></div>
                        <span className="text-sm">Reduced staff turnover (15% improvement)</span>
                      </li>
                      <li className="flex items-center">
                        <div className="w-2 h-2 bg-care-secondary rounded-full mr-3"></div>
                        <span className="text-sm">Increased family satisfaction (94% rating)</span>
                      </li>
                      <li className="flex items-center">
                        <div className="w-2 h-2 bg-care-secondary rounded-full mr-3"></div>
                        <span className="text-sm">Measurable cognitive improvements</span>
                      </li>
                      <li className="flex items-center">
                        <div className="w-2 h-2 bg-care-secondary rounded-full mr-3"></div>
                        <span className="text-sm">Automated compliance documentation</span>
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <ChartLine className="mr-2 h-5 w-5 text-accent" />
                    Performance Trends
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium">Cognitive Training Effectiveness</span>
                        <span className="text-sm text-care-secondary">87%</span>
                      </div>
                      <Progress value={87} className="h-2" />
                    </div>
                    
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium">Family Engagement Score</span>
                        <span className="text-sm text-care-primary">92%</span>
                      </div>
                      <Progress value={92} className="h-2" />
                    </div>
                    
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium">AI Processing Accuracy</span>
                        <span className="text-sm text-accent">96%</span>
                      </div>
                      <Progress value={96} className="h-2" />
                    </div>

                    <div className="bg-gradient-to-r from-care-primary/10 to-care-secondary/10 p-4 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-2">Monthly Improvement</h4>
                      <p className="text-sm text-gray-600">
                        Cognitive scores show consistent 12% monthly improvement with AI-personalized activities.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="insurance" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Shield className="mr-2 h-5 w-5 text-accent" />
                  Insurance Integration & Compliance
                </CardTitle>
                <p className="text-gray-600">
                  Automated documentation and billing support for cognitive therapy services
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-semibold text-green-900 mb-2">Medicare Compliance</h4>
                    <p className="text-sm text-green-800">100% compliant documentation</p>
                    <Badge className="mt-2 bg-green-100 text-green-800">✓ Verified</Badge>
                  </div>
                  
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h4 className="font-semibold text-blue-900 mb-2">Medicaid Integration</h4>
                    <p className="text-sm text-blue-800">Automated billing support</p>
                    <Badge className="mt-2 bg-blue-100 text-blue-800">✓ Active</Badge>
                  </div>
                  
                  <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                    <h4 className="font-semibold text-purple-900 mb-2">Private Insurance</h4>
                    <p className="text-sm text-purple-800">Multi-provider support</p>
                    <Badge className="mt-2 bg-purple-100 text-purple-800">✓ Integrated</Badge>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900">Reimbursement Opportunities</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium">Cognitive Therapy Sessions</p>
                        <p className="text-sm text-gray-500">CPT Code: 97532</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-green-600">$180-250</p>
                        <p className="text-xs text-gray-500">per session</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium">AI-Enhanced Assessment</p>
                        <p className="text-sm text-gray-500">CPT Code: 96116</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-green-600">$95-140</p>
                        <p className="text-xs text-gray-500">per assessment</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium">Family Training & Support</p>
                        <p className="text-sm text-gray-500">CPT Code: 97550</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-green-600">$75-120</p>
                        <p className="text-xs text-gray-500">per session</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-accent/10 rounded-lg p-4">
                  <h4 className="font-semibold text-accent mb-2">Projected Annual Revenue</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-2xl font-bold text-accent">$3.2M</p>
                      <p className="text-sm text-gray-600">Direct insurance reimbursements</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-care-secondary">$890K</p>
                      <p className="text-sm text-gray-600">Operational savings</p>
                    </div>
                  </div>
                </div>

                <Button className="w-full bg-care-secondary text-white hover:bg-care-secondary/90">
                  <Download className="mr-2 h-4 w-4" />
                  Download Insurance Benefits Package
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
