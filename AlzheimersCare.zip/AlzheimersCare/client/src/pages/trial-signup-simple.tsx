import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { CreditCard, Shield, Clock, CheckCircle, AlertCircle, Heart, Brain } from 'lucide-react';
import { useLocation } from 'wouter';
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

// Form validation schema
const trialSignupSchema = z.object({
  firstName: z.string().min(2, 'First name must be at least 2 characters'),
  lastName: z.string().min(2, 'Last name must be at least 2 characters'),
  email: z.string().email('Please enter a valid email address'),
  phone: z.string().min(10, 'Please enter a valid phone number'),
  acceptTerms: z.boolean().refine(val => val === true, 'You must accept the terms and conditions')
});

type TrialSignupForm = z.infer<typeof trialSignupSchema>;

export default function TrialSignupSimple() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [step, setStep] = useState<'info' | 'payment' | 'success'>('info');
  const [userInfo, setUserInfo] = useState<TrialSignupForm | null>(null);
  
  const form = useForm<TrialSignupForm>({
    resolver: zodResolver(trialSignupSchema),
    defaultValues: {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      acceptTerms: false
    }
  });

  const handleInfoSubmit = async (data: TrialSignupForm) => {
    setUserInfo(data);
    setStep('payment');
  };

  const handlePaymentSubmit = async () => {
    if (!userInfo) return;
    
    setIsProcessing(true);
    
    try {
      // Create Square customer and start trial
      const data = await apiRequest('POST', '/api/square/create-trial-customer', {
        ...userInfo,
        trialDays: 14,
        subscriptionAmount: 4999 // $49.99 in cents
      });

      // Track analytics for trial signup
      try {
        await apiRequest('POST', '/api/analytics/track-trial', {
          email: userInfo.email,
          firstName: userInfo.firstName,
          lastName: userInfo.lastName,
          phoneNumber: userInfo.phone,
        });
      } catch (analyticsError) {
        console.log('Analytics tracking failed:', analyticsError);
        // Don't block trial signup if analytics fails
      }

      setStep('success');
      toast({
        title: "Trial Started!",
        description: "Your 14-day free trial has begun. Welcome to Care Companion!",
      });
    } catch (error: any) {
      console.error('Trial signup error:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to start trial. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  if (step === 'success') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-teal-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <CardTitle className="text-2xl font-bold text-green-900">Trial Started!</CardTitle>
            <CardDescription>Your 14-day free trial is now active</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center space-y-2">
              <p className="text-gray-600">Welcome to Care Companion, {userInfo?.firstName}!</p>
              <p className="text-sm text-gray-500">
                You have 14 days to explore all premium features. After the trial, you'll be charged $49.99/month.
              </p>
            </div>
            <Button 
              onClick={() => navigate('/patient-companion')} 
              className="w-full"
            >
              Start Using Care Companion
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (step === 'payment') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-teal-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="w-5 h-5" />
              Complete Your Trial Setup
            </CardTitle>
            <CardDescription>
              Add your payment method to start your 14-day free trial
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <Alert>
              <Shield className="h-4 w-4" />
              <AlertDescription>
                <strong>Your Information:</strong> {userInfo?.firstName} {userInfo?.lastName} ({userInfo?.email})
              </AlertDescription>
            </Alert>

            <div className="space-y-4">
              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <h3 className="font-semibold text-yellow-900 mb-2">Credit Card Information</h3>
                <p className="text-sm text-yellow-800 mb-4">
                  Your card will not be charged during the 14-day trial period. After the trial, 
                  you'll be automatically charged $49.99/month unless you cancel.
                </p>
                
                {/* Square Pay integration will be added here */}
                <div className="space-y-3">
                  <div>
                    <Label htmlFor="card-number">Card Number</Label>
                    <Input id="card-number" placeholder="1234 5678 9012 3456" />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label htmlFor="expiry">Expiry Date</Label>
                      <Input id="expiry" placeholder="MM/YY" />
                    </div>
                    <div>
                      <Label htmlFor="cvv">CVV</Label>
                      <Input id="cvv" placeholder="123" />
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Shield className="w-4 h-4" />
                <span>256-bit SSL encryption • PCI DSS compliant • 100% money-back guarantee</span>
              </div>
            </div>

            <div className="space-y-3">
              <Button 
                onClick={handlePaymentSubmit}
                disabled={isProcessing}
                className="w-full"
              >
                {isProcessing ? 'Processing...' : 'Start 14-Day Free Trial'}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setStep('info')}
                className="w-full"
              >
                Back to Information
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-blue-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-teal-600 to-blue-600 rounded-xl flex items-center justify-center">
              <Heart className="h-6 w-6 text-white" />
            </div>
            <div>
              <CardTitle>Care Companion</CardTitle>
              <CardDescription>Start your free trial</CardDescription>
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-teal-600" />
              <span className="text-sm font-medium">14-day free trial</span>
            </div>
            <div className="flex items-center gap-2">
              <Brain className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium">Full AI companion access</span>
            </div>
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-green-600" />
              <span className="text-sm font-medium">No commitment required</span>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={form.handleSubmit(handleInfoSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="firstName">First Name</Label>
                <Input
                  id="firstName"
                  {...form.register('firstName')}
                  placeholder="Enter first name"
                />
                {form.formState.errors.firstName && (
                  <p className="text-sm text-red-600">{form.formState.errors.firstName.message}</p>
                )}
              </div>
              <div>
                <Label htmlFor="lastName">Last Name</Label>
                <Input
                  id="lastName"
                  {...form.register('lastName')}
                  placeholder="Enter last name"
                />
                {form.formState.errors.lastName && (
                  <p className="text-sm text-red-600">{form.formState.errors.lastName.message}</p>
                )}
              </div>
            </div>

            <div>
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                {...form.register('email')}
                placeholder="Enter your email"
              />
              {form.formState.errors.email && (
                <p className="text-sm text-red-600">{form.formState.errors.email.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                type="tel"
                {...form.register('phone')}
                placeholder="Enter your phone number"
              />
              {form.formState.errors.phone && (
                <p className="text-sm text-red-600">{form.formState.errors.phone.message}</p>
              )}
            </div>

            <div className="flex items-start space-x-2">
              <input
                id="acceptTerms"
                type="checkbox"
                {...form.register('acceptTerms')}
                className="mt-1"
              />
              <Label htmlFor="acceptTerms" className="text-sm leading-relaxed">
                I agree to the Terms of Service and Privacy Policy
              </Label>
            </div>
            {form.formState.errors.acceptTerms && (
              <p className="text-sm text-red-600">{form.formState.errors.acceptTerms.message}</p>
            )}

            <Button type="submit" className="w-full">
              Continue to Payment
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}