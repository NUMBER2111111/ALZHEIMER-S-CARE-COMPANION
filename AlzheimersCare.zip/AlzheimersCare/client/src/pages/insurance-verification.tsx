import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle, AlertCircle, Phone, FileText, Heart } from "lucide-react";

export default function InsuranceVerification() {
  const [insuranceType, setInsuranceType] = useState("");
  const [planName, setPlanName] = useState("");
  const [memberID, setMemberID] = useState("");
  const [showResults, setShowResults] = useState(false);
  const [coverageResult, setCoverageResult] = useState<string>("");

  const handleVerification = () => {
    setShowResults(true);
    
    // Determine coverage likelihood based on insurance type
    if (insuranceType === "medicare-advantage") {
      setCoverageResult("high");
    } else if (insuranceType === "private-commercial") {
      setCoverageResult("medium");
    } else if (insuranceType === "medicaid") {
      setCoverageResult("medium");
    } else {
      setCoverageResult("low");
    }
  };

  const getCoverageInfo = (result: string) => {
    switch (result) {
      case "high":
        return {
          title: "Excellent Coverage Potential",
          description: "Your plan type frequently covers remote patient monitoring and AI-assisted care.",
          color: "text-green-600",
          icon: CheckCircle,
          likelihood: "70-85%"
        };
      case "medium":
        return {
          title: "Good Coverage Potential", 
          description: "Your plan may cover our services under specific benefit categories.",
          color: "text-blue-600",
          icon: AlertCircle,
          likelihood: "45-70%"
        };
      default:
        return {
          title: "Limited Coverage",
          description: "Coverage less likely but still possible under certain circumstances.",
          color: "text-orange-600", 
          icon: AlertCircle,
          likelihood: "15-30%"
        };
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-blue-50 p-4">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="w-16 h-16 bg-gradient-to-br from-teal-400 to-blue-500 rounded-full flex items-center justify-center">
              <Heart className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900">Insurance Coverage Verification</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Check if your insurance may cover Care Companion AI under remote patient monitoring benefits
          </p>
        </div>

        {/* Coverage Overview */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              How Insurance Coverage Works
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">Medicare Part B</div>
                <div className="text-sm text-gray-600">Remote Patient Monitoring</div>
                <div className="text-xs mt-2">Billing Codes: 99453-99458</div>
              </div>
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">Private Insurance</div>
                <div className="text-sm text-gray-600">Chronic Care Management</div>
                <div className="text-xs mt-2">Telehealth Benefits</div>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <div className="text-2xl font-bold text-purple-600">HSA/FSA</div>
                <div className="text-sm text-gray-600">Medical Equipment</div>
                <div className="text-xs mt-2">Tax-Free Payment</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Verification Form */}
        <Card>
          <CardHeader>
            <CardTitle>Check Your Coverage</CardTitle>
            <CardDescription>
              Enter your insurance information to get personalized coverage guidance
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="insurance-type">Insurance Type</Label>
                <Select value={insuranceType} onValueChange={setInsuranceType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select your insurance type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="medicare-original">Medicare Original (Parts A & B)</SelectItem>
                    <SelectItem value="medicare-advantage">Medicare Advantage</SelectItem>
                    <SelectItem value="private-commercial">Private/Commercial Insurance</SelectItem>
                    <SelectItem value="medicaid">Medicaid</SelectItem>
                    <SelectItem value="tricare">TRICARE</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="plan-name">Plan Name (Optional)</Label>
                <Input 
                  id="plan-name"
                  placeholder="e.g., Blue Cross Blue Shield"
                  value={planName}
                  onChange={(e) => setPlanName(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="member-id">Member ID (Optional - for personalized guidance)</Label>
              <Input 
                id="member-id"
                placeholder="Your insurance member ID"
                value={memberID}
                onChange={(e) => setMemberID(e.target.value)}
              />
            </div>

            <Button 
              onClick={handleVerification}
              className="w-full bg-teal-600 hover:bg-teal-700"
              disabled={!insuranceType}
            >
              Check Coverage Potential
            </Button>
          </CardContent>
        </Card>

        {/* Results */}
        {showResults && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {(() => {
                  const info = getCoverageInfo(coverageResult);
                  const IconComponent = info.icon;
                  return (
                    <>
                      <IconComponent className={`w-5 h-5 ${info.color}`} />
                      {info.title}
                    </>
                  );
                })()}
              </CardTitle>
              <CardDescription>
                Coverage likelihood: {getCoverageInfo(coverageResult).likelihood}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-gray-700">
                {getCoverageInfo(coverageResult).description}
              </p>

              {/* Next Steps */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-semibold mb-3">Next Steps to Verify Coverage:</h3>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <Phone className="w-5 h-5 text-blue-600 mt-0.5" />
                    <div>
                      <div className="font-medium">Call Your Insurance</div>
                      <div className="text-sm text-gray-600">
                        Use the script below to ask about Remote Patient Monitoring coverage
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Phone Script */}
              <Card className="bg-blue-50 border-blue-200">
                <CardHeader>
                  <CardTitle className="text-lg">What to Say When You Call</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-white p-4 rounded border-l-4 border-blue-500 text-sm">
                    <p className="font-medium mb-2">"Hi, I need to verify coverage for remote patient monitoring services for my [relationship] who has Alzheimer's disease."</p>
                    
                    <p className="mb-2"><strong>Ask specifically:</strong></p>
                    <ul className="list-disc list-inside space-y-1 ml-4">
                      <li>Do you cover Remote Patient Monitoring (RPM) under my plan?</li>
                      <li>Are AI-assisted health monitoring devices covered?</li>
                      <li>What are the billing codes for RPM? (99453-99458)</li>
                      <li>Is prior authorization required?</li>
                      <li>What would my copay or deductible be?</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              {/* Coverage Categories */}
              <div className="grid md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Likely Covered Under:</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        Remote Patient Monitoring
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        Chronic Care Management
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        Telehealth Services
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        Durable Medical Equipment
                      </li>
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Alternative Payment:</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600" />
                        HSA/FSA Eligible
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600" />
                        Tax Deductible Medical Expense
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600" />
                        Payment Plans Available
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600" />
                        14-Day Free Trial
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </div>

              {/* Support */}
              <div className="text-center p-4 bg-teal-50 rounded-lg">
                <h3 className="font-semibold mb-2">Need Help with Insurance Verification?</h3>
                <p className="text-sm text-gray-600 mb-3">
                  Our insurance specialists can help you navigate the verification process
                </p>
                <Button variant="outline" className="border-teal-600 text-teal-700">
                  Schedule Free Insurance Consultation
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Disclaimer */}
        <Card className="border-amber-200 bg-amber-50">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-amber-800 mb-1">Important Disclaimer</p>
                <p className="text-amber-700">
                  This tool provides general guidance only. Actual coverage depends on your specific plan, medical necessity, 
                  and other factors determined by your insurance provider. Always verify directly with your insurance company. 
                  Care Companion AI cannot guarantee insurance coverage.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}