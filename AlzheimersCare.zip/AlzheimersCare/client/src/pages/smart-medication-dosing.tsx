import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertTriangle, Clock, TrendingUp, Brain, Heart, Activity, Pill, AlertCircle, CheckCircle, Calendar, Zap } from 'lucide-react';

export default function SmartMedicationDosing() {
  const [currentMedications, setCurrentMedications] = useState([
    {
      id: 1,
      name: "Donepezil",
      dosage: "10mg",
      frequency: "Once daily",
      nextDose: "8:00 AM",
      adherence: 94,
      effectiveness: 87,
      sideEffects: ["Mild nausea", "Occasional dizziness"],
      aiRecommendation: "Optimal dosage - continue current regimen"
    },
    {
      id: 2,
      name: "Memantine",
      dosage: "20mg",
      frequency: "Twice daily",
      nextDose: "2:00 PM",
      adherence: 89,
      effectiveness: 76,
      sideEffects: ["Headache"],
      aiRecommendation: "Consider splitting evening dose for better tolerance"
    },
    {
      id: 3,
      name: "Vitamin E",
      dosage: "400 IU",
      frequency: "Once daily",
      nextDose: "6:00 PM",
      adherence: 98,
      effectiveness: 68,
      sideEffects: [],
      aiRecommendation: "Good adherence - monitor cognitive markers"
    }
  ]);

  const [biomarkers, setBiomarkers] = useState({
    acetylcholine: 72,
    amyloidBeta: 45,
    tauProtein: 38,
    inflammation: 29,
    oxidativeStress: 42,
    neurotransmitters: 78
  });

  const [dosageOptimization, setDosageOptimization] = useState({
    currentEffectiveness: 77,
    predictedImprovement: 12,
    riskFactor: 8,
    confidenceLevel: 91
  });

  const aiRecommendations = [
    {
      priority: "High",
      category: "Dosage Adjustment",
      medication: "Donepezil",
      recommendation: "Increase to 23mg daily based on genetic markers and tolerance profile",
      evidence: "Patient shows CYP2D6 normal metabolizer phenotype with good tolerability",
      expectedImprovement: "15-20% cognitive function improvement",
      riskLevel: "Low"
    },
    {
      priority: "Medium",
      category: "Timing Optimization",
      medication: "Memantine",
      recommendation: "Split 20mg dose to 10mg morning, 10mg evening",
      evidence: "Pharmacokinetic modeling suggests better steady-state levels",
      expectedImprovement: "Reduced side effects, improved adherence",
      riskLevel: "Very Low"
    },
    {
      priority: "Medium",
      category: "Combination Therapy",
      medication: "New: Aducanumab",
      recommendation: "Consider adding targeted amyloid therapy",
      evidence: "Elevated amyloid-beta levels detected, patient meets criteria",
      expectedImprovement: "Potential disease modification",
      riskLevel: "Medium"
    }
  ];

  const interactionWarnings = [
    {
      severity: "High",
      medications: ["Donepezil", "Ketoconazole"],
      warning: "CYP3A4 inhibition may increase donepezil levels",
      action: "Monitor for cholinergic side effects"
    },
    {
      severity: "Medium",
      medications: ["Memantine", "Carbonic Anhydrase Inhibitors"],
      warning: "May alter memantine clearance",
      action: "Consider dose adjustment if co-administered"
    }
  ];

  const pharmacogeneticProfile = {
    cyp2d6: "Normal Metabolizer",
    cyp3a4: "Intermediate Metabolizer",
    apoe4: "Heterozygous (ε3/ε4)",
    comt: "Val/Met",
    bdnf: "Val/Val"
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            AI-Powered Smart Medication Dosing
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            Precision medicine with pharmacogenomics and real-time biomarker monitoring
          </p>
        </div>

        <Tabs defaultValue="current" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="current">Current Medications</TabsTrigger>
            <TabsTrigger value="optimization">AI Optimization</TabsTrigger>
            <TabsTrigger value="biomarkers">Biomarkers</TabsTrigger>
            <TabsTrigger value="genetics">Pharmacogenetics</TabsTrigger>
            <TabsTrigger value="interactions">Drug Interactions</TabsTrigger>
          </TabsList>

          <TabsContent value="current" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {currentMedications.map((med) => (
                <Card key={med.id} className="relative">
                  <CardHeader className="pb-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{med.name}</CardTitle>
                        <CardDescription>{med.dosage} - {med.frequency}</CardDescription>
                      </div>
                      <Badge variant={med.adherence >= 90 ? 'default' : 'destructive'}>
                        {med.adherence}% adherent
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Next Dose:</span>
                        <span className="font-medium flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          {med.nextDose}
                        </span>
                      </div>
                      
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>Effectiveness:</span>
                          <span>{med.effectiveness}%</span>
                        </div>
                        <Progress value={med.effectiveness} className="h-2" />
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>Adherence:</span>
                          <span>{med.adherence}%</span>
                        </div>
                        <Progress value={med.adherence} className="h-2" />
                      </div>
                    </div>

                    {med.sideEffects.length > 0 && (
                      <div>
                        <div className="text-sm font-medium mb-2 text-orange-600 dark:text-orange-400">
                          Side Effects:
                        </div>
                        <div className="space-y-1">
                          {med.sideEffects.map((effect, index) => (
                            <div key={index} className="text-sm text-gray-600 dark:text-gray-400">
                              • {effect}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                      <div className="text-sm font-medium text-blue-700 dark:text-blue-400 mb-1">
                        AI Recommendation:
                      </div>
                      <div className="text-sm text-blue-600 dark:text-blue-300">
                        {med.aiRecommendation}
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button size="sm" className="flex-1">
                        <Pill className="h-4 w-4 mr-2" />
                        Take Now
                      </Button>
                      <Button size="sm" variant="outline">
                        Adjust
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="optimization" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  AI Dosage Optimization
                </CardTitle>
                <CardDescription>Machine learning-powered medication adjustments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                  <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <TrendingUp className="h-8 w-8 mx-auto mb-2 text-green-600" />
                    <div className="text-2xl font-bold text-green-700 dark:text-green-400">
                      {dosageOptimization.currentEffectiveness}%
                    </div>
                    <div className="text-sm text-green-600">Current Effectiveness</div>
                  </div>
                  <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <Zap className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                    <div className="text-2xl font-bold text-blue-700 dark:text-blue-400">
                      +{dosageOptimization.predictedImprovement}%
                    </div>
                    <div className="text-sm text-blue-600">Predicted Improvement</div>
                  </div>
                  <div className="text-center p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                    <AlertTriangle className="h-8 w-8 mx-auto mb-2 text-yellow-600" />
                    <div className="text-2xl font-bold text-yellow-700 dark:text-yellow-400">
                      {dosageOptimization.riskFactor}%
                    </div>
                    <div className="text-sm text-yellow-600">Risk Factor</div>
                  </div>
                  <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                    <CheckCircle className="h-8 w-8 mx-auto mb-2 text-purple-600" />
                    <div className="text-2xl font-bold text-purple-700 dark:text-purple-400">
                      {dosageOptimization.confidenceLevel}%
                    </div>
                    <div className="text-sm text-purple-600">AI Confidence</div>
                  </div>
                </div>

                <div className="space-y-4">
                  {aiRecommendations.map((rec, index) => (
                    <Card key={index} className={`border-l-4 ${
                      rec.priority === 'High' ? 'border-l-red-500' :
                      rec.priority === 'Medium' ? 'border-l-yellow-500' : 'border-l-green-500'
                    }`}>
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-lg">{rec.category}</CardTitle>
                            <CardDescription>{rec.medication}</CardDescription>
                          </div>
                          <div className="flex gap-2">
                            <Badge variant={rec.priority === 'High' ? 'destructive' : 'secondary'}>
                              {rec.priority} Priority
                            </Badge>
                            <Badge variant="outline">
                              {rec.riskLevel} Risk
                            </Badge>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div>
                          <div className="font-medium text-sm mb-1">Recommendation:</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">
                            {rec.recommendation}
                          </div>
                        </div>
                        <div>
                          <div className="font-medium text-sm mb-1">Evidence:</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">
                            {rec.evidence}
                          </div>
                        </div>
                        <div>
                          <div className="font-medium text-sm mb-1">Expected Outcome:</div>
                          <div className="text-sm text-green-600 dark:text-green-400">
                            {rec.expectedImprovement}
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" className="flex-1">
                            Implement Changes
                          </Button>
                          <Button size="sm" variant="outline">
                            Consult Doctor
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="biomarkers" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Real-time Biomarker Monitoring
                </CardTitle>
                <CardDescription>Molecular targets for medication effectiveness</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="font-medium">Acetylcholine Levels</span>
                        <span className="text-green-600">{biomarkers.acetylcholine}%</span>
                      </div>
                      <Progress value={biomarkers.acetylcholine} className="h-3" />
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        Target for cholinesterase inhibitors
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="font-medium">Amyloid Beta Clearance</span>
                        <span className="text-yellow-600">{biomarkers.amyloidBeta}%</span>
                      </div>
                      <Progress value={biomarkers.amyloidBeta} className="h-3" />
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        Below optimal - consider amyloid therapy
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="font-medium">Tau Protein Control</span>
                        <span className="text-yellow-600">{biomarkers.tauProtein}%</span>
                      </div>
                      <Progress value={biomarkers.tauProtein} className="h-3" />
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        Moderate elevation detected
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="font-medium">Inflammation Markers</span>
                        <span className="text-red-600">{biomarkers.inflammation}%</span>
                      </div>
                      <Progress value={biomarkers.inflammation} className="h-3" />
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        Elevated - anti-inflammatory therapy indicated
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="font-medium">Oxidative Stress</span>
                        <span className="text-yellow-600">{biomarkers.oxidativeStress}%</span>
                      </div>
                      <Progress value={biomarkers.oxidativeStress} className="h-3" />
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        Antioxidant therapy effective
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="font-medium">Neurotransmitter Balance</span>
                        <span className="text-green-600">{biomarkers.neurotransmitters}%</span>
                      </div>
                      <Progress value={biomarkers.neurotransmitters} className="h-3" />
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        Good response to current regimen
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="genetics" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="h-5 w-5" />
                  Pharmacogenetic Profile
                </CardTitle>
                <CardDescription>Genetic factors affecting drug metabolism and response</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg">Drug Metabolism Genes</h3>
                    {Object.entries(pharmacogeneticProfile).slice(0, 3).map(([gene, variant]) => (
                      <div key={gene} className="flex justify-between items-center p-3 border rounded-lg">
                        <div>
                          <div className="font-medium uppercase">{gene}</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">
                            {gene === 'cyp2d6' ? 'Donepezil metabolism' :
                             gene === 'cyp3a4' ? 'Multiple drug interactions' :
                             'Alzheimer\'s risk factor'}
                          </div>
                        </div>
                        <Badge variant={variant.includes('Normal') ? 'default' : 'secondary'}>
                          {variant}
                        </Badge>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg">Neurological Risk Genes</h3>
                    {Object.entries(pharmacogeneticProfile).slice(3).map(([gene, variant]) => (
                      <div key={gene} className="flex justify-between items-center p-3 border rounded-lg">
                        <div>
                          <div className="font-medium uppercase">{gene}</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">
                            {gene === 'comt' ? 'Dopamine metabolism' : 'Neuroplasticity factor'}
                          </div>
                        </div>
                        <Badge variant={variant.includes('ε4') ? 'destructive' : 'default'}>
                          {variant}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <h4 className="font-medium text-blue-700 dark:text-blue-400 mb-2">
                    Personalized Medication Insights:
                  </h4>
                  <div className="space-y-2 text-sm text-blue-600 dark:text-blue-300">
                    <div>• Normal CYP2D6 metabolism allows standard donepezil dosing</div>
                    <div>• APOE4 heterozygous status suggests good response to combination therapy</div>
                    <div>• COMT Val/Met variant indicates optimal dopaminergic medication response</div>
                    <div>• BDNF Val/Val supports neuroplasticity-enhancing interventions</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="interactions" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertCircle className="h-5 w-5" />
                  Drug Interaction Monitoring
                </CardTitle>
                <CardDescription>Real-time interaction detection and safety alerts</CardDescription>
              </CardHeader>
              <CardContent>
                {interactionWarnings.length > 0 ? (
                  <div className="space-y-4">
                    {interactionWarnings.map((warning, index) => (
                      <Card key={index} className={`border-l-4 ${
                        warning.severity === 'High' ? 'border-l-red-500 bg-red-50 dark:bg-red-900/10' :
                        'border-l-yellow-500 bg-yellow-50 dark:bg-yellow-900/10'
                      }`}>
                        <CardContent className="pt-6">
                          <div className="flex justify-between items-start mb-3">
                            <div className="flex items-center gap-2">
                              <AlertTriangle className={`h-5 w-5 ${
                                warning.severity === 'High' ? 'text-red-600' : 'text-yellow-600'
                              }`} />
                              <span className="font-medium">
                                {warning.medications.join(' + ')}
                              </span>
                            </div>
                            <Badge variant={warning.severity === 'High' ? 'destructive' : 'secondary'}>
                              {warning.severity} Risk
                            </Badge>
                          </div>
                          <div className="space-y-2">
                            <div>
                              <span className="font-medium text-sm">Warning: </span>
                              <span className="text-sm">{warning.warning}</span>
                            </div>
                            <div>
                              <span className="font-medium text-sm">Action Required: </span>
                              <span className="text-sm">{warning.action}</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <CheckCircle className="h-12 w-12 mx-auto mb-4 text-green-600" />
                    <div className="text-lg font-medium text-green-700 dark:text-green-400">
                      No Drug Interactions Detected
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      Current medication regimen is safe
                    </div>
                  </div>
                )}

                <div className="mt-6 p-4 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg">
                  <div className="text-center">
                    <Pill className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                    <div className="font-medium mb-2">Add New Medication</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                      Check for interactions before adding new medications
                    </div>
                    <Button variant="outline">
                      <Calendar className="h-4 w-4 mr-2" />
                      Check Interactions
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}