import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Shield, 
  Lock, 
  AlertTriangle, 
  CheckCircle2, 
  Activity, 
  Eye, 
  Database,
  Network,
  Key,
  Clock
} from 'lucide-react';

export default function SecurityDashboard() {
  const [securityMetrics, setSecurityMetrics] = useState({
    threatsBlocked: 247,
    encryptionStatus: 'ACTIVE',
    lastThreatAnalysis: '2 minutes ago',
    riskLevel: 'LOW',
    activeConnections: 142,
    systemHealth: 98.7
  });

  const [threatHistory] = useState([
    { id: 1, type: 'SQL_INJECTION', severity: 'HIGH', blocked: true, timestamp: '2025-01-27 14:32:15', ip: '192.168.1.100' },
    { id: 2, type: 'XSS_ATTACK', severity: 'MEDIUM', blocked: true, timestamp: '2025-01-27 14:28:42', ip: '10.0.0.15' },
    { id: 3, type: 'RATE_LIMIT_EXCEEDED', severity: 'LOW', blocked: true, timestamp: '2025-01-27 14:25:18', ip: '172.16.0.50' },
    { id: 4, type: 'BEHAVIORAL_ANOMALY', severity: 'MEDIUM', blocked: false, timestamp: '2025-01-27 14:20:33', ip: '192.168.1.75' },
    { id: 5, type: 'APT_INDICATOR', severity: 'CRITICAL', blocked: true, timestamp: '2025-01-27 14:15:28', ip: '203.0.113.42' }
  ]);

  const [encryptionStatus] = useState({
    aes256: 'ACTIVE',
    rsa4096: 'ACTIVE',
    quantumResistant: 'ACTIVE',
    zeroKnowledge: 'ACTIVE',
    keyRotation: 'SCHEDULED'
  });

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'CRITICAL': return 'destructive';
      case 'HIGH': return 'destructive';
      case 'MEDIUM': return 'default';
      case 'LOW': return 'secondary';
      default: return 'outline';
    }
  };

  const getRiskLevelColor = (level: string) => {
    switch (level) {
      case 'CRITICAL': return 'bg-red-500';
      case 'HIGH': return 'bg-orange-500';
      case 'MEDIUM': return 'bg-yellow-500';
      case 'LOW': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Shield className="h-12 w-12 text-blue-400 mr-3" />
            <h1 className="text-4xl font-bold text-white">Military-Grade Security Center</h1>
          </div>
          <p className="text-gray-300 text-lg">
            Comprehensive threat detection and quantum-resistant encryption platform
          </p>
        </div>

        {/* Security Status Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Threats Blocked</CardTitle>
              <Shield className="h-4 w-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{securityMetrics.threatsBlocked}</div>
              <p className="text-xs text-gray-400">Last 24 hours</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Risk Level</CardTitle>
              <AlertTriangle className="h-4 w-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${getRiskLevelColor(securityMetrics.riskLevel)}`}></div>
                <div className="text-2xl font-bold text-white">{securityMetrics.riskLevel}</div>
              </div>
              <p className="text-xs text-gray-400">System wide assessment</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Active Connections</CardTitle>
              <Network className="h-4 w-4 text-blue-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{securityMetrics.activeConnections}</div>
              <p className="text-xs text-gray-400">Currently monitored</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">System Health</CardTitle>
              <Activity className="h-4 w-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{securityMetrics.systemHealth}%</div>
              <Progress value={securityMetrics.systemHealth} className="mt-2" />
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="threats" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-slate-800">
            <TabsTrigger value="threats" className="text-white">Threat Detection</TabsTrigger>
            <TabsTrigger value="encryption" className="text-white">Encryption Status</TabsTrigger>
            <TabsTrigger value="monitoring" className="text-white">Real-time Monitoring</TabsTrigger>
            <TabsTrigger value="reports" className="text-white">Security Reports</TabsTrigger>
          </TabsList>

          {/* Threat Detection Tab */}
          <TabsContent value="threats" className="space-y-6">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <AlertTriangle className="mr-2 h-5 w-5" />
                  Recent Threat Activity
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Real-time threat detection and prevention
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {threatHistory.map((threat) => (
                    <div key={threat.id} className="flex items-center justify-between p-4 bg-slate-700 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <Badge variant={getSeverityColor(threat.severity)}>
                          {threat.severity}
                        </Badge>
                        <div>
                          <p className="text-white font-medium">{threat.type.replace('_', ' ')}</p>
                          <p className="text-gray-400 text-sm">IP: {threat.ip}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center space-x-2">
                          {threat.blocked ? (
                            <CheckCircle2 className="h-4 w-4 text-green-400" />
                          ) : (
                            <Eye className="h-4 w-4 text-yellow-400" />
                          )}
                          <span className="text-white text-sm">
                            {threat.blocked ? 'Blocked' : 'Monitored'}
                          </span>
                        </div>
                        <p className="text-gray-400 text-xs">{threat.timestamp}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Encryption Status Tab */}
          <TabsContent value="encryption" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Lock className="mr-2 h-5 w-5" />
                    Encryption Layers
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    Triple-layer military-grade encryption
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-slate-700 rounded">
                    <span className="text-white">AES-256-GCM</span>
                    <Badge variant="secondary" className="bg-green-600">ACTIVE</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-slate-700 rounded">
                    <span className="text-white">RSA-4096</span>
                    <Badge variant="secondary" className="bg-green-600">ACTIVE</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-slate-700 rounded">
                    <span className="text-white">ChaCha20-Poly1305</span>
                    <Badge variant="secondary" className="bg-green-600">ACTIVE</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-slate-700 rounded">
                    <span className="text-white">Quantum-Resistant Keys</span>
                    <Badge variant="secondary" className="bg-green-600">ACTIVE</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Key className="mr-2 h-5 w-5" />
                    Key Management
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    Automated key rotation and security
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-slate-700 rounded">
                    <span className="text-white">Medical Data Keys</span>
                    <Badge variant="outline" className="text-green-400 border-green-400">ROTATED</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-slate-700 rounded">
                    <span className="text-white">Payment Keys</span>
                    <Badge variant="outline" className="text-green-400 border-green-400">ROTATED</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-slate-700 rounded">
                    <span className="text-white">Communication Keys</span>
                    <Badge variant="outline" className="text-yellow-400 border-yellow-400">SCHEDULED</Badge>
                  </div>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">
                    Rotate All Keys Now
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Real-time Monitoring Tab */}
          <TabsContent value="monitoring" className="space-y-6">
            <Alert className="bg-slate-800 border-slate-600">
              <Activity className="h-4 w-4" />
              <AlertTitle className="text-white">System Status: Operational</AlertTitle>
              <AlertDescription className="text-gray-300">
                All security systems are functioning normally. Last threat analysis completed {securityMetrics.lastThreatAnalysis}.
              </AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Request Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-400">15,847</div>
                  <p className="text-gray-400">Requests analyzed today</p>
                  <Progress value={87} className="mt-2" />
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Behavioral Profiles</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-400">1,024</div>
                  <p className="text-gray-400">Active user profiles</p>
                  <Progress value={65} className="mt-2" />
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Blacklisted IPs</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-400">42</div>
                  <p className="text-gray-400">Currently blocked</p>
                  <Progress value={12} className="mt-2" />
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Security Reports Tab */}
          <TabsContent value="reports" className="space-y-6">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Database className="mr-2 h-5 w-5" />
                  Security Analytics
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Comprehensive security insights and recommendations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="text-white font-semibold">Threat Categories (Last 7 Days)</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">SQL Injection</span>
                        <span className="text-red-400">34 blocked</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">XSS Attacks</span>
                        <span className="text-orange-400">18 blocked</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">Rate Limiting</span>
                        <span className="text-yellow-400">156 triggered</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">Anomalous Behavior</span>
                        <span className="text-blue-400">89 detected</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-white font-semibold">Security Recommendations</h4>
                    <div className="space-y-2 text-gray-300">
                      <div className="flex items-start space-x-2">
                        <CheckCircle2 className="h-4 w-4 text-green-400 mt-0.5" />
                        <span className="text-sm">Enable Web Application Firewall</span>
                      </div>
                      <div className="flex items-start space-x-2">
                        <CheckCircle2 className="h-4 w-4 text-green-400 mt-0.5" />
                        <span className="text-sm">Implement DDoS protection</span>
                      </div>
                      <div className="flex items-start space-x-2">
                        <Clock className="h-4 w-4 text-yellow-400 mt-0.5" />
                        <span className="text-sm">Schedule quarterly security audit</span>
                      </div>
                      <div className="flex items-start space-x-2">
                        <Clock className="h-4 w-4 text-yellow-400 mt-0.5" />
                        <span className="text-sm">Update threat intelligence feeds</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex space-x-4">
                  <Button variant="outline" className="text-white border-slate-600 hover:bg-slate-700">
                    Download Report
                  </Button>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Generate Full Analysis
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}