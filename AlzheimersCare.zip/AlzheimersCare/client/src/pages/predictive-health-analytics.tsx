import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Brain, Activity, TrendingUp, AlertTriangle, Zap, Eye, Users, Shield } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

interface DigitalTwinData {
  patientId: number;
  cognitiveScore: number;
  memoryRetention: number;
  emotionalStability: number;
  physicalHealth: number;
  socialEngagement: number;
  predictedDecline: number;
  riskFactors: string[];
  recommendations: string[];
}

interface PredictiveAlert {
  id: string;
  type: 'cognitive' | 'physical' | 'emotional' | 'behavioral';
  severity: 'low' | 'medium' | 'high' | 'critical';
  probability: number;
  timeframe: string;
  description: string;
  preventiveActions: string[];
  confidence: number;
}

export default function PredictiveHealthAnalytics() {
  const [selectedPatientId] = useState(1);
  const [digitalTwin, setDigitalTwin] = useState<DigitalTwinData | null>(null);
  const [predictiveAlerts, setPredictiveAlerts] = useState<PredictiveAlert[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [quantumProcessing, setQuantumProcessing] = useState(false);

  // Simulated digital twin data (in production, this would come from ML models)
  useEffect(() => {
    const mockDigitalTwin: DigitalTwinData = {
      patientId: selectedPatientId,
      cognitiveScore: 74,
      memoryRetention: 68,
      emotionalStability: 82,
      physicalHealth: 76,
      socialEngagement: 71,
      predictedDecline: 15,
      riskFactors: [
        'Declining short-term memory patterns',
        'Reduced social interaction frequency',
        'Irregular sleep patterns detected',
        'Medication adherence variance'
      ],
      recommendations: [
        'Increase cognitive training frequency to 3x daily',
        'Schedule family video calls during peak alertness (10-11 AM)',
        'Adjust sleep environment lighting',
        'Implement medication reminder with voice confirmation'
      ]
    };

    const mockAlerts: PredictiveAlert[] = [
      {
        id: '1',
        type: 'cognitive',
        severity: 'medium',
        probability: 78,
        timeframe: '48-72 hours',
        description: 'Potential cognitive episode based on recent memory test patterns',
        preventiveActions: [
          'Increase mental stimulation activities',
          'Review medication timing',
          'Schedule family interaction session'
        ],
        confidence: 84
      },
      {
        id: '2',
        type: 'physical',
        severity: 'low',
        probability: 42,
        timeframe: '5-7 days',
        description: 'Possible mobility decline based on gait analysis',
        preventiveActions: [
          'Physical therapy session',
          'Environment safety check',
          'Balance training exercises'
        ],
        confidence: 71
      },
      {
        id: '3',
        type: 'emotional',
        severity: 'high',
        probability: 89,
        timeframe: '24-48 hours',
        description: 'High risk of emotional distress based on voice pattern analysis',
        preventiveActions: [
          'Schedule immediate family contact',
          'Activate comfort protocol',
          'Review emotional support strategies'
        ],
        confidence: 92
      }
    ];

    setDigitalTwin(mockDigitalTwin);
    setPredictiveAlerts(mockAlerts);
  }, [selectedPatientId]);

  const runQuantumAnalysis = async () => {
    setQuantumProcessing(true);
    setIsAnalyzing(true);

    // Simulate quantum processing delay
    setTimeout(() => {
      setQuantumProcessing(false);
      setIsAnalyzing(false);
      
      // Update with enhanced predictions
      if (digitalTwin) {
        setDigitalTwin({
          ...digitalTwin,
          cognitiveScore: digitalTwin.cognitiveScore + 2,
          predictedDecline: Math.max(0, digitalTwin.predictedDecline - 3)
        });
      }
    }, 3000);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'critical': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const cognitiveData = [
    { time: '00:00', score: 72 },
    { time: '04:00', score: 68 },
    { time: '08:00', score: 76 },
    { time: '12:00', score: 74 },
    { time: '16:00', score: 71 },
    { time: '20:00', score: 69 },
    { time: '24:00', score: 74 }
  ];

  const predictionData = [
    { day: 'Today', actual: 74, predicted: 74 },
    { day: 'Tomorrow', actual: null, predicted: 72 },
    { day: 'Day 3', actual: null, predicted: 70 },
    { day: 'Day 4', actual: null, predicted: 71 },
    { day: 'Day 5', actual: null, predicted: 69 },
    { day: 'Day 6', actual: null, predicted: 67 },
    { day: 'Day 7', actual: null, predicted: 68 }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-blue-600 rounded-xl flex items-center justify-center">
              <Brain className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900">Predictive Health Analytics</h1>
          </div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Advanced AI-powered digital twin technology with quantum-enhanced processing for 
            predictive health insights and personalized care optimization.
          </p>
        </div>

        {/* Quantum Processing Status */}
        <Card className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Zap className="h-8 w-8" />
                <div>
                  <h3 className="text-xl font-bold">Quantum-Enhanced AI Processing</h3>
                  <p className="text-purple-100">
                    {quantumProcessing ? 'Running quantum analysis...' : 'Ready for quantum processing'}
                  </p>
                </div>
              </div>
              <Button 
                onClick={runQuantumAnalysis}
                disabled={isAnalyzing}
                className="bg-white text-purple-600 hover:bg-purple-50"
              >
                {isAnalyzing ? 'Processing...' : 'Run Quantum Analysis'}
              </Button>
            </div>
            {quantumProcessing && (
              <div className="mt-4">
                <Progress value={66} className="bg-purple-400" />
                <p className="text-sm text-purple-100 mt-2">
                  Quantum algorithms analyzing 847 million data points...
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        <Tabs defaultValue="digital-twin" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4 bg-white/70 backdrop-blur-sm p-1 h-auto">
            <TabsTrigger value="digital-twin" className="text-sm px-2 py-2 whitespace-nowrap">Digital Twin</TabsTrigger>
            <TabsTrigger value="predictions" className="text-sm px-2 py-2 whitespace-nowrap">Predictive Alerts</TabsTrigger>
            <TabsTrigger value="analytics" className="text-sm px-2 py-2 whitespace-nowrap">Advanced Analytics</TabsTrigger>
            <TabsTrigger value="neural-interface" className="text-sm px-2 py-2 whitespace-nowrap">Neural Interface</TabsTrigger>
          </TabsList>

          <TabsContent value="digital-twin" className="space-y-6">
            {digitalTwin && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Digital Twin Overview */}
                <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Activity className="h-5 w-5" />
                      Digital Twin Status
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium text-gray-600">Cognitive Score</label>
                          <div className="flex items-center gap-2">
                            <Progress value={digitalTwin.cognitiveScore} className="flex-1" />
                            <span className="text-lg font-bold text-blue-600">{digitalTwin.cognitiveScore}%</span>
                          </div>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-gray-600">Memory Retention</label>
                          <div className="flex items-center gap-2">
                            <Progress value={digitalTwin.memoryRetention} className="flex-1" />
                            <span className="text-lg font-bold text-green-600">{digitalTwin.memoryRetention}%</span>
                          </div>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-gray-600">Emotional Stability</label>
                          <div className="flex items-center gap-2">
                            <Progress value={digitalTwin.emotionalStability} className="flex-1" />
                            <span className="text-lg font-bold text-purple-600">{digitalTwin.emotionalStability}%</span>
                          </div>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-gray-600">Physical Health</label>
                          <div className="flex items-center gap-2">
                            <Progress value={digitalTwin.physicalHealth} className="flex-1" />
                            <span className="text-lg font-bold text-orange-600">{digitalTwin.physicalHealth}%</span>
                          </div>
                        </div>
                      </div>

                      <div className="pt-4 border-t">
                        <h4 className="font-medium mb-2">Risk Factors</h4>
                        <div className="space-y-2">
                          {digitalTwin.riskFactors.map((risk, index) => (
                            <div key={index} className="flex items-start gap-2">
                              <AlertTriangle className="h-4 w-4 text-orange-500 mt-0.5" />
                              <span className="text-sm text-gray-700">{risk}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Real-time Cognitive Monitoring */}
                <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5" />
                      Real-time Cognitive Monitoring
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={200}>
                      <LineChart data={cognitiveData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="time" />
                        <YAxis domain={[60, 80]} />
                        <Tooltip />
                        <Line 
                          type="monotone" 
                          dataKey="score" 
                          stroke="#3b82f6" 
                          strokeWidth={3}
                          dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                    <div className="mt-4 text-center">
                      <Badge variant="outline" className="bg-blue-50 text-blue-700">
                        Current Score: {digitalTwin.cognitiveScore}% (Stable)
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="predictions" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Predictive Alerts */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Active Predictive Alerts</h3>
                {predictiveAlerts.map((alert) => (
                  <Card key={alert.id} className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <Badge className={getSeverityColor(alert.severity)}>
                            {alert.severity.toUpperCase()}
                          </Badge>
                          <span className="text-sm font-medium">{alert.timeframe}</span>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-bold text-blue-600">{alert.probability}%</div>
                          <div className="text-xs text-gray-500">Probability</div>
                        </div>
                      </div>
                      
                      <p className="text-gray-700 mb-3">{alert.description}</p>
                      
                      <div className="space-y-2">
                        <h4 className="text-sm font-medium text-gray-900">Preventive Actions:</h4>
                        {alert.preventiveActions.map((action, index) => (
                          <div key={index} className="flex items-center gap-2">
                            <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                            <span className="text-sm text-gray-600">{action}</span>
                          </div>
                        ))}
                      </div>
                      
                      <div className="mt-3 pt-3 border-t flex justify-between items-center">
                        <span className="text-xs text-gray-500">
                          Confidence: {alert.confidence}%
                        </span>
                        <Button size="sm" variant="outline">
                          Implement Actions
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Prediction Timeline */}
              <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    7-Day Cognitive Prediction
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={predictionData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="day" />
                      <YAxis domain={[60, 80]} />
                      <Tooltip />
                      <Area 
                        type="monotone" 
                        dataKey="predicted" 
                        stroke="#8b5cf6" 
                        fill="#8b5cf6" 
                        fillOpacity={0.3}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="actual" 
                        stroke="#3b82f6" 
                        strokeWidth={3}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="bg-gradient-to-br from-blue-500 to-purple-600 text-white border-0">
                <CardContent className="p-6 text-center">
                  <Brain className="h-8 w-8 mx-auto mb-2" />
                  <div className="text-2xl font-bold">2.4M</div>
                  <div className="text-blue-100">Neural Patterns Analyzed</div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-green-500 to-teal-600 text-white border-0">
                <CardContent className="p-6 text-center">
                  <Activity className="h-8 w-8 mx-auto mb-2" />
                  <div className="text-2xl font-bold">94.7%</div>
                  <div className="text-green-100">Prediction Accuracy</div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-orange-500 to-red-600 text-white border-0">
                <CardContent className="p-6 text-center">
                  <TrendingUp className="h-8 w-8 mx-auto mb-2" />
                  <div className="text-2xl font-bold">72hrs</div>
                  <div className="text-orange-100">Early Warning Window</div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="neural-interface" className="space-y-6">
            <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  Neural Interface Technology
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="font-medium">EEG Integration</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Alpha Waves</span>
                        <span className="text-sm font-medium">8.2 Hz</span>
                      </div>
                      <Progress value={82} />
                      
                      <div className="flex justify-between">
                        <span className="text-sm">Beta Waves</span>
                        <span className="text-sm font-medium">15.7 Hz</span>
                      </div>
                      <Progress value={67} />
                      
                      <div className="flex justify-between">
                        <span className="text-sm">Theta Waves</span>
                        <span className="text-sm font-medium">5.1 Hz</span>
                      </div>
                      <Progress value={45} />
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h4 className="font-medium">Thought-to-Text Interface</h4>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <p className="text-sm text-gray-600 mb-2">Latest thought pattern:</p>
                      <p className="font-medium">"I want to see my family"</p>
                      <div className="mt-2 flex items-center gap-2">
                        <Badge variant="outline">Confidence: 94%</Badge>
                        <Badge variant="outline">Emotional: Longing</Badge>
                      </div>
                    </div>
                    
                    <Button className="w-full">
                      <Brain className="mr-2 h-4 w-4" />
                      Initialize Neural Interface
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}