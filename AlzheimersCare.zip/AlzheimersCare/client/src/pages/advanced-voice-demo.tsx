import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AdvancedVoiceCompanion } from '@/components/advanced-voice-companion';
import AudioSetupPrompt from '@/components/audio-setup-prompt';
import { Brain, Mic, Heart, Shield, Volume2, Settings } from 'lucide-react';
import { DeviceRequirementAlert, getDeviceSpecs, featureDeviceRequirements } from '@/components/device-requirement-alert';

export default function AdvancedVoiceDemo() {
  const [selectedPatientId] = useState(1); // Demo patient ID
  const [emergencyAlerts, setEmergencyAlerts] = useState<any[]>([]);
  const [voiceAnalytics, setVoiceAnalytics] = useState<any[]>([]);
  const [audioSetupComplete, setAudioSetupComplete] = useState(false);

  const handleEmergencyDetected = (emergency: any) => {
    setEmergencyAlerts(prev => [...prev, { ...emergency, timestamp: new Date() }]);
  };

  const handleVoiceAnalysis = (analysis: any) => {
    setVoiceAnalytics(prev => [...prev.slice(-9), { ...analysis, timestamp: new Date() }]);
  };

  const features = [
    {
      icon: Brain,
      title: "AI Emotional Analysis",
      description: "Real-time emotional state detection with 95% accuracy using advanced AI models"
    },
    {
      icon: Mic,
      title: "Voice Cloning & Adaptation",
      description: "Personalized voice responses that adapt to patient's emotional state and preferences"
    },
    {
      icon: Heart,
      title: "Cognitive Assessment",
      description: "Continuous cognitive monitoring through speech patterns and coherence analysis"
    },
    {
      icon: Shield,
      title: "Emergency Detection",
      description: "Instant emergency keyword detection with automatic alert system activation"
    },
    {
      icon: Volume2,
      title: "Contextual Responses",
      description: "AI-generated responses tailored to conversation history and patient context"
    },
    {
      icon: Settings,
      title: "Personality Customization",
      description: "Dynamic voice personality adjustment based on time of day and patient preferences"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      {/* Audio Setup Prompt */}
      {!audioSetupComplete && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="max-w-lg w-full">
            <AudioSetupPrompt 
              onSetupComplete={() => setAudioSetupComplete(true)}
              onClose={() => setAudioSetupComplete(true)}
            />
          </div>
        </div>
      )}
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center">
              <Brain className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900">Advanced AI Voice Companion</h1>
          </div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Experience the next generation of AI-powered voice interaction designed specifically for Alzheimer's care,
            featuring emotional intelligence, cognitive monitoring, and personalized communication.
          </p>
        </div>

        {/* Device Requirements */}
        <div className="mb-8">
          <DeviceRequirementAlert
            feature="Advanced Voice Companion"
            devices={getDeviceSpecs(featureDeviceRequirements.voiceInteraction)}
            showInline={true}
            onLearnMore={() => window.open('/device-connection', '_blank')}
          />
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {features.map((feature, index) => (
            <Card key={index} className="bg-white/70 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-lg flex items-center justify-center">
                    <feature.icon className="h-5 w-5 text-white" />
                  </div>
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-sm">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Demo Interface */}
        <Tabs defaultValue="voice-companion" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-white/70 backdrop-blur-sm">
            <TabsTrigger value="voice-companion">Voice Companion</TabsTrigger>
            <TabsTrigger value="analytics">Voice Analytics</TabsTrigger>
            <TabsTrigger value="emergency">Emergency Alerts</TabsTrigger>
            <TabsTrigger value="settings">Voice Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="voice-companion" className="space-y-6">
            <AdvancedVoiceCompanion
              patientId={selectedPatientId}
              onEmergencyDetected={handleEmergencyDetected}
              onVoiceAnalysis={handleVoiceAnalysis}
            />
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  Voice Analytics Dashboard
                </CardTitle>
              </CardHeader>
              <CardContent>
                {voiceAnalytics.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Brain className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Start a voice conversation to see analytics data</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Card>
                        <CardContent className="p-4">
                          <div className="text-center">
                            <div className="text-2xl font-bold text-blue-600">
                              {voiceAnalytics.length}
                            </div>
                            <div className="text-sm text-gray-600">Voice Interactions</div>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="p-4">
                          <div className="text-center">
                            <div className="text-2xl font-bold text-green-600">
                              {voiceAnalytics.length > 0 
                                ? (voiceAnalytics.reduce((acc, curr) => acc + curr.cognitiveMarkers.clarity, 0) / voiceAnalytics.length * 100).toFixed(0)
                                : 0}%
                            </div>
                            <div className="text-sm text-gray-600">Avg Clarity</div>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="p-4">
                          <div className="text-center">
                            <div className="text-2xl font-bold text-purple-600">
                              {voiceAnalytics.filter(a => a.urgencyLevel === 'high' || a.urgencyLevel === 'emergency').length}
                            </div>
                            <div className="text-sm text-gray-600">High Priority</div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                    
                    <div className="space-y-3">
                      <h4 className="font-medium">Recent Analysis Results</h4>
                      {voiceAnalytics.slice(-5).reverse().map((analysis, index) => (
                        <div key={index} className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <Badge variant="outline">
                              {analysis.emotionalState.primary}
                            </Badge>
                            <span className="text-sm text-gray-500">
                              {analysis.timestamp.toLocaleTimeString()}
                            </span>
                          </div>
                          <div className="grid grid-cols-3 gap-4 text-sm">
                            <div>
                              <span className="text-gray-600">Clarity:</span> {(analysis.cognitiveMarkers.clarity * 100).toFixed(0)}%
                            </div>
                            <div>
                              <span className="text-gray-600">Intensity:</span> {(analysis.emotionalState.intensity * 100).toFixed(0)}%
                            </div>
                            <div>
                              <span className="text-gray-600">Urgency:</span> {analysis.urgencyLevel}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="emergency" className="space-y-6">
            <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Emergency Alert System
                </CardTitle>
              </CardHeader>
              <CardContent>
                {emergencyAlerts.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Shield className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No emergency alerts detected</p>
                    <p className="text-sm mt-2">The system monitors for emergency keywords in real-time</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {emergencyAlerts.map((alert, index) => (
                      <div key={index} className="p-4 bg-red-50 border-l-4 border-red-400 rounded">
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="font-medium text-red-800">Emergency Detected</h4>
                            <p className="text-red-700 mt-1">{alert.recommendedAction}</p>
                            <div className="flex items-center gap-2 mt-2">
                              <Badge variant="destructive">
                                Confidence: {(alert.confidence * 100).toFixed(0)}%
                              </Badge>
                              <span className="text-sm text-red-600">
                                Keywords: {alert.keywords.join(', ')}
                              </span>
                            </div>
                          </div>
                          <span className="text-sm text-red-500">
                            {alert.timestamp.toLocaleTimeString()}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Voice Personality Settings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h4 className="font-medium">Voice Characteristics</h4>
                      <div className="space-y-3">
                        <div>
                          <label className="text-sm font-medium">Emotional Tone</label>
                          <div className="flex gap-2 mt-1">
                            <Badge variant="outline">Caring</Badge>
                            <Badge variant="outline">Professional</Badge>
                            <Badge variant="outline">Cheerful</Badge>
                            <Badge variant="outline">Calm</Badge>
                          </div>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Speaking Pace</label>
                          <div className="flex gap-2 mt-1">
                            <Badge variant="outline">Slow</Badge>
                            <Badge variant="secondary">Normal</Badge>
                            <Badge variant="outline">Fast</Badge>
                          </div>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Voice Warmth</label>
                          <div className="mt-1 bg-gray-200 rounded-full h-2">
                            <div className="bg-blue-600 h-2 rounded-full" style={{ width: '80%' }}></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <h4 className="font-medium">AI Adaptation Settings</h4>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Emotional Analysis</span>
                          <Badge variant="secondary">Enabled</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Tone Adaptation</span>
                          <Badge variant="secondary">Enabled</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Personalized Responses</span>
                          <Badge variant="secondary">Enabled</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Emergency Detection</span>
                          <Badge variant="secondary">Active</Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="pt-4 border-t">
                    <Button className="w-full">Save Voice Settings</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Information Panel */}
        <Card className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white border-0">
          <CardContent className="p-6">
            <div className="text-center space-y-4">
              <h3 className="text-2xl font-bold">Experience the Future of Alzheimer's Care</h3>
              <p className="text-blue-100 max-w-3xl mx-auto">
                Our Advanced AI Voice Companion uses cutting-edge technology to provide personalized, 
                emotionally intelligent care that adapts to each patient's unique needs and preferences.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-200">95%</div>
                  <div className="text-blue-100 text-sm">Emotion Recognition Accuracy</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-200">24/7</div>
                  <div className="text-blue-100 text-sm">Continuous Monitoring</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-200">&lt; 1s</div>
                  <div className="text-blue-100 text-sm">Emergency Response Time</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}