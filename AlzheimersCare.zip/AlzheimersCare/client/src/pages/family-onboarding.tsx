import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { FamilyInputPanel } from "@/components/family-input-panel";
import { AIProcessingStatus } from "@/components/ai-processing-status";
import { CareCompanionAPI } from "@/lib/api";
import { Heart, Users, Calendar, FileText, Image, Upload, CheckCircle, ArrowRight, ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";

interface OnboardingData {
  patient: {
    firstName: string;
    lastName: string;
    dateOfBirth: string;
    medicalInfo: {
      conditions: string[];
      medications: string[];
      allergies: string[];
    };
    emergencyInfo: {
      contacts: Array<{
        name: string;
        relationship: string;
        phone: string;
      }>;
    };
  };
  familyMembers: Array<{
    firstName: string;
    lastName: string;
    email: string;
    relationship: string;
    responsibilityLevel: string;
  }>;
  memories: Array<{
    type: string;
    title: string;
    description: string;
    file?: File;
  }>;
}

const ONBOARDING_STEPS = [
  { id: 'patient', title: 'Patient Information', icon: Heart },
  { id: 'family', title: 'Family Members', icon: Users },
  { id: 'memories', title: 'Share Memories', icon: Image },
  { id: 'review', title: 'Review & Complete', icon: CheckCircle },
];

export default function FamilyOnboarding() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(0);
  const [onboardingData, setOnboardingData] = useState<OnboardingData>({
    patient: {
      firstName: '',
      lastName: '',
      dateOfBirth: '',
      medicalInfo: {
        conditions: [],
        medications: [],
        allergies: [],
      },
      emergencyInfo: {
        contacts: [],
      },
    },
    familyMembers: [],
    memories: [],
  });

  const [uploadedPhotos, setUploadedPhotos] = useState<Array<{file: File, preview: string}>>([]);
  
  const [aiProcessingStatus, setAIProcessingStatus] = useState({
    isProcessing: false,
    progress: 0,
    currentTask: '',
    completedTasks: [] as string[],
  });

  // Photo upload handlers
  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    Array.from(files).forEach(file => {
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          setUploadedPhotos(prev => [...prev, {
            file,
            preview: e.target?.result as string
          }]);
        };
        reader.readAsDataURL(file);
      }
    });

    toast({
      title: "Photos Uploaded",
      description: `${files.length} photo(s) uploaded successfully`,
    });
  };

  const removePhoto = (index: number) => {
    setUploadedPhotos(prev => prev.filter((_, i) => i !== index));
  };

  const createPatientMutation = useMutation({
    mutationFn: CareCompanionAPI.createPatient,
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Patient profile created successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create patient profile",
        variant: "destructive",
      });
    },
  });

  const createUserMutation = useMutation({
    mutationFn: CareCompanionAPI.createUser,
    onSuccess: (data) => {
      if (data.isExisting) {
        toast({
          title: "Using Existing Account",
          description: "Found existing account with this email - using that profile",
        });
      } else {
        toast({
          title: "Success",
          description: "Family member added successfully",
        });
      }
    },
    onError: (error: any) => {
      console.error("Onboarding error:", error);
      let errorMessage = "Failed to add family member";
      
      if (error.response?.data?.code === "DUPLICATE_EMAIL") {
        errorMessage = "This email is already registered. Please use a different email address.";
      } else if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      }
      
      toast({
        title: "Error Adding Family Member",
        description: errorMessage,
        variant: "destructive",
      });
    },
  });

  const createMemoryMutation = useMutation({
    mutationFn: ({ data, file }: { data: any; file?: File }) => 
      CareCompanionAPI.createFamilyMemory(data, file),
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Memory shared successfully and processed by AI",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to share memory",
        variant: "destructive",
      });
    },
  });

  const updatePatientData = (field: string, value: any) => {
    setOnboardingData(prev => ({
      ...prev,
      patient: {
        ...prev.patient,
        [field]: value,
      },
    }));
  };

  const addFamilyMember = (member: any) => {
    setOnboardingData(prev => ({
      ...prev,
      familyMembers: [...prev.familyMembers, member],
    }));
  };

  const editFamilyMember = (index: number, updatedMember: any) => {
    setOnboardingData(prev => ({
      ...prev,
      familyMembers: prev.familyMembers.map((member, i) => 
        i === index ? updatedMember : member
      ),
    }));
  };

  const removeFamilyMember = (index: number) => {
    setOnboardingData(prev => ({
      ...prev,
      familyMembers: prev.familyMembers.filter((_, i) => i !== index),
    }));
  };

  const addMemory = (memory: any) => {
    setOnboardingData(prev => ({
      ...prev,
      memories: [...prev.memories, memory],
    }));
  };

  const handleComplete = async () => {
    setAIProcessingStatus({
      isProcessing: true,
      progress: 0,
      currentTask: 'Creating patient profile...',
      completedTasks: [],
    });

    try {
      // Create patient
      const patient = await createPatientMutation.mutateAsync({
        firstName: onboardingData.patient.firstName,
        lastName: onboardingData.patient.lastName,
        dateOfBirth: new Date(onboardingData.patient.dateOfBirth),
        medicalInfo: onboardingData.patient.medicalInfo,
        emergencyInfo: onboardingData.patient.emergencyInfo,
      });

      setAIProcessingStatus(prev => ({
        ...prev,
        progress: 25,
        currentTask: 'Creating family member profiles...',
        completedTasks: ['Patient profile created'],
      }));

      // Create family members with proper error handling
      const createdFamilyMembers = [];
      for (const member of onboardingData.familyMembers) {
        try {
          const familyUser = await createUserMutation.mutateAsync({
            firstName: member.firstName,
            lastName: member.lastName,
            email: member.email,
            userType: 'family_member',
          });
          
          createdFamilyMembers.push(familyUser);

          // Create relationship
          await CareCompanionAPI.createFamilyRelationship({
            familyMemberId: familyUser.id,
            patientId: patient.id,
            relationship: member.relationship,
            responsibilityLevel: member.responsibilityLevel,
          });
        } catch (memberError: any) {
          console.error("Error creating family member:", memberError);
          
          // Handle duplicate email error by showing toast and stopping onboarding
          if (memberError.response?.data?.message?.includes("Email already registered") || 
              memberError.response?.data?.code === "DUPLICATE_EMAIL") {
            
            setAIProcessingStatus({
              isProcessing: false,
              progress: 0,
              currentTask: '',
              completedTasks: [],
            });
            
            toast({
              title: "Email Already Registered",
              description: `The email ${member.email} is already registered. Please go back and use a different email address.`,
              variant: "destructive",
            });
            
            // Go back to family member step
            setCurrentStep(1);
            return;
          }
          
          throw memberError; // Re-throw if it's not a duplicate email error
        }
      }

      setAIProcessingStatus(prev => ({
        ...prev,
        progress: 50,
        currentTask: 'Processing family memories with AI...',
        completedTasks: [...prev.completedTasks, 'Family profiles created'],
      }));

      // Process memories
      for (const memory of onboardingData.memories) {
        await createMemoryMutation.mutateAsync({
          data: {
            patientId: patient.id,
            familyMemberId: 1, // Would be actual user ID
            memoryType: memory.type,
            title: memory.title,
            description: memory.description,
            content: {},
          },
          file: memory.file,
        });
      }

      setAIProcessingStatus(prev => ({
        ...prev,
        progress: 75,
        currentTask: 'Generating personalized cognitive activities...',
        completedTasks: [...prev.completedTasks, 'Memories processed'],
      }));

      // Generate cognitive activities
      await CareCompanionAPI.generateCognitiveActivities(patient.id, 'recognition');

      setAIProcessingStatus(prev => ({
        ...prev,
        progress: 100,
        currentTask: 'Setup complete!',
        completedTasks: [...prev.completedTasks, 'Cognitive activities generated'],
      }));

      setTimeout(() => {
        navigate(`/patient-companion/${patient.id}`);
      }, 2000);

    } catch (error: any) {
      console.error('Onboarding error:', error);
      setAIProcessingStatus(prev => ({
        ...prev,
        isProcessing: false,
      }));
      
      let errorMessage = "Failed to complete onboarding. Please try again.";
      
      if (error.response?.data?.code === "DUPLICATE_EMAIL") {
        errorMessage = "Email already registered. Please use different email addresses for family members.";
      } else if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      toast({
        title: "Onboarding Error",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  const nextStep = () => {
    if (currentStep < ONBOARDING_STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const progressPercentage = ((currentStep + 1) / ONBOARDING_STEPS.length) * 100;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 care-gradient rounded-lg flex items-center justify-center">
                <Heart className="text-white h-5 w-5" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Care Companion</h1>
                <p className="text-sm text-gray-500">Share Onboarding Initial Setup</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-600">Step {currentStep + 1} of {ONBOARDING_STEPS.length}</p>
                <p className="text-xs text-gray-500">{ONBOARDING_STEPS[currentStep].title}</p>
              </div>
            </div>
          </div>
          
          {/* Progress Bar */}
          <div className="mt-6">
            <Progress value={progressPercentage} className="h-2" />
            <div className="flex justify-between mt-2">
              {ONBOARDING_STEPS.map((step, index) => {
                const Icon = step.icon;
                const isActive = index === currentStep;
                const isCompleted = index < currentStep;
                
                return (
                  <div key={step.id} className="flex flex-col items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      isActive ? 'bg-care-primary text-white' :
                      isCompleted ? 'bg-care-secondary text-white' :
                      'bg-gray-200 text-gray-400'
                    }`}>
                      <Icon className="h-4 w-4" />
                    </div>
                    <p className={`text-xs mt-1 ${
                      isActive ? 'text-care-primary font-medium' :
                      isCompleted ? 'text-care-secondary' :
                      'text-gray-400'
                    }`}>
                      {step.title}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {aiProcessingStatus.isProcessing ? (
          <AIProcessingStatus status={aiProcessingStatus} />
        ) : (
          <>
            {/* Step Content */}
            {currentStep === 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Heart className="mr-2 h-5 w-5 text-care-primary" />
                    Patient Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        value={onboardingData.patient.firstName}
                        onChange={(e) => updatePatientData('firstName', e.target.value)}
                        placeholder="Enter first name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        value={onboardingData.patient.lastName}
                        onChange={(e) => updatePatientData('lastName', e.target.value)}
                        placeholder="Enter last name"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="dateOfBirth">Date of Birth</Label>
                    <Input
                      id="dateOfBirth"
                      type="date"
                      value={onboardingData.patient.dateOfBirth}
                      onChange={(e) => updatePatientData('dateOfBirth', e.target.value)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="conditions">Medical Conditions</Label>
                    <Textarea
                      id="conditions"
                      placeholder="List any medical conditions (one per line)"
                      className="min-h-[100px]"
                    />
                  </div>

                  <div>
                    <Label htmlFor="medications">Current Medications</Label>
                    <Textarea
                      id="medications"
                      placeholder="List current medications (one per line)"
                      className="min-h-[100px]"
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {currentStep === 1 && (
              <FamilyInputPanel 
                familyMembers={onboardingData.familyMembers}
                onAddMember={addFamilyMember}
                onEditMember={editFamilyMember}
                onRemoveMember={removeFamilyMember}
              />
            )}

            {currentStep === 2 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Image className="mr-2 h-5 w-5 text-care-primary" />
                    Share Family Memories
                  </CardTitle>
                  <p className="text-gray-600">
                    Share photos, stories, and memories that will be transformed into personalized cognitive training activities.
                  </p>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Upload Family Photos</h3>
                    <p className="text-gray-600 mb-4">Our AI will analyze photos to create recognition exercises</p>
                    <input
                      type="file"
                      id="photo-upload"
                      accept="image/*"
                      multiple
                      className="hidden"
                      onChange={handlePhotoUpload}
                    />
                    <Button variant="outline" onClick={() => document.getElementById('photo-upload')?.click()}>
                      <Upload className="mr-2 h-4 w-4" />
                      Choose Photos
                    </Button>
                    {uploadedPhotos.length > 0 && (
                      <div className="mt-4 grid grid-cols-3 gap-2">
                        {uploadedPhotos.map((photo, index) => (
                          <div key={index} className="relative">
                            <img 
                              src={photo.preview} 
                              alt={`Upload ${index + 1}`}
                              className="w-full h-20 object-cover rounded border"
                            />
                            <button
                              onClick={() => removePhoto(index)}
                              className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs"
                            >
                              ×
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="story">Share a Family Story</Label>
                    <Textarea
                      id="story"
                      placeholder="Tell us about a special memory, tradition, or story that's important to your family..."
                      className="min-h-[150px]"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="favoriteActivities">Favorite Activities</Label>
                      <Textarea
                        id="favoriteActivities"
                        placeholder="What activities did they enjoy?"
                        className="min-h-[100px]"
                      />
                    </div>
                    <div>
                      <Label htmlFor="importantPeople">Important People</Label>
                      <Textarea
                        id="importantPeople"
                        placeholder="Names of important people in their life"
                        className="min-h-[100px]"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {currentStep === 3 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <CheckCircle className="mr-2 h-5 w-5 text-care-primary" />
                    Review & Complete Setup
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h3 className="font-semibold text-blue-900 mb-2">Setup Summary</h3>
                    <div className="space-y-2 text-sm text-blue-800">
                      <p>✓ Patient: {onboardingData.patient.firstName} {onboardingData.patient.lastName}</p>
                      <p>✓ Family Members: {onboardingData.familyMembers.length} added</p>
                      <p>✓ Memories: {onboardingData.memories.length} shared</p>
                    </div>
                  </div>

                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h3 className="font-semibold text-green-900 mb-2">What Happens Next</h3>
                    <div className="space-y-2 text-sm text-green-800">
                      <p>• AI will analyze family memories and create personalized activities</p>
                      <p>• Patient care companion will be customized with family context</p>
                      <p>• Family members will receive progress reports and updates</p>
                      <p>• Care facility will get analytics and ROI metrics</p>
                    </div>
                  </div>

                  <Button 
                    onClick={handleComplete}
                    className="w-full care-gradient text-white text-lg py-3"
                    size="lg"
                  >
                    Complete Setup & Launch Care Companion
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Navigation */}
            <div className="flex justify-between mt-8">
              <Button 
                variant="outline" 
                onClick={prevStep}
                disabled={currentStep === 0}
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Previous
              </Button>
              
              <Button 
                onClick={nextStep}
                disabled={currentStep === ONBOARDING_STEPS.length - 1}
                className="bg-care-primary text-white hover:bg-care-primary/90"
              >
                Next
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
