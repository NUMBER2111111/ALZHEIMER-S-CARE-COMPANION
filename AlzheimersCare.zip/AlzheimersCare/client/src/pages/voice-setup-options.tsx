import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Volume2, 
  Mic, 
  Headphones, 
  Speaker, 
  Settings, 
  CheckCircle, 
  AlertCircle,
  ArrowLeft,
  Star,
  Smartphone,
  Wifi,
  Clock,
  Users,
  Heart,
  Zap
} from 'lucide-react';
import { Link } from 'wouter';

export default function VoiceSetupOptions() {
  const [selectedOption, setSelectedOption] = useState('alexa');

  const voiceOptions = [
    {
      id: 'alexa',
      title: 'Amazon Alexa',
      subtitle: 'Recommended for Seniors',
      description: 'Use your existing Alexa device for hands-free voice interaction',
      icon: <Speaker className="h-8 w-8 text-blue-600" />,
      badge: 'Recommended',
      badgeColor: 'bg-blue-100 text-blue-800',
      benefits: [
        'No setup required if you already have Alexa',
        'Hands-free operation - just speak naturally',
        'Professional-grade audio quality',
        '24/7 always-listening capability',
        'Perfect for seniors with mobility issues'
      ],
      requirements: [
        'Amazon Alexa device (Echo, Echo Dot, etc.)',
        'Stable Wi-Fi connection',
        'Amazon Alexa app on smartphone/tablet'
      ],
      setupTime: '5 minutes',
      difficulty: 'Easy'
    },
    {
      id: 'traditional',
      title: 'Headphones & Microphone',
      subtitle: 'Traditional Audio Setup',
      description: 'Use computer headphones and microphone for voice interaction',
      icon: <Headphones className="h-8 w-8 text-gray-600" />,
      badge: 'Alternative',
      badgeColor: 'bg-gray-100 text-gray-800',
      benefits: [
        'Works with any computer or device',
        'Private audio - only you can hear responses',
        'No additional hardware needed for most computers',
        'Full control over audio settings'
      ],
      requirements: [
        'Computer with working speakers/headphones',
        'Built-in or external microphone',
        'Modern web browser (Chrome, Firefox, Safari)',
        'Microphone permissions enabled'
      ],
      setupTime: '10-15 minutes',
      difficulty: 'Moderate'
    }
  ];

  const selectedConfig = voiceOptions.find(option => option.id === selectedOption) || voiceOptions[0];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="max-w-6xl mx-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="outline" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Voice Setup Options</h1>
              <p className="text-gray-600 mt-1">Choose your preferred method for AI voice interaction</p>
            </div>
          </div>
          <Badge className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <Volume2 className="h-4 w-4 mr-2" />
            Voice-Powered Platform
          </Badge>
        </div>

        {/* Quick Recommendation */}
        <Alert className="border-blue-200 bg-blue-50">
          <Star className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-800">
            <strong>Recommended for Seniors:</strong> Amazon Alexa provides the easiest, most natural voice experience. 
            If you already have an Alexa device, setup takes just 5 minutes!
          </AlertDescription>
        </Alert>

        {/* Voice Options Selection */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {voiceOptions.map((option) => (
            <Card 
              key={option.id}
              className={`cursor-pointer transition-all duration-200 ${
                selectedOption === option.id 
                  ? 'ring-2 ring-blue-500 shadow-lg' 
                  : 'hover:shadow-md border-gray-200'
              }`}
              onClick={() => setSelectedOption(option.id)}
            >
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-gray-100 rounded-lg">
                      {option.icon}
                    </div>
                    <div>
                      <CardTitle className="text-lg">{option.title}</CardTitle>
                      <p className="text-sm text-gray-600 mt-1">{option.subtitle}</p>
                    </div>
                  </div>
                  <Badge className={option.badgeColor}>
                    {option.badge}
                  </Badge>
                </div>
                <p className="text-gray-700 mt-3">{option.description}</p>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-gray-500" />
                    <span>{option.setupTime}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Settings className="h-4 w-4 text-gray-500" />
                    <span>{option.difficulty}</span>
                  </div>
                </div>
                
                {selectedOption === option.id && (
                  <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-blue-600 mb-2" />
                    <p className="text-sm text-blue-800 font-medium">Selected Option</p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Detailed Setup Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              {selectedConfig.icon}
              Setup Guide: {selectedConfig.title}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="benefits" className="space-y-4">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="benefits">Benefits</TabsTrigger>
                <TabsTrigger value="requirements">Requirements</TabsTrigger>
                <TabsTrigger value="next-steps">Next Steps</TabsTrigger>
              </TabsList>

              <TabsContent value="benefits" className="space-y-4">
                <h3 className="font-semibold text-gray-900 mb-3">Why Choose {selectedConfig.title}?</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {selectedConfig.benefits.map((benefit, index) => (
                    <div key={index} className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{benefit}</span>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="requirements" className="space-y-4">
                <h3 className="font-semibold text-gray-900 mb-3">What You'll Need</h3>
                <div className="space-y-3">
                  {selectedConfig.requirements.map((requirement, index) => (
                    <div key={index} className="flex items-start gap-2">
                      <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="text-blue-600 text-sm font-semibold">{index + 1}</span>
                      </div>
                      <span className="text-gray-700">{requirement}</span>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="next-steps" className="space-y-4">
                <h3 className="font-semibold text-gray-900 mb-3">Ready to Get Started?</h3>
                <div className="space-y-4">
                  {selectedOption === 'alexa' ? (
                    <div>
                      <p className="text-gray-700 mb-4">
                        Follow our comprehensive Alexa integration guide to connect your device in just a few minutes.
                      </p>
                      <Link href="/alexa-integration">
                        <Button className="bg-blue-600 hover:bg-blue-700">
                          <Smartphone className="h-4 w-4 mr-2" />
                          Set Up Alexa Integration
                        </Button>
                      </Link>
                    </div>
                  ) : (
                    <div>
                      <p className="text-gray-700 mb-4">
                        Continue with the traditional audio setup guide to configure your headphones and microphone.
                      </p>
                      <Link href="/audio-setup-guide">
                        <Button variant="outline">
                          <Headphones className="h-4 w-4 mr-2" />
                          Set Up Traditional Audio
                        </Button>
                      </Link>
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Why Voice Interaction Matters */}
        <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
          <CardContent className="p-6">
            <div className="flex items-center gap-4 mb-4">
              <Heart className="h-8 w-8 text-red-500" />
              <div>
                <h3 className="text-xl font-bold text-gray-900">Why Voice Interaction is Perfect for Care</h3>
                <p className="text-gray-600">Natural communication for better health outcomes</p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Natural Communication</h4>
                <p className="text-sm text-gray-600">Speak naturally as you would to a family member or caregiver</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Zap className="h-6 w-6 text-green-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Instant Response</h4>
                <p className="text-sm text-gray-600">Get immediate help and answers when you need them most</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Heart className="h-6 w-6 text-purple-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Always Available</h4>
                <p className="text-sm text-gray-600">24/7 companion ready to assist with health and safety</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}