import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Heart, Brain, Users, Hospital, ChartLine, Shield, Gamepad, MemoryStick, Download, FileText, Volume2, Mic, Headphones } from "lucide-react";
import { useLocation } from "wouter";


export default function Landing() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Header */}
      <nav className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 care-gradient rounded-lg flex items-center justify-center">
                  <Heart className="text-white h-5 w-5" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">Care Companion</h1>
                  <p className="text-xs text-gray-500">AI-Powered Alzheimer's Care</p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-accent/10 px-3 py-1 rounded-full">
                <div className="w-2 h-2 bg-accent rounded-full ai-pulse"></div>
                <span className="text-sm font-medium text-accent">AI Active</span>
              </div>
              <Button 
                className="bg-care-primary text-white hover:bg-care-primary/90"
                onClick={() => navigate("/multilingual-support")}
              >
                <Users className="mr-2 h-4 w-4" />
                Languages
              </Button>
              <Button 
                className="bg-care-primary text-white hover:bg-care-primary/90"
                onClick={() => navigate("/admin-dashboard")}
              >
                <Users className="mr-2 h-4 w-4" />
                Dashboard
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Immersive Audio Experience Banner */}
      <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-blue-700 border-b border-blue-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Alert className="bg-transparent border-0 text-white py-4">
            <div className="flex items-center justify-between gap-6 flex-wrap">
              {/* Audio Icons */}
              <div className="flex items-center gap-2 flex-shrink-0">
                <Volume2 className="h-5 w-5 text-blue-200" />
                <Mic className="h-5 w-5 text-blue-200" />
                <Headphones className="h-5 w-5 text-blue-200" />
              </div>
              
              {/* Main Message */}
              <AlertDescription className="flex-1 min-w-0">
                <div className="text-center lg:text-left">
                  <div className="font-semibold text-blue-100 text-lg mb-1">
                    Immersive AI Voice Experience
                  </div>
                  <div className="text-blue-100 text-sm">
                    Enable speakers and microphone for full voice-powered interaction with your AI companion
                  </div>
                </div>
              </AlertDescription>
              
              {/* Action Buttons */}
              <div className="flex items-center gap-3 flex-shrink-0">
                <Badge className="bg-blue-400/20 text-blue-100 border-blue-300 whitespace-nowrap px-3 py-1">
                  Voice-Enabled Platform
                </Badge>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="bg-blue-400/20 text-blue-100 border-blue-300 hover:bg-blue-300/30 whitespace-nowrap"
                  onClick={() => navigate("/audio-setup-guide")}
                >
                  Setup Guide
                </Button>
              </div>
            </div>
          </Alert>
        </div>
      </div>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-50 via-white to-green-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="inline-flex items-center bg-accent/10 text-accent mb-6">
                <Brain className="mr-2 h-4 w-4" />
                Powered by Advanced AI Technology
              </Badge>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
                Transforming Alzheimer's Care Through 
                <span className="text-transparent bg-clip-text ai-gradient ml-2">AI-Powered</span> 
                <br />Family Connection
              </h1>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Revolutionary platform that transforms family memories into personalized cognitive training, 
                while providing comprehensive care insights for families and medical facilities.
              </p>

            </div>
            <div className="relative">
              <div className="float-animation">
                <img 
                  src="https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                  alt="Healthcare professional using tablet with brain imaging technology" 
                  className="rounded-2xl shadow-2xl w-full"
                />
              </div>
              {/* Floating AI Elements */}
              <div className="absolute -top-4 -right-4 bg-accent/20 backdrop-blur-sm p-4 rounded-xl">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-accent rounded-full ai-pulse"></div>
                  <span className="text-sm font-medium text-accent">AI Processing</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Action Buttons Section */}
      <section className="py-16 bg-gradient-to-r from-gray-50 to-blue-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
              Choose Your Path to Better Care
            </h2>
            <p className="text-lg text-gray-600">
              Explore our revolutionary features, start family onboarding, or discover admin benefits
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Button 
              size="lg" 
              className="care-gradient text-white hover:shadow-lg transition-all transform hover:-translate-y-1 px-8 py-4 text-lg"
              onClick={() => navigate("/features-showcase")}
            >
              <Brain className="mr-3 h-6 w-6" />
              Explore Revolutionary Features
            </Button>
            <Button 
              size="lg" 
              className="bg-purple-600 text-white hover:bg-purple-700 hover:shadow-lg transition-all transform hover:-translate-y-1 px-8 py-4 text-lg"
              onClick={() => navigate("/trial-signup")}
            >
              <Heart className="mr-3 h-6 w-6" />
              Start 14-Day Free Trial
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-2 border-gray-300 hover:border-care-primary hover:text-care-primary hover:shadow-lg transition-all transform hover:-translate-y-1 px-8 py-4 text-lg"
              onClick={() => navigate("/admin-dashboard")}
            >
              <Hospital className="mr-3 h-6 w-6" />
              Admin Benefits
            </Button>
          </div>
        </div>
      </section>

      {/* Family Onboarding Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Family-Powered AI Personalization
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our AI transforms your family memories, photos, and stories into personalized cognitive training activities 
              that adapt to your loved one's unique life history.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
            {/* Family Input Panel */}
            <Card className="family-card rounded-2xl p-8">
              <div className="w-16 h-16 care-gradient rounded-xl flex items-center justify-center mb-6">
                <Users className="text-white text-2xl h-8 w-8" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Family Input Panel</h3>
              <p className="text-gray-600 mb-6">
                Share photos, stories, and memories through our intuitive family interface. 
                Define relationships and care responsibilities.
              </p>
              
              {/* Mock Family Member Cards */}
              <div className="space-y-3">
                <Card className="bg-white border border-gray-200">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <Users className="text-care-primary h-5 w-5" />
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">Sarah (Daughter)</p>
                        <p className="text-sm text-gray-500">Primary Caregiver</p>
                      </div>
                      <div className="ml-auto">
                        <Badge className="bg-green-100 text-green-800">Active</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-white border border-gray-200">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                        <Users className="text-accent h-5 w-5" />
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">Michael (Son)</p>
                        <p className="text-sm text-gray-500">Support Member</p>
                      </div>
                      <div className="ml-auto">
                        <Badge className="bg-green-100 text-green-800">Active</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </Card>

            {/* AI Processing */}
            <Card className="cognitive-activity rounded-2xl p-8">
              <div className="w-16 h-16 ai-gradient rounded-xl flex items-center justify-center mb-6">
                <Brain className="text-white text-2xl h-8 w-8" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">AI Processing Engine</h3>
              <p className="text-gray-600 mb-6">
                Advanced AI analyzes family input to create personalized cognitive training activities 
                and therapeutic conversations.
              </p>
              
              {/* AI Processing Visualization */}
              <Card className="bg-white border border-accent/20">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2 mb-3">
                    <div className="w-3 h-3 bg-accent rounded-full ai-pulse"></div>
                    <span className="text-sm font-medium text-accent">Processing Family Data</span>
                  </div>
                  <div className="space-y-2">
                    <div className="bg-gray-100 rounded-full h-2">
                      <div className="bg-accent h-2 rounded-full w-4/5"></div>
                    </div>
                    <p className="text-xs text-gray-500">Analyzing 47 photos, 12 stories, 3 family members</p>
                  </div>
                </CardContent>
              </Card>
              
              <div className="mt-4 bg-accent/10 rounded-lg p-3">
                <p className="text-sm text-accent font-medium">
                  <span className="mr-2">💡</span>
                  Generated 23 personalized activities from family memories
                </p>
              </div>
            </Card>

            {/* Patient Experience */}
            <Card className="bg-gradient-to-br from-green-50 to-blue-50 rounded-2xl p-8 border-2 border-care-secondary/20">
              <div className="w-16 h-16 bg-care-secondary rounded-xl flex items-center justify-center mb-6">
                <Heart className="text-white text-2xl h-8 w-8" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Patient Care Companion</h3>
              <p className="text-gray-600 mb-6">
                Personalized cognitive training delivered through engaging activities based on 
                your loved one's life story and family connections.
              </p>
              
              {/* Mock Patient Activities */}
              <div className="space-y-3">
                <Card className="bg-white border border-gray-200">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold text-gray-900">Family Photo MemoryStick</p>
                        <p className="text-sm text-gray-500">Recognition training with Sarah's wedding</p>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold text-care-secondary">89%</p>
                        <p className="text-xs text-gray-500">Success Rate</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-white border border-gray-200">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold text-gray-900">Story Recall Exercise</p>
                        <p className="text-sm text-gray-500">Christmas memories from 1985</p>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold text-care-secondary">76%</p>
                        <p className="text-xs text-gray-500">Success Rate</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Admin Benefits Dashboard */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Administrative Benefits & ROI
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Comprehensive analytics and measurable outcomes that demonstrate care quality improvements, 
              staff efficiency gains, and insurance reimbursement opportunities.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              {/* ROI Metrics Dashboard */}
              <Card className="bg-white/10 backdrop-blur-sm border border-white/20">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold mb-6 flex items-center text-white">
                    <ChartLine className="mr-3 text-care-secondary h-6 w-6" />
                    ROI Dashboard
                  </h3>
                  
                  <div className="grid grid-cols-2 gap-6 mb-6">
                    <div className="bg-white/5 rounded-lg p-4">
                      <p className="text-3xl font-bold text-care-secondary">23%</p>
                      <p className="text-sm text-gray-300">Care Quality Improvement</p>
                    </div>
                    <div className="bg-white/5 rounded-lg p-4">
                      <p className="text-3xl font-bold text-accent">$3.2M</p>
                      <p className="text-sm text-gray-300">Annual Insurance Benefits</p>
                    </div>
                    <div className="bg-white/5 rounded-lg p-4">
                      <p className="text-3xl font-bold text-care-primary">18%</p>
                      <p className="text-sm text-gray-300">Staff Efficiency Gain</p>
                    </div>
                    <div className="bg-white/5 rounded-lg p-4">
                      <p className="text-3xl font-bold text-yellow-400">94%</p>
                      <p className="text-sm text-gray-300">Family Satisfaction</p>
                    </div>
                  </div>

                  {/* Insurance Integration */}
                  <div className="bg-accent/20 rounded-lg p-4 mb-4">
                    <h4 className="font-semibold mb-2 flex items-center text-white">
                      <Shield className="mr-2 text-accent h-5 w-5" />
                      Insurance Integration
                    </h4>
                    <p className="text-sm text-gray-200">
                      Automated documentation and billing support for cognitive therapy services. 
                      Medicare and Medicaid compliant reporting.
                    </p>
                  </div>

                  <Button className="w-full bg-care-secondary text-white hover:bg-care-secondary/90">
                    <Download className="mr-2 h-4 w-4" />
                    Download Full Benefits Report
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Benefits Lists */}
            <div className="space-y-6">
              <Card className="bg-white/10 backdrop-blur-sm border border-white/20">
                <CardContent className="p-6">
                  <h4 className="text-xl font-bold mb-4 text-care-primary">Care Quality Metrics</h4>
                  <ul className="space-y-3">
                    <li className="flex items-center text-white">
                      <div className="w-2 h-2 bg-care-secondary rounded-full mr-3"></div>
                      <span>Measurable cognitive improvement tracking</span>
                    </li>
                    <li className="flex items-center text-white">
                      <div className="w-2 h-2 bg-care-secondary rounded-full mr-3"></div>
                      <span>Family engagement analytics</span>
                    </li>
                    <li className="flex items-center text-white">
                      <div className="w-2 h-2 bg-care-secondary rounded-full mr-3"></div>
                      <span>Personalized care plan optimization</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="bg-white/10 backdrop-blur-sm border border-white/20">
                <CardContent className="p-6">
                  <h4 className="text-xl font-bold mb-4 text-accent">Staff Efficiency</h4>
                  <ul className="space-y-3">
                    <li className="flex items-center text-white">
                      <div className="w-2 h-2 bg-care-secondary rounded-full mr-3"></div>
                      <span>Automated activity planning and tracking</span>
                    </li>
                    <li className="flex items-center text-white">
                      <div className="w-2 h-2 bg-care-secondary rounded-full mr-3"></div>
                      <span>Real-time progress monitoring</span>
                    </li>
                    <li className="flex items-center text-white">
                      <div className="w-2 h-2 bg-care-secondary rounded-full mr-3"></div>
                      <span>Comprehensive reporting dashboard</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="bg-white/10 backdrop-blur-sm border border-white/20">
                <CardContent className="p-6">
                  <h4 className="text-xl font-bold mb-4 text-yellow-400">Revenue Opportunities</h4>
                  <ul className="space-y-3">
                    <li className="flex items-center text-white">
                      <div className="w-2 h-2 bg-care-secondary rounded-full mr-3"></div>
                      <span>Insurance reimbursable cognitive therapy</span>
                    </li>
                    <li className="flex items-center text-white">
                      <div className="w-2 h-2 bg-care-secondary rounded-full mr-3"></div>
                      <span>Premium family engagement services</span>
                    </li>
                    <li className="flex items-center text-white">
                      <div className="w-2 h-2 bg-care-secondary rounded-full mr-3"></div>
                      <span>Compliance documentation automation</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* AI Features Showcase */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Advanced AI Capabilities
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Revolutionary invisible cognitive enhancement strategies that deliver potent, measurable improvements 
              in memory, attention, and executive function while operating completely unnoticeably through normal interface interactions.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* MemoryStick Processing */}
            <Card className="bg-gradient-to-br from-purple-50 to-blue-50 border border-accent/20 hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 ai-gradient rounded-xl flex items-center justify-center mb-6">
                  <MemoryStick className="text-white text-2xl h-8 w-8" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">MemoryStick Preservation Engine</h3>
                <p className="text-gray-600 mb-6">
                  AI processes family histories and relationships to create ongoing therapeutic conversations 
                  and cognitive stimulation activities.
                </p>
                <Card className="bg-white border border-gray-200">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-gray-600">Processing Confidence</span>
                      <span className="text-sm font-bold text-accent">94%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-accent h-2 rounded-full w-[94%]"></div>
                    </div>
                  </CardContent>
                </Card>
              </CardContent>
            </Card>

            {/* Cognitive Assessment */}
            <Card className="bg-gradient-to-br from-green-50 to-blue-50 border border-care-secondary/20 hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-care-secondary rounded-xl flex items-center justify-center mb-6">
                  <Brain className="text-white text-2xl h-8 w-8" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Real-time Cognitive Assessment</h3>
                <p className="text-gray-600 mb-6">
                  Continuous monitoring of cognitive performance through AI-analyzed activities 
                  with detailed progress tracking and early intervention alerts.
                </p>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">MemoryStick Recall</span>
                    <Badge className="bg-care-secondary text-white">Good</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Recognition</span>
                    <Badge className="bg-yellow-500 text-white">Moderate</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Attention</span>
                    <Badge className="bg-care-secondary text-white">Good</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Dynamic Training */}
            <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border border-care-primary/20 hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-care-primary rounded-xl flex items-center justify-center mb-6">
                  <Gamepad className="text-white text-2xl h-8 w-8" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Dynamic Training Generator</h3>
                <p className="text-gray-600 mb-6">
                  AI creates custom memory games, recognition exercises, and conversation prompts 
                  based on family-provided content and patient progress.
                </p>
                <Card className="bg-white border border-gray-200">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold text-gray-900">Today's Activity</p>
                        <p className="text-sm text-gray-500">Photo Recognition: Family Vacation</p>
                      </div>
                      <Button size="sm" className="bg-care-primary text-white">
                        Start
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 ai-gradient">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Transform Alzheimer's Care?
          </h2>
          <p className="text-xl text-white/90 mb-10">
            Join families and care facilities who are already experiencing the power of 
            AI-driven personalized cognitive care.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-white text-accent hover:shadow-lg transition-all transform hover:-translate-y-1"
              onClick={() => navigate("/family-onboarding")}
            >
              <Users className="mr-2 h-5 w-5" />
              Start Family Onboarding
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="bg-white/10 backdrop-blur-sm text-white border-2 border-white/20 hover:bg-white/20"
              onClick={() => navigate("/admin-dashboard")}
            >
              <Hospital className="mr-2 h-5 w-5" />
              Request Admin Demo
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="bg-white/10 backdrop-blur-sm text-white border-2 border-white/20 hover:bg-white/20"
              onClick={() => navigate("/features-showcase")}
            >
              <FileText className="mr-2 h-5 w-5" />
              View All Features
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 care-gradient rounded-lg flex items-center justify-center">
                  <Heart className="text-white h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Care Companion</h3>
                  <p className="text-sm text-gray-400">AI-Powered Alzheimer's Care</p>
                </div>
              </div>
              <p className="text-gray-400 mb-4">
                Transforming Alzheimer's care through AI-powered family connections, 
                personalized cognitive training, and comprehensive care analytics.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">For Families</h4>
              <ul className="space-y-2 text-gray-400">
                <li><button onClick={() => navigate("/family-onboarding")} className="hover:text-white transition-colors text-left">Family Onboarding</button></li>
                <li><button onClick={() => navigate("/photo-memory-demo")} className="hover:text-white transition-colors text-left">Memory Analysis</button></li>
                <li><button onClick={() => navigate("/patient-companion")} className="hover:text-white transition-colors text-left">Patient Companion</button></li>
                <li><button onClick={() => navigate("/audio-experience-guide")} className="hover:text-white transition-colors text-left">Voice Setup Guide</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">For Facilities</h4>
              <ul className="space-y-2 text-gray-400">
                <li><button onClick={() => navigate("/admin-dashboard")} className="hover:text-white transition-colors text-left">Admin Dashboard</button></li>
                <li><button onClick={() => navigate("/features-showcase")} className="hover:text-white transition-colors text-left">Technology Features</button></li>
                <li><button onClick={() => navigate("/insurance-verification")} className="hover:text-white transition-colors text-left">Insurance Integration</button></li>
                <li><button onClick={() => navigate("/at-home-care-center")} className="hover:text-white transition-colors text-left">At-Home Care Center</button></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Care Companion. All rights reserved. HIPAA Compliant Healthcare Technology.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
