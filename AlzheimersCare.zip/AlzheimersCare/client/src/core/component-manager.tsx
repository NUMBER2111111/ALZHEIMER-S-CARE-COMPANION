import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

/**
 * Unified component state management and error handling
 * Reduces code duplication across healthcare components
 */
export interface ComponentState {
  loading: boolean;
  error: string | null;
  data: any;
  initialized: boolean;
}

export interface ComponentManagerProps {
  patientId?: number;
  onError?: (error: string) => void;
  onSuccess?: (data: any) => void;
  autoRefresh?: boolean;
  refreshInterval?: number;
}

export class ComponentManager {
  private static errorBoundaries = new Map<string, React.ComponentType>();
  private static loadingStates = new Map<string, boolean>();

  static withErrorBoundary<T extends React.ComponentProps<any>>(
    Component: React.ComponentType<T>,
    componentName: string
  ): React.ComponentType<T> {
    if (this.errorBoundaries.has(componentName)) {
      return this.errorBoundaries.get(componentName)!;
    }

    const WrappedComponent: React.ComponentType<T> = (props) => {
      const [hasError, setHasError] = useState(false);
      const [error, setError] = useState<string | null>(null);
      const { toast } = useToast();

      const handleError = useCallback((error: Error) => {
        setHasError(true);
        setError(error.message);
        toast({
          title: `${componentName} Error`,
          description: error.message,
          variant: 'destructive'
        });
      }, [toast]);

      useEffect(() => {
        const handleGlobalError = (event: ErrorEvent) => {
          if (event.error && event.error.componentName === componentName) {
            handleError(event.error);
          }
        };

        window.addEventListener('error', handleGlobalError);
        return () => window.removeEventListener('error', handleGlobalError);
      }, [handleError]);

      if (hasError) {
        return (
          <div className="flex flex-col items-center justify-center p-8 bg-red-50 dark:bg-red-900/20 rounded-lg">
            <div className="text-red-600 dark:text-red-400 text-lg font-semibold mb-2">
              {componentName} Error
            </div>
            <div className="text-red-500 dark:text-red-300 text-sm mb-4">
              {error}
            </div>
            <button
              onClick={() => {
                setHasError(false);
                setError(null);
                window.location.reload();
              }}
              className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
            >
              Retry
            </button>
          </div>
        );
      }

      try {
        return <Component {...props} />;
      } catch (error: any) {
        handleError(error);
        return null;
      }
    };

    this.errorBoundaries.set(componentName, WrappedComponent);
    return WrappedComponent;
  }

  static useHealthcareData(endpoint: string, options: ComponentManagerProps = {}) {
    const { patientId, onError, onSuccess, autoRefresh = false, refreshInterval = 30000 } = options;
    const { toast } = useToast();

    const queryKey = patientId ? [endpoint, patientId] : [endpoint];

    const query = useQuery({
      queryKey,
      queryFn: async () => {
        try {
          const response = await apiRequest('GET', endpoint);
          const data = await response.json();
          
          if (!data.success) {
            throw new Error(data.error?.message || 'Request failed');
          }
          
          onSuccess?.(data);
          return data;
        } catch (error: any) {
          const message = error.message || 'Unknown error occurred';
          onError?.(message);
          toast({
            title: 'Data Loading Error',
            description: message,
            variant: 'destructive'
          });
          throw error;
        }
      },
      refetchInterval: autoRefresh ? refreshInterval : false,
      retry: 3,
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000)
    });

    return {
      ...query,
      state: {
        loading: query.isLoading,
        error: query.error?.message || null,
        data: query.data,
        initialized: !query.isLoading && !query.isError
      } as ComponentState
    };
  }

  static useHealthcareMutation(endpoint: string, method: 'POST' | 'PUT' | 'PATCH' | 'DELETE', options: ComponentManagerProps = {}) {
    const { onError, onSuccess } = options;
    const { toast } = useToast();
    const queryClient = useQueryClient();

    return useMutation({
      mutationFn: async (data: any) => {
        try {
          const response = await apiRequest(method, endpoint, data);
          const result = await response.json();
          
          if (!result.success) {
            throw new Error(result.error?.message || 'Request failed');
          }
          
          onSuccess?.(result);
          toast({
            title: 'Success',
            description: 'Operation completed successfully'
          });
          
          return result;
        } catch (error: any) {
          const message = error.message || 'Unknown error occurred';
          onError?.(message);
          toast({
            title: 'Operation Failed',
            description: message,
            variant: 'destructive'
          });
          throw error;
        }
      },
      onSuccess: () => {
        // Invalidate related queries
        queryClient.invalidateQueries({ queryKey: [endpoint] });
      }
    });
  }

  static LoadingSpinner: React.FC<{ size?: 'small' | 'medium' | 'large' }> = ({ size = 'medium' }) => {
    const sizeClasses = {
      small: 'w-4 h-4',
      medium: 'w-8 h-8',
      large: 'w-12 h-12'
    };

    return (
      <div className="flex items-center justify-center p-4">
        <div className={`${sizeClasses[size]} border-4 border-primary border-t-transparent rounded-full animate-spin`} />
      </div>
    );
  };

  static EmptyState: React.FC<{ message: string; action?: () => void; actionLabel?: string }> = ({ 
    message, 
    action, 
    actionLabel = 'Retry' 
  }) => (
    <div className="flex flex-col items-center justify-center p-8 text-center">
      <div className="text-gray-500 dark:text-gray-400 mb-4">{message}</div>
      {action && (
        <button
          onClick={action}
          className="px-4 py-2 bg-primary text-primary-foreground rounded hover:bg-primary/90 transition-colors"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );

  static ErrorState: React.FC<{ error: string; onRetry?: () => void }> = ({ error, onRetry }) => (
    <div className="flex flex-col items-center justify-center p-8 bg-red-50 dark:bg-red-900/20 rounded-lg">
      <div className="text-red-600 dark:text-red-400 text-lg font-semibold mb-2">
        Error
      </div>
      <div className="text-red-500 dark:text-red-300 text-sm mb-4 text-center">
        {error}
      </div>
      {onRetry && (
        <button
          onClick={onRetry}
          className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
        >
          Retry
        </button>
      )}
    </div>
  );
}

/**
 * Enhanced hook for patient-specific data with automatic error handling
 */
export function usePatientData(patientId: number, dataType: string) {
  const endpoint = `/api/patients/${patientId}/${dataType}`;
  
  return ComponentManager.useHealthcareData(endpoint, {
    patientId,
    autoRefresh: true,
    refreshInterval: 30000
  });
}

/**
 * Enhanced hook for creating patient-related records
 */
export function usePatientMutation(patientId: number, dataType: string, method: 'POST' | 'PUT' | 'PATCH' = 'POST') {
  const endpoint = `/api/patients/${patientId}/${dataType}`;
  
  return ComponentManager.useHealthcareMutation(endpoint, method, {
    patientId
  });
}

/**
 * Consolidated form state management
 */
export function useFormState<T extends Record<string, any>>(initialState: T) {
  const [formData, setFormData] = useState<T>(initialState);
  const [errors, setErrors] = useState<Partial<Record<keyof T, string>>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const updateField = useCallback((field: keyof T, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  }, [errors]);

  const setFieldError = useCallback((field: keyof T, error: string) => {
    setErrors(prev => ({ ...prev, [field]: error }));
  }, []);

  const clearErrors = useCallback(() => {
    setErrors({});
  }, []);

  const reset = useCallback(() => {
    setFormData(initialState);
    setErrors({});
    setIsSubmitting(false);
  }, [initialState]);

  const validate = useCallback((validationRules: Partial<Record<keyof T, (value: any) => string | null>>) => {
    const newErrors: Partial<Record<keyof T, string>> = {};
    let isValid = true;

    Object.entries(validationRules).forEach(([field, validator]) => {
      const error = validator!(formData[field as keyof T]);
      if (error) {
        newErrors[field as keyof T] = error;
        isValid = false;
      }
    });

    setErrors(newErrors);
    return isValid;
  }, [formData]);

  return {
    formData,
    errors,
    isSubmitting,
    setIsSubmitting,
    updateField,
    setFieldError,
    clearErrors,
    reset,
    validate,
    hasErrors: Object.keys(errors).length > 0
  };
}

/**
 * Consolidated audio/voice management
 */
export function useAudioManager() {
  const [isSupported, setIsSupported] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [hasPermission, setHasPermission] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const checkSupport = async () => {
      const supported = 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
      setIsSupported(supported);

      if (supported) {
        try {
          const permission = await navigator.mediaDevices.getUserMedia({ audio: true });
          setHasPermission(true);
          permission.getTracks().forEach(track => track.stop());
        } catch (error) {
          setHasPermission(false);
        }
      }
    };

    checkSupport();
  }, []);

  const requestPermission = useCallback(async () => {
    try {
      const permission = await navigator.mediaDevices.getUserMedia({ audio: true });
      setHasPermission(true);
      permission.getTracks().forEach(track => track.stop());
      toast({
        title: 'Audio Permission Granted',
        description: 'Voice features are now available'
      });
    } catch (error) {
      setHasPermission(false);
      toast({
        title: 'Audio Permission Denied',
        description: 'Voice features require microphone access',
        variant: 'destructive'
      });
    }
  }, [toast]);

  const startListening = useCallback(() => {
    if (!isSupported || !hasPermission) return;
    setIsListening(true);
  }, [isSupported, hasPermission]);

  const stopListening = useCallback(() => {
    setIsListening(false);
  }, []);

  return {
    isSupported,
    isListening,
    hasPermission,
    requestPermission,
    startListening,
    stopListening
  };
}