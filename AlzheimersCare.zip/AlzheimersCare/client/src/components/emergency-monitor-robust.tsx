import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Heart, Activity, Thermometer, Droplets, AlertTriangle, CheckCircle } from 'lucide-react';

interface VitalSigns {
  id: number;
  heartRate: number | null;
  bloodPressureSystolic: number | null;
  bloodPressureDiastolic: number | null;
  oxygenSaturation: number | null;
  temperature: number | null;
  isEmergencyAlert: boolean;
  alertType?: string | null;
  createdAt: string;
}

interface EmergencyEvent {
  id: number;
  eventType: string;
  severity: string;
  description: string | null;
  status: string;
  createdAt: string;
}

interface EmergencyMonitorProps {
  patientId: number;
}

export function EmergencyMonitor({ patientId }: EmergencyMonitorProps) {
  const [simulationMode, setSimulationMode] = useState(false);

  // Robust data fetching with error handling
  const { data: latestVitals, isLoading: vitalsLoading, error: vitalsError } = useQuery({
    queryKey: ['/api/patients', patientId, 'vital-signs', 'latest'],
    refetchInterval: 30000,
    retry: 3,
    retryDelay: 1000,
  });

  const { data: emergencyAlerts = [], isLoading: alertsLoading } = useQuery({
    queryKey: ['/api/emergency-alerts', patientId],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/emergency-alerts?patientId=${patientId}`);
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        return response.json();
      } catch (error) {
        console.error('Failed to fetch emergency alerts:', error);
        return [];
      }
    },
    refetchInterval: 10000,
    retry: 2,
  });

  const { data: emergencyEvents = [], isLoading: eventsLoading } = useQuery({
    queryKey: ['/api/patients', patientId, 'emergency-events'],
    retry: 3,
  });

  // Robust mutation handling
  const acknowledgeEmergencyMutation = useMutation({
    mutationFn: async (eventId: number) => {
      try {
        return await apiRequest('POST', `/api/emergency-events/${eventId}/acknowledge`, { userId: 1 });
      } catch (error) {
        console.error('Failed to acknowledge emergency:', error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'emergency-events'] });
      queryClient.invalidateQueries({ queryKey: ['/api/emergency-alerts', patientId] });
    },
    onError: (error) => {
      console.error('Acknowledge emergency failed:', error);
    },
  });

  const resolveEmergencyMutation = useMutation({
    mutationFn: async (eventId: number) => {
      try {
        return await apiRequest('POST', `/api/emergency-events/${eventId}/resolve`);
      } catch (error) {
        console.error('Failed to resolve emergency:', error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'emergency-events'] });
      queryClient.invalidateQueries({ queryKey: ['/api/emergency-alerts', patientId] });
    },
    onError: (error) => {
      console.error('Resolve emergency failed:', error);
    },
  });

  // Robust vital signs simulation
  const simulateEmergencyMutation = useMutation({
    mutationFn: async () => {
      try {
        return await apiRequest('POST', `/api/patients/${patientId}/vital-signs/simulate`, {
          heartRate: Math.floor(Math.random() * 50) + 140, // High heart rate
          bloodPressureSystolic: Math.floor(Math.random() * 40) + 160,
          bloodPressureDiastolic: Math.floor(Math.random() * 20) + 100,
          oxygenSaturation: Math.floor(Math.random() * 10) + 85,
          temperature: (Math.random() * 3 + 101).toFixed(1),
          isEmergencyAlert: true,
          alertType: 'High Blood Pressure',
        });
      } catch (error) {
        console.error('Failed to simulate emergency:', error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'vital-signs', 'latest'] });
      queryClient.invalidateQueries({ queryKey: ['/api/emergency-alerts', patientId] });
    },
  });

  // Robust risk assessment
  const getRiskLevel = (vitals: any): 'normal' | 'warning' | 'critical' => {
    if (!vitals || typeof vitals !== 'object') return 'normal';
    
    const heartRate = vitals.heartRate || 0;
    const systolic = vitals.bloodPressureSystolic || 0;
    const oxygen = vitals.oxygenSaturation || 100;
    const temp = parseFloat(vitals.temperature) || 98.6;
    
    if (heartRate > 120 || heartRate < 50 || 
        systolic > 160 || systolic < 90 ||
        oxygen < 90 || temp > 102 || temp < 96) {
      return 'critical';
    }
    
    if (heartRate > 100 || heartRate < 60 ||
        systolic > 140 || systolic < 100 ||
        oxygen < 95 || temp > 100 || temp < 97) {
      return 'warning';
    }
    
    return 'normal';
  };

  // Render vital signs with null safety
  const renderVitalSigns = () => {
    if (vitalsLoading) {
      return <div className="text-sm text-gray-500">Loading vital signs...</div>;
    }

    if (vitalsError) {
      return <div className="text-sm text-red-500">Error loading vital signs</div>;
    }

    if (!latestVitals || typeof latestVitals !== 'object') {
      return <div className="text-sm text-gray-500">No vital signs data available</div>;
    }

    const vitals = latestVitals as any;
    const riskLevel = getRiskLevel(vitals);

    return (
      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <span className="text-sm font-medium flex items-center gap-2">
            <Heart className="h-4 w-4" />
            Heart Rate
          </span>
          <span className={`font-mono ${vitals.heartRate > 100 ? 'text-red-500' : 'text-green-600'}`}>
            {vitals.heartRate || '--'} BPM
          </span>
        </div>
        
        <div className="flex justify-between items-center">
          <span className="text-sm font-medium flex items-center gap-2">
            <Activity className="h-4 w-4" />
            Blood Pressure
          </span>
          <span className={`font-mono ${(vitals.bloodPressureSystolic || 0) > 140 ? 'text-red-500' : 'text-green-600'}`}>
            {vitals.bloodPressureSystolic || '--'}/{vitals.bloodPressureDiastolic || '--'}
          </span>
        </div>
        
        <div className="flex justify-between items-center">
          <span className="text-sm font-medium flex items-center gap-2">
            <Droplets className="h-4 w-4" />
            O₂ Saturation
          </span>
          <span className={`font-mono ${(vitals.oxygenSaturation || 100) < 95 ? 'text-red-500' : 'text-green-600'}`}>
            {vitals.oxygenSaturation || '--'}%
          </span>
        </div>
        
        <div className="flex justify-between items-center">
          <span className="text-sm font-medium flex items-center gap-2">
            <Thermometer className="h-4 w-4" />
            Temperature
          </span>
          <span className="font-mono text-green-600">
            {vitals.temperature || '--'}°F
          </span>
        </div>
        
        <div className="pt-2 border-t">
          <Badge variant={riskLevel === 'critical' ? 'destructive' : riskLevel === 'warning' ? 'secondary' : 'default'}>
            {riskLevel === 'critical' ? 'Critical Risk' : riskLevel === 'warning' ? 'Warning' : 'Normal'}
          </Badge>
        </div>
        
        {vitals.isEmergencyAlert && (
          <Alert className="border-red-200 bg-red-50">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription className="text-red-700">
              Alert: {vitals.alertType || 'Emergency condition detected'}
            </AlertDescription>
          </Alert>
        )}
        
        <div className="text-xs text-gray-500">
          Last updated: {vitals.createdAt ? new Date(vitals.createdAt).toLocaleTimeString() : 'Unknown'}
        </div>
      </div>
    );
  };

  // Render emergency alerts with robust error handling
  const renderEmergencyAlerts = () => {
    if (alertsLoading) return <div className="text-sm text-gray-500">Loading alerts...</div>;
    
    if (!Array.isArray(emergencyAlerts) || emergencyAlerts.length === 0) {
      return <div className="text-sm text-gray-500">No active emergency alerts</div>;
    }

    return emergencyAlerts.slice(0, 3).map((alert: any, index: number) => (
      <Alert key={alert.id || index} className="border-red-200 bg-red-50">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription className="text-red-700">
          {alert.alertType || 'Emergency Alert'} - {alert.description || 'No description available'}
        </AlertDescription>
      </Alert>
    ));
  };

  // Render emergency events with robust error handling
  const renderEmergencyEvents = () => {
    if (eventsLoading) return <div className="text-sm text-gray-500">Loading events...</div>;
    
    if (!Array.isArray(emergencyEvents) || emergencyEvents.length === 0) {
      return <div className="text-sm text-gray-500">No emergency events</div>;
    }

    return emergencyEvents.map((event: any, index: number) => (
      <div key={event.id || index} className="p-3 border border-gray-200 rounded-lg">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <div className="font-medium text-sm">{event.eventType || 'Unknown Event'}</div>
            <div className="text-xs text-gray-500 mt-1">
              {event.description || 'No description available'}
            </div>
            <div className="text-xs text-gray-400 mt-1">
              {event.createdAt ? new Date(event.createdAt).toLocaleString() : 'Unknown time'}
            </div>
          </div>
          <div className="flex gap-2 ml-2">
            <Badge variant={event.severity === 'critical' ? 'destructive' : 'secondary'}>
              {event.severity || 'unknown'}
            </Badge>
            <Badge variant={event.status === 'resolved' ? 'default' : 'outline'}>
              {event.status || 'pending'}
            </Badge>
          </div>
        </div>
        
        {event.status === 'active' && (
          <div className="flex gap-2 mt-3">
            <Button
              size="sm"
              variant="outline"
              onClick={() => acknowledgeEmergencyMutation.mutate(event.id)}
              disabled={acknowledgeEmergencyMutation.isPending}
            >
              {acknowledgeEmergencyMutation.isPending ? 'Processing...' : 'Acknowledge'}
            </Button>
            <Button
              size="sm"
              onClick={() => resolveEmergencyMutation.mutate(event.id)}
              disabled={resolveEmergencyMutation.isPending}
            >
              {resolveEmergencyMutation.isPending ? 'Processing...' : 'Resolve'}
            </Button>
          </div>
        )}
      </div>
    ));
  };

  return (
    <div className="space-y-6">
      {/* Current Vital Signs */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Current Vital Signs</CardTitle>
        </CardHeader>
        <CardContent>
          {renderVitalSigns()}
        </CardContent>
      </Card>

      {/* Emergency Alerts */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-red-500" />
            Active Alerts
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {renderEmergencyAlerts()}
        </CardContent>
      </Card>

      {/* Emergency Events */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Emergency Events</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {renderEmergencyEvents()}
        </CardContent>
      </Card>

      {/* Emergency Simulation */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Emergency Simulation</CardTitle>
        </CardHeader>
        <CardContent>
          <Button
            onClick={() => simulateEmergencyMutation.mutate()}
            disabled={simulateEmergencyMutation.isPending}
            variant="destructive"
            className="w-full"
          >
            {simulateEmergencyMutation.isPending ? 'Simulating...' : 'Simulate Emergency Alert'}
          </Button>
          <p className="text-xs text-gray-500 mt-2">
            This will create test vital signs data with emergency conditions
          </p>
        </CardContent>
      </Card>
    </div>
  );
}