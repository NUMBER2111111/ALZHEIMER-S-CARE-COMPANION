import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Pill, Clock, CheckCircle, XCircle, AlertTriangle } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface Medication {
  id: number;
  name: string;
  dosage: string;
  frequency: string;
  timeSlots: string[];
  instructions: string;
  isActive: boolean;
  emergencyContact: string;
}

interface MedicationLog {
  id: number;
  medicationId: number;
  scheduledTime: string;
  actualTime?: string;
  status: 'taken' | 'missed' | 'delayed' | 'refused';
  dispenserConfirmed: boolean;
  notes?: string;
}

interface MedicationAdherence {
  adherenceScore: number;
  patterns: string[];
  riskFactors: string[];
  recommendations: string[];
  interventions: string[];
}

interface MedicineTrackerProps {
  patientId: number;
}

export function MedicineTracker({ patientId }: MedicineTrackerProps) {
  const queryClient = useQueryClient();
  const [selectedMedication, setSelectedMedication] = useState<number | null>(null);

  const { data: medications, isLoading: medicationsLoading } = useQuery({
    queryKey: ['/api/patients', patientId, 'medications'],
  });

  const { data: medicationLogs } = useQuery({
    queryKey: ['/api/patients', patientId, 'medication-logs'],
  });

  const { data: adherenceAnalysis } = useQuery({
    queryKey: ['/api/patients', patientId, 'medication-adherence'],
  });

  const logMedicationMutation = useMutation({
    mutationFn: async (logData: {
      medicationId: number;
      scheduledTime: string;
      status: string;
      actualTime?: string;
      notes?: string;
    }) => {
      await apiRequest('/api/medication-logs', {
        method: 'POST',
        body: JSON.stringify({
          ...logData,
          patientId,
        }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'medication-logs'] });
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'medication-adherence'] });
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'taken': return 'default';
      case 'missed': return 'destructive';
      case 'delayed': return 'secondary';
      case 'refused': return 'destructive';
      default: return 'default';
    }
  };

  const getAdherenceColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 75) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getTodaysSchedule = () => {
    if (!medications) return [];
    
    const today = new Date().toISOString().split('T')[0];
    const schedule: any[] = [];
    
    medications.forEach((med: Medication) => {
      med.timeSlots?.forEach((time: string) => {
        const scheduledDateTime = `${today}T${time}:00`;
        const log = medicationLogs?.find((log: MedicationLog) => 
          log.medicationId === med.id && 
          log.scheduledTime.startsWith(today) &&
          log.scheduledTime.includes(time)
        );
        
        schedule.push({
          medication: med,
          scheduledTime: scheduledDateTime,
          timeSlot: time,
          log,
          status: log?.status || 'pending'
        });
      });
    });
    
    return schedule.sort((a, b) => a.timeSlot.localeCompare(b.timeSlot));
  };

  const todaysSchedule = getTodaysSchedule();

  if (medicationsLoading) {
    return <div className="flex items-center justify-center h-64">Loading medications...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Adherence Overview */}
      {adherenceAnalysis && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Pill className="h-5 w-5" />
              Medication Adherence
            </CardTitle>
            <CardDescription>AI-powered analysis of medication compliance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <div className="text-center">
                  <div className={`text-3xl font-bold ${getAdherenceColor(adherenceAnalysis.adherenceScore)}`}>
                    {adherenceAnalysis.adherenceScore}%
                  </div>
                  <p className="text-sm text-gray-600 mt-1">Adherence Score</p>
                </div>
                <Progress 
                  value={adherenceAnalysis.adherenceScore} 
                  className="mt-3"
                />
              </div>
              
              <div>
                <h4 className="font-medium mb-2">Risk Factors</h4>
                <div className="space-y-1">
                  {adherenceAnalysis.riskFactors.slice(0, 3).map((factor, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <AlertTriangle className="h-3 w-3 text-red-500" />
                      <span className="text-sm">{factor}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <h4 className="font-medium mb-2">Recommendations</h4>
                <div className="space-y-1">
                  {adherenceAnalysis.recommendations.slice(0, 3).map((rec, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <CheckCircle className="h-3 w-3 text-green-500" />
                      <span className="text-sm">{rec}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Today's Schedule */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Today's Medication Schedule
            </CardTitle>
            <CardDescription>Track today's medication doses</CardDescription>
          </CardHeader>
          <CardContent>
            {todaysSchedule.length > 0 ? (
              <div className="space-y-4">
                {todaysSchedule.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium">{item.medication.name}</span>
                        <Badge variant={getStatusColor(item.status)}>
                          {item.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">
                        {item.timeSlot} - {item.medication.dosage}
                      </p>
                      {item.log?.notes && (
                        <p className="text-xs text-gray-500 mt-1">{item.log.notes}</p>
                      )}
                    </div>
                    
                    {item.status === 'pending' && (
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => logMedicationMutation.mutate({
                            medicationId: item.medication.id,
                            scheduledTime: item.scheduledTime,
                            status: 'taken',
                            actualTime: new Date().toISOString(),
                          })}
                          disabled={logMedicationMutation.isPending}
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Taken
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => logMedicationMutation.mutate({
                            medicationId: item.medication.id,
                            scheduledTime: item.scheduledTime,
                            status: 'missed',
                          })}
                          disabled={logMedicationMutation.isPending}
                        >
                          <XCircle className="h-4 w-4 mr-1" />
                          Missed
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500">No medications scheduled for today</p>
            )}
          </CardContent>
        </Card>

        {/* Active Medications */}
        <Card>
          <CardHeader>
            <CardTitle>Active Medications</CardTitle>
            <CardDescription>Current medication regimen</CardDescription>
          </CardHeader>
          <CardContent>
            {medications && medications.length > 0 ? (
              <div className="space-y-4">
                {medications.filter((med: Medication) => med.isActive).map((med: Medication) => (
                  <div key={med.id} className="p-4 border rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-medium">{med.name}</h4>
                      <Badge variant="outline">{med.frequency}</Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{med.dosage}</p>
                    
                    {med.timeSlots && med.timeSlots.length > 0 && (
                      <div className="flex flex-wrap gap-1 mb-2">
                        {med.timeSlots.map((time, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {time}
                          </Badge>
                        ))}
                      </div>
                    )}
                    
                    {med.instructions && (
                      <p className="text-xs text-gray-500">{med.instructions}</p>
                    )}
                    
                    {med.emergencyContact && (
                      <div className="mt-2 text-xs">
                        <span className="text-gray-500">Emergency Contact: </span>
                        <span className="font-medium">{med.emergencyContact}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500">No active medications</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Medication History */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Medication History</CardTitle>
          <CardDescription>Last 7 days of medication logs</CardDescription>
        </CardHeader>
        <CardContent>
          {medicationLogs && medicationLogs.length > 0 ? (
            <div className="space-y-3">
              {medicationLogs.slice(0, 10).map((log: MedicationLog) => {
                const medication = medications?.find((m: Medication) => m.id === log.medicationId);
                return (
                  <div key={log.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">{medication?.name || 'Unknown Medication'}</p>
                      <p className="text-sm text-gray-600">
                        Scheduled: {new Date(log.scheduledTime).toLocaleString()}
                      </p>
                      {log.actualTime && (
                        <p className="text-sm text-gray-600">
                          Taken: {new Date(log.actualTime).toLocaleString()}
                        </p>
                      )}
                      {log.notes && (
                        <p className="text-xs text-gray-500 mt-1">{log.notes}</p>
                      )}
                    </div>
                    <div className="text-right">
                      <Badge variant={getStatusColor(log.status)}>
                        {log.status}
                      </Badge>
                      {log.dispenserConfirmed && (
                        <p className="text-xs text-green-600 mt-1">Dispenser Confirmed</p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-gray-500">No medication logs available</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}