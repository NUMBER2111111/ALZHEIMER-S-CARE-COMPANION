import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Gamepad2, Trophy, Brain, Clock, Target } from 'lucide-react';

interface GameActivity {
  id: number;
  gameType: string;
  gameName: string;
  difficulty: string;
  gameState: any;
  playerMoves: any[];
  aiMoves: any[];
  status: string;
  startTime: string;
  cognitiveScore?: number;
  engagementLevel?: number;
}

interface AIGamingProps {
  patientId: number;
}

export function AIGaming({ patientId }: AIGamingProps) {
  const [selectedGame, setSelectedGame] = useState<string>('chess');
  const [difficulty, setDifficulty] = useState<string>('easy');

  // Robust data fetching with comprehensive error handling
  const { data: games = [], isLoading: gamesLoading, error: gamesError } = useQuery({
    queryKey: ['/api/patients', patientId, 'games'],
    retry: 3,
    retryDelay: 1000,
    staleTime: 30000,
  });

  const { data: activeGames = [], isLoading: activeLoading } = useQuery({
    queryKey: ['/api/patients', patientId, 'games', 'active'],
    retry: 2,
  });

  const { data: cognitiveStats, isLoading: statsLoading } = useQuery({
    queryKey: ['/api/patients', patientId, 'cognitive-stats'],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/patients/${patientId}/cognitive-stats`);
        if (!response.ok) {
          if (response.status === 404) {
            return null;
          }
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        return response.json();
      } catch (error) {
        console.error('Failed to fetch cognitive stats:', error);
        return null;
      }
    },
    retry: 2,
  });

  // Start new game with comprehensive error handling
  const startGameMutation = useMutation({
    mutationFn: async ({ gameType, difficulty }: { gameType: string; difficulty: string }) => {
      try {
        // Validate inputs
        if (!gameType || !difficulty) {
          throw new Error('Game type and difficulty are required');
        }

        const validGameTypes = ['chess', 'memory', 'word-association', 'pattern-matching'];
        const validDifficulties = ['easy', 'medium', 'hard'];

        if (!validGameTypes.includes(gameType)) {
          throw new Error(`Invalid game type: ${gameType}`);
        }

        if (!validDifficulties.includes(difficulty)) {
          throw new Error(`Invalid difficulty: ${difficulty}`);
        }

        return await apiRequest('POST', `/api/patients/${patientId}/games`, {
          gameType,
          difficulty,
          gameName: `${gameType.charAt(0).toUpperCase() + gameType.slice(1)} Game`,
        });
      } catch (error) {
        console.error('Failed to start game:', error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'games'] });
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'games', 'active'] });
    },
    onError: (error) => {
      console.error('Start game failed:', error);
    },
  });

  // Make move with validation
  const makeMoveAIGame = useMutation({
    mutationFn: async ({ gameId, move }: { gameId: number; move: any }) => {
      try {
        if (!gameId || !move) {
          throw new Error('Game ID and move are required');
        }

        return await apiRequest('POST', `/api/games/${gameId}/move`, {
          move,
          timestamp: new Date().toISOString(),
        });
      } catch (error) {
        console.error('Failed to make move:', error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'games'] });
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'games', 'active'] });
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'cognitive-stats'] });
    },
  });

  // End game with score calculation
  const endGameMutation = useMutation({
    mutationFn: async (gameId: number) => {
      try {
        if (!gameId) {
          throw new Error('Game ID is required');
        }

        return await apiRequest('POST', `/api/games/${gameId}/end`);
      } catch (error) {
        console.error('Failed to end game:', error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'games'] });
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'games', 'active'] });
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'cognitive-stats'] });
    },
  });

  // Calculate cognitive benefit with error handling
  const calculateCognitiveBenefit = (game: any): number => {
    if (!game || typeof game !== 'object') return 0;

    try {
      const { gameType, difficulty, playerMoves = [], status } = game;
      
      let baseScore = 0;
      
      // Base scores by game type
      switch (gameType) {
        case 'chess':
          baseScore = 80;
          break;
        case 'memory':
          baseScore = 70;
          break;
        case 'word-association':
          baseScore = 60;
          break;
        case 'pattern-matching':
          baseScore = 65;
          break;
        default:
          baseScore = 50;
      }

      // Difficulty multiplier
      const difficultyMultiplier = {
        easy: 1.0,
        medium: 1.3,
        hard: 1.6,
      }[difficulty] || 1.0;

      // Engagement bonus based on number of moves
      const engagementBonus = Math.min(Array.isArray(playerMoves) ? playerMoves.length : 0, 20) * 2;

      // Completion bonus
      const completionBonus = status === 'completed' ? 20 : 0;

      return Math.round((baseScore * difficultyMultiplier) + engagementBonus + completionBonus);
    } catch (error) {
      console.error('Error calculating cognitive benefit:', error);
      return 0;
    }
  };

  // Render game types selection
  const renderGameSelection = () => {
    const gameTypes = [
      { id: 'chess', name: 'Chess', description: 'Strategic thinking and planning', icon: '♟️' },
      { id: 'memory', name: 'Memory Cards', description: 'Memory recall and pattern recognition', icon: '🧠' },
      { id: 'word-association', name: 'Word Association', description: 'Language and cognitive flexibility', icon: '💭' },
      { id: 'pattern-matching', name: 'Pattern Matching', description: 'Visual processing and attention', icon: '🔍' },
    ];

    return (
      <div className="grid grid-cols-2 gap-3">
        {gameTypes.map((gameType) => (
          <Button
            key={gameType.id}
            variant={selectedGame === gameType.id ? 'default' : 'outline'}
            className="h-auto p-3 text-left"
            onClick={() => setSelectedGame(gameType.id)}
          >
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-lg">{gameType.icon}</span>
                <span className="font-medium text-sm">{gameType.name}</span>
              </div>
              <p className="text-xs text-gray-500">{gameType.description}</p>
            </div>
          </Button>
        ))}
      </div>
    );
  };

  // Render active games with error handling
  const renderActiveGames = () => {
    if (activeLoading) {
      return <div className="text-sm text-gray-500">Loading active games...</div>;
    }

    if (!Array.isArray(activeGames) || activeGames.length === 0) {
      return <div className="text-sm text-gray-500">No active games</div>;
    }

    return activeGames.map((game: any, index: number) => {
      if (!game || typeof game !== 'object') {
        return <div key={index} className="text-sm text-gray-400">Invalid game data</div>;
      }

      const cognitiveBenefit = calculateCognitiveBenefit(game);

      return (
        <Card key={game.id || index} className="border-l-4 border-l-green-500">
          <CardHeader className="pb-3">
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-base">{game.gameName || 'Unknown Game'}</CardTitle>
                <p className="text-sm text-gray-500 mt-1">
                  {game.gameType || 'Unknown'} - {game.difficulty || 'Unknown'} difficulty
                </p>
              </div>
              <Badge variant={game.status === 'active' ? 'default' : 'secondary'}>
                {game.status || 'unknown'}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm">Cognitive Benefit</span>
              <div className="flex items-center gap-2">
                <Progress value={Math.min(cognitiveBenefit, 100)} className="w-20" />
                <span className="text-sm font-medium">{cognitiveBenefit}</span>
              </div>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-sm">Moves Made</span>
              <span className="text-sm font-medium">
                {Array.isArray(game.playerMoves) ? game.playerMoves.length : 0}
              </span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-sm">Started</span>
              <span className="text-sm font-medium">
                {game.startTime ? new Date(game.startTime).toLocaleTimeString() : 'Unknown'}
              </span>
            </div>
            
            <div className="flex gap-2 pt-2">
              <Button
                size="sm"
                onClick={() => makeMoveAIGame.mutate({ 
                  gameId: game.id, 
                  move: { type: 'auto', action: 'continue' } 
                })}
                disabled={makeMoveAIGame.isPending}
                className="flex-1"
              >
                <Target className="h-4 w-4 mr-1" />
                {makeMoveAIGame.isPending ? 'Processing...' : 'Continue'}
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => endGameMutation.mutate(game.id)}
                disabled={endGameMutation.isPending}
              >
                <Trophy className="h-4 w-4 mr-1" />
                Finish
              </Button>
            </div>
          </CardContent>
        </Card>
      );
    });
  };

  // Render recent games with error handling
  const renderRecentGames = () => {
    if (gamesLoading) {
      return <div className="text-sm text-gray-500">Loading games...</div>;
    }

    if (gamesError) {
      return <div className="text-sm text-red-500">Error loading games</div>;
    }

    if (!Array.isArray(games) || games.length === 0) {
      return <div className="text-sm text-gray-500">No games played yet</div>;
    }

    return games.slice(0, 5).map((game: any, index: number) => {
      if (!game || typeof game !== 'object') {
        return <div key={index} className="text-sm text-gray-400">Invalid game data</div>;
      }

      const cognitiveBenefit = calculateCognitiveBenefit(game);

      return (
        <div key={game.id || index} className="flex justify-between items-center p-3 border border-gray-200 rounded-lg">
          <div className="flex-1">
            <div className="font-medium text-sm">{game.gameName || 'Unknown Game'}</div>
            <div className="text-xs text-gray-500 mt-1">
              {game.gameType || 'Unknown'} - {game.difficulty || 'Unknown'} difficulty
            </div>
            <div className="text-xs text-gray-400 mt-1">
              {game.startTime ? new Date(game.startTime).toLocaleString() : 'Unknown time'}
            </div>
          </div>
          <div className="text-right">
            <Badge variant={game.status === 'completed' ? 'default' : 'secondary'}>
              {game.status || 'unknown'}
            </Badge>
            <div className="text-xs text-gray-500 mt-1">
              Score: {cognitiveBenefit}
            </div>
          </div>
        </div>
      );
    });
  };

  // Render cognitive statistics
  const renderCognitiveStats = () => {
    if (statsLoading) {
      return <div className="text-sm text-gray-500">Loading statistics...</div>;
    }

    if (!cognitiveStats || typeof cognitiveStats !== 'object') {
      return <div className="text-sm text-gray-500">No statistics available</div>;
    }

    return (
      <div className="grid grid-cols-2 gap-4">
        <div className="text-center">
          <div className="text-2xl font-bold text-blue-600">
            {cognitiveStats.totalGames || 0}
          </div>
          <div className="text-xs text-gray-500">Games Played</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-green-600">
            {Math.round(cognitiveStats.averageScore || 0)}
          </div>
          <div className="text-xs text-gray-500">Avg Score</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-purple-600">
            {Math.round(cognitiveStats.engagementLevel || 0)}%
          </div>
          <div className="text-xs text-gray-500">Engagement</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-orange-600">
            {cognitiveStats.improvementRate || 0}%
          </div>
          <div className="text-xs text-gray-500">Improvement</div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Game Selection */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Gamepad2 className="h-5 w-5" />
            Start New Game
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {renderGameSelection()}
          
          <div>
            <label className="text-sm font-medium mb-2 block">Difficulty Level</label>
            <div className="flex gap-2">
              {['easy', 'medium', 'hard'].map((level) => (
                <Button
                  key={level}
                  size="sm"
                  variant={difficulty === level ? 'default' : 'outline'}
                  onClick={() => setDifficulty(level)}
                >
                  {level.charAt(0).toUpperCase() + level.slice(1)}
                </Button>
              ))}
            </div>
          </div>
          
          <Button
            className="w-full"
            onClick={() => startGameMutation.mutate({ gameType: selectedGame, difficulty })}
            disabled={startGameMutation.isPending}
          >
            {startGameMutation.isPending ? 'Starting Game...' : `Start ${selectedGame} Game`}
          </Button>
        </CardContent>
      </Card>

      {/* Active Games */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Clock className="h-5 w-5 text-green-500" />
            Active Games
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {renderActiveGames()}
        </CardContent>
      </Card>

      {/* Cognitive Statistics */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Brain className="h-5 w-5" />
            Cognitive Performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          {renderCognitiveStats()}
        </CardContent>
      </Card>

      {/* Recent Games */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Trophy className="h-5 w-5" />
            Recent Games
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {renderRecentGames()}
        </CardContent>
      </Card>
    </div>
  );
}