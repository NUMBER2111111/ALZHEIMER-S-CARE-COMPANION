import { useState, useEffect } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Shield, Lock, Unlock, AlertTriangle, MessageSquare, Key, Users } from 'lucide-react';

interface FamilyMember {
  id: number;
  name: string;
  relationship: string;
  responsibilityLevel: string;
  isPrimaryContact: boolean;
  canAccessMedical: boolean;
  isLockedOut: boolean;
  securityLevel: string;
}

interface SecureMessage {
  id: number;
  fromUserId: number;
  messageType: string;
  content: string;
  verified: boolean;
  isBlocked: boolean;
  sentAt: string;
}

interface FamilySecurityManagerProps {
  patientId: number;
  currentUserId: number;
  isPrimaryFamilyMember: boolean;
}

export function FamilySecurityManager({ 
  patientId, 
  currentUserId, 
  isPrimaryFamilyMember 
}: FamilySecurityManagerProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedMember, setSelectedMember] = useState<number | null>(null);
  const [lockoutReason, setLockoutReason] = useState('');
  const [lockoutType, setLockoutType] = useState<'medical_access' | 'communication' | 'full_lockout'>('medical_access');
  const [unlockCode, setUnlockCode] = useState('');
  const [secureMessage, setSecureMessage] = useState('');
  const [messageType, setMessageType] = useState<'medical_request' | 'admin_communication' | 'medication_change'>('medical_request');

  // Check if current user is primary family member
  const { data: isPrimary, isLoading: isPrimaryLoading } = useQuery({
    queryKey: ['/api/family-security/verify-primary', currentUserId, patientId],
    retry: 2,
  });

  // Check current user's lockout status
  const { data: lockoutStatus, isLoading: lockoutLoading } = useQuery({
    queryKey: ['/api/family-security/lockout-status', currentUserId, patientId],
    retry: 2,
  });

  // Get family members for the patient
  const { data: familyMembers = [], isLoading: membersLoading } = useQuery({
    queryKey: ['/api/patients', patientId, 'family-relationships'],
    retry: 2,
  });

  // Get secure messages
  const { data: secureMessages = [], isLoading: messagesLoading } = useQuery({
    queryKey: ['/api/secure-messaging', currentUserId],
    retry: 2,
  });

  // Lock out family member mutation
  const lockoutMutation = useMutation({
    mutationFn: async (data: {
      primaryFamilyId: number;
      lockedOutFamilyId: number;
      patientId: number;
      lockoutType: string;
      reason: string;
    }) => {
      const response = await apiRequest('POST', '/api/family-security/lockout', data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Family Member Locked Out",
        description: `Emergency unlock code: ${data.unlockCode}`,
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'family-relationships'] });
      setSelectedMember(null);
      setLockoutReason('');
    },
    onError: (error) => {
      toast({
        title: "Lockout Failed",
        description: error.message || "Failed to lock out family member",
        variant: "destructive",
      });
    },
  });

  // Send secure message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (data: {
      fromUserId: number;
      toUserId?: number;
      toFacilityId?: number;
      messageType: string;
      content: string;
    }) => {
      const response = await apiRequest('POST', '/api/secure-messaging/send', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Secure Message Sent",
        description: "Your encrypted message has been sent successfully",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/secure-messaging', currentUserId] });
      setSecureMessage('');
    },
    onError: (error) => {
      if (error.message.includes('locked out')) {
        toast({
          title: "Access Denied",
          description: "You are locked out from sending medical/admin communications",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Message Failed",
          description: "Failed to send secure message",
          variant: "destructive",
        });
      }
    },
  });

  // Administrative unlock mutation
  const unlockMutation = useMutation({
    mutationFn: async (data: { unlockCode: string; adminUserId: number }) => {
      const response = await apiRequest('POST', '/api/family-security/admin-unlock', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Access Restored",
        description: "Family member access has been restored by administrator",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/family-security/lockout-status'] });
      setUnlockCode('');
    },
    onError: () => {
      toast({
        title: "Unlock Failed",
        description: "Invalid unlock code or expired lockout",
        variant: "destructive",
      });
    },
  });

  const handleLockoutMember = () => {
    if (!selectedMember || !lockoutReason.trim()) {
      toast({
        title: "Missing Information",
        description: "Please select a member and provide a reason",
        variant: "destructive",
      });
      return;
    }

    lockoutMutation.mutate({
      primaryFamilyId: currentUserId,
      lockedOutFamilyId: selectedMember,
      patientId,
      lockoutType,
      reason: lockoutReason,
    });
  };

  const handleSendSecureMessage = () => {
    if (!secureMessage.trim()) {
      toast({
        title: "Empty Message",
        description: "Please enter a message to send",
        variant: "destructive",
      });
      return;
    }

    sendMessageMutation.mutate({
      fromUserId: currentUserId,
      toFacilityId: 1, // Facility ID
      messageType,
      content: secureMessage,
    });
  };

  const handleAdminUnlock = () => {
    if (!unlockCode.trim()) {
      toast({
        title: "Missing Code",
        description: "Please enter the unlock code",
        variant: "destructive",
      });
      return;
    }

    unlockMutation.mutate({
      unlockCode,
      adminUserId: currentUserId,
    });
  };

  if (lockoutLoading || isPrimaryLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <Shield className="h-8 w-8 mx-auto mb-4 text-gray-400" />
          <p className="text-gray-600">Loading security settings...</p>
        </div>
      </div>
    );
  }

  // Show lockout warning if user is locked out
  if (lockoutStatus?.isLockedOut) {
    return (
      <div className="p-6">
        <Alert className="border-red-200 bg-red-50">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription className="text-red-700">
            <strong>Access Restricted:</strong> You have been locked out from medical and admin communications by the primary family member. 
            Contact your care facility administrator for assistance.
          </AlertDescription>
        </Alert>
        
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Unlock className="h-5 w-5" />
              Administrative Unlock
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-gray-600">
              If you have an emergency unlock code from an administrator, enter it below:
            </p>
            <Input
              placeholder="Enter unlock code"
              value={unlockCode}
              onChange={(e) => setUnlockCode(e.target.value)}
            />
            <Button 
              onClick={handleAdminUnlock}
              disabled={unlockMutation.isPending}
              className="w-full"
            >
              {unlockMutation.isPending ? 'Unlocking...' : 'Restore Access'}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Security Status Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Family Security Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Security Level</p>
              <Badge variant={isPrimary?.isPrimary ? "default" : "secondary"}>
                {isPrimary?.isPrimary ? "Primary Family Member" : "Secondary Member"}
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              <Key className="h-4 w-4 text-green-600" />
              <span className="text-sm text-green-600">Encrypted Communications Active</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Primary Family Member Controls */}
      {isPrimary?.isPrimary && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5" />
              Family Member Security Controls
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Family Member</label>
                <Select value={selectedMember?.toString() || ""} onValueChange={(value) => setSelectedMember(parseInt(value))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select family member" />
                  </SelectTrigger>
                  <SelectContent>
                    {familyMembers.map((member: FamilyMember) => (
                      <SelectItem key={member.id} value={member.id.toString()}>
                        {member.name} ({member.relationship})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="text-sm font-medium">Lockout Type</label>
                <Select value={lockoutType} onValueChange={(value: any) => setLockoutType(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="medical_access">Medical Access Only</SelectItem>
                    <SelectItem value="communication">Admin Communications</SelectItem>
                    <SelectItem value="full_lockout">Complete Lockout</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <label className="text-sm font-medium">Reason for Lockout</label>
              <Textarea
                placeholder="Provide a detailed reason for the security lockout..."
                value={lockoutReason}
                onChange={(e) => setLockoutReason(e.target.value)}
                rows={3}
              />
            </div>

            <Button
              onClick={handleLockoutMember}
              disabled={lockoutMutation.isPending}
              className="w-full"
              variant="destructive"
            >
              {lockoutMutation.isPending ? 'Processing...' : 'Lock Out Family Member'}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Secure Messaging */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            Encrypted Communications
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium">Message Type</label>
            <Select value={messageType} onValueChange={(value: any) => setMessageType(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="medical_request">Medical Request</SelectItem>
                <SelectItem value="admin_communication">Admin Communication</SelectItem>
                <SelectItem value="medication_change">Medication Change</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium">Secure Message</label>
            <Textarea
              placeholder="Enter your secure, encrypted message..."
              value={secureMessage}
              onChange={(e) => setSecureMessage(e.target.value)}
              rows={4}
            />
          </div>

          <Button
            onClick={handleSendSecureMessage}
            disabled={sendMessageMutation.isPending}
            className="w-full"
          >
            {sendMessageMutation.isPending ? 'Sending...' : 'Send Encrypted Message'}
          </Button>
        </CardContent>
      </Card>

      {/* Message History */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Secure Message History
          </CardTitle>
        </CardHeader>
        <CardContent>
          {messagesLoading ? (
            <p className="text-gray-500">Loading messages...</p>
          ) : secureMessages.length === 0 ? (
            <p className="text-gray-500">No secure messages found</p>
          ) : (
            <div className="space-y-3">
              {secureMessages.map((message: SecureMessage) => (
                <div
                  key={message.id}
                  className={`p-3 rounded-lg border ${
                    message.isBlocked 
                      ? 'border-red-200 bg-red-50' 
                      : message.verified 
                        ? 'border-green-200 bg-green-50' 
                        : 'border-yellow-200 bg-yellow-50'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant={
                      message.messageType === 'medication_change' ? 'destructive' :
                      message.messageType === 'medical_request' ? 'default' : 'secondary'
                    }>
                      {message.messageType.replace('_', ' ')}
                    </Badge>
                    <span className="text-xs text-gray-500">
                      {new Date(message.sentAt).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-sm">
                    {message.isBlocked ? '[BLOCKED MESSAGE]' : message.content}
                  </p>
                  <div className="flex items-center gap-2 mt-2">
                    {message.verified ? (
                      <Badge variant="outline" className="text-green-600">Encrypted ✓</Badge>
                    ) : (
                      <Badge variant="outline" className="text-yellow-600">Decryption Failed</Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}