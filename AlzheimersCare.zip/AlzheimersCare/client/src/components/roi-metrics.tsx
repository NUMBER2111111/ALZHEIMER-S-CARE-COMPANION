import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  TrendingUp, 
  DollarSign, 
  Users, 
  Brain, 
  Shield, 
  Clock,
  ChartLine,
  Trophy,
  Heart,
  Zap
} from "lucide-react";

interface ROIMetricsProps {
  analytics: any;
}

export function ROIMetrics({ analytics }: ROIMetricsProps) {
  const benefitsAnalysis = analytics?.benefitsAnalysis || {};
  const roiMetrics = benefitsAnalysis.roiMetrics || {};

  // Mock ROI data based on typical care facility metrics
  const mockMetrics = {
    careQualityScore: 85,
    annualSavings: "3.2M",
    staffEfficiencyGain: 18,
    familySatisfaction: 94,
    cognitiveImprovement: 23,
    reimbursementIncrease: 12,
    operationalSavings: "890K",
    complianceScore: 98,
    ...roiMetrics
  };

  const keyMetrics = [
    {
      title: "Annual ROI",
      value: `$${mockMetrics.annualSavings}`,
      change: "+12% vs last year",
      icon: DollarSign,
      color: "text-green-600",
      bgColor: "bg-green-50",
      description: "Total financial benefits including insurance reimbursements and operational savings"
    },
    {
      title: "Care Quality Score",
      value: `${mockMetrics.careQualityScore}%`,
      change: "+23% improvement",
      icon: Brain,
      color: "text-care-secondary",
      bgColor: "bg-green-50",
      description: "Measurable improvements in cognitive training outcomes and patient engagement"
    },
    {
      title: "Staff Efficiency",
      value: `${mockMetrics.staffEfficiencyGain}%`,
      change: "Time savings per patient",
      icon: Clock,
      color: "text-care-primary",
      bgColor: "bg-blue-50",
      description: "Automated activity planning and progress tracking reduces manual work"
    },
    {
      title: "Family Satisfaction",
      value: `${mockMetrics.familySatisfaction}%`,
      change: "94% would recommend",
      icon: Heart,
      color: "text-red-500",
      bgColor: "bg-red-50",
      description: "Family feedback scores on care quality and communication"
    }
  ];

  const detailedMetrics = [
    {
      category: "Financial Impact",
      metrics: [
        { name: "Insurance Reimbursements", value: "$2.31M", trend: "+15%" },
        { name: "Operational Cost Savings", value: "$890K", trend: "+8%" },
        { name: "Staff Productivity Gains", value: "$450K", trend: "+18%" },
        { name: "Compliance Cost Reduction", value: "$120K", trend: "+25%" }
      ]
    },
    {
      category: "Clinical Outcomes",
      metrics: [
        { name: "Cognitive Test Improvements", value: "23%", trend: "+5%" },
        { name: "Activity Participation Rate", value: "87%", trend: "+12%" },
        { name: "Family Engagement Score", value: "92%", trend: "+18%" },
        { name: "Medication Adherence", value: "94%", trend: "+7%" }
      ]
    },
    {
      category: "Operational Efficiency",
      metrics: [
        { name: "Documentation Time Reduction", value: "45%", trend: "+15%" },
        { name: "Care Plan Updates", value: "Real-time", trend: "New" },
        { name: "Staff Training Hours", value: "-30%", trend: "+20%" },
        { name: "Compliance Reporting", value: "Automated", trend: "New" }
      ]
    }
  ];

  return (
    <div className="space-y-6">
      {/* Key Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {keyMetrics.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 ${metric.bgColor} rounded-xl flex items-center justify-center`}>
                    <Icon className={`h-6 w-6 ${metric.color}`} />
                  </div>
                  <Badge className="bg-green-100 text-green-800 text-xs">
                    {metric.change}
                  </Badge>
                </div>
                <div className="space-y-2">
                  <p className="text-sm font-medium text-gray-600">{metric.title}</p>
                  <p className={`text-3xl font-bold ${metric.color}`}>{metric.value}</p>
                  <p className="text-xs text-gray-500 leading-relaxed">{metric.description}</p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Detailed ROI Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {detailedMetrics.map((category, categoryIndex) => (
          <Card key={categoryIndex}>
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-gray-900 flex items-center">
                {categoryIndex === 0 && <DollarSign className="mr-2 h-5 w-5 text-green-600" />}
                {categoryIndex === 1 && <Brain className="mr-2 h-5 w-5 text-care-secondary" />}
                {categoryIndex === 2 && <Zap className="mr-2 h-5 w-5 text-care-primary" />}
                {category.category}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {category.metrics.map((metric, metricIndex) => (
                  <div key={metricIndex} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900 text-sm">{metric.name}</p>
                      <p className="text-lg font-bold text-gray-800">{metric.value}</p>
                    </div>
                    <Badge 
                      className={`text-xs ${
                        metric.trend.includes('+') 
                          ? 'bg-green-100 text-green-800' 
                          : metric.trend === 'New'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-yellow-100 text-yellow-800'
                      }`}
                    >
                      {metric.trend}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* ROI Projections */}
      <Card className="bg-gradient-to-br from-green-50 to-blue-50 border-2 border-care-secondary/20">
        <CardHeader>
          <CardTitle className="text-xl font-bold text-gray-900 flex items-center">
            <TrendingUp className="mr-2 h-6 w-6 text-care-secondary" />
            5-Year ROI Projection
          </CardTitle>
          <p className="text-gray-600">
            Projected cumulative benefits of Care Companion AI implementation
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-gray-700">Year 1 ROI</span>
                <span className="text-lg font-bold text-care-secondary">285%</span>
              </div>
              <Progress value={85} className="h-2" />
              
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-gray-700">Year 3 ROI</span>
                <span className="text-lg font-bold text-care-secondary">450%</span>
              </div>
              <Progress value={95} className="h-2" />
              
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-gray-700">Year 5 ROI</span>
                <span className="text-lg font-bold text-care-secondary">720%</span>
              </div>
              <Progress value={100} className="h-2" />
            </div>

            <div className="space-y-4">
              <div className="bg-white rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 mb-2">Cumulative Benefits</h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-care-secondary rounded-full mr-2"></div>
                    $16.8M in total insurance reimbursements
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-care-primary rounded-full mr-2"></div>
                    $4.2M in operational cost savings
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-accent rounded-full mr-2"></div>
                    40% reduction in staff turnover costs
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    95% family satisfaction maintained
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Comparison with Industry */}
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold text-gray-900 flex items-center">
            <Trophy className="mr-2 h-6 w-6 text-yellow-500" />
            Industry Benchmark Comparison
          </CardTitle>
          <p className="text-gray-600">
            How your facility performs compared to industry averages
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="font-semibold text-gray-900">Care Quality Metrics</h4>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-600">Patient Satisfaction</span>
                    <span className="text-sm font-bold text-care-secondary">94% (Industry: 78%)</span>
                  </div>
                  <Progress value={94} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-600">Family Engagement</span>
                    <span className="text-sm font-bold text-care-secondary">92% (Industry: 65%)</span>
                  </div>
                  <Progress value={92} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-600">Cognitive Improvement</span>
                    <span className="text-sm font-bold text-care-secondary">85% (Industry: 58%)</span>
                  </div>
                  <Progress value={85} className="h-2" />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-semibold text-gray-900">Operational Efficiency</h4>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-600">Documentation Speed</span>
                    <span className="text-sm font-bold text-care-primary">+45% faster</span>
                  </div>
                  <Progress value={90} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-600">Staff Productivity</span>
                    <span className="text-sm font-bold text-care-primary">+18% improvement</span>
                  </div>
                  <Progress value={88} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-600">Compliance Score</span>
                    <span className="text-sm font-bold text-care-primary">98% (Industry: 82%)</span>
                  </div>
                  <Progress value={98} className="h-2" />
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
