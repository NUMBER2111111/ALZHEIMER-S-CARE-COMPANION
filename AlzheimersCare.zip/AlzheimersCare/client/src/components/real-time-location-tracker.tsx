import { useState, useEffect, useRef, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { 
  MapPin, 
  AlertTriangle, 
  Shield, 
  Navigation, 
  Settings,
  Clock,
  Target,
  Radio,
  Smartphone,
  Home,
  Car,
  Phone
} from 'lucide-react';

interface Location {
  lat: number;
  lng: number;
  timestamp: Date;
  accuracy?: number;
  source: 'gps' | 'network' | 'passive';
}

interface GeofenceSettings {
  enabled: boolean;
  radius: number; // in meters
  centerLat: number;
  centerLng: number;
  alertContacts: string[];
  emergencyContacts: string[];
}

interface LocationTrackerProps {
  patientId: number;
  patientName: string;
  familyMemberId: number;
}

declare global {
  interface Window {
    google: any;
    initMap: () => void;
  }
}

export function RealTimeLocationTracker({ 
  patientId, 
  patientName,
  familyMemberId 
}: LocationTrackerProps) {
  const [currentLocation, setCurrentLocation] = useState<Location | null>(null);
  const [locationHistory, setLocationHistory] = useState<Location[]>([]);
  const [geofenceSettings, setGeofenceSettings] = useState<GeofenceSettings>({
    enabled: true,
    radius: 100, // 100 meters default
    centerLat: 40.7128,
    centerLng: -74.0060,
    alertContacts: [],
    emergencyContacts: []
  });
  const [isTracking, setIsTracking] = useState(false);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [geofenceViolation, setGeofenceViolation] = useState(false);
  const [settingsMode, setSettingsMode] = useState(false);
  
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const markerRef = useRef<any>(null);
  const geofenceCircleRef = useRef<any>(null);
  const watchIdRef = useRef<number | null>(null);
  
  const { toast } = useToast();

  // Load Google Maps API
  useEffect(() => {
    if (!window.google) {
      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=${import.meta.env.VITE_GOOGLE_MAPS_API_KEY}&libraries=geometry`;
      script.async = true;
      script.defer = true;
      script.onload = () => {
        setMapLoaded(true);
        initializeMap();
      };
      document.head.appendChild(script);
    } else {
      setMapLoaded(true);
      initializeMap();
    }
  }, []);

  // Initialize Google Map
  const initializeMap = useCallback(() => {
    if (!mapRef.current || !window.google) return;

    const map = new window.google.maps.Map(mapRef.current, {
      zoom: 16,
      center: { lat: geofenceSettings.centerLat, lng: geofenceSettings.centerLng },
      mapTypeId: 'roadmap',
      styles: [
        {
          featureType: 'poi',
          elementType: 'labels',
          stylers: [{ visibility: 'off' }]
        }
      ]
    });

    mapInstanceRef.current = map;

    // Add patient location marker
    markerRef.current = new window.google.maps.Marker({
      position: { lat: geofenceSettings.centerLat, lng: geofenceSettings.centerLng },
      map: map,
      title: `${patientName}'s Location`,
      icon: {
        url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
          <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="16" cy="16" r="15" fill="#3B82F6" stroke="white" stroke-width="2"/>
            <circle cx="16" cy="16" r="6" fill="white"/>
          </svg>
        `),
        scaledSize: new window.google.maps.Size(32, 32),
        anchor: new window.google.maps.Point(16, 16)
      }
    });

    // Add geofence circle
    updateGeofenceCircle();

    // Add click listener to adjust geofence center
    map.addListener('click', (e: any) => {
      if (settingsMode) {
        setGeofenceSettings(prev => ({
          ...prev,
          centerLat: e.latLng.lat(),
          centerLng: e.latLng.lng()
        }));
      }
    });
  }, [geofenceSettings.centerLat, geofenceSettings.centerLng, patientName, settingsMode]);

  // Update geofence circle on map
  const updateGeofenceCircle = useCallback(() => {
    if (!mapInstanceRef.current || !window.google) return;

    // Remove existing circle
    if (geofenceCircleRef.current) {
      geofenceCircleRef.current.setMap(null);
    }

    // Add new circle
    geofenceCircleRef.current = new window.google.maps.Circle({
      strokeColor: geofenceViolation ? '#EF4444' : '#10B981',
      strokeOpacity: 0.8,
      strokeWeight: 2,
      fillColor: geofenceViolation ? '#EF4444' : '#10B981',
      fillOpacity: 0.2,
      map: mapInstanceRef.current,
      center: { lat: geofenceSettings.centerLat, lng: geofenceSettings.centerLng },
      radius: geofenceSettings.radius,
      editable: settingsMode,
      draggable: settingsMode
    });

    // Add listeners for editing
    if (settingsMode) {
      geofenceCircleRef.current.addListener('radius_changed', () => {
        setGeofenceSettings(prev => ({
          ...prev,
          radius: geofenceCircleRef.current.getRadius()
        }));
      });

      geofenceCircleRef.current.addListener('center_changed', () => {
        const center = geofenceCircleRef.current.getCenter();
        setGeofenceSettings(prev => ({
          ...prev,
          centerLat: center.lat(),
          centerLng: center.lng()
        }));
      });
    }
  }, [geofenceSettings, geofenceViolation, settingsMode]);

  // Check geofence violation
  const checkGeofenceViolation = useCallback((location: Location) => {
    if (!geofenceSettings.enabled || !window.google) return false;

    const center = new window.google.maps.LatLng(
      geofenceSettings.centerLat, 
      geofenceSettings.centerLng
    );
    const point = new window.google.maps.LatLng(location.lat, location.lng);
    const distance = window.google.maps.geometry.spherical.computeDistanceBetween(center, point);

    const isViolation = distance > geofenceSettings.radius;
    
    if (isViolation !== geofenceViolation) {
      setGeofenceViolation(isViolation);
      
      if (isViolation) {
        handleGeofenceViolation(location, distance);
      }
    }
    
    return isViolation;
  }, [geofenceSettings, geofenceViolation]);

  // Handle geofence violation
  const handleGeofenceViolation = async (location: Location, distance: number) => {
    const violationData = {
      patientId,
      location,
      geofenceCenter: {
        lat: geofenceSettings.centerLat,
        lng: geofenceSettings.centerLng
      },
      radius: geofenceSettings.radius,
      distance: Math.round(distance),
      timestamp: new Date(),
      familyMemberId
    };

    try {
      await apiRequest('POST', '/api/geofence/violation', violationData);
      
      toast({
        title: "⚠️ Geofence Alert",
        description: `${patientName} has left the safe area (${Math.round(distance - geofenceSettings.radius)}m outside boundary)`,
        variant: "destructive",
      });

      // Send emergency notifications if configured
      if (geofenceSettings.emergencyContacts.length > 0) {
        await apiRequest('POST', '/api/emergency/notify', {
          patientId,
          type: 'geofence_violation',
          contacts: geofenceSettings.emergencyContacts,
          location,
          distance: Math.round(distance)
        });
      }
    } catch (error) {
      console.error('Failed to report geofence violation:', error);
    }
  };

  // Start location tracking
  const startTracking = () => {
    if (!navigator.geolocation) {
      toast({
        title: "Location Not Supported",
        description: "Your device doesn't support location tracking",
        variant: "destructive",
      });
      return;
    }

    const options = {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 0
    };

    watchIdRef.current = navigator.geolocation.watchPosition(
      (position) => {
        const newLocation: Location = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          timestamp: new Date(),
          accuracy: position.coords.accuracy,
          source: 'gps'
        };

        setCurrentLocation(newLocation);
        setLocationHistory(prev => [...prev.slice(-99), newLocation]); // Keep last 100 locations

        // Update marker position
        if (markerRef.current) {
          markerRef.current.setPosition({ lat: newLocation.lat, lng: newLocation.lng });
        }

        // Center map on new location
        if (mapInstanceRef.current) {
          mapInstanceRef.current.panTo({ lat: newLocation.lat, lng: newLocation.lng });
        }

        // Check geofence
        checkGeofenceViolation(newLocation);

        // Send location to server
        saveLocationToServer(newLocation);
      },
      (error) => {
        console.error('Location error:', error);
        toast({
          title: "Location Error",
          description: "Unable to get current location",
          variant: "destructive",
        });
      },
      options
    );

    setIsTracking(true);
  };

  // Stop location tracking
  const stopTracking = () => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    setIsTracking(false);
  };

  // Save location to server
  const saveLocationToServer = async (location: Location) => {
    try {
      await apiRequest('POST', '/api/patients/location', {
        patientId,
        location,
        familyMemberId
      });
    } catch (error) {
      console.error('Failed to save location:', error);
    }
  };

  // Save geofence settings
  const saveGeofenceSettings = async () => {
    try {
      await apiRequest('PUT', `/api/patients/${patientId}/geofence`, {
        ...geofenceSettings,
        familyMemberId
      });
      
      toast({
        title: "Settings Saved",
        description: "Geofence settings have been updated successfully",
      });
      
      setSettingsMode(false);
      updateGeofenceCircle();
    } catch (error) {
      console.error('Failed to save geofence settings:', error);
      toast({
        title: "Save Failed",
        description: "Unable to save geofence settings",
        variant: "destructive",
      });
    }
  };

  // Update geofence circle when settings change
  useEffect(() => {
    updateGeofenceCircle();
  }, [geofenceSettings, updateGeofenceCircle]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopTracking();
    };
  }, []);

  if (!import.meta.env.VITE_GOOGLE_MAPS_API_KEY) {
    return (
      <Card className="w-full">
        <CardContent className="p-6">
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Google Maps API key is required for location tracking. Please contact support to enable this feature.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="w-full space-y-4">
      {/* Status Panel */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Navigation className="h-5 w-5" />
              Real-Time Location Tracking
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge variant={isTracking ? "default" : "secondary"} className="flex items-center gap-1">
                <Radio className="h-3 w-3" />
                {isTracking ? "Active" : "Inactive"}
              </Badge>
              {geofenceViolation && (
                <Badge variant="destructive" className="flex items-center gap-1 animate-pulse">
                  <AlertTriangle className="h-3 w-3" />
                  Outside Safe Area
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {/* Current Location Info */}
          {currentLocation && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-blue-600" />
                <div>
                  <p className="text-sm font-medium">Current Location</p>
                  <p className="text-xs text-gray-600">
                    {currentLocation.lat.toFixed(6)}, {currentLocation.lng.toFixed(6)}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-green-600" />
                <div>
                  <p className="text-sm font-medium">Last Update</p>
                  <p className="text-xs text-gray-600">
                    {currentLocation.timestamp.toLocaleTimeString()}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Target className="h-4 w-4 text-purple-600" />
                <div>
                  <p className="text-sm font-medium">Accuracy</p>
                  <p className="text-xs text-gray-600">
                    ±{currentLocation.accuracy?.toFixed(0) || 'Unknown'}m
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Control Buttons */}
          <div className="flex flex-wrap gap-2">
            <Button
              onClick={isTracking ? stopTracking : startTracking}
              variant={isTracking ? "destructive" : "default"}
              className="flex items-center gap-2"
            >
              {isTracking ? (
                <>
                  <Radio className="h-4 w-4" />
                  Stop Tracking
                </>
              ) : (
                <>
                  <Smartphone className="h-4 w-4" />
                  Start Tracking
                </>
              )}
            </Button>
            
            <Button
              onClick={() => setSettingsMode(!settingsMode)}
              variant="outline"
              className="flex items-center gap-2"
            >
              <Settings className="h-4 w-4" />
              {settingsMode ? "Exit Settings" : "Geofence Settings"}
            </Button>
            
            {currentLocation && (
              <Button
                onClick={() => {
                  if (mapInstanceRef.current) {
                    mapInstanceRef.current.panTo({
                      lat: currentLocation.lat,
                      lng: currentLocation.lng
                    });
                  }
                }}
                variant="outline"
                className="flex items-center gap-2"
              >
                <Home className="h-4 w-4" />
                Center on Patient
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Geofence Settings Panel */}
      {settingsMode && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Geofence Configuration
            </CardTitle>
          </CardHeader>
          
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="geofence-enabled">Enable Geofence Monitoring</Label>
              <Switch
                id="geofence-enabled"
                checked={geofenceSettings.enabled}
                onCheckedChange={(enabled) =>
                  setGeofenceSettings(prev => ({ ...prev, enabled }))
                }
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="radius">Safe Area Radius (meters)</Label>
              <Input
                id="radius"
                type="number"
                min="10"
                max="1000"
                value={geofenceSettings.radius}
                onChange={(e) =>
                  setGeofenceSettings(prev => ({
                    ...prev,
                    radius: parseInt(e.target.value) || 100
                  }))
                }
              />
              <p className="text-xs text-gray-600">
                Drag the circle on the map or click to reposition the safe area center
              </p>
            </div>
            
            <Button onClick={saveGeofenceSettings} className="w-full">
              Save Geofence Settings
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Map Container */}
      <Card>
        <CardContent className="p-0">
          <div
            ref={mapRef}
            className="w-full h-96 rounded-lg"
            style={{ minHeight: '400px' }}
          />
          {!mapLoaded && (
            <div className="w-full h-96 flex items-center justify-center bg-gray-100 rounded-lg">
              <div className="text-center">
                <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-2"></div>
                <p className="text-gray-600">Loading Google Maps...</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export default RealTimeLocationTracker;