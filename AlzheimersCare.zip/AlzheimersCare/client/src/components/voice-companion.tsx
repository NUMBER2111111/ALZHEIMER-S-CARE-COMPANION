/**
 * Professional Voice Companion with ElevenLabs Integration
 * Enhanced AI companion with high-quality voice synthesis
 */

import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useElevenLabsVoice } from '@/hooks/useElevenLabsVoice';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  MessageCircle, 
  Heart,
  AlertTriangle,
  CheckCircle,
  Loader2,
  Settings
} from 'lucide-react';

interface VoiceCompanionProps {
  patientId: string;
  patientName?: string;
}

export function VoiceCompanion({ patientId, patientName }: VoiceCompanionProps) {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [conversation, setConversation] = useState<Array<{
    type: 'user' | 'companion';
    message: string;
    timestamp: Date;
    emotion?: string;
  }>>([]);
  const [companionPersonality, setCompanionPersonality] = useState('warm');
  const [voiceEnabled, setVoiceEnabled] = useState(true);

  const { state: voiceState, speakWithFallback, stop, checkUsage } = useElevenLabsVoice();
  const { toast } = useToast();
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  useEffect(() => {
    // Initialize speech recognition
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          }
        }
        if (finalTranscript) {
          setTranscript(finalTranscript);
          handleUserMessage(finalTranscript);
        }
      };

      recognitionRef.current.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        if (event.error === 'not-allowed') {
          toast({
            title: "Microphone Access Required",
            description: "Please allow microphone access for voice interaction.",
            variant: "destructive",
          });
        }
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }

    // Welcome message on load
    setTimeout(() => {
      const welcomeMessage = `${getTimeOfDayGreeting()}, ${patientName || 'dear'}. I'm your AI companion, here to chat and help you throughout the day. How are you feeling today?`;
      handleCompanionResponse(welcomeMessage, 'encouraging');
    }, 1000);

    // Check ElevenLabs usage
    checkUsage();
  }, [patientName, checkUsage]);

  const getTimeOfDayGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 17) return "Good afternoon";
    return "Good evening";
  };

  const toggleListening = () => {
    if (!recognitionRef.current) {
      toast({
        title: "Speech Recognition Not Available",
        description: "Your browser doesn't support speech recognition.",
        variant: "destructive",
      });
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      recognitionRef.current.start();
      setIsListening(true);
      setTranscript('');
    }
  };

  const handleUserMessage = async (message: string) => {
    const userEntry = {
      type: 'user' as const,
      message,
      timestamp: new Date(),
    };

    setConversation(prev => [...prev, userEntry]);

    try {
      // Analyze emotional context and detect emergencies
      const emotionalContext = detectEmotionalContext(message);
      const isEmergency = detectEmergencyKeywords(message);

      if (isEmergency) {
        await handleEmergencyResponse(message);
        return;
      }

      // Get AI companion response
      const response = await fetch('/api/ai-support/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message,
          patientId,
          emotionalContext,
          conversationHistory: conversation.slice(-5), // Last 5 messages for context
        }),
      });

      const data = await response.json();
      await handleCompanionResponse(data.response, emotionalContext);

    } catch (error) {
      console.error('Companion chat error:', error);
      const fallbackMessage = "I'm here for you. While I'm having trouble right now, please know that you're not alone.";
      await handleCompanionResponse(fallbackMessage, 'calm');
    }
  };

  const handleCompanionResponse = async (message: string, emotionalContext: string = 'calm') => {
    const companionEntry = {
      type: 'companion' as const,
      message,
      timestamp: new Date(),
      emotion: emotionalContext,
    };

    setConversation(prev => [...prev, companionEntry]);

    // Speak the response with appropriate emotional context
    if (voiceEnabled) {
      await speakWithFallback(message, {
        emotionalContext: emotionalContext as 'calm' | 'encouraging' | 'concerned' | 'emergency',
        voiceOptions: {
          stability: emotionalContext === 'emergency' ? 0.95 : 0.75,
          similarityBoost: 0.85,
          style: emotionalContext === 'encouraging' ? 0.5 : 0.3,
        }
      });
    }
  };

  const detectEmotionalContext = (message: string): string => {
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('help') || lowerMessage.includes('emergency') || lowerMessage.includes('urgent')) {
      return 'emergency';
    }
    if (lowerMessage.includes('worried') || lowerMessage.includes('confused') || lowerMessage.includes('scared')) {
      return 'concerned';
    }
    if (lowerMessage.includes('good') || lowerMessage.includes('happy') || lowerMessage.includes('better')) {
      return 'encouraging';
    }
    return 'calm';
  };

  const detectEmergencyKeywords = (message: string): boolean => {
    const emergencyKeywords = [
      'help', 'emergency', 'urgent', 'pain', 'chest pain', 'can\'t breathe', 
      'dizzy', 'fall', 'fell', 'bleeding', 'call 911', 'ambulance'
    ];
    
    const lowerMessage = message.toLowerCase();
    return emergencyKeywords.some(keyword => lowerMessage.includes(keyword));
  };

  const handleEmergencyResponse = async (message: string) => {
    const emergencyMessage = "I understand this is urgent. I'm alerting your care team right away. Stay calm, and if this is a medical emergency, please call 911 immediately.";
    
    await handleCompanionResponse(emergencyMessage, 'emergency');

    // Trigger emergency alert
    try {
      await apiRequest('POST', '/api/emergency/trigger-alert', {
        patientId,
        message,
        type: 'voice_emergency',
        urgency: 'high',
      });
    } catch (error) {
      console.error('Failed to trigger emergency alert:', error);
    }
  };

  const getVoiceStatusIcon = () => {
    if (voiceState.isLoading) return <Loader2 className="h-4 w-4 animate-spin" />;
    if (voiceState.isSpeaking) return <Volume2 className="h-4 w-4 text-green-600" />;
    if (voiceState.error) return <VolumeX className="h-4 w-4 text-red-600" />;
    return <Volume2 className="h-4 w-4" />;
  };

  const getEmotionBadgeColor = (emotion?: string) => {
    switch (emotion) {
      case 'emergency': return 'bg-red-100 text-red-800';
      case 'concerned': return 'bg-yellow-100 text-yellow-800';
      case 'encouraging': return 'bg-green-100 text-green-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  return (
    <Card className="bg-white/95 backdrop-blur-sm border border-white/20 shadow-xl">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Heart className="h-5 w-5 text-care-primary" />
            AI Companion
          </CardTitle>
          <div className="flex items-center gap-2">
            {getVoiceStatusIcon()}
            <Badge variant="outline" className="text-xs">
              ElevenLabs Voice
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Voice Controls */}
        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
          <div className="flex items-center gap-3">
            <Button
              onClick={toggleListening}
              variant={isListening ? "destructive" : "default"}
              size="sm"
              className="flex items-center gap-2"
            >
              {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
              {isListening ? 'Stop' : 'Talk'}
            </Button>
            
            <Button
              onClick={() => setVoiceEnabled(!voiceEnabled)}
              variant="outline"
              size="sm"
              className="flex items-center gap-2"
            >
              {voiceEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
              {voiceEnabled ? 'Voice On' : 'Voice Off'}
            </Button>
          </div>

          {voiceState.usage && (
            <div className="text-xs text-gray-600">
              Voice Usage: {voiceState.usage.charactersUsed}/{voiceState.usage.charactersLimit}
            </div>
          )}
        </div>

        {/* Current Transcript */}
        {isListening && (
          <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-center gap-2 mb-2">
              <Mic className="h-4 w-4 text-blue-600 animate-pulse" />
              <span className="text-sm font-medium text-blue-800">Listening...</span>
            </div>
            <p className="text-sm text-gray-700">
              {transcript || "Start speaking..."}
            </p>
          </div>
        )}

        {/* Conversation History */}
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {conversation.map((entry, index) => (
            <div
              key={index}
              className={`p-3 rounded-lg ${
                entry.type === 'user' 
                  ? 'bg-blue-50 border border-blue-200 ml-4' 
                  : 'bg-gray-50 border border-gray-200 mr-4'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  {entry.type === 'user' ? (
                    <MessageCircle className="h-4 w-4 text-blue-600" />
                  ) : (
                    <Heart className="h-4 w-4 text-care-primary" />
                  )}
                  <span className="text-sm font-medium">
                    {entry.type === 'user' ? 'You' : 'AI Companion'}
                  </span>
                  {entry.emotion && (
                    <Badge variant="outline" className={`text-xs ${getEmotionBadgeColor(entry.emotion)}`}>
                      {entry.emotion}
                    </Badge>
                  )}
                </div>
                <span className="text-xs text-gray-500">
                  {entry.timestamp.toLocaleTimeString([], { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                </span>
              </div>
              <p className="text-sm text-gray-700">{entry.message}</p>
            </div>
          ))}
        </div>

        {/* Voice Status */}
        {voiceState.error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-red-600" />
              <span className="text-sm text-red-800">Voice Error: {voiceState.error}</span>
            </div>
          </div>
        )}

        {(voiceState.isLoading || voiceState.isSpeaking) && (
          <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-center gap-2">
              {voiceState.isLoading ? (
                <Loader2 className="h-4 w-4 text-green-600 animate-spin" />
              ) : (
                <Volume2 className="h-4 w-4 text-green-600" />
              )}
              <span className="text-sm text-green-800">
                {voiceState.isLoading ? 'Generating voice...' : 'Speaking...'}
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}