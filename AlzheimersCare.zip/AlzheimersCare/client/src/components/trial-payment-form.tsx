import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Lock, CreditCard, Shield } from 'lucide-react';

interface TrialPaymentFormProps {
  onPaymentMethodCreated: (paymentMethodId: string) => void;
  isLoading: boolean;
  userInfo: {
    firstName: string;
    lastName: string;
    email: string;
    phoneNumber: string;
  };
}

export function TrialPaymentForm({ onPaymentMethodCreated, isLoading, userInfo }: TrialPaymentFormProps) {
  const { toast } = useToast();
  const [processing, setProcessing] = useState(false);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setProcessing(true);

    try {
      // Square Pay integration will be implemented here
      // For now, we'll simulate payment method creation
      setTimeout(() => {
        onPaymentMethodCreated('square_payment_method_' + Date.now());
        setProcessing(false);
      }, 2000);
    } catch (error: any) {
      toast({
        title: "Payment Error",
        description: error.message || "Failed to process payment method",
        variant: "destructive",
      });
      setProcessing(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="w-5 h-5" />
          Payment Information
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Alert>
            <Shield className="h-4 w-4" />
            <AlertDescription>
              <strong>Customer:</strong> {userInfo.firstName} {userInfo.lastName} ({userInfo.email})
            </AlertDescription>
          </Alert>

          <div className="space-y-4">
            <div>
              <Label htmlFor="card-number">Card Number</Label>
              <Input
                id="card-number"
                placeholder="1234 5678 9012 3456"
                required
              />
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="expiry">Expiry Date</Label>
                <Input
                  id="expiry"
                  placeholder="MM/YY"
                  required
                />
              </div>
              <div>
                <Label htmlFor="cvv">CVV</Label>
                <Input
                  id="cvv"
                  placeholder="123"
                  required
                />
              </div>
            </div>

            <div>
              <Label htmlFor="zip">ZIP Code</Label>
              <Input
                id="zip"
                placeholder="12345"
                required
              />
            </div>
          </div>

          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Lock className="w-4 h-4" />
            <span>Secured with 256-bit SSL encryption</span>
          </div>

          <Button 
            type="submit"
            disabled={processing || isLoading}
            className="w-full"
          >
            {processing ? 'Processing...' : 'Add Payment Method'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}