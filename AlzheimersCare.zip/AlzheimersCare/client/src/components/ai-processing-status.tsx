import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Brain, CheckCircle, Clock, Zap, Heart, Users } from "lucide-react";

interface AIProcessingStatusProps {
  status: {
    isProcessing: boolean;
    progress: number;
    currentTask: string;
    completedTasks: string[];
  };
}

export function AIProcessingStatus({ status }: AIProcessingStatusProps) {
  const { isProcessing, progress, currentTask, completedTasks } = status;

  const getTaskIcon = (task: string) => {
    if (task.includes('profile')) return <Users className="h-4 w-4" />;
    if (task.includes('memories') || task.includes('AI')) return <Brain className="h-4 w-4" />;
    if (task.includes('activities')) return <Zap className="h-4 w-4" />;
    return <Heart className="h-4 w-4" />;
  };

  const processingSteps = [
    { 
      name: "Patient profile created", 
      description: "Setting up personalized care profile with medical information and preferences",
      estimatedTime: "30 seconds"
    },
    { 
      name: "Family profiles created", 
      description: "Establishing family member relationships and care responsibilities",
      estimatedTime: "45 seconds"
    },
    { 
      name: "Memories processed", 
      description: "AI analyzing family photos and stories to understand life context and emotional connections",
      estimatedTime: "2-3 minutes"
    },
    { 
      name: "Cognitive activities generated", 
      description: "Creating personalized brain training exercises based on family memories and cognitive needs",
      estimatedTime: "1-2 minutes"
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Main Processing Card */}
      <Card className="bg-gradient-to-br from-purple-50 to-blue-50 border-2 border-accent/20">
        <CardHeader>
          <CardTitle className="flex items-center text-2xl font-bold text-gray-900">
            <div className="w-12 h-12 ai-gradient rounded-xl flex items-center justify-center mr-4">
              <Brain className="h-6 w-6 text-white ai-pulse" />
            </div>
            AI Setting Up Your Care Companion
          </CardTitle>
          <p className="text-gray-600 text-lg">
            Our advanced AI is analyzing your family memories and creating personalized cognitive training activities. 
            This process ensures the best possible therapeutic outcomes.
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-gray-700">Overall Progress</span>
              <span className="text-sm font-bold text-accent">{progress}%</span>
            </div>
            <Progress value={progress} className="h-3" />
          </div>

          {/* Current Task */}
          <div className="bg-white/60 backdrop-blur-sm rounded-lg p-4 border border-white/40">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-accent/20 rounded-full flex items-center justify-center">
                <Clock className="h-4 w-4 text-accent ai-pulse" />
              </div>
              <div>
                <p className="font-semibold text-gray-900">Currently Processing</p>
                <p className="text-accent font-medium">{currentTask}</p>
              </div>
            </div>
          </div>

          {/* Completed Tasks */}
          {completedTasks.length > 0 && (
            <div className="space-y-3">
              <h4 className="font-semibold text-gray-900 flex items-center">
                <CheckCircle className="mr-2 h-5 w-5 text-care-secondary" />
                Completed Steps
              </h4>
              <div className="space-y-2">
                {completedTasks.map((task, index) => (
                  <div key={index} className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg border border-green-200">
                    <CheckCircle className="h-5 w-5 text-care-secondary" />
                    <span className="text-gray-800 font-medium">{task}</span>
                    <Badge className="ml-auto bg-care-secondary text-white">✓ Complete</Badge>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Processing Steps Detail */}
      <Card className="bg-white/80 backdrop-blur-sm border border-gray-200">
        <CardHeader>
          <CardTitle className="text-xl font-bold text-gray-900">
            What's Happening Behind the Scenes
          </CardTitle>
          <p className="text-gray-600">
            Here's how our AI creates your personalized Care Companion experience:
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {processingSteps.map((step, index) => {
              const isCompleted = completedTasks.includes(step.name);
              const isCurrent = currentTask.toLowerCase().includes(step.name.toLowerCase().split(' ')[0]);
              
              return (
                <div 
                  key={index} 
                  className={`p-4 rounded-lg border-2 transition-all ${
                    isCompleted 
                      ? 'bg-green-50 border-care-secondary' 
                      : isCurrent 
                        ? 'bg-accent/10 border-accent' 
                        : 'bg-gray-50 border-gray-200'
                  }`}
                >
                  <div className="flex items-start space-x-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      isCompleted 
                        ? 'bg-care-secondary' 
                        : isCurrent 
                          ? 'bg-accent' 
                          : 'bg-gray-300'
                    }`}>
                      {isCompleted ? (
                        <CheckCircle className="h-4 w-4 text-white" />
                      ) : (
                        getTaskIcon(step.name)
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className={`font-semibold ${
                          isCompleted ? 'text-care-secondary' : isCurrent ? 'text-accent' : 'text-gray-700'
                        }`}>
                          {step.name}
                        </h4>
                        <Badge variant="outline" className="text-xs">
                          {step.estimatedTime}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 mt-1">{step.description}</p>
                      {isCurrent && (
                        <div className="mt-2">
                          <div className="flex items-center space-x-2">
                            <div className="w-2 h-2 bg-accent rounded-full ai-pulse"></div>
                            <span className="text-xs font-medium text-accent">Processing now...</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* AI Benefits Info */}
      <Card className="bg-gradient-to-r from-care-primary/10 to-care-secondary/10 border border-care-primary/20">
        <CardContent className="p-6">
          <div className="text-center">
            <h3 className="text-xl font-bold text-gray-900 mb-3">
              Why AI Processing Takes Time
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div className="text-center">
                <div className="w-12 h-12 bg-care-primary/20 rounded-xl flex items-center justify-center mx-auto mb-2">
                  <Brain className="h-6 w-6 text-care-primary" />
                </div>
                <p className="font-medium text-gray-800">Deep Analysis</p>
                <p className="text-gray-600">AI examines emotional context, relationships, and cognitive patterns in your memories</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-care-secondary/20 rounded-xl flex items-center justify-center mx-auto mb-2">
                  <Heart className="h-6 w-6 text-care-secondary" />
                </div>
                <p className="font-medium text-gray-800">Personalization</p>
                <p className="text-gray-600">Each activity is tailored to your loved one's specific life experiences and preferences</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-accent/20 rounded-xl flex items-center justify-center mx-auto mb-2">
                  <Zap className="h-6 w-6 text-accent" />
                </div>
                <p className="font-medium text-gray-800">Optimization</p>
                <p className="text-gray-600">AI ensures activities are perfectly balanced for cognitive benefit and enjoyment</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
