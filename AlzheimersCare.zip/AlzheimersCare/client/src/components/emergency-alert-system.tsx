import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { 
  AlertTriangle, 
  Phone, 
  MessageSquare, 
  Mail, 
  Clock, 
  CheckCircle,
  XCircle,
  Heart,
  MapPin,
  User,
  Timer,
  Bell
} from 'lucide-react';

interface EmergencyAlert {
  alertId: string;
  alert: {
    patientId: number;
    patientName: string;
    alertType: string;
    severity: 'low' | 'medium' | 'high' | 'critical';
    description: string;
    location?: {
      lat: number;
      lng: number;
      address?: string;
    };
    vitalSigns?: {
      heartRate?: number;
      bloodPressure?: string;
      oxygenSaturation?: number;
      temperature?: number;
    };
    timestamp: Date;
  };
  attempts: Array<{
    contactId: number;
    method: 'call' | 'sms' | 'email';
    status: 'pending' | 'sent' | 'delivered' | 'acknowledged' | 'failed';
    timestamp: Date;
  }>;
  acknowledgedBy?: number;
  startTime: Date;
}

interface EmergencyAlertSystemProps {
  patientId?: number;
  familyMemberId: number;
}

export function EmergencyAlertSystem({ patientId, familyMemberId }: EmergencyAlertSystemProps) {
  const [activeAlerts, setActiveAlerts] = useState<EmergencyAlert[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  // Poll for active alerts
  useEffect(() => {
    const fetchActiveAlerts = async () => {
      try {
        const response = await apiRequest('GET', '/api/emergency/active-alerts');
        const data = await response.json();
        
        if (data.success) {
          setActiveAlerts(data.alerts);
        }
      } catch (error) {
        console.error('Failed to fetch active alerts:', error);
      }
    };

    fetchActiveAlerts();
    const interval = setInterval(fetchActiveAlerts, 5000); // Poll every 5 seconds

    return () => clearInterval(interval);
  }, []);

  // Test emergency alert function
  const triggerTestAlert = async (alertType: string, severity: string) => {
    setIsLoading(true);
    
    try {
      const testAlert = {
        patientId: patientId || 1,
        alertType,
        severity,
        description: `Test ${alertType.replace('_', ' ')} alert - This is a demonstration of the emergency notification system`,
        location: {
          lat: 40.7128,
          lng: -74.0060,
          address: '123 Care Street, Safety City, NY 10001'
        },
        vitalSigns: alertType === 'vital_emergency' ? {
          heartRate: 45,
          bloodPressure: '180/110',
          oxygenSaturation: 88,
          temperature: 99.8
        } : undefined
      };

      const response = await apiRequest('POST', '/api/emergency/trigger-alert', testAlert);
      const data = await response.json();

      if (data.success) {
        toast({
          title: "Emergency Alert Triggered",
          description: "Test emergency notifications have been sent to all primary contacts. They will continue until acknowledged.",
        });
      } else {
        throw new Error(data.message);
      }
    } catch (error: any) {
      toast({
        title: "Alert Failed",
        description: error.message || "Failed to trigger emergency alert",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Acknowledge alert function
  const acknowledgeAlert = async (alertId: string) => {
    try {
      const response = await apiRequest('POST', `/api/emergency/acknowledge/${alertId}`, {
        acknowledgedBy: familyMemberId
      });
      
      const data = await response.json();

      if (data.success) {
        toast({
          title: "Alert Acknowledged",
          description: "Emergency notifications have been stopped.",
        });
        
        // Remove from active alerts
        setActiveAlerts(prev => prev.filter(alert => alert.alertId !== alertId));
      } else {
        throw new Error(data.message);
      }
    } catch (error: any) {
      toast({
        title: "Acknowledgment Failed",
        description: error.message || "Failed to acknowledge alert",
        variant: "destructive",
      });
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getMethodIcon = (method: string) => {
    switch (method) {
      case 'call': return <Phone className="h-3 w-3" />;
      case 'sms': return <MessageSquare className="h-3 w-3" />;
      case 'email': return <Mail className="h-3 w-3" />;
      default: return <Bell className="h-3 w-3" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'acknowledged': return 'text-green-600';
      case 'delivered': return 'text-blue-600';
      case 'sent': return 'text-yellow-600';
      case 'failed': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      {/* Active Alerts */}
      {activeAlerts.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-red-600 flex items-center gap-2">
            <AlertTriangle className="h-5 w-5" />
            Active Emergency Alerts ({activeAlerts.length})
          </h2>
          
          {activeAlerts.map((alertData) => (
            <Card key={alertData.alertId} className="border-red-200 bg-red-50">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-red-900 flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5" />
                    {alertData.alert.alertType.replace('_', ' ').toUpperCase()}
                  </CardTitle>
                  <Badge className={getSeverityColor(alertData.alert.severity)}>
                    {alertData.alert.severity.toUpperCase()}
                  </Badge>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4" />
                    <span>{alertData.alert.patientName}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    <span>{new Date(alertData.alert.timestamp).toLocaleString()}</span>
                  </div>
                  {alertData.alert.location && (
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4" />
                      <span>{alertData.alert.location.address || `${alertData.alert.location.lat}, ${alertData.alert.location.lng}`}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <Timer className="h-4 w-4" />
                    <span>Active for {Math.round((Date.now() - new Date(alertData.startTime).getTime()) / 60000)} minutes</span>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <Alert className="border-red-200">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription className="text-red-800">
                    <strong>Emergency:</strong> {alertData.alert.description}
                  </AlertDescription>
                </Alert>

                {alertData.alert.vitalSigns && (
                  <div className="p-3 bg-white rounded-lg border">
                    <h4 className="font-medium mb-2 flex items-center gap-2">
                      <Heart className="h-4 w-4" />
                      Vital Signs at Alert Time
                    </h4>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      {alertData.alert.vitalSigns.heartRate && (
                        <div>Heart Rate: <span className="font-medium">{alertData.alert.vitalSigns.heartRate} bpm</span></div>
                      )}
                      {alertData.alert.vitalSigns.bloodPressure && (
                        <div>Blood Pressure: <span className="font-medium">{alertData.alert.vitalSigns.bloodPressure}</span></div>
                      )}
                      {alertData.alert.vitalSigns.oxygenSaturation && (
                        <div>Oxygen: <span className="font-medium">{alertData.alert.vitalSigns.oxygenSaturation}%</span></div>
                      )}
                      {alertData.alert.vitalSigns.temperature && (
                        <div>Temperature: <span className="font-medium">{alertData.alert.vitalSigns.temperature}°F</span></div>
                      )}
                    </div>
                  </div>
                )}

                <div className="p-3 bg-white rounded-lg border">
                  <h4 className="font-medium mb-2">Notification Attempts ({alertData.attempts.length})</h4>
                  <div className="space-y-1">
                    {alertData.attempts.slice(-6).map((attempt, index) => (
                      <div key={index} className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          {getMethodIcon(attempt.method)}
                          <span className="capitalize">{attempt.method}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={getStatusColor(attempt.status)}>{attempt.status}</span>
                          <span className="text-gray-500">
                            {new Date(attempt.timestamp).toLocaleTimeString()}
                          </span>
                        </div>
                      </div>
                    ))}
                    {alertData.attempts.length > 6 && (
                      <p className="text-xs text-gray-500">... and {alertData.attempts.length - 6} more attempts</p>
                    )}
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={() => acknowledgeAlert(alertData.alertId)}
                    className="bg-red-600 hover:bg-red-700 flex-1"
                  >
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Acknowledge Alert & Stop Notifications
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Emergency Alert Testing Panel */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5" />
            Emergency Alert System Testing
          </CardTitle>
          <p className="text-sm text-gray-600">
            Test the automated emergency calling and texting system. Notifications will continue until acknowledged.
          </p>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <Alert>
            <Bell className="h-4 w-4" />
            <AlertDescription>
              <strong>How it works:</strong> When an emergency is detected, the system will automatically call and text 
              primary family members repeatedly until someone acknowledges the alert. Calls are made first for critical 
              alerts, followed by SMS and email notifications.
            </AlertDescription>
          </Alert>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-medium">Critical Alerts (Calls + SMS + Email)</h4>
              <div className="space-y-2">
                <Button
                  onClick={() => triggerTestAlert('vital_emergency', 'critical')}
                  disabled={isLoading}
                  variant="destructive"
                  className="w-full justify-start"
                >
                  <Heart className="h-4 w-4 mr-2" />
                  Test Vital Signs Emergency
                </Button>
                <Button
                  onClick={() => triggerTestAlert('fall_detected', 'critical')}
                  disabled={isLoading}
                  variant="destructive"
                  className="w-full justify-start"
                >
                  <AlertTriangle className="h-4 w-4 mr-2" />
                  Test Fall Detection
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium">High Priority Alerts (SMS + Email)</h4>
              <div className="space-y-2">
                <Button
                  onClick={() => triggerTestAlert('geofence_violation', 'high')}
                  disabled={isLoading}
                  variant="outline"
                  className="w-full justify-start border-orange-200 text-orange-700 hover:bg-orange-50"
                >
                  <MapPin className="h-4 w-4 mr-2" />
                  Test Geofence Violation
                </Button>
                <Button
                  onClick={() => triggerTestAlert('medication_missed', 'medium')}
                  disabled={isLoading}
                  variant="outline"
                  className="w-full justify-start border-yellow-200 text-yellow-700 hover:bg-yellow-50"
                >
                  <Clock className="h-4 w-4 mr-2" />
                  Test Missed Medication
                </Button>
              </div>
            </div>
          </div>

          {activeAlerts.length === 0 && (
            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>
                No active emergency alerts. All systems are normal.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export default EmergencyAlertSystem;