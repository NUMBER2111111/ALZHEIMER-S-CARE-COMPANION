import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Users, Plus, X, Heart, Phone, Mail, UserCheck } from "lucide-react";

interface FamilyMember {
  id?: number;
  firstName: string;
  lastName: string;
  email: string;
  relationship: string;
  responsibilityLevel: string;
}

interface FamilyInputPanelProps {
  familyMembers: FamilyMember[];
  onAddMember: (member: FamilyMember) => void;
  onRemoveMember?: (index: number) => void;
  onEditMember?: (index: number, member: FamilyMember) => void;
}

const RELATIONSHIPS = [
  "Spouse",
  "Son", 
  "Daughter",
  "Mother",
  "Father",
  "Brother",
  "Sister",
  "Grandson",
  "Granddaughter",
  "Cousin",
  "Nephew",
  "Niece",
  "Friend",
  "Caregiver"
];

const RESPONSIBILITY_LEVELS = [
  { value: "primary", label: "Primary Caregiver", description: "Main point of contact and decision maker" },
  { value: "secondary", label: "Secondary Caregiver", description: "Backup support and regular communication" },
  { value: "support", label: "Support Member", description: "Occasional visits and emotional support" },
  { value: "emergency", label: "Emergency Contact", description: "Contact in case of emergencies only" }
];

export function FamilyInputPanel({ familyMembers, onAddMember, onRemoveMember, onEditMember }: FamilyInputPanelProps) {
  const [isAddingMember, setIsAddingMember] = useState(false);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [newMember, setNewMember] = useState<FamilyMember>({
    firstName: "",
    lastName: "",
    email: "",
    relationship: "",
    responsibilityLevel: "",
  });
  const [editingMember, setEditingMember] = useState<FamilyMember>({
    firstName: "",
    lastName: "",
    email: "",
    relationship: "",
    responsibilityLevel: "",
  });

  const handleAddMember = () => {
    if (!newMember.firstName || !newMember.lastName || !newMember.email || !newMember.relationship || !newMember.responsibilityLevel) {
      return;
    }

    onAddMember(newMember);
    setNewMember({
      firstName: "",
      lastName: "",
      email: "",
      relationship: "",
      responsibilityLevel: "",
    });
    setIsAddingMember(false);
  };

  const handleEditMember = (index: number) => {
    const member = familyMembers[index];
    setEditingMember(member);
    setEditingIndex(index);
  };

  const handleSaveEdit = () => {
    if (editingIndex !== null && onEditMember) {
      onEditMember(editingIndex, editingMember);
      setEditingIndex(null);
      setEditingMember({
        firstName: "",
        lastName: "",
        email: "",
        relationship: "",
        responsibilityLevel: "",
      });
    }
  };

  const getResponsibilityColor = (level: string) => {
    switch (level) {
      case "primary": return "bg-red-100 text-red-800 border-red-200";
      case "secondary": return "bg-blue-100 text-blue-800 border-blue-200";
      case "support": return "bg-green-100 text-green-800 border-green-200";
      case "emergency": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getRelationshipIcon = (relationship: string) => {
    if (["Spouse"].includes(relationship)) return <Heart className="h-4 w-4" />;
    if (["Son", "Daughter", "Mother", "Father", "Brother", "Sister"].includes(relationship)) return <Users className="h-4 w-4" />;
    return <UserCheck className="h-4 w-4" />;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <Users className="mr-2 h-5 w-5 text-care-primary" />
            Family Members & Caregivers
          </div>
          <Dialog open={isAddingMember} onOpenChange={setIsAddingMember}>
            <DialogTrigger asChild>
              <Button className="bg-care-primary text-white hover:bg-care-primary/90">
                <Plus className="mr-2 h-4 w-4" />
                Add Family Member
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Add Family Member</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      value={newMember.firstName}
                      onChange={(e) => setNewMember({ ...newMember, firstName: e.target.value })}
                      placeholder="Enter first name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      value={newMember.lastName}
                      onChange={(e) => setNewMember({ ...newMember, lastName: e.target.value })}
                      placeholder="Enter last name"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    value={newMember.email}
                    onChange={(e) => setNewMember({ ...newMember, email: e.target.value })}
                    placeholder="Enter email address"
                  />
                </div>

                <div>
                  <Label htmlFor="relationship">Relationship to Patient</Label>
                  <Select 
                    value={newMember.relationship} 
                    onValueChange={(value) => setNewMember({ ...newMember, relationship: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select relationship" />
                    </SelectTrigger>
                    <SelectContent>
                      {RELATIONSHIPS.map((rel) => (
                        <SelectItem key={rel} value={rel}>{rel}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="responsibilityLevel">Care Responsibility Level</Label>
                  <Select 
                    value={newMember.responsibilityLevel} 
                    onValueChange={(value) => setNewMember({ ...newMember, responsibilityLevel: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select responsibility level" />
                    </SelectTrigger>
                    <SelectContent>
                      {RESPONSIBILITY_LEVELS.map((level) => (
                        <SelectItem key={level.value} value={level.value}>
                          <div>
                            <div className="font-medium">{level.label}</div>
                            <div className="text-xs text-gray-500">{level.description}</div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex justify-end space-x-2 pt-4">
                  <Button variant="outline" onClick={() => setIsAddingMember(false)}>
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleAddMember}
                    className="bg-care-primary text-white hover:bg-care-primary/90"
                  >
                    Add Member
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </CardTitle>
        <p className="text-gray-600">
          Add family members and caregivers who will be involved in the care process. 
          Their relationship and responsibility level helps our AI create more personalized experiences.
        </p>
      </CardHeader>
      <CardContent>
        {familyMembers.length === 0 ? (
          <div className="text-center py-12 border-2 border-dashed border-gray-300 rounded-lg">
            <Users className="mx-auto h-16 w-16 text-gray-400 mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No Family Members Added</h3>
            <p className="text-gray-600 mb-4">
              Start by adding family members who will be involved in the care process.
            </p>
            <Button 
              onClick={() => setIsAddingMember(true)}
              className="bg-care-primary text-white hover:bg-care-primary/90"
            >
              <Plus className="mr-2 h-4 w-4" />
              Add First Family Member
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {familyMembers.map((member, index) => (
              <Card key={index} className="border border-gray-200">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-care-primary/10 to-care-secondary/10 rounded-full flex items-center justify-center">
                        {getRelationshipIcon(member.relationship)}
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">
                          {member.firstName} {member.lastName}
                        </h4>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant="outline" className="text-xs">
                            {member.relationship}
                          </Badge>
                          <Badge className={`text-xs ${getResponsibilityColor(member.responsibilityLevel)}`}>
                            {RESPONSIBILITY_LEVELS.find(l => l.value === member.responsibilityLevel)?.label || member.responsibilityLevel}
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-4 mt-2 text-sm text-gray-600">
                          <div className="flex items-center">
                            <Mail className="h-3 w-3 mr-1" />
                            {member.email}
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Badge className="bg-green-100 text-green-800">Active</Badge>
                      {onEditMember && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditMember(index)}
                          className="text-blue-600 hover:text-blue-800 hover:bg-blue-50"
                        >
                          Edit
                        </Button>
                      )}
                      {onRemoveMember && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onRemoveMember(index)}
                          className="text-red-600 hover:text-red-800 hover:bg-red-50"
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-semibold text-blue-900 mb-2 flex items-center">
                <Heart className="mr-2 h-4 w-4" />
                What This Means
              </h4>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• Family members will receive personalized progress reports</li>
                <li>• AI will use relationship context to create relevant activities</li>
                <li>• Primary caregivers get immediate alerts and detailed insights</li>
                <li>• Support members receive weekly summaries and milestone updates</li>
              </ul>
            </div>
          </div>
        )}

        {/* Edit Member Dialog */}
        <Dialog open={editingIndex !== null} onOpenChange={(open) => {
          if (!open) {
            setEditingIndex(null);
            setEditingMember({
              firstName: "",
              lastName: "",
              email: "",
              relationship: "",
              responsibilityLevel: "",
            });
          }
        }}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Edit Family Member</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="editFirstName">First Name</Label>
                  <Input
                    id="editFirstName"
                    value={editingMember.firstName}
                    onChange={(e) => setEditingMember({ ...editingMember, firstName: e.target.value })}
                    placeholder="Enter first name"
                  />
                </div>
                <div>
                  <Label htmlFor="editLastName">Last Name</Label>
                  <Input
                    id="editLastName"
                    value={editingMember.lastName}
                    onChange={(e) => setEditingMember({ ...editingMember, lastName: e.target.value })}
                    placeholder="Enter last name"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="editEmail">Email Address</Label>
                <Input
                  id="editEmail"
                  type="email"
                  value={editingMember.email}
                  onChange={(e) => setEditingMember({ ...editingMember, email: e.target.value })}
                  placeholder="Enter email address"
                />
              </div>

              <div>
                <Label htmlFor="editRelationship">Relationship to Patient</Label>
                <Select 
                  value={editingMember.relationship} 
                  onValueChange={(value) => setEditingMember({ ...editingMember, relationship: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select relationship" />
                  </SelectTrigger>
                  <SelectContent>
                    {RELATIONSHIPS.map((rel) => (
                      <SelectItem key={rel} value={rel}>{rel}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="editResponsibilityLevel">Care Responsibility Level</Label>
                <Select 
                  value={editingMember.responsibilityLevel} 
                  onValueChange={(value) => setEditingMember({ ...editingMember, responsibilityLevel: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select responsibility level" />
                  </SelectTrigger>
                  <SelectContent>
                    {RESPONSIBILITY_LEVELS.map((level) => (
                      <SelectItem key={level.value} value={level.value}>
                        <div>
                          <div className="font-medium">{level.label}</div>
                          <div className="text-xs text-gray-500">{level.description}</div>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={() => setEditingIndex(null)}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleSaveEdit}
                  className="bg-care-primary text-white hover:bg-care-primary/90"
                >
                  Save Changes
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
