import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Gamepad2, Crown, Spade, Brain, Target } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface GameActivity {
  id: number;
  gameType: string;
  gameName: string;
  difficulty: string;
  gameState: any;
  playerMoves: any[];
  aiMoves: any[];
  status: string;
  startTime: string;
  cognitiveScore?: number;
  engagementLevel?: number;
}

interface AIGamingProps {
  patientId: number;
}

export function AIGaming({ patientId }: AIGamingProps) {
  const queryClient = useQueryClient();
  const [selectedGameType, setSelectedGameType] = useState<string>('chess');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('easy');
  const [activeGame, setActiveGame] = useState<GameActivity | null>(null);

  const { data: games, isLoading: gamesLoading } = useQuery({
    queryKey: ['/api/patients', patientId, 'games'],
  });

  const { data: activeGames } = useQuery({
    queryKey: ['/api/patients', patientId, 'games', 'active'],
  });

  const createGameMutation = useMutation({
    mutationFn: async (gameData: {
      gameType: string;
      gameName: string;
      difficulty: string;
    }) => {
      const response = await apiRequest('POST', '/api/games', {
        ...gameData,
        patientId,
      });
      return response.json();
    },
    onSuccess: (newGame) => {
      setActiveGame(newGame);
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'games'] });
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'games', 'active'] });
    },
  });

  const makeMoveMutation = useMutation({
    mutationFn: async ({ gameId, move }: { gameId: number; move: any }) => {
      const response = await apiRequest('POST', `/api/games/${gameId}/move`, {
        move,
        playerMoves: activeGame?.playerMoves || [],
      });
      return response.json();
    },
    onSuccess: (response) => {
      setActiveGame(response.game);
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'games'] });
    },
  });

  const gameTypes = [
    { value: 'chess', label: 'Chess', icon: Crown },
    { value: 'cards', label: 'Card Games', icon: Spade },
    { value: 'memory', label: 'Memory Games', icon: Brain },
    { value: 'puzzle', label: 'Puzzle Games', icon: Target },
  ];

  const difficulties = [
    { value: 'easy', label: 'Easy', color: 'bg-green-100 text-green-800' },
    { value: 'medium', label: 'Medium', color: 'bg-yellow-100 text-yellow-800' },
    { value: 'hard', label: 'Hard', color: 'bg-red-100 text-red-800' },
  ];

  const startNewGame = () => {
    const gameName = selectedGameType === 'chess' ? 'Classic Chess' :
                     selectedGameType === 'cards' ? 'Memory Cards' :
                     selectedGameType === 'memory' ? 'Pattern Memory' :
                     'Logic Puzzle';

    createGameMutation.mutate({
      gameType: selectedGameType,
      gameName,
      difficulty: selectedDifficulty,
    });
  };

  const getCognitiveScoreColor = (score?: number) => {
    if (!score) return 'text-gray-500';
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const renderChessBoard = (gameState: any) => {
    // Simplified chess board representation
    return (
      <div className="grid grid-cols-8 gap-1 w-64 h-64 mx-auto">
        {Array.from({ length: 64 }, (_, i) => {
          const row = Math.floor(i / 8);
          const col = i % 8;
          const isLight = (row + col) % 2 === 0;
          
          return (
            <div
              key={i}
              className={`aspect-square flex items-center justify-center text-xs font-bold
                ${isLight ? 'bg-amber-100' : 'bg-amber-800 text-white'}`}
              onClick={() => {
                if (activeGame) {
                  makeMoveMutation.mutate({
                    gameId: activeGame.id,
                    move: { from: i, to: i, piece: 'pawn' }
                  });
                }
              }}
            >
              {/* Simplified piece representation */}
              {i < 16 || i >= 48 ? '♟' : ''}
            </div>
          );
        })}
      </div>
    );
  };

  const renderCardGame = (gameState: any) => {
    // Simplified card game interface
    const cards = Array.from({ length: 12 }, (_, i) => ({
      id: i,
      value: Math.floor(i / 2) + 1,
      flipped: gameState?.flippedCards?.includes(i) || false,
      matched: gameState?.matchedCards?.includes(i) || false,
    }));

    return (
      <div className="grid grid-cols-4 gap-2 w-64 mx-auto">
        {cards.map((card) => (
          <div
            key={card.id}
            className={`aspect-square flex items-center justify-center text-lg font-bold rounded cursor-pointer
              ${card.matched ? 'bg-green-200 text-green-800' :
                card.flipped ? 'bg-blue-200 text-blue-800' :
                'bg-gray-300 hover:bg-gray-400'}`}
            onClick={() => {
              if (activeGame && !card.matched && !card.flipped) {
                makeMoveMutation.mutate({
                  gameId: activeGame.id,
                  move: { cardId: card.id, action: 'flip' }
                });
              }
            }}
          >
            {card.flipped || card.matched ? card.value : '?'}
          </div>
        ))}
      </div>
    );
  };

  if (gamesLoading) {
    return <div className="flex items-center justify-center h-64">Loading games...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Game Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Gamepad2 className="h-5 w-5" />
            AI Gaming Center
          </CardTitle>
          <CardDescription>Cognitive training through interactive games</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Game Type</label>
              <Select value={selectedGameType} onValueChange={setSelectedGameType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select game type" />
                </SelectTrigger>
                <SelectContent>
                  {gameTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      <div className="flex items-center gap-2">
                        <type.icon className="h-4 w-4" />
                        {type.label}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Difficulty</label>
              <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
                <SelectTrigger>
                  <SelectValue placeholder="Select difficulty" />
                </SelectTrigger>
                <SelectContent>
                  {difficulties.map((diff) => (
                    <SelectItem key={diff.value} value={diff.value}>
                      <Badge className={diff.color}>{diff.label}</Badge>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Button 
                onClick={startNewGame}
                disabled={createGameMutation.isPending}
                className="w-full"
              >
                Start New Game
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Game */}
      {activeGame && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>{activeGame.gameName}</span>
              <div className="flex gap-2">
                <Badge variant="outline">{activeGame.difficulty}</Badge>
                <Badge variant={activeGame.status === 'in_progress' ? 'default' : 'secondary'}>
                  {activeGame.status}
                </Badge>
              </div>
            </CardTitle>
            <CardDescription>
              Started: {new Date(activeGame.startTime).toLocaleString()}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Game Board */}
              <div className="flex justify-center p-4 bg-gray-50 rounded-lg">
                {activeGame.gameType === 'chess' && renderChessBoard(activeGame.gameState)}
                {activeGame.gameType === 'cards' && renderCardGame(activeGame.gameState)}
                {(activeGame.gameType === 'memory' || activeGame.gameType === 'puzzle') && (
                  <div className="text-center py-8">
                    <Brain className="h-12 w-12 mx-auto mb-4 text-blue-500" />
                    <p className="text-gray-600">Interactive {activeGame.gameType} game interface</p>
                    <Button className="mt-4" variant="outline">
                      Continue Game
                    </Button>
                  </div>
                )}
              </div>

              {/* Game Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <p className="text-sm text-gray-600">Player Moves</p>
                  <p className="text-xl font-bold">{activeGame.playerMoves?.length || 0}</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-600">AI Moves</p>
                  <p className="text-xl font-bold">{activeGame.aiMoves?.length || 0}</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-600">Cognitive Score</p>
                  <p className={`text-xl font-bold ${getCognitiveScoreColor(activeGame.cognitiveScore)}`}>
                    {activeGame.cognitiveScore || '--'}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-600">Engagement</p>
                  <p className="text-xl font-bold text-blue-600">
                    {activeGame.engagementLevel || '--'}%
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Game History */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Games</CardTitle>
          <CardDescription>Your gaming progress and achievements</CardDescription>
        </CardHeader>
        <CardContent>
          {games && games.length > 0 ? (
            <div className="space-y-4">
              {games.slice(0, 5).map((game: GameActivity) => (
                <div key={game.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-medium">{game.gameName}</h4>
                      <Badge variant="outline">{game.gameType}</Badge>
                      <Badge className={difficulties.find(d => d.value === game.difficulty)?.color}>
                        {game.difficulty}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600">
                      {new Date(game.startTime).toLocaleDateString()}
                    </p>
                  </div>
                  
                  <div className="text-right">
                    <Badge variant={game.status === 'completed' ? 'default' : 'secondary'}>
                      {game.status}
                    </Badge>
                    {game.cognitiveScore && (
                      <p className={`text-sm font-medium mt-1 ${getCognitiveScoreColor(game.cognitiveScore)}`}>
                        Score: {game.cognitiveScore}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500">No games played yet</p>
          )}
        </CardContent>
      </Card>

      {/* Cognitive Benefits */}
      <Card>
        <CardHeader>
          <CardTitle>Cognitive Benefits</CardTitle>
          <CardDescription>How gaming supports your mental wellness</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium mb-3">Memory Enhancement</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Pattern recognition exercises</li>
                <li>• Short-term memory challenges</li>
                <li>• Visual-spatial memory training</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-3">Cognitive Stimulation</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Problem-solving skills</li>
                <li>• Strategic thinking development</li>
                <li>• Attention and focus improvement</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}