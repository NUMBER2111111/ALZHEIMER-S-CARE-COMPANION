import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Heart, Activity, AlertTriangle, CheckCircle } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface VitalSigns {
  id: number;
  heartRate: number;
  bloodPressureSystolic: number;
  bloodPressureDiastolic: number;
  oxygenSaturation: number;
  temperature: number;
  isEmergencyAlert: boolean;
  alertType?: string;
  createdAt: string;
}

interface EmergencyEvent {
  id: number;
  eventType: string;
  severity: string;
  description: string;
  status: string;
  createdAt: string;
}

interface EmergencyMonitorProps {
  patientId: number;
}

export function EmergencyMonitor({ patientId }: EmergencyMonitorProps) {
  const queryClient = useQueryClient();

  const { data: latestVitals, isLoading: vitalsLoading } = useQuery({
    queryKey: ['/api/patients', patientId, 'vital-signs', 'latest'],
    refetchInterval: 30000, // Check every 30 seconds
  }) as { data: VitalSigns | undefined; isLoading: boolean };

  const { data: emergencyAlerts = [] } = useQuery({
    queryKey: ['/api/emergency-alerts', patientId],
    queryFn: () => fetch(`/api/emergency-alerts?patientId=${patientId}`).then(res => res.json()),
    refetchInterval: 10000, // Check every 10 seconds
  });

  const { data: emergencyEvents = [] } = useQuery({
    queryKey: ['/api/patients', patientId, 'emergency-events'],
  });

  const acknowledgeEmergencyMutation = useMutation({
    mutationFn: async (eventId: number) => {
      return apiRequest('POST', `/api/emergency-events/${eventId}/acknowledge`, { userId: 1 });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'emergency-events'] });
      queryClient.invalidateQueries({ queryKey: ['/api/emergency-alerts', patientId] });
    },
  });

  const resolveEmergencyMutation = useMutation({
    mutationFn: async (eventId: number) => {
      return apiRequest('POST', `/api/emergency-events/${eventId}/resolve`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'emergency-events'] });
      queryClient.invalidateQueries({ queryKey: ['/api/emergency-alerts', patientId] });
    },
  });

  const getRiskLevel = (vitals: any) => {
    if (!vitals || typeof vitals !== 'object') return 'normal';
    
    const { heartRate, bloodPressureSystolic, oxygenSaturation } = vitals;
    
    if (heartRate > 120 || heartRate < 50 || 
        bloodPressureSystolic > 180 || bloodPressureSystolic < 80 ||
        oxygenSaturation < 90) {
      return 'critical';
    }
    
    if (heartRate > 100 || heartRate < 60 ||
        bloodPressureSystolic > 140 || bloodPressureSystolic < 90 ||
        oxygenSaturation < 95) {
      return 'warning';
    }
    
    return 'normal';
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'critical': return 'destructive';
      case 'warning': return 'secondary';
      default: return 'default';
    }
  };

  if (vitalsLoading) {
    return <div className="flex items-center justify-center h-64">Loading vital signs...</div>;
  }

  const riskLevel = getRiskLevel(latestVitals);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Current Vital Signs */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-medium">Current Vital Signs</CardTitle>
            <Heart className="h-5 w-5 text-red-500" />
          </CardHeader>
          <CardContent>
            {latestVitals ? (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Risk Level</span>
                  <Badge variant={getRiskColor(riskLevel)}>
                    {riskLevel.toUpperCase()}
                  </Badge>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-600">Heart Rate</span>
                    <p className="font-semibold">{(latestVitals as VitalSigns).heartRate || 'N/A'} BPM</p>
                  </div>
                  <div>
                    <span className="text-gray-600">Blood Pressure</span>
                    <p className="font-semibold">
                      {(latestVitals as VitalSigns).bloodPressureSystolic || 'N/A'}/{(latestVitals as VitalSigns).bloodPressureDiastolic || 'N/A'}
                    </p>
                  </div>
                  <div>
                    <span className="text-gray-600">Oxygen Saturation</span>
                    <p className="font-semibold">{(latestVitals as VitalSigns).oxygenSaturation || 'N/A'}%</p>
                  </div>
                  <div>
                    <span className="text-gray-600">Temperature</span>
                    <p className="font-semibold">{(latestVitals as VitalSigns).temperature || 'N/A'}°F</p>
                  </div>
                </div>
                
                {(latestVitals as VitalSigns).isEmergencyAlert && (
                  <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>
                      Emergency Alert: {(latestVitals as VitalSigns).alertType || 'Abnormal vital signs detected'}
                    </AlertDescription>
                  </Alert>
                )}
                
                <p className="text-xs text-gray-500">
                  Last updated: {(latestVitals as VitalSigns).createdAt ? new Date((latestVitals as VitalSigns).createdAt).toLocaleString() : 'Never'}
                </p>
              </div>
            ) : (
              <p className="text-gray-500">No vital signs data available</p>
            )}
          </CardContent>
        </Card>

        {/* Emergency Alerts */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-medium">Emergency Alerts</CardTitle>
            <Activity className="h-5 w-5 text-orange-500" />
          </CardHeader>
          <CardContent>
            {emergencyAlerts && emergencyAlerts.length > 0 ? (
              <div className="space-y-3">
                {emergencyAlerts.slice(0, 3).map((alert: VitalSigns) => (
                  <div key={alert.id} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                    <div>
                      <p className="font-medium text-red-800">
                        {alert.alertType || 'Vital Signs Alert'}
                      </p>
                      <p className="text-sm text-red-600">
                        {new Date(alert.createdAt).toLocaleString()}
                      </p>
                    </div>
                    <AlertTriangle className="h-5 w-5 text-red-500" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex items-center text-green-600">
                <CheckCircle className="h-5 w-5 mr-2" />
                <span>No active emergency alerts</span>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Emergency Events Management */}
      <Card>
        <CardHeader>
          <CardTitle>Emergency Events</CardTitle>
          <CardDescription>Recent emergency events and their status</CardDescription>
        </CardHeader>
        <CardContent>
          {emergencyEvents && emergencyEvents.length > 0 ? (
            <div className="space-y-4">
              {emergencyEvents.map((event: EmergencyEvent) => (
                <div key={event.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant={event.severity === 'critical' ? 'destructive' : 'secondary'}>
                        {event.severity}
                      </Badge>
                      <Badge variant={event.status === 'active' ? 'destructive' : 'default'}>
                        {event.status}
                      </Badge>
                    </div>
                    <h4 className="font-medium">{event.eventType.replace('_', ' ')}</h4>
                    <p className="text-sm text-gray-600">{event.description}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {new Date(event.createdAt).toLocaleString()}
                    </p>
                  </div>
                  
                  {event.status === 'active' && (
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => acknowledgeEmergencyMutation.mutate(event.id)}
                        disabled={acknowledgeEmergencyMutation.isPending}
                      >
                        Acknowledge
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => resolveEmergencyMutation.mutate(event.id)}
                        disabled={resolveEmergencyMutation.isPending}
                      >
                        Resolve
                      </Button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500">No emergency events recorded</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}