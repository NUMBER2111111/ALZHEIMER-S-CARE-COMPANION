import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Gamepad2, Trophy, Brain, Clock, Target, RefreshCw, Play, Pause } from 'lucide-react';

interface GameActivity {
  id: number;
  gameType: string;
  gameName: string;
  difficulty: string;
  gameState: any;
  playerMoves: any[];
  aiMoves: any[];
  status: string;
  startTime: string;
  cognitiveScore?: number;
  engagementLevel?: number;
}

interface EnhancedAIGamingProps {
  patientId: number;
}

// Simple chess board component
function ChessBoard({ gameState, onMove, isPlayerTurn }: any) {
  const [selectedSquare, setSelectedSquare] = useState<string | null>(null);
  
  const board = gameState?.board || [
    ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'],
    ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'],
    [null, null, null, null, null, null, null, null],
    [null, null, null, null, null, null, null, null],
    [null, null, null, null, null, null, null, null],
    [null, null, null, null, null, null, null, null],
    ['P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'],
    ['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R']
  ];

  const getPieceSymbol = (piece: string | null) => {
    if (!piece) return '';
    const symbols: { [key: string]: string } = {
      'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟',
      'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙'
    };
    return symbols[piece] || piece;
  };

  const handleSquareClick = (row: number, col: number) => {
    const square = `${String.fromCharCode(97 + col)}${8 - row}`;
    if (selectedSquare) {
      onMove({ from: selectedSquare, to: square });
      setSelectedSquare(null);
    } else {
      setSelectedSquare(square);
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="grid grid-cols-8 gap-1 w-80 h-80 mx-auto border-4 border-gray-800">
        {board.map((row: any[], rowIndex: number) =>
          row.map((piece: string | null, colIndex: number) => {
            const isLight = (rowIndex + colIndex) % 2 === 0;
            const square = `${String.fromCharCode(97 + colIndex)}${8 - rowIndex}`;
            const isSelected = selectedSquare === square;
            
            return (
              <div
                key={`${rowIndex}-${colIndex}`}
                className={`
                  w-10 h-10 flex items-center justify-center text-2xl cursor-pointer
                  ${isLight ? 'bg-amber-100' : 'bg-amber-800'}
                  ${isSelected ? 'ring-4 ring-blue-500' : ''}
                  hover:ring-2 hover:ring-blue-300 transition-all
                `}
                onClick={() => handleSquareClick(rowIndex, colIndex)}
              >
                <span className="select-none font-bold text-gray-800">
                  {getPieceSymbol(piece)}
                </span>
              </div>
            );
          })
        )}
      </div>
      <div className="mt-4 text-center">
        <Badge variant={isPlayerTurn ? "default" : "secondary"} className="text-lg px-4 py-2">
          {isPlayerTurn ? "Your Turn" : "AI Thinking..."}
        </Badge>
      </div>
    </div>
  );
}

// Memory game component
function MemoryGame({ gameState, onMove }: any) {
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [matchedCards, setMatchedCards] = useState<number[]>(gameState?.matched || []);
  
  const cards = gameState?.cards || [
    '🎯', '🎯', '🧠', '🧠', '🎮', '🎮', '🏆', '🏆',
    '🎪', '🎪', '🎨', '🎨', '🎭', '🎭', '🎸', '🎸'
  ];

  const handleCardClick = (index: number) => {
    if (flippedCards.length < 2 && !flippedCards.includes(index) && !matchedCards.includes(index)) {
      const newFlipped = [...flippedCards, index];
      setFlippedCards(newFlipped);
      
      if (newFlipped.length === 2) {
        setTimeout(() => {
          if (cards[newFlipped[0]] === cards[newFlipped[1]]) {
            setMatchedCards([...matchedCards, ...newFlipped]);
            onMove({ type: 'match', cards: newFlipped });
          }
          setFlippedCards([]);
        }, 1000);
      }
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="grid grid-cols-4 gap-3 w-80 mx-auto">
        {cards.map((card: string, index: number) => {
          const isFlipped = flippedCards.includes(index) || matchedCards.includes(index);
          
          return (
            <div
              key={index}
              className={`
                w-16 h-16 flex items-center justify-center text-2xl cursor-pointer
                rounded-lg border-2 transition-all duration-300 transform
                ${isFlipped 
                  ? 'bg-green-100 border-green-300 scale-105' 
                  : 'bg-blue-100 border-blue-300 hover:bg-blue-200'
                }
                ${matchedCards.includes(index) ? 'opacity-75' : ''}
              `}
              onClick={() => handleCardClick(index)}
            >
              <span className="select-none">
                {isFlipped ? card : '?'}
              </span>
            </div>
          );
        })}
      </div>
      <div className="mt-4 text-center">
        <Badge variant="outline" className="text-lg px-4 py-2">
          Matches: {matchedCards.length / 2} / {cards.length / 2}
        </Badge>
      </div>
    </div>
  );
}

// Solitaire game component
function SolitaireGame({ gameState, onMove }: any) {
  const [selectedCard, setSelectedCard] = useState<string | null>(null);
  const [foundation, setFoundation] = useState<any[]>(gameState?.foundation || [[], [], [], []]);
  const [tableau, setTableau] = useState<any[][]>(gameState?.tableau || [
    ['♠K'], ['♥Q', '♠J'], ['♦A', '♣2', '♥3'], ['♠4', '♦5', '♣6', '♥7']
  ]);

  const getCardColor = (card: string) => {
    return card.includes('♥') || card.includes('♦') ? 'text-red-600' : 'text-black';
  };

  const handleCardClick = (card: string, pile: string, index: number) => {
    if (selectedCard) {
      onMove({ from: selectedCard, to: card, pile, index });
      setSelectedCard(null);
    } else {
      setSelectedCard(card);
    }
  };

  return (
    <div className="bg-green-100 p-6 rounded-lg shadow-lg min-h-96">
      <div className="text-center mb-4">
        <h3 className="text-xl font-bold mb-2">Klondike Solitaire</h3>
      </div>
      
      {/* Foundation piles */}
      <div className="flex justify-center gap-2 mb-6">
        {foundation.map((pile, index) => (
          <div
            key={index}
            className="w-16 h-20 border-2 border-gray-400 rounded-lg bg-green-200 flex items-center justify-center text-2xl"
          >
            {pile.length > 0 ? pile[pile.length - 1] : '♠'}
          </div>
        ))}
      </div>

      {/* Tableau */}
      <div className="grid grid-cols-4 gap-4">
        {tableau.map((pile, pileIndex) => (
          <div key={pileIndex} className="min-h-32">
            {pile.map((card, cardIndex) => (
              <div
                key={cardIndex}
                className={`
                  w-16 h-20 bg-white border border-gray-300 rounded-lg shadow-sm
                  flex items-center justify-center text-lg font-bold cursor-pointer
                  transform hover:scale-105 transition-all duration-200
                  ${selectedCard === card ? 'ring-4 ring-blue-500' : ''}
                  ${getCardColor(card)}
                  ${cardIndex === pile.length - 1 ? '' : '-mb-14'}
                `}
                style={{ zIndex: cardIndex }}
                onClick={() => handleCardClick(card, 'tableau', pileIndex)}
              >
                {card}
              </div>
            ))}
            {pile.length === 0 && (
              <div className="w-16 h-20 border-2 border-dashed border-gray-400 rounded-lg"></div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// Rummy game component
function RummyGame({ gameState, onMove }: any) {
  const [hand, setHand] = useState<string[]>(gameState?.playerHand || [
    '♠A', '♠2', '♠3', '♥4', '♥5', '♦6', '♣7'
  ]);
  const [selectedCards, setSelectedCards] = useState<string[]>([]);
  const [discardPile, setDiscardPile] = useState<string[]>(gameState?.discardPile || ['♦8']);

  const suits = ['♠', '♥', '♦', '♣'];
  const values = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

  const getCardColor = (card: string) => {
    return card.includes('♥') || card.includes('♦') ? 'text-red-600' : 'text-black';
  };

  const handleCardClick = (card: string) => {
    if (selectedCards.includes(card)) {
      setSelectedCards(selectedCards.filter(c => c !== card));
    } else {
      setSelectedCards([...selectedCards, card]);
    }
  };

  const handleMeld = () => {
    if (selectedCards.length >= 3) {
      onMove({ type: 'meld', cards: selectedCards });
      setSelectedCards([]);
    }
  };

  const handleDiscard = () => {
    if (selectedCards.length === 1) {
      onMove({ type: 'discard', card: selectedCards[0] });
      setHand(hand.filter(c => c !== selectedCards[0]));
      setDiscardPile([...discardPile, selectedCards[0]]);
      setSelectedCards([]);
    }
  };

  return (
    <div className="bg-green-100 p-6 rounded-lg shadow-lg">
      <div className="text-center mb-4">
        <h3 className="text-xl font-bold mb-2">Gin Rummy</h3>
        <p className="text-gray-600">Form sets and runs with your cards</p>
      </div>

      {/* Discard pile */}
      <div className="text-center mb-6">
        <div className="inline-block">
          <div className="text-sm text-gray-600 mb-2">Discard Pile</div>
          <div className={`
            w-16 h-20 bg-white border border-gray-300 rounded-lg shadow-sm
            flex items-center justify-center text-lg font-bold cursor-pointer
            ${getCardColor(discardPile[discardPile.length - 1])}
          `}>
            {discardPile[discardPile.length - 1]}
          </div>
        </div>
      </div>

      {/* Player hand */}
      <div className="mb-6">
        <div className="text-sm text-gray-600 mb-2 text-center">Your Hand</div>
        <div className="flex flex-wrap justify-center gap-2">
          {hand.map((card, index) => (
            <div
              key={index}
              className={`
                w-16 h-20 bg-white border border-gray-300 rounded-lg shadow-sm
                flex items-center justify-center text-lg font-bold cursor-pointer
                transform hover:scale-105 transition-all duration-200
                ${selectedCards.includes(card) ? 'ring-4 ring-blue-500 -translate-y-2' : ''}
                ${getCardColor(card)}
              `}
              onClick={() => handleCardClick(card)}
            >
              {card}
            </div>
          ))}
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex justify-center gap-4">
        <Button
          onClick={handleMeld}
          disabled={selectedCards.length < 3}
          className="bg-green-600 hover:bg-green-700"
        >
          Meld ({selectedCards.length})
        </Button>
        <Button
          onClick={handleDiscard}
          disabled={selectedCards.length !== 1}
          variant="outline"
        >
          Discard
        </Button>
      </div>
    </div>
  );
}

// Pattern matching game
function PatternGame({ gameState, onMove }: any) {
  const [playerSequence, setPlayerSequence] = useState<number[]>([]);
  const [showingPattern, setShowingPattern] = useState(false);
  
  const pattern = gameState?.pattern || [1, 2, 3, 1, 4, 2];
  const colors = ['bg-red-500', 'bg-blue-500', 'bg-green-500', 'bg-yellow-500', 'bg-purple-500'];
  
  const handleButtonClick = (buttonIndex: number) => {
    if (showingPattern) return;
    
    const newSequence = [...playerSequence, buttonIndex];
    setPlayerSequence(newSequence);
    
    if (newSequence.length === pattern.length) {
      const isCorrect = newSequence.every((val, idx) => val === pattern[idx]);
      onMove({ sequence: newSequence, correct: isCorrect });
      if (isCorrect) {
        setTimeout(() => setPlayerSequence([]), 1000);
      }
    }
  };

  useEffect(() => {
    if (playerSequence.length === 0) {
      setShowingPattern(true);
      setTimeout(() => setShowingPattern(false), 2000);
    }
  }, [playerSequence.length]);

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="text-center mb-4">
        <h3 className="text-xl font-bold mb-2">Pattern Memory</h3>
        <p className="text-gray-600">
          {showingPattern ? 'Watch the pattern...' : 'Repeat the pattern!'}
        </p>
      </div>
      
      <div className="grid grid-cols-3 gap-4 w-60 mx-auto">
        {[0, 1, 2, 3, 4].map((index) => (
          <div
            key={index}
            className={`
              w-16 h-16 rounded-lg cursor-pointer transition-all duration-200
              ${colors[index]} hover:opacity-80 transform hover:scale-105
              ${showingPattern && pattern.includes(index + 1) ? 'animate-pulse' : ''}
              ${playerSequence.includes(index + 1) ? 'ring-4 ring-white' : ''}
            `}
            onClick={() => handleButtonClick(index + 1)}
          />
        ))}
      </div>
      
      <div className="mt-4 text-center">
        <Badge variant="outline" className="text-lg px-4 py-2">
          Progress: {playerSequence.length} / {pattern.length}
        </Badge>
      </div>
    </div>
  );
}

export function EnhancedAIGaming({ patientId }: EnhancedAIGamingProps) {
  const [selectedGame, setSelectedGame] = useState<string>('chess');
  const [difficulty, setDifficulty] = useState<string>('easy');
  const [currentGame, setCurrentGame] = useState<GameActivity | null>(null);
  const [gameError, setGameError] = useState<string | null>(null);

  const { data: games = [], isLoading: gamesLoading } = useQuery({
    queryKey: ['/api/patients', patientId, 'games'],
    retry: 3,
    retryDelay: 1000,
  });

  const { data: activeGames = [] } = useQuery({
    queryKey: ['/api/patients', patientId, 'games', 'active'],
    retry: 2,
  });

  const startGameMutation = useMutation({
    mutationFn: async ({ gameType, difficulty }: { gameType: string; difficulty: string }) => {
      try {
        const response = await apiRequest('POST', `/api/games`, {
          patientId,
          gameType,
          difficulty,
          gameName: `${gameType.charAt(0).toUpperCase() + gameType.slice(1)} Game`,
        });
        return await response.json();
      } catch (error) {
        console.error('Failed to start game:', error);
        throw error;
      }
    },
    onSuccess: (data: GameActivity) => {
      setCurrentGame(data);
      setGameError(null);
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'games'] });
    },
    onError: (error: any) => {
      setGameError(error.message || 'Failed to start game');
    },
  });

  const makeMoveMutation = useMutation({
    mutationFn: async ({ gameId, move }: { gameId: number; move: any }) => {
      const response = await apiRequest('POST', `/api/games/${gameId}/move`, { move });
      return await response.json();
    },
    onSuccess: (data: { game: GameActivity }) => {
      setCurrentGame(data.game);
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'games'] });
    },
    onError: (error: any) => {
      setGameError(error.message || 'Failed to make move');
    },
  });

  const handleStartGame = () => {
    startGameMutation.mutate({ gameType: selectedGame, difficulty });
  };

  const handleMove = (move: any) => {
    if (currentGame) {
      makeMoveMutation.mutate({ gameId: currentGame.id, move });
    }
  };

  const renderGameInterface = () => {
    if (!currentGame) return null;

    switch (currentGame.gameType) {
      case 'chess':
        return (
          <ChessBoard
            gameState={currentGame.gameState}
            onMove={handleMove}
            isPlayerTurn={currentGame.status === 'active'}
          />
        );
      case 'memory':
        return (
          <MemoryGame
            gameState={currentGame.gameState}
            onMove={handleMove}
          />
        );
      case 'solitaire':
        return (
          <SolitaireGame
            gameState={currentGame.gameState}
            onMove={handleMove}
          />
        );
      case 'rummy':
        return (
          <RummyGame
            gameState={currentGame.gameState}
            onMove={handleMove}
          />
        );
      case 'puzzle':
      case 'pattern-matching':
        return (
          <PatternGame
            gameState={currentGame.gameState}
            onMove={handleMove}
          />
        );
      default:
        return (
          <div className="bg-white p-8 rounded-lg shadow-lg text-center">
            <Gamepad2 className="mx-auto h-16 w-16 text-gray-400 mb-4" />
            <p className="text-gray-600">Game type not supported yet</p>
          </div>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Game Selection */}
      <Card className="border-2 border-blue-200 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
          <CardTitle className="flex items-center text-2xl text-blue-900">
            <Brain className="mr-3 h-8 w-8" />
            AI Gaming Platform
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-6">
            {[
              { id: 'chess', name: 'Chess', icon: '♔', desc: 'Strategic thinking' },
              { id: 'memory', name: 'Memory Match', icon: '🧠', desc: 'Memory training' },
              { id: 'solitaire', name: 'Solitaire', icon: '♠', desc: 'Classic card game' },
              { id: 'rummy', name: 'Gin Rummy', icon: '🃏', desc: 'Card matching' },
              { id: 'puzzle', name: 'Pattern Puzzle', icon: '🧩', desc: 'Pattern recognition' }
            ].map((game) => (
              <Card
                key={game.id}
                className={`cursor-pointer transition-all duration-200 hover:shadow-lg transform hover:scale-105 ${
                  selectedGame === game.id
                    ? 'ring-4 ring-blue-500 bg-blue-50'
                    : 'hover:bg-gray-50'
                }`}
                onClick={() => setSelectedGame(game.id)}
              >
                <CardContent className="p-4 text-center">
                  <div className="text-4xl mb-2">{game.icon}</div>
                  <h3 className="font-bold text-lg">{game.name}</h3>
                  <p className="text-sm text-gray-600">{game.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
            <div className="flex items-center gap-4">
              <label className="font-medium">Difficulty:</label>
              <div className="flex gap-2">
                {['easy', 'medium', 'hard'].map((level) => (
                  <Button
                    key={level}
                    variant={difficulty === level ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setDifficulty(level)}
                    className="capitalize"
                  >
                    {level}
                  </Button>
                ))}
              </div>
            </div>
            
            <Button
              onClick={handleStartGame}
              disabled={startGameMutation.isPending}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-2 text-lg"
            >
              {startGameMutation.isPending ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Starting...
                </>
              ) : (
                <>
                  <Play className="mr-2 h-4 w-4" />
                  Start Game
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Error Display */}
      {gameError && (
        <Alert className="border-red-200 bg-red-50">
          <AlertDescription className="text-red-800">
            {gameError}
          </AlertDescription>
        </Alert>
      )}

      {/* Game Interface */}
      {currentGame && (
        <Card className="border-2 border-green-200 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50">
            <CardTitle className="flex items-center justify-between text-xl text-green-900">
              <span className="flex items-center">
                <Trophy className="mr-2 h-6 w-6" />
                {currentGame.gameName}
              </span>
              <Badge variant="outline" className="text-lg px-3 py-1">
                {currentGame.difficulty}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {renderGameInterface()}
            
            {/* Game Stats */}
            <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-3 bg-blue-50 rounded-lg">
                <Clock className="mx-auto h-6 w-6 text-blue-600 mb-1" />
                <div className="text-sm text-gray-600">Duration</div>
                <div className="font-bold">
                  {currentGame.startTime ? 
                    Math.floor((Date.now() - new Date(currentGame.startTime).getTime()) / 60000) + 'm' 
                    : '0m'
                  }
                </div>
              </div>
              <div className="text-center p-3 bg-green-50 rounded-lg">
                <Target className="mx-auto h-6 w-6 text-green-600 mb-1" />
                <div className="text-sm text-gray-600">Status</div>
                <div className="font-bold capitalize">{currentGame.status}</div>
              </div>
              <div className="text-center p-3 bg-purple-50 rounded-lg">
                <Brain className="mx-auto h-6 w-6 text-purple-600 mb-1" />
                <div className="text-sm text-gray-600">Score</div>
                <div className="font-bold">{currentGame.cognitiveScore || 0}</div>
              </div>
              <div className="text-center p-3 bg-yellow-50 rounded-lg">
                <Gamepad2 className="mx-auto h-6 w-6 text-yellow-600 mb-1" />
                <div className="text-sm text-gray-600">Moves</div>
                <div className="font-bold">{currentGame.playerMoves?.length || 0}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Games */}
      {games.length > 0 && (
        <Card className="border-2 border-gray-200 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center text-xl">
              <Trophy className="mr-2 h-6 w-6" />
              Recent Games
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {Array.isArray(games) && games.slice(0, 5).map((game: any) => (
                <div key={game.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <div className="font-medium">{game.gameName || 'Game'}</div>
                    <div className="text-sm text-gray-600 capitalize">
                      {game.difficulty || 'medium'} • {game.status || 'completed'}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-lg">{game.cognitiveScore || 0}</div>
                    <div className="text-sm text-gray-600">Score</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}