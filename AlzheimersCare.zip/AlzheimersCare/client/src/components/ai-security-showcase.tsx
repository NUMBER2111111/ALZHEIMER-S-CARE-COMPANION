import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Shield, 
  Lock, 
  Eye, 
  AlertTriangle, 
  CheckCircle, 
  Camera, 
  Wifi, 
  Brain,
  UserCheck,
  Clock,
  Activity,
  Home,
  Phone,
  Zap,
  Monitor
} from 'lucide-react';

interface SecurityFeature {
  name: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  status: 'active' | 'monitoring' | 'alert';
  details: string[];
  coverage: number;
}

interface ThreatAlert {
  id: string;
  type: 'intrusion' | 'medical' | 'behavioral' | 'system';
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  timestamp: Date;
  resolved: boolean;
  autoResolved?: boolean;
}

export function AISecurityShowcase() {
  const [activeTab, setActiveTab] = useState('overview');
  const [securityLevel, setSecurityLevel] = useState(98);

  const securityFeatures: SecurityFeature[] = [
    {
      name: "AI Behavioral Analysis",
      description: "Continuous monitoring of patient behavior patterns for anomaly detection",
      icon: Brain,
      status: 'active',
      details: [
        "24/7 movement pattern analysis",
        "Cognitive decline early detection",
        "Wandering prevention alerts",
        "Fall risk assessment",
        "Medication adherence monitoring"
      ],
      coverage: 95
    },
    {
      name: "Perimeter Security AI",
      description: "Smart home boundary monitoring with facial recognition",
      icon: Eye,
      status: 'monitoring',
      details: [
        "Authorized visitor recognition",
        "Stranger intrusion alerts",
        "Door/window monitoring",
        "Safe zone enforcement",
        "Emergency exit detection"
      ],
      coverage: 88
    },
    {
      name: "Medical Emergency AI",
      description: "Real-time health crisis detection and response",
      icon: Activity,
      status: 'active',
      details: [
        "Heart rate anomaly detection",
        "Fall detection with 99% accuracy",
        "Speech pattern analysis",
        "Medication emergency alerts",
        "Automatic 911 calling"
      ],
      coverage: 99
    },
    {
      name: "Voice Security System",
      description: "AI-powered voice authentication and distress detection",
      icon: UserCheck,
      status: 'active',
      details: [
        "Voice biometric authentication",
        "Distress keyword detection",
        "Emotional state monitoring",
        "Unauthorized voice alerts",
        "Emergency phrase recognition"
      ],
      coverage: 92
    },
    {
      name: "Smart Device Protection",
      description: "IoT device security and privacy protection",
      icon: Shield,
      status: 'monitoring',
      details: [
        "End-to-end encryption",
        "Device authentication",
        "Network intrusion prevention",
        "Data privacy compliance",
        "Secure remote access"
      ],
      coverage: 96
    },
    {
      name: "Family Communication Security",
      description: "Encrypted family connection with verification",
      icon: Phone,
      status: 'active',
      details: [
        "Secure video calling",
        "Identity verification",
        "Communication monitoring",
        "Emergency family alerts",
        "Privacy protection"
      ],
      coverage: 94
    }
  ];

  const recentAlerts: ThreatAlert[] = [
    {
      id: '1',
      type: 'medical',
      severity: 'high',
      message: 'Heart rate anomaly detected - Emergency response initiated',
      timestamp: new Date(Date.now() - 2 * 60 * 1000),
      resolved: true,
      autoResolved: true
    },
    {
      id: '2',
      type: 'behavioral',
      severity: 'medium',
      message: 'Unusual movement pattern - Night wandering detected',
      timestamp: new Date(Date.now() - 45 * 60 * 1000),
      resolved: true
    },
    {
      id: '3',
      type: 'intrusion',
      severity: 'low',
      message: 'Unknown visitor at front door - Family notified',
      timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
      resolved: true
    },
    {
      id: '4',
      type: 'system',
      severity: 'low',
      message: 'Device firmware updated - Security enhanced',
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
      resolved: true,
      autoResolved: true
    }
  ];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'text-red-600 bg-red-100';
      case 'high': return 'text-orange-600 bg-orange-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-blue-600 bg-blue-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-600 bg-green-100';
      case 'monitoring': return 'text-blue-600 bg-blue-100';
      case 'alert': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="space-y-6">
      {/* Security Overview Header */}
      <Card className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="h-8 w-8" />
              <div>
                <CardTitle className="text-2xl">AI Security Command Center</CardTitle>
                <p className="text-blue-100 mt-2">Advanced AI protection for at-home care</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold">{securityLevel}%</div>
              <div className="text-blue-100">Security Level</div>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Quick Security Status */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <div className="font-semibold text-green-600">All Systems Active</div>
                <div className="text-sm text-gray-600">6/6 Security Features</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <Eye className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <div className="font-semibold text-blue-600">24/7 Monitoring</div>
                <div className="text-sm text-gray-600">Continuous AI Watch</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-orange-600" />
              </div>
              <div>
                <div className="font-semibold text-orange-600">4 Alerts Today</div>
                <div className="text-sm text-gray-600">All Resolved</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                <Zap className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <div className="font-semibold text-purple-600">Sub-1s Response</div>
                <div className="text-sm text-gray-600">Emergency Detection</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 bg-white">
          <TabsTrigger value="overview">Security Features</TabsTrigger>
          <TabsTrigger value="alerts">Recent Alerts</TabsTrigger>
          <TabsTrigger value="analytics">AI Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {securityFeatures.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                          <Icon className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{feature.name}</CardTitle>
                          <Badge className={getStatusColor(feature.status)}>{feature.status}</Badge>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-blue-600">{feature.coverage}%</div>
                        <div className="text-xs text-gray-600">Coverage</div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">{feature.description}</p>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Security Coverage</span>
                        <span>{feature.coverage}%</span>
                      </div>
                      <Progress value={feature.coverage} className="h-2" />
                    </div>
                    <div className="mt-4">
                      <h4 className="font-medium mb-2">Key Features:</h4>
                      <ul className="text-sm text-gray-600 space-y-1">
                        {feature.details.map((detail, idx) => (
                          <li key={idx} className="flex items-center gap-2">
                            <CheckCircle className="h-3 w-3 text-green-500 flex-shrink-0" />
                            {detail}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="alerts">
          <Card>
            <CardHeader>
              <CardTitle>Recent Security Events</CardTitle>
              <p className="text-gray-600">AI-detected incidents and automatic responses</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentAlerts.map((alert) => (
                  <div key={alert.id} className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${getSeverityColor(alert.severity)}`}>
                      <AlertTriangle className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium">{alert.message}</span>
                        {alert.resolved && <CheckCircle className="h-4 w-4 text-green-500" />}
                        {alert.autoResolved && <Badge variant="outline" className="text-xs">Auto-Resolved</Badge>}
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span>Type: {alert.type}</span>
                        <span>Severity: {alert.severity}</span>
                        <span>Time: {alert.timestamp.toLocaleTimeString()}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>AI Detection Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Fall Detection Accuracy</span>
                    <span className="font-bold text-green-600">99.2%</span>
                  </div>
                  <Progress value={99.2} className="h-2" />
                  
                  <div className="flex justify-between items-center">
                    <span>Voice Recognition Rate</span>
                    <span className="font-bold text-blue-600">97.8%</span>
                  </div>
                  <Progress value={97.8} className="h-2" />
                  
                  <div className="flex justify-between items-center">
                    <span>Behavioral Pattern Match</span>
                    <span className="font-bold text-purple-600">94.5%</span>
                  </div>
                  <Progress value={94.5} className="h-2" />
                  
                  <div className="flex justify-between items-center">
                    <span>Emergency Response Time</span>
                    <span className="font-bold text-orange-600">0.8s</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Security Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-3xl font-bold text-green-600">0</div>
                    <div className="text-sm text-gray-600">Security Breaches</div>
                  </div>
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-3xl font-bold text-blue-600">24/7</div>
                    <div className="text-sm text-gray-600">AI Monitoring</div>
                  </div>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <div className="text-3xl font-bold text-purple-600">156</div>
                    <div className="text-sm text-gray-600">Lives Protected</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Key Benefits for At-Home Users */}
      <Card className="bg-gradient-to-r from-green-50 to-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Home className="h-5 w-5 text-green-600" />
            Why AI Security Matters for At-Home Care
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="font-semibold mb-2">Complete Protection</h3>
              <p className="text-sm text-gray-600">24/7 AI monitoring ensures immediate response to any emergency or security threat</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Brain className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="font-semibold mb-2">Intelligent Adaptation</h3>
              <p className="text-sm text-gray-600">AI learns patient patterns to reduce false alarms and improve accuracy over time</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <UserCheck className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="font-semibold mb-2">Family Peace of Mind</h3>
              <p className="text-sm text-gray-600">Real-time alerts and communication keep families connected and informed</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default AISecurityShowcase;