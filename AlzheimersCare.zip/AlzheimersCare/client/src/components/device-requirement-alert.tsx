import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  AlertCircle, 
  Smartphone, 
  Headphones, 
  Heart, 
  Camera, 
  Mic, 
  Watch, 
  Wifi, 
  Bluetooth,
  Monitor,
  Brain,
  Activity,
  Thermometer,
  Volume2
} from 'lucide-react';

interface DeviceSpec {
  name: string;
  icon: React.ComponentType<{ className?: string }>;
  purpose: string;
  requirements: string[];
  optional?: boolean;
  price?: string;
  compatibility: string[];
}

interface DeviceRequirementAlertProps {
  feature: string;
  devices: DeviceSpec[];
  onProceed?: () => void;
  onLearnMore?: () => void;
  showInline?: boolean;
}

const deviceSpecs: Record<string, DeviceSpec> = {
  microphone: {
    name: "High-Quality Microphone",
    icon: Mic,
    purpose: "Clear voice interaction with AI companion for conversation and emergency detection",
    requirements: [
      "Noise cancellation capability",
      "USB or 3.5mm connection", 
      "Frequency response: 20Hz-20kHz",
      "Compatible with Windows/Mac/Chrome"
    ],
    price: "$25-75",
    compatibility: ["Desktop", "Laptop", "Tablet"]
  },
  speakers: {
    name: "Quality Speakers or Headphones", 
    icon: Headphones,
    purpose: "Clear AI voice responses and audio alerts for medication reminders",
    requirements: [
      "Clear mid-range frequency response",
      "Volume control capability",
      "3.5mm or Bluetooth connection",
      "Comfortable for extended use"
    ],
    price: "$20-100",
    compatibility: ["Desktop", "Laptop", "Tablet", "Phone"]
  },
  camera: {
    name: "HD Webcam or Camera",
    icon: Camera, 
    purpose: "Photo memory analysis and family recognition for cognitive engagement",
    requirements: [
      "1080p HD resolution minimum",
      "Good low-light performance",
      "USB connection or built-in",
      "Privacy shutter recommended"
    ],
    price: "$30-150",
    compatibility: ["Desktop", "Laptop", "Tablet"]
  },
  heartRateMonitor: {
    name: "Heart Rate Monitor",
    icon: Heart,
    purpose: "Continuous vital signs monitoring for emergency detection and health tracking",
    requirements: [
      "Bluetooth 4.0+ connectivity",
      "FDA approved for medical use",
      "24/7 continuous monitoring",
      "Battery life 5+ days"
    ],
    price: "$50-200",
    compatibility: ["Chest strap", "Wearable device", "Smart watch"]
  },
  smartWatch: {
    name: "Smart Health Watch",
    icon: Watch,
    purpose: "Comprehensive health monitoring including heart rate, activity, and fall detection",
    requirements: [
      "Heart rate sensor",
      "Accelerometer for fall detection", 
      "Bluetooth connectivity",
      "Health app integration"
    ],
    price: "$100-400",
    compatibility: ["Apple Watch", "Fitbit", "Samsung Galaxy Watch", "Garmin"]
  },
  bloodPressureMonitor: {
    name: "Bluetooth Blood Pressure Monitor",
    icon: Activity,
    purpose: "Regular blood pressure tracking for cardiovascular health monitoring",
    requirements: [
      "FDA approved accuracy",
      "Bluetooth data transmission",
      "Appropriate cuff size",
      "Memory for multiple readings"
    ],
    price: "$40-120",
    compatibility: ["Arm cuff preferred", "Wrist monitors available"]
  },
  thermometer: {
    name: "Smart Thermometer",
    icon: Thermometer,
    purpose: "Temperature monitoring for health tracking and infection detection",
    requirements: [
      "Medical grade accuracy (±0.2°F)",
      "Bluetooth connectivity",
      "Fast reading (under 10 seconds)",
      "Fever alert capability"
    ],
    price: "$25-80",
    compatibility: ["Forehead", "Ear", "Oral digital"]
  },
  tablet: {
    name: "Healthcare Tablet",
    icon: Monitor,
    purpose: "Primary interface for Care Companion with large, clear display for easy interaction",
    requirements: [
      "10+ inch screen size",
      "Touch screen capability",
      "WiFi connectivity",
      "Front-facing camera",
      "Good speakers/headphone jack"
    ],
    price: "$150-500",
    compatibility: ["iPad", "Android tablet", "Windows tablet"]
  }
};

export function DeviceRequirementAlert({ 
  feature, 
  devices, 
  onProceed, 
  onLearnMore,
  showInline = false 
}: DeviceRequirementAlertProps) {
  const requiredDevices = devices.filter(d => !d.optional);
  const optionalDevices = devices.filter(d => d.optional);

  if (showInline) {
    return (
      <Card className="border-amber-200 bg-amber-50">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-amber-800">
            <AlertCircle className="h-5 w-5" />
            Device Requirements for {feature}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {requiredDevices.length > 0 && (
            <div>
              <h4 className="font-medium text-amber-800 mb-2">Required Devices:</h4>
              <div className="grid gap-2">
                {requiredDevices.map((device, index) => {
                  const Icon = device.icon;
                  return (
                    <div key={index} className="flex items-start gap-3 p-3 bg-white rounded-lg border">
                      <Icon className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-gray-900">{device.name}</span>
                          <Badge variant="secondary" className="text-xs">{device.price}</Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{device.purpose}</p>
                        <div className="text-xs text-gray-500">
                          Compatible: {device.compatibility.join(", ")}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {optionalDevices.length > 0 && (
            <div>
              <h4 className="font-medium text-amber-800 mb-2">Optional Enhancements:</h4>
              <div className="grid gap-2">
                {optionalDevices.map((device, index) => {
                  const Icon = device.icon;
                  return (
                    <div key={index} className="flex items-start gap-3 p-3 bg-white/70 rounded-lg border border-dashed">
                      <Icon className="h-5 w-5 text-gray-500 mt-0.5 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-gray-700">{device.name}</span>
                          <Badge variant="outline" className="text-xs">Optional</Badge>
                          <Badge variant="secondary" className="text-xs">{device.price}</Badge>
                        </div>
                        <p className="text-sm text-gray-600">{device.purpose}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          <div className="flex gap-2 pt-2">
            {onLearnMore && (
              <Button variant="outline" size="sm" onClick={onLearnMore}>
                View Device Guide
              </Button>
            )}
            {onProceed && (
              <Button size="sm" onClick={onProceed}>
                I Have These Devices
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Alert className="border-amber-200 bg-amber-50">
      <AlertCircle className="h-4 w-4 text-amber-600" />
      <AlertTitle className="text-amber-800">Device Requirements for {feature}</AlertTitle>
      <AlertDescription className="text-amber-700 mt-2">
        <div className="space-y-3">
          <p>This feature requires specific devices for optimal functionality:</p>
          
          {requiredDevices.length > 0 && (
            <div>
              <strong>Required:</strong>
              <ul className="list-disc list-inside mt-1 space-y-1">
                {requiredDevices.map((device, index) => (
                  <li key={index} className="text-sm">
                    <strong>{device.name}</strong> - {device.purpose}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {optionalDevices.length > 0 && (
            <div>
              <strong>Optional Enhancements:</strong>
              <ul className="list-disc list-inside mt-1 space-y-1">
                {optionalDevices.map((device, index) => (
                  <li key={index} className="text-sm">
                    <strong>{device.name}</strong> - {device.purpose}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="flex gap-2 mt-4">
            {onLearnMore && (
              <Button variant="outline" size="sm" onClick={onLearnMore}>
                Learn More About Devices
              </Button>
            )}
            {onProceed && (
              <Button size="sm" onClick={onProceed}>
                Continue Anyway
              </Button>
            )}
          </div>
        </div>
      </AlertDescription>
    </Alert>
  );
}

// Helper function to get device specs
export function getDeviceSpecs(deviceKeys: string[]): DeviceSpec[] {
  return deviceKeys.map(key => deviceSpecs[key]).filter(Boolean);
}

// Predefined device combinations for common features
export const featureDeviceRequirements = {
  voiceInteraction: ['microphone', 'speakers'],
  photoMemoryAnalysis: ['camera'],
  vitalSigns: ['heartRateMonitor', 'bloodPressureMonitor', 'thermometer'],
  emergencyMonitoring: ['smartWatch', 'microphone', 'speakers'],
  patientCompanion: ['tablet', 'microphone', 'speakers'],
  cognitiveAssessment: ['microphone', 'speakers', 'camera'],
  medicationReminders: ['speakers', 'smartWatch'],
  fallDetection: ['smartWatch'],
  telemedicine: ['camera', 'microphone', 'speakers'],
  audioGuide: ['speakers']
};

export { deviceSpecs };