import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Heart, Brain, Battery, Shield, Users, Smile, MessageCircle, Send, Sparkles } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQuery } from "@tanstack/react-query";

interface MoodEntry {
  id: number;
  patientId: number;
  moodLevel: number;
  emotionalState: string;
  energy: number;
  anxiety: number;
  socialConnection: number;
  physicalComfort: number;
  cognitiveClarity: number;
  notes?: string;
  createdAt: Date;
}

interface CompanionResponse {
  id: number;
  responseContent: string;
  responseType: string;
  empathyLevel: string;
  aiInsights?: string;
  responseActions?: string[];
  wasDelivered: boolean;
  createdAt: Date;
}

interface MoodTrackerProps {
  patientId: number;
}

export default function MoodTracker({ patientId }: MoodTrackerProps) {
  const { toast } = useToast();
  const [moodLevel, setMoodLevel] = useState([5]);
  const [energy, setEnergy] = useState([5]);
  const [anxiety, setAnxiety] = useState([3]);
  const [socialConnection, setSocialConnection] = useState([7]);
  const [physicalComfort, setPhysicalComfort] = useState([7]);
  const [cognitiveClarity, setCognitiveClarity] = useState([6]);
  const [emotionalState, setEmotionalState] = useState("neutral");
  const [notes, setNotes] = useState("");
  const [showCompanionResponse, setShowCompanionResponse] = useState(false);
  const [companionResponse, setCompanionResponse] = useState<CompanionResponse | null>(null);

  const emotionalStates = [
    { value: "joyful", label: "Joyful", color: "bg-yellow-100 text-yellow-800" },
    { value: "content", label: "Content", color: "bg-green-100 text-green-800" },
    { value: "neutral", label: "Neutral", color: "bg-gray-100 text-gray-800" },
    { value: "sad", label: "Sad", color: "bg-blue-100 text-blue-800" },
    { value: "anxious", label: "Anxious", color: "bg-orange-100 text-orange-800" },
    { value: "frustrated", label: "Frustrated", color: "bg-red-100 text-red-800" },
    { value: "confused", label: "Confused", color: "bg-purple-100 text-purple-800" },
    { value: "peaceful", label: "Peaceful", color: "bg-teal-100 text-teal-800" }
  ];

  // Get latest mood entry
  const { data: latestMood } = useQuery({
    queryKey: [`/api/mood/latest/${patientId}`],
  });

  // Submit mood entry mutation
  const submitMoodMutation = useMutation({
    mutationFn: async (moodData: any) => {
      return await apiRequest("POST", "/api/mood/entry", moodData);
    },
    onSuccess: (data) => {
      toast({
        title: "Mood Entry Saved",
        description: "Your AI companion is preparing a personalized response.",
      });
      
      if (data.companionResponse) {
        setCompanionResponse(data.companionResponse);
        setShowCompanionResponse(true);
      }
      
      // Reset form
      setMoodLevel([5]);
      setEnergy([5]);
      setAnxiety([3]);
      setSocialConnection([7]);
      setPhysicalComfort([7]);
      setCognitiveClarity([6]);
      setEmotionalState("neutral");
      setNotes("");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to save mood entry. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Mark companion response as delivered
  const markDeliveredMutation = useMutation({
    mutationFn: async ({ responseId, reaction }: { responseId: number, reaction?: string }) => {
      return await apiRequest("POST", `/api/mood/response/${responseId}/delivered`, { reaction });
    },
    onSuccess: () => {
      setShowCompanionResponse(false);
      setCompanionResponse(null);
    },
  });

  const handleSubmitMood = () => {
    const moodData = {
      patientId,
      moodLevel: moodLevel[0],
      emotionalState,
      energy: energy[0],
      anxiety: anxiety[0],
      socialConnection: socialConnection[0],
      physicalComfort: physicalComfort[0],
      cognitiveClarity: cognitiveClarity[0],
      notes: notes.trim() || null,
      inputMethod: "manual"
    };

    submitMoodMutation.mutate(moodData);
  };

  const handleCompanionReaction = (reaction: string) => {
    if (companionResponse) {
      markDeliveredMutation.mutate({ 
        responseId: companionResponse.id, 
        reaction 
      });
    }
  };

  const getMoodColor = (level: number) => {
    if (level <= 3) return "text-red-600";
    if (level <= 5) return "text-orange-600";
    if (level <= 7) return "text-yellow-600";
    return "text-green-600";
  };

  const getEmpathyBadgeColor = (level: string) => {
    switch (level) {
      case 'very_high': return "bg-purple-100 text-purple-800";
      case 'high': return "bg-blue-100 text-blue-800";
      case 'moderate': return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="space-y-6">
      {/* Companion Response Display */}
      {showCompanionResponse && companionResponse && (
        <Card className="border-l-4 border-l-blue-500 bg-gradient-to-r from-blue-50 to-purple-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-900">
              <Heart className="h-5 w-5 text-red-500" />
              Your AI Companion Response
              <Badge className={getEmpathyBadgeColor(companionResponse.empathyLevel)}>
                {companionResponse.empathyLevel.replace('_', ' ')} empathy
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-white rounded-lg border">
              <p className="text-gray-800 leading-relaxed">{companionResponse.responseContent}</p>
            </div>
            
            {companionResponse.responseActions && companionResponse.responseActions.length > 0 && (
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Suggested Actions:</h4>
                <ul className="space-y-1">
                  {companionResponse.responseActions.map((action, index) => (
                    <li key={index} className="flex items-center gap-2 text-sm text-gray-700">
                      <Sparkles className="h-3 w-3 text-blue-500" />
                      {action}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            
            <div className="flex gap-2 pt-4 border-t">
              <Button 
                onClick={() => handleCompanionReaction("helpful")}
                variant="outline" 
                size="sm"
                className="text-green-600 border-green-200 hover:bg-green-50"
              >
                <Smile className="h-4 w-4 mr-1" />
                Helpful
              </Button>
              <Button 
                onClick={() => handleCompanionReaction("comforting")}
                variant="outline" 
                size="sm"
                className="text-blue-600 border-blue-200 hover:bg-blue-50"
              >
                <Heart className="h-4 w-4 mr-1" />
                Comforting
              </Button>
              <Button 
                onClick={() => handleCompanionReaction("understood")}
                variant="outline" 
                size="sm"
                className="text-purple-600 border-purple-200 hover:bg-purple-50"
              >
                <Brain className="h-4 w-4 mr-1" />
                Understood
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Mood Entry Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="h-5 w-5 text-blue-600" />
            How are you feeling today?
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Overall Mood Level */}
          <div className="space-y-3">
            <label className="text-sm font-medium">Overall Mood Level</label>
            <div className="px-4">
              <Slider
                value={moodLevel}
                onValueChange={setMoodLevel}
                max={10}
                min={1}
                step={1}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Very Low</span>
                <span className={`font-semibold ${getMoodColor(moodLevel[0])}`}>
                  {moodLevel[0]}/10
                </span>
                <span>Very High</span>
              </div>
            </div>
          </div>

          <Separator />

          {/* Emotional State Selection */}
          <div className="space-y-3">
            <label className="text-sm font-medium">How would you describe your emotional state?</label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {emotionalStates.map((state) => (
                <Button
                  key={state.value}
                  variant={emotionalState === state.value ? "default" : "outline"}
                  size="sm"
                  onClick={() => setEmotionalState(state.value)}
                  className={emotionalState === state.value ? "" : "border-gray-200"}
                >
                  {state.label}
                </Button>
              ))}
            </div>
          </div>

          <Separator />

          {/* Detailed Metrics */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <Battery className="h-4 w-4 text-green-600" />
                  Energy Level
                </label>
                <Slider
                  value={energy}
                  onValueChange={setEnergy}
                  max={10}
                  min={1}
                  step={1}
                />
                <div className="text-xs text-gray-500 text-center">{energy[0]}/10</div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <Shield className="h-4 w-4 text-orange-600" />
                  Anxiety Level
                </label>
                <Slider
                  value={anxiety}
                  onValueChange={setAnxiety}
                  max={10}
                  min={1}
                  step={1}
                />
                <div className="text-xs text-gray-500 text-center">{anxiety[0]}/10</div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <Users className="h-4 w-4 text-blue-600" />
                  Social Connection
                </label>
                <Slider
                  value={socialConnection}
                  onValueChange={setSocialConnection}
                  max={10}
                  min={1}
                  step={1}
                />
                <div className="text-xs text-gray-500 text-center">{socialConnection[0]}/10</div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <Heart className="h-4 w-4 text-red-600" />
                  Physical Comfort
                </label>
                <Slider
                  value={physicalComfort}
                  onValueChange={setPhysicalComfort}
                  max={10}
                  min={1}
                  step={1}
                />
                <div className="text-xs text-gray-500 text-center">{physicalComfort[0]}/10</div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <Brain className="h-4 w-4 text-purple-600" />
                  Mental Clarity
                </label>
                <Slider
                  value={cognitiveClarity}
                  onValueChange={setCognitiveClarity}
                  max={10}
                  min={1}
                  step={1}
                />
                <div className="text-xs text-gray-500 text-center">{cognitiveClarity[0]}/10</div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Notes */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Additional Notes (Optional)</label>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Share anything else about how you're feeling today..."
              className="min-h-[100px]"
            />
          </div>

          {/* Submit Button */}
          <Button 
            onClick={handleSubmitMood}
            disabled={submitMoodMutation.isPending}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white"
          >
            {submitMoodMutation.isPending ? (
              "Saving..."
            ) : (
              <>
                <Send className="h-4 w-4 mr-2" />
                Share with AI Companion
              </>
            )}
          </Button>

          {/* Latest Entry Display */}
          {latestMood?.latestEntry && (
            <div className="mt-4 p-3 bg-gray-50 rounded-lg">
              <p className="text-xs text-gray-600">
                Last entry: {new Date(latestMood.latestEntry.createdAt).toLocaleDateString()} - 
                Mood: {latestMood.latestEntry.moodLevel}/10, 
                State: {latestMood.latestEntry.emotionalState}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}