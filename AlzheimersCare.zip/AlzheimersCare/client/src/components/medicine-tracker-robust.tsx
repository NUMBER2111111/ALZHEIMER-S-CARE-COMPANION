import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Pill, Clock, AlertTriangle, CheckCircle, Calendar } from 'lucide-react';

interface Medication {
  id: number;
  name: string;
  dosage: string;
  frequency: string;
  timeSlots: string[] | null;
  instructions: string | null;
  isActive: boolean;
  createdAt: string;
}

interface MedicationLog {
  id: number;
  medicationId: number;
  scheduledTime: string;
  actualTime: string | null;
  status: string;
  notes: string | null;
  createdAt: string;
  medication?: Medication;
}

interface MedicationAnalysis {
  adherenceScore: number;
  riskFactors: string[];
  recommendations: string[];
  missedDoses: number;
  totalDoses: number;
}

interface MedicineTrackerProps {
  patientId: number;
}

export function MedicineTracker({ patientId }: MedicineTrackerProps) {
  const [selectedMedication, setSelectedMedication] = useState<number | null>(null);

  // Robust data fetching with comprehensive error handling
  const { data: medications = [], isLoading: medicationsLoading, error: medicationsError } = useQuery({
    queryKey: ['/api/patients', patientId, 'medications'],
    retry: 3,
    retryDelay: 1000,
  });

  const { data: medicationLogs = [], isLoading: logsLoading } = useQuery({
    queryKey: ['/api/patients', patientId, 'medication-logs'],
    retry: 3,
  });

  const { data: missedMedications = [], isLoading: missedLoading } = useQuery({
    queryKey: ['/api/patients', patientId, 'missed-medications'],
    retry: 2,
  });

  // AI Analysis with error handling
  const { data: aiAnalysis, isLoading: analysisLoading, error: analysisError } = useQuery({
    queryKey: ['/api/patients', patientId, 'medication-analysis'],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/patients/${patientId}/medication-analysis`);
        if (!response.ok) {
          if (response.status === 404) {
            return null; // No analysis available yet
          }
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        return response.json();
      } catch (error) {
        console.error('Failed to fetch medication analysis:', error);
        return null;
      }
    },
    retry: 2,
  });

  // Robust medication log mutation
  const logMedicationMutation = useMutation({
    mutationFn: async ({ medicationId, status, notes }: { medicationId: number; status: string; notes?: string }) => {
      try {
        return await apiRequest('POST', `/api/patients/${patientId}/medication-logs`, {
          medicationId,
          status,
          notes: notes || null,
          actualTime: new Date().toISOString(),
        });
      } catch (error) {
        console.error('Failed to log medication:', error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'medication-logs'] });
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'missed-medications'] });
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'medication-analysis'] });
    },
    onError: (error) => {
      console.error('Log medication failed:', error);
    },
  });

  // Add medication mutation with validation
  const addMedicationMutation = useMutation({
    mutationFn: async (medicationData: Partial<Medication>) => {
      try {
        // Validate required fields
        if (!medicationData.name || !medicationData.dosage || !medicationData.frequency) {
          throw new Error('Name, dosage, and frequency are required');
        }
        
        return await apiRequest('POST', `/api/patients/${patientId}/medications`, {
          ...medicationData,
          isActive: true,
        });
      } catch (error) {
        console.error('Failed to add medication:', error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'medications'] });
    },
  });

  // Get medication adherence with null safety
  const getMedicationAdherence = (medication: any): number => {
    if (!medication || !Array.isArray(medicationLogs)) return 0;
    
    const medicationLogEntries = medicationLogs.filter((log: any) => 
      log && log.medicationId === medication.id
    );
    
    if (medicationLogEntries.length === 0) return 0;
    
    const takenLogs = medicationLogEntries.filter((log: any) => 
      log && log.status === 'taken'
    );
    
    return Math.round((takenLogs.length / medicationLogEntries.length) * 100);
  };

  // Get next dose time with error handling
  const getNextDoseTime = (medication: any): string => {
    if (!medication || !medication.timeSlots || !Array.isArray(medication.timeSlots)) {
      return 'Not scheduled';
    }
    
    try {
      const now = new Date();
      const currentTime = now.getHours() * 60 + now.getMinutes();
      
      const nextSlot = medication.timeSlots
        .map((slot: string) => {
          const [hours, minutes] = slot.split(':').map(Number);
          return hours * 60 + minutes;
        })
        .find((slotTime: number) => slotTime > currentTime);
      
      if (nextSlot) {
        const hours = Math.floor(nextSlot / 60);
        const minutes = nextSlot % 60;
        return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
      }
      
      // Next dose is tomorrow
      const firstSlot = medication.timeSlots[0];
      return `Tomorrow at ${firstSlot}`;
    } catch (error) {
      console.error('Error calculating next dose time:', error);
      return 'Schedule error';
    }
  };

  // Render medications with comprehensive error handling
  const renderMedications = () => {
    if (medicationsLoading) {
      return <div className="text-sm text-gray-500">Loading medications...</div>;
    }

    if (medicationsError) {
      return <div className="text-sm text-red-500">Error loading medications</div>;
    }

    if (!Array.isArray(medications) || medications.length === 0) {
      return <div className="text-sm text-gray-500">No medications prescribed</div>;
    }

    return medications.map((medication: any, index: number) => {
      if (!medication || typeof medication !== 'object') {
        return <div key={index} className="text-sm text-gray-400">Invalid medication data</div>;
      }

      const adherence = getMedicationAdherence(medication);
      const nextDose = getNextDoseTime(medication);

      return (
        <Card key={medication.id || index} className="border-l-4 border-l-blue-500">
          <CardHeader className="pb-3">
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-base">{medication.name || 'Unknown Medication'}</CardTitle>
                <p className="text-sm text-gray-500 mt-1">
                  {medication.dosage || 'Unknown dosage'} - {medication.frequency || 'Unknown frequency'}
                </p>
              </div>
              <Badge variant={medication.isActive ? 'default' : 'secondary'}>
                {medication.isActive ? 'Active' : 'Inactive'}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm">Adherence Rate</span>
              <div className="flex items-center gap-2">
                <Progress value={adherence} className="w-20" />
                <span className="text-sm font-medium">{adherence}%</span>
              </div>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-sm">Next Dose</span>
              <span className="text-sm font-medium">{nextDose}</span>
            </div>
            
            {medication.instructions && (
              <div className="text-xs text-gray-600 bg-gray-50 p-2 rounded">
                {medication.instructions}
              </div>
            )}
            
            <div className="flex gap-2 pt-2">
              <Button
                size="sm"
                onClick={() => logMedicationMutation.mutate({ 
                  medicationId: medication.id, 
                  status: 'taken' 
                })}
                disabled={logMedicationMutation.isPending}
                className="flex-1"
              >
                <CheckCircle className="h-4 w-4 mr-1" />
                {logMedicationMutation.isPending ? 'Logging...' : 'Mark Taken'}
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => logMedicationMutation.mutate({ 
                  medicationId: medication.id, 
                  status: 'missed', 
                  notes: 'Patient reported missed dose' 
                })}
                disabled={logMedicationMutation.isPending}
              >
                <AlertTriangle className="h-4 w-4 mr-1" />
                Missed
              </Button>
            </div>
          </CardContent>
        </Card>
      );
    });
  };

  // Render AI analysis with error handling
  const renderAIAnalysis = () => {
    if (analysisLoading) {
      return <div className="text-sm text-gray-500">Analyzing medication patterns...</div>;
    }

    if (analysisError) {
      return <div className="text-sm text-red-500">Error loading analysis</div>;
    }

    if (!aiAnalysis || typeof aiAnalysis !== 'object') {
      return <div className="text-sm text-gray-500">No analysis available yet</div>;
    }

    const analysis = aiAnalysis as MedicationAnalysis;

    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <span className="text-sm font-medium">Overall Adherence</span>
          <div className="flex items-center gap-2">
            <Progress value={analysis.adherenceScore || 0} className="w-24" />
            <Badge variant={
              (analysis.adherenceScore || 0) >= 80 ? 'default' : 
              (analysis.adherenceScore || 0) >= 60 ? 'secondary' : 'destructive'
            }>
              {Math.round(analysis.adherenceScore || 0)}%
            </Badge>
          </div>
        </div>

        {Array.isArray(analysis.riskFactors) && analysis.riskFactors.length > 0 && (
          <div>
            <h4 className="text-sm font-medium mb-2">Risk Factors</h4>
            <div className="space-y-1">
              {analysis.riskFactors.map((factor: string, index: number) => (
                <Alert key={index} className="border-yellow-200 bg-yellow-50">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription className="text-yellow-800">
                    {factor || 'Unknown risk factor'}
                  </AlertDescription>
                </Alert>
              ))}
            </div>
          </div>
        )}

        {Array.isArray(analysis.recommendations) && analysis.recommendations.length > 0 && (
          <div>
            <h4 className="text-sm font-medium mb-2">AI Recommendations</h4>
            <div className="space-y-1">
              {analysis.recommendations.map((rec: string, index: number) => (
                <div key={index} className="text-sm text-blue-700 bg-blue-50 p-2 rounded">
                  {rec || 'No recommendation available'}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  };

  // Render missed medications with error handling
  const renderMissedMedications = () => {
    if (missedLoading) {
      return <div className="text-sm text-gray-500">Loading missed medications...</div>;
    }

    if (!Array.isArray(missedMedications) || missedMedications.length === 0) {
      return <div className="text-sm text-green-600">No missed medications</div>;
    }

    return missedMedications.slice(0, 5).map((missed: any, index: number) => {
      if (!missed || typeof missed !== 'object') {
        return <div key={index} className="text-sm text-gray-400">Invalid data</div>;
      }

      return (
        <div key={missed.id || index} className="flex justify-between items-center p-2 bg-red-50 rounded">
          <div>
            <div className="font-medium text-sm">
              {missed.medication?.name || 'Unknown Medication'}
            </div>
            <div className="text-xs text-gray-500">
              Scheduled: {missed.scheduledTime ? new Date(missed.scheduledTime).toLocaleString() : 'Unknown time'}
            </div>
          </div>
          <Badge variant="destructive">Missed</Badge>
        </div>
      );
    });
  };

  return (
    <div className="space-y-6">
      {/* Current Medications */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Pill className="h-5 w-5" />
            Current Medications
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {renderMedications()}
        </CardContent>
      </Card>

      {/* AI Analysis */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Medication Insights</CardTitle>
        </CardHeader>
        <CardContent>
          {renderAIAnalysis()}
        </CardContent>
      </Card>

      {/* Missed Medications */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Clock className="h-5 w-5 text-red-500" />
            Recent Missed Doses
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {renderMissedMedications()}
        </CardContent>
      </Card>

      {/* Quick Add Medication */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <Button
            onClick={() => addMedicationMutation.mutate({
              name: 'Sample Medication',
              dosage: '10mg',
              frequency: 'Twice daily',
              timeSlots: ['08:00', '20:00'],
              instructions: 'Take with food',
            })}
            disabled={addMedicationMutation.isPending}
            className="w-full"
          >
            {addMedicationMutation.isPending ? 'Adding...' : 'Add Sample Medication'}
          </Button>
          <p className="text-xs text-gray-500 mt-2">
            This adds a sample medication for testing the medication tracking system
          </p>
        </CardContent>
      </Card>
    </div>
  );
}