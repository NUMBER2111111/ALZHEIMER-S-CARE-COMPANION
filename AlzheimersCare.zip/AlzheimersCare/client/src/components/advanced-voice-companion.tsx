import { useState, useEffect, useRef, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { useAdvancedVoice } from '@/hooks/useAdvancedVoice';
import { apiRequest } from '@/lib/queryClient';
import { Mic, MicOff, Volume2, VolumeX, Activity, Heart, Brain, AlertTriangle } from 'lucide-react';

interface VoiceAnalysis {
  emotionalState: {
    primary: string;
    intensity: number;
    confidence: number;
  };
  cognitiveMarkers: {
    clarity: number;
    coherence: number;
    memoryIndicators: string[];
  };
  urgencyLevel: string;
  personalizedResponse: string;
  voicePersonality: {
    tone: string;
    pace: string;
    warmth: number;
  };
}

interface EmergencyAnalysis {
  isEmergency: boolean;
  confidence: number;
  keywords: string[];
  recommendedAction: string;
}

interface AdvancedVoiceCompanionProps {
  patientId: number;
  onEmergencyDetected?: (emergency: EmergencyAnalysis) => void;
  onVoiceAnalysis?: (analysis: VoiceAnalysis) => void;
}

export function AdvancedVoiceCompanion({ 
  patientId, 
  onEmergencyDetected, 
  onVoiceAnalysis 
}: AdvancedVoiceCompanionProps) {
  const [isActive, setIsActive] = useState(false);
  const [currentAnalysis, setCurrentAnalysis] = useState<VoiceAnalysis | null>(null);
  const [emergencyStatus, setEmergencyStatus] = useState<EmergencyAnalysis | null>(null);
  const [conversationHistory, setConversationHistory] = useState<Array<{
    user: string;
    ai: string;
    timestamp: Date;
    emotion?: any;
  }>>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastResponse, setLastResponse] = useState<string>('');
  const [voicePersonality, setVoicePersonality] = useState<any>(null);

  const advancedVoice = useAdvancedVoice();
  const processingTimeoutRef = useRef<NodeJS.Timeout>();

  // Handle voice transcript processing
  const processVoiceInput = useCallback(async (transcript: string) => {
    if (!transcript.trim() || isProcessing) return;
    
    setIsProcessing(true);
    
    try {
      // Analyze voice input with AI
      const analysisResponse = await apiRequest(`/api/patients/${patientId}/voice/analyze`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          transcript,
          conversationHistory: conversationHistory.slice(-5)
        })
      });

      const { analysis, emergency } = analysisResponse as { analysis: any; emergency: any };
      setCurrentAnalysis(analysis);
      setEmergencyStatus(emergency);

      // Handle emergency detection
      if (emergency.isEmergency && emergency.confidence > 0.7) {
        onEmergencyDetected?.(emergency);
        advancedVoice.speakWithEmotion(
          `I detected you might need help. ${emergency.recommendedAction}`, 
          {
            sentiment: 'negative',
            energy: 'high',
            urgency: 'urgent',
            confidence: emergency.confidence
          }
        );
        return;
      }

      // Generate contextual response
      const responseData = await apiRequest(`/api/patients/${patientId}/voice/respond`, {
        method: 'POST',
        body: JSON.stringify({
          transcript,
          voiceAnalysis: analysis,
          conversationHistory: conversationHistory.slice(-5)
        })
      });

      const aiResponse = responseData.response;
      setLastResponse(aiResponse);

      // Speak the response with emotional adaptation
      const emotionalContext = {
        sentiment: analysis.emotionalState.primary === 'joy' ? 'positive' as const : 
                  analysis.emotionalState.primary === 'sadness' ? 'negative' as const : 'neutral' as const,
        energy: analysis.emotionalState.intensity > 0.7 ? 'high' as const : 
                analysis.emotionalState.intensity < 0.3 ? 'low' as const : 'medium' as const,
        urgency: analysis.urgencyLevel === 'high' || analysis.urgencyLevel === 'emergency' ? 'urgent' as const : 
                 analysis.urgencyLevel === 'low' ? 'relaxed' as const : 'normal' as const,
        confidence: analysis.emotionalState.confidence
      };

      advancedVoice.speakWithEmotion(aiResponse, emotionalContext);

      // Update conversation history
      setConversationHistory(prev => [...prev, {
        user: transcript,
        ai: aiResponse,
        timestamp: new Date(),
        emotion: emotionalContext
      }]);

      // Call analysis callback
      onVoiceAnalysis?.(analysis);

    } catch (error) {
      console.error('Voice processing error:', error);
      advancedVoice.speakWithEmotion(
        "I'm having trouble understanding right now. Could you try speaking again?",
        { sentiment: 'neutral', energy: 'medium', urgency: 'normal', confidence: 0.8 }
      );
    } finally {
      setIsProcessing(false);
    }
  }, [patientId, conversationHistory, isProcessing, advancedVoice, onEmergencyDetected, onVoiceAnalysis]);

  // Override the advanced voice transcript callback
  useEffect(() => {
    advancedVoice.onTranscriptReady = processVoiceInput;
  }, [processVoiceInput, advancedVoice]);

  // Load voice personality on component mount
  useEffect(() => {
    const loadVoicePersonality = async () => {
      try {
        const personality = await apiRequest(`/api/patients/${patientId}/voice/personality`, {
          method: 'POST',
          body: JSON.stringify({
            timeOfDay: new Date().toLocaleTimeString(),
            recentInteractions: conversationHistory.slice(-3)
          })
        });
        setVoicePersonality(personality.personality);
        advancedVoice.adjustPersonality({
          rate: personality.personality.rate,
          pitch: personality.personality.pitch,
          volume: personality.personality.volume,
          emotionalTone: personality.personality.emotionalTone
        });
      } catch (error) {
        console.error('Failed to load voice personality:', error);
      }
    };

    loadVoicePersonality();
  }, [patientId, advancedVoice]);

  const toggleAdvancedVoice = () => {
    if (isActive) {
      advancedVoice.stopAdvancedListening();
      setIsActive(false);
    } else {
      advancedVoice.startAdvancedListening();
      setIsActive(true);
      
      // Welcome message
      setTimeout(() => {
        advancedVoice.speakWithEmotion(
          voicePersonality?.greetingStyle === 'peaceful' 
            ? "Good evening. I'm here whenever you need me."
            : voicePersonality?.greetingStyle === 'energizing'
            ? "Good morning! How can I help brighten your day?"
            : "Hello! I'm your companion. How are you feeling today?",
          { sentiment: 'positive', energy: 'medium', urgency: 'normal', confidence: 1.0 }
        );
      }, 500);
    }
  };

  const getEmotionalStateColor = (emotion: string) => {
    switch (emotion) {
      case 'joy': return 'bg-green-500';
      case 'sadness': return 'bg-blue-500';
      case 'anger': return 'bg-red-500';
      case 'fear': return 'bg-purple-500';
      case 'surprise': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'emergency': return 'text-red-600 bg-red-50';
      case 'high': return 'text-orange-600 bg-orange-50';
      case 'medium': return 'text-yellow-600 bg-yellow-50';
      case 'low': return 'text-green-600 bg-green-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="space-y-6">
      {/* Voice Control Panel */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            Advanced AI Voice Companion
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Button
              onClick={toggleAdvancedVoice}
              variant={isActive ? 'destructive' : 'default'}
              size="lg"
              className="flex items-center gap-2"
            >
              {isActive ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
              {isActive ? 'Stop Listening' : 'Start Advanced Voice'}
            </Button>
            
            <div className="flex items-center gap-2">
              {advancedVoice.isListening && (
                <Badge variant="secondary" className="animate-pulse">
                  <Activity className="h-3 w-3 mr-1" />
                  Listening
                </Badge>
              )}
              {advancedVoice.isSpeaking && (
                <Badge variant="secondary" className="animate-pulse">
                  <Volume2 className="h-3 w-3 mr-1" />
                  Speaking
                </Badge>
              )}
              {isProcessing && (
                <Badge variant="secondary" className="animate-pulse">
                  <Brain className="h-3 w-3 mr-1" />
                  Analyzing
                </Badge>
              )}
            </div>
          </div>

          {/* Emergency Alert */}
          {emergencyStatus?.isEmergency && (
            <div className="bg-red-50 border-l-4 border-red-400 p-4 rounded-md">
              <div className="flex items-center">
                <AlertTriangle className="h-5 w-5 text-red-400 mr-2" />
                <div>
                  <h4 className="text-red-800 font-medium">Emergency Detected</h4>
                  <p className="text-red-700 text-sm mt-1">
                    {emergencyStatus.recommendedAction}
                  </p>
                  <p className="text-red-600 text-xs mt-1">
                    Confidence: {(emergencyStatus.confidence * 100).toFixed(1)}%
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Current Transcript */}
          {advancedVoice.transcript && (
            <div className="bg-blue-50 p-3 rounded-md">
              <p className="text-sm text-blue-900">
                <strong>You said:</strong> "{advancedVoice.transcript}"
              </p>
            </div>
          )}

          {/* Last AI Response */}
          {lastResponse && (
            <div className="bg-green-50 p-3 rounded-md">
              <p className="text-sm text-green-900">
                <strong>AI Response:</strong> "{lastResponse}"
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Voice Analysis Panel */}
      {currentAnalysis && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Heart className="h-5 w-5" />
              Voice Analysis
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Emotional State */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Emotional State</span>
                <Badge variant="outline" className={getEmotionalStateColor(currentAnalysis.emotionalState.primary)}>
                  {currentAnalysis.emotionalState.primary}
                </Badge>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-gray-600">
                  <span>Intensity</span>
                  <span>{(currentAnalysis.emotionalState.intensity * 100).toFixed(0)}%</span>
                </div>
                <Progress value={currentAnalysis.emotionalState.intensity * 100} className="h-2" />
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-gray-600">
                  <span>Confidence</span>
                  <span>{(currentAnalysis.emotionalState.confidence * 100).toFixed(0)}%</span>
                </div>
                <Progress value={currentAnalysis.emotionalState.confidence * 100} className="h-2" />
              </div>
            </div>

            <Separator />

            {/* Cognitive Markers */}
            <div className="space-y-2">
              <span className="text-sm font-medium">Cognitive Assessment</span>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="flex justify-between text-xs text-gray-600 mb-1">
                    <span>Clarity</span>
                    <span>{(currentAnalysis.cognitiveMarkers.clarity * 100).toFixed(0)}%</span>
                  </div>
                  <Progress value={currentAnalysis.cognitiveMarkers.clarity * 100} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-xs text-gray-600 mb-1">
                    <span>Coherence</span>
                    <span>{(currentAnalysis.cognitiveMarkers.coherence * 100).toFixed(0)}%</span>
                  </div>
                  <Progress value={currentAnalysis.cognitiveMarkers.coherence * 100} className="h-2" />
                </div>
              </div>
              
              {currentAnalysis.cognitiveMarkers.memoryIndicators.length > 0 && (
                <div className="mt-2">
                  <span className="text-xs text-gray-600">Memory Indicators:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {currentAnalysis.cognitiveMarkers.memoryIndicators.map((indicator, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {indicator}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <Separator />

            {/* Urgency Level */}
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Urgency Level</span>
              <Badge className={getUrgencyColor(currentAnalysis.urgencyLevel)}>
                {currentAnalysis.urgencyLevel}
              </Badge>
            </div>

            {/* Voice Personality */}
            {currentAnalysis.voicePersonality && (
              <div className="space-y-2">
                <span className="text-sm font-medium">Voice Adaptation</span>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div className="text-center p-2 bg-gray-50 rounded">
                    <div className="font-medium">Tone</div>
                    <div className="text-gray-600">{currentAnalysis.voicePersonality.tone}</div>
                  </div>
                  <div className="text-center p-2 bg-gray-50 rounded">
                    <div className="font-medium">Pace</div>
                    <div className="text-gray-600">{currentAnalysis.voicePersonality.pace}</div>
                  </div>
                  <div className="text-center p-2 bg-gray-50 rounded">
                    <div className="font-medium">Warmth</div>
                    <div className="text-gray-600">{(currentAnalysis.voicePersonality.warmth * 100).toFixed(0)}%</div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Conversation History */}
      {conversationHistory.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Conversation History</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-64">
              <div className="space-y-3">
                {conversationHistory.slice(-5).map((entry, index) => (
                  <div key={index} className="space-y-2">
                    <div className="bg-blue-50 p-2 rounded text-sm">
                      <strong>You:</strong> {entry.user}
                    </div>
                    <div className="bg-green-50 p-2 rounded text-sm">
                      <strong>AI:</strong> {entry.ai}
                    </div>
                    <div className="text-xs text-gray-500 flex justify-between">
                      <span>{entry.timestamp.toLocaleTimeString()}</span>
                      {entry.emotion && (
                        <span>Emotion: {entry.emotion.sentiment}</span>
                      )}
                    </div>
                    {index < conversationHistory.slice(-5).length - 1 && <Separator />}
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  );
}