import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Volume2, Mic, VolumeX, MicOff, 
  CheckCircle, AlertTriangle, Play,
  Headphones, Speaker, Settings, X
} from 'lucide-react';

interface AudioSetupPromptProps {
  onSetupComplete?: () => void;
  onClose?: () => void;
  showMinimal?: boolean;
}

const AudioSetupPrompt = ({ onSetupComplete, onClose, showMinimal = false }: AudioSetupPromptProps) => {
  const [audioPermission, setAudioPermission] = useState<'unknown' | 'granted' | 'denied'>('unknown');
  const [speakerTest, setSpeakerTest] = useState<'pending' | 'playing' | 'confirmed'>('pending');
  const [micTest, setMicTest] = useState<'pending' | 'testing' | 'confirmed'>('pending');
  const [setupComplete, setSetupComplete] = useState(false);
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);

  useEffect(() => {
    // Check if setup was previously completed
    const wasSetupComplete = localStorage.getItem('audioSetupComplete');
    if (wasSetupComplete === 'true') {
      setSetupComplete(true);
      onSetupComplete?.();
    }
  }, [onSetupComplete]);

  const requestMicrophonePermission = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      setAudioPermission('granted');
      setMicTest('confirmed');
      
      // Stop the stream immediately after permission is granted
      stream.getTracks().forEach(track => track.stop());
      
      // Create audio context for speaker test
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      setAudioContext(ctx);
      
      return true;
    } catch (error) {
      console.error('Microphone permission denied:', error);
      setAudioPermission('denied');
      return false;
    }
  };

  const testSpeakers = () => {
    setSpeakerTest('playing');
    
    if (audioContext) {
      // Create a pleasant test tone
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.setValueAtTime(440, audioContext.currentTime); // A4 note
      oscillator.type = 'sine';
      
      gainNode.gain.setValueAtTime(0, audioContext.currentTime);
      gainNode.gain.linearRampToValueAtTime(0.1, audioContext.currentTime + 0.1);
      gainNode.gain.linearRampToValueAtTime(0, audioContext.currentTime + 0.5);
      
      oscillator.start();
      oscillator.stop(audioContext.currentTime + 0.5);
      
      // Auto-advance after tone plays
      setTimeout(() => {
        setSpeakerTest('confirmed');
        checkSetupComplete();
      }, 1000);
    }
  };

  const confirmSpeakerTest = () => {
    setSpeakerTest('confirmed');
    checkSetupComplete();
  };

  const checkSetupComplete = () => {
    if (audioPermission === 'granted' && speakerTest === 'confirmed' && micTest === 'confirmed') {
      setSetupComplete(true);
      localStorage.setItem('audioSetupComplete', 'true');
      onSetupComplete?.();
    }
  };

  const resetSetup = () => {
    setAudioPermission('unknown');
    setSpeakerTest('pending');
    setMicTest('pending');
    setSetupComplete(false);
    localStorage.removeItem('audioSetupComplete');
  };

  const handleClose = () => {
    localStorage.setItem('audioSetupDismissed', 'true');
    onClose?.();
  };

  const handleSkip = () => {
    setSetupComplete(true);
    localStorage.setItem('audioSetupComplete', 'true');
    localStorage.setItem('audioSetupSkipped', 'true');
    onSetupComplete?.();
  };

  // Minimal version for already setup users
  if (showMinimal && setupComplete) {
    return (
      <div className="flex items-center gap-2 p-2 bg-green-50 rounded-lg border border-green-200">
        <CheckCircle className="w-4 h-4 text-green-600" />
        <span className="text-sm text-green-700">Audio enabled for immersive AI interaction</span>
        <Button variant="ghost" size="sm" onClick={resetSetup}>
          <Settings className="w-3 h-3" />
        </Button>
      </div>
    );
  }

  if (setupComplete) {
    return (
      <Alert className="bg-green-50 border-green-200">
        <CheckCircle className="h-4 w-4 text-green-600" />
        <AlertDescription className="text-green-700">
          <strong>Audio Setup Complete!</strong> You're ready for immersive AI voice interaction.
          <Button variant="ghost" size="sm" onClick={resetSetup} className="ml-2">
            Reconfigure
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200">
      <CardHeader className="text-center relative">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={handleClose}
          className="absolute top-2 right-2 w-8 h-8 p-0"
        >
          <X className="w-4 h-4" />
        </Button>
        <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
          <div className="flex gap-1">
            <Volume2 className="w-6 h-6 text-blue-600" />
            <Mic className="w-6 h-6 text-blue-600" />
          </div>
        </div>
        <CardTitle className="text-2xl font-bold text-gray-900">
          Enable Immersive AI Interaction
        </CardTitle>
        <CardDescription className="text-lg">
          Turn on your speakers and microphone for the full voice-powered experience
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Step 1: Microphone Permission */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                audioPermission === 'granted' ? 'bg-green-100' : 
                audioPermission === 'denied' ? 'bg-red-100' : 'bg-gray-100'
              }`}>
                {audioPermission === 'granted' ? (
                  <Mic className="w-4 h-4 text-green-600" />
                ) : audioPermission === 'denied' ? (
                  <MicOff className="w-4 h-4 text-red-600" />
                ) : (
                  <Mic className="w-4 h-4 text-gray-600" />
                )}
              </div>
              <div>
                <h3 className="font-semibold">Enable Microphone</h3>
                <p className="text-sm text-gray-600">Required for voice commands and conversation</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {audioPermission === 'granted' && (
                <Badge variant="default" className="bg-green-100 text-green-700">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Enabled
                </Badge>
              )}
              {audioPermission === 'denied' && (
                <Badge variant="destructive">
                  <AlertTriangle className="w-3 h-3 mr-1" />
                  Denied
                </Badge>
              )}
              {audioPermission === 'unknown' && (
                <Button onClick={requestMicrophonePermission} size="sm">
                  Enable Microphone
                </Button>
              )}
            </div>
          </div>
          
          {audioPermission === 'denied' && (
            <Alert className="bg-red-50 border-red-200">
              <AlertTriangle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-700">
                Microphone access was denied. Please check your browser settings and allow microphone access for this site.
                <div className="mt-2">
                  <Button onClick={handleSkip} size="sm" variant="outline">
                    Continue without voice interaction
                  </Button>
                </div>
              </AlertDescription>
            </Alert>
          )}
        </div>

        {/* Step 2: Speaker Test */}
        {audioPermission === 'granted' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  speakerTest === 'confirmed' ? 'bg-green-100' : 
                  speakerTest === 'playing' ? 'bg-blue-100' : 'bg-gray-100'
                }`}>
                  {speakerTest === 'confirmed' ? (
                    <Volume2 className="w-4 h-4 text-green-600" />
                  ) : speakerTest === 'playing' ? (
                    <Speaker className="w-4 h-4 text-blue-600 animate-pulse" />
                  ) : (
                    <VolumeX className="w-4 h-4 text-gray-600" />
                  )}
                </div>
                <div>
                  <h3 className="font-semibold">Test Speakers</h3>
                  <p className="text-sm text-gray-600">Ensure you can hear AI voice responses</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {speakerTest === 'confirmed' && (
                  <Badge variant="default" className="bg-green-100 text-green-700">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Working
                  </Badge>
                )}
                {speakerTest === 'playing' && (
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">Playing...</Badge>
                    <Button onClick={confirmSpeakerTest} size="sm" variant="outline">
                      I heard it
                    </Button>
                  </div>
                )}
                {speakerTest === 'pending' && (
                  <Button onClick={testSpeakers} size="sm" variant="outline">
                    <Play className="w-3 h-3 mr-1" />
                    Test Audio
                  </Button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Audio Tips */}
        <div className="bg-blue-50 rounded-lg p-4 space-y-2">
          <h4 className="font-semibold text-blue-900 flex items-center gap-2">
            <Headphones className="w-4 h-4" />
            For Best Experience
          </h4>
          <ul className="text-sm text-blue-700 space-y-1">
            <li>• Use Alexa hands-free for the best voice experience</li>
            <li>• Ensure microphone volume is adequate in a quiet environment</li>
            <li>• The AI companion responds naturally to voice commands</li>
            <li>• You can speak conversationally - no special phrases needed</li>
          </ul>
        </div>

        {/* Progress Indicator */}
        <div className="text-center">
          <div className="flex justify-center gap-2 mb-2">
            <div className={`w-3 h-3 rounded-full ${
              audioPermission === 'granted' ? 'bg-green-500' : 'bg-gray-300'
            }`} />
            <div className={`w-3 h-3 rounded-full ${
              speakerTest === 'confirmed' ? 'bg-green-500' : 'bg-gray-300'
            }`} />
          </div>
          <p className="text-sm text-gray-600">
            {audioPermission === 'unknown' ? 'Step 1 of 2: Enable microphone' :
             speakerTest === 'pending' ? 'Step 2 of 2: Test speakers' :
             speakerTest === 'playing' ? 'Confirm you can hear the test tone' :
             'Setup complete!'}
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default AudioSetupPrompt;