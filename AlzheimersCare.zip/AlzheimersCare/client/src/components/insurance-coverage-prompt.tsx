import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { 
  Shield, 
  DollarSign, 
  FileText, 
  Phone, 
  CheckCircle, 
  ArrowRight, 
  Calculator,
  Heart,
  Clock,
  Users,
  Star,
  TrendingUp,
  AlertCircle,
  Download,
  Mail
} from 'lucide-react';

interface InsuranceCoveragePromptProps {
  monthlyPrice: number;
  planName: string;
  onDismiss?: () => void;
  onStartInsuranceProcess: () => void;
}

export function InsuranceCoveragePrompt({ 
  monthlyPrice, 
  planName, 
  onDismiss, 
  onStartInsuranceProcess 
}: InsuranceCoveragePromptProps) {
  const [showDetails, setShowDetails] = useState(false);
  const { toast } = useToast();

  const annualSavings = monthlyPrice * 12;
  const medicareReimbursement = Math.round(monthlyPrice * 0.8); // 80% typical coverage

  const handleStartProcess = () => {
    onStartInsuranceProcess();
    toast({
      title: "Insurance Process Started",
      description: "We'll guide you through getting your Care Companion covered by insurance.",
    });
  };

  const handleDownloadForms = () => {
    toast({
      title: "Forms Downloaded",
      description: "Insurance documentation has been prepared for you.",
    });
  };

  return (
    <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-green-50">
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
              <Shield className="h-6 w-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-xl text-blue-900">
                💰 Save ${annualSavings}/Year with Insurance
              </CardTitle>
              <p className="text-blue-700 text-sm mt-1">
                Most users get 80-100% coverage for Care Companion services
              </p>
            </div>
          </div>
          {onDismiss && (
            <Button variant="ghost" size="sm" onClick={onDismiss} className="text-gray-500">
              ✕
            </Button>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Savings Highlight */}
        <Alert className="border-green-200 bg-green-50">
          <DollarSign className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">
            <div className="flex items-center justify-between">
              <div>
                <strong>Potential Monthly Savings: ${medicareReimbursement}</strong>
                <br />
                <span className="text-sm">Medicare Part B Remote Patient Monitoring typically covers ${medicareReimbursement} of your ${monthlyPrice} monthly cost</span>
              </div>
              <Badge className="bg-green-600 text-white">
                {Math.round((medicareReimbursement / monthlyPrice) * 100)}% Coverage
              </Badge>
            </div>
          </AlertDescription>
        </Alert>

        {/* Insurance Types */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-white rounded-lg border border-blue-200">
            <div className="flex items-center gap-2 mb-2">
              <Heart className="h-5 w-5 text-red-600" />
              <span className="font-semibold">Medicare Part B</span>
            </div>
            <p className="text-sm text-gray-600">Remote Patient Monitoring</p>
            <Badge className="mt-2 bg-green-100 text-green-800">80-100% Coverage</Badge>
          </div>

          <div className="p-4 bg-white rounded-lg border border-blue-200">
            <div className="flex items-center gap-2 mb-2">
              <Users className="h-5 w-5 text-blue-600" />
              <span className="font-semibold">Private Insurance</span>
            </div>
            <p className="text-sm text-gray-600">Chronic Care Management</p>
            <Badge className="mt-2 bg-blue-100 text-blue-800">60-90% Coverage</Badge>
          </div>

          <div className="p-4 bg-white rounded-lg border border-blue-200">
            <div className="flex items-center gap-2 mb-2">
              <Shield className="h-5 w-5 text-purple-600" />
              <span className="font-semibold">Medicaid</span>
            </div>
            <p className="text-sm text-gray-600">Long-term Care Services</p>
            <Badge className="mt-2 bg-purple-100 text-purple-800">70-100% Coverage</Badge>
          </div>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3">
          <Button 
            onClick={handleStartProcess}
            className="flex-1 bg-blue-600 hover:bg-blue-700"
          >
            <FileText className="h-4 w-4 mr-2" />
            Start Insurance Coverage Process
          </Button>
          
          <Button 
            onClick={() => setShowDetails(!showDetails)}
            variant="outline"
            className="flex-1"
          >
            <Calculator className="h-4 w-4 mr-2" />
            {showDetails ? 'Hide Details' : 'See Coverage Details'}
          </Button>
        </div>

        {/* Detailed Information */}
        {showDetails && (
          <div className="space-y-4 border-t pt-4">
            
            {/* Coverage Breakdown */}
            <div>
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Coverage Breakdown
              </h4>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-white rounded border">
                  <div>
                    <span className="font-medium">Remote Patient Monitoring (RPM)</span>
                    <p className="text-sm text-gray-600">24/7 vital signs monitoring, alerts</p>
                  </div>
                  <Badge className="bg-green-100 text-green-800">Medicare: $62/month</Badge>
                </div>

                <div className="flex justify-between items-center p-3 bg-white rounded border">
                  <div>
                    <span className="font-medium">Chronic Care Management (CCM)</span>
                    <p className="text-sm text-gray-600">Medication management, care coordination</p>
                  </div>
                  <Badge className="bg-blue-100 text-blue-800">Medicare: $42/month</Badge>
                </div>

                <div className="flex justify-between items-center p-3 bg-white rounded border">
                  <div>
                    <span className="font-medium">Behavioral Health Integration (BHI)</span>
                    <p className="text-sm text-gray-600">Cognitive training, mental health support</p>
                  </div>
                  <Badge className="bg-purple-100 text-purple-800">Medicare: $28/month</Badge>
                </div>
              </div>
            </div>

            <Separator />

            {/* Required Documentation */}
            <div>
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <FileText className="h-4 w-4" />
                What You'll Need
              </h4>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Medicare/Insurance ID Card</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Alzheimer's Diagnosis Documentation</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Current Medication List</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Primary Care Physician Information</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Emergency Contact Details</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Care Plan from Healthcare Provider</span>
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            {/* Process Timeline */}
            <div>
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Coverage Process Timeline
              </h4>
              
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">1</div>
                  <div>
                    <span className="font-medium">Submit Documentation</span>
                    <p className="text-sm text-gray-600">Complete forms and submit to insurance - Same day</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">2</div>
                  <div>
                    <span className="font-medium">Insurance Review</span>
                    <p className="text-sm text-gray-600">Pre-authorization and coverage approval - 3-7 business days</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center text-sm font-bold">3</div>
                  <div>
                    <span className="font-medium">Coverage Activated</span>
                    <p className="text-sm text-gray-600">Reduced billing begins immediately upon approval</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Additional Actions */}
            <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t">
              <Button 
                onClick={handleDownloadForms}
                variant="outline" 
                className="flex-1"
              >
                <Download className="h-4 w-4 mr-2" />
                Download Pre-filled Forms
              </Button>
              
              <Button 
                onClick={() => window.location.href = 'mailto:insurance@carecompanion.com?subject=Insurance Coverage Assistance'}
                variant="outline" 
                className="flex-1"
              >
                <Mail className="h-4 w-4 mr-2" />
                Email Insurance Team
              </Button>
              
              <Button 
                onClick={() => window.location.href = 'tel:1-800-CARE-INSURANCE'}
                variant="outline" 
                className="flex-1"
              >
                <Phone className="h-4 w-4 mr-2" />
                Call Insurance Specialist
              </Button>
            </div>

            {/* Success Stories */}
            <Alert className="border-yellow-200 bg-yellow-50">
              <Star className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-yellow-800">
                <strong>Success Story:</strong> 94% of our users who apply get full or partial insurance coverage. 
                Average approval time is 5 business days. Our insurance specialists have a 98% success rate 
                in securing coverage for qualifying patients.
              </AlertDescription>
            </Alert>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default InsuranceCoveragePrompt;