import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Brain, CheckCircle, X, RotateCcw, Star, Timer, ArrowRight } from "lucide-react";

interface CognitiveActivityCardProps {
  activity: any;
  onResponse: (response: any) => void;
  onComplete: () => void;
}

export function CognitiveActivityCard({ activity, onResponse, onComplete }: CognitiveActivityCardProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [responses, setResponses] = useState<any[]>([]);
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);

  // Mock activity content based on activity type
  const generateActivityContent = () => {
    switch (activity.activityType) {
      case 'recognition':
        return {
          title: "Family Photo Recognition",
          instructions: "Look at these photos and identify the people and places you remember.",
          questions: [
            {
              type: "photo_recognition",
              question: "Who is this person in the photo?",
              image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
              options: ["Sarah", "Michael", "Mom", "A friend"],
              correct: 0
            },
            {
              type: "photo_recognition", 
              question: "Where was this photo taken?",
              image: "https://images.unsplash.com/photo-1511593358241-7eea1f3c84e5?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
              options: ["Our backyard", "The park", "Beach vacation", "Restaurant"],
              correct: 2
            },
            {
              type: "photo_recognition",
              question: "What special occasion was this?",
              image: "https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
              options: ["Birthday party", "Wedding", "Christmas", "Thanksgiving"],
              correct: 1
            }
          ]
        };
      case 'memory_recall':
        return {
          title: "Family Story Recall",
          instructions: "Answer these questions about your family memories and experiences.",
          questions: [
            {
              type: "recall",
              question: "What was your favorite family tradition during the holidays?",
              type_detail: "open_ended"
            },
            {
              type: "recall",
              question: "Where did you and your spouse first meet?",
              options: ["At school", "At work", "Through friends", "At a party"],
              correct: 1
            },
            {
              type: "recall",
              question: "What was your child's favorite bedtime story?",
              type_detail: "open_ended"
            }
          ]
        };
      case 'conversation':
        return {
          title: "Memory Conversation",
          instructions: "Let's talk about some wonderful memories from your past.",
          questions: [
            {
              type: "conversation",
              question: "Tell me about a time when your family gathered for a special celebration.",
              type_detail: "open_ended"
            },
            {
              type: "conversation", 
              question: "What made you happiest when spending time with your children?",
              type_detail: "open_ended"
            }
          ]
        };
      default:
        return {
          title: "Cognitive Exercise",
          instructions: "Complete this personalized activity.",
          questions: [
            {
              type: "general",
              question: "How are you feeling today?",
              options: ["Great", "Good", "Okay", "Not so good"],
              correct: -1
            }
          ]
        };
    }
  };

  const activityContent = generateActivityContent();

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeElapsed(prev => prev + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleAnswer = (answer: any, isCorrect?: boolean) => {
    const response = {
      questionIndex: currentQuestion,
      question: activityContent.questions[currentQuestion].question,
      answer,
      correct: isCorrect !== undefined ? isCorrect : true,
      timeToAnswer: timeElapsed,
      timestamp: new Date().toISOString()
    };

    setResponses(prev => [...prev, response]);
    onResponse(response);

    if (currentQuestion < activityContent.questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      setIsCompleted(true);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getSuccessRate = () => {
    if (responses.length === 0) return 0;
    const correct = responses.filter(r => r.correct).length;
    return Math.round((correct / responses.length) * 100);
  };

  if (isCompleted) {
    return (
      <Card className="bg-gradient-to-br from-green-50 to-blue-50 border-2 border-care-secondary">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-care-secondary rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="h-8 w-8 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-900">
            Excellent Work!
          </CardTitle>
          <p className="text-gray-600">You've completed this cognitive exercise successfully.</p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-white rounded-lg">
              <div className="text-3xl font-bold text-care-secondary mb-1">{getSuccessRate()}%</div>
              <p className="text-sm text-gray-600">Success Rate</p>
            </div>
            <div className="text-center p-4 bg-white rounded-lg">
              <div className="text-3xl font-bold text-care-primary mb-1">{responses.length}</div>
              <p className="text-sm text-gray-600">Questions Answered</p>
            </div>
            <div className="text-center p-4 bg-white rounded-lg">
              <div className="text-3xl font-bold text-accent mb-1">{formatTime(timeElapsed)}</div>
              <p className="text-sm text-gray-600">Time Spent</p>
            </div>
          </div>

          <div className="bg-white rounded-lg p-4">
            <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
              <Star className="mr-2 h-5 w-5 text-yellow-500" />
              Activity Summary
            </h4>
            <div className="space-y-2 text-sm">
              <p className="text-gray-700">
                • You demonstrated excellent memory recall and recognition skills
              </p>
              <p className="text-gray-700">
                • Your responses show strong emotional connection to family memories
              </p>
              <p className="text-gray-700">
                • Cognitive performance indicates positive engagement with the material
              </p>
            </div>
          </div>

          <div className="flex space-x-3">
            <Button 
              onClick={onComplete}
              className="flex-1 bg-care-secondary text-white hover:bg-care-secondary/90"
            >
              <CheckCircle className="mr-2 h-4 w-4" />
              Complete Activity
            </Button>
            <Button 
              variant="outline"
              onClick={() => {
                setCurrentQuestion(0);
                setResponses([]);
                setIsCompleted(false);
                setTimeElapsed(0);
              }}
            >
              <RotateCcw className="mr-2 h-4 w-4" />
              Try Again
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  const currentQ = activityContent.questions[currentQuestion];
  const progress = ((currentQuestion + 1) / activityContent.questions.length) * 100;

  return (
    <div className="space-y-6">
      {/* Progress Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Badge className="bg-care-primary text-white">
            Question {currentQuestion + 1} of {activityContent.questions.length}
          </Badge>
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Timer className="h-4 w-4" />
            <span>{formatTime(timeElapsed)}</span>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-sm font-medium text-gray-600">Progress</span>
          <span className="text-sm font-bold text-care-primary">{Math.round(progress)}%</span>
        </div>
      </div>

      <Progress value={progress} className="h-2" />

      {/* Question Card */}
      <Card className="bg-white border-2 border-gray-200">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-gray-900">
            {currentQ.question}
          </CardTitle>
          {currentQ.image && (
            <div className="mt-4">
              <img 
                src={currentQ.image} 
                alt="Memory photo" 
                className="w-full max-w-md mx-auto rounded-lg shadow-lg"
              />
            </div>
          )}
        </CardHeader>
        <CardContent>
          {currentQ.options ? (
            /* Multiple Choice */
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {currentQ.options.map((option: string, index: number) => (
                <Button
                  key={index}
                  variant="outline"
                  className="p-4 h-auto text-left justify-start hover:bg-care-primary/10 hover:border-care-primary"
                  onClick={() => handleAnswer(option, index === currentQ.correct)}
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-care-primary/10 rounded-full flex items-center justify-center text-care-primary font-semibold">
                      {String.fromCharCode(65 + index)}
                    </div>
                    <span className="text-gray-900">{option}</span>
                  </div>
                </Button>
              ))}
            </div>
          ) : (
            /* Open Ended */
            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-4 min-h-[120px] flex items-center justify-center">
                <p className="text-gray-600 text-center">
                  Take your time to think about this question. When you're ready, 
                  you can share your thoughts or memories.
                </p>
              </div>
              <div className="flex space-x-3">
                <Button 
                  onClick={() => handleAnswer("Response provided", true)}
                  className="flex-1 bg-care-primary text-white hover:bg-care-primary/90"
                >
                  I've thought about it
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => handleAnswer("Skipped", false)}
                  className="hover:bg-gray-50"
                >
                  <X className="mr-2 h-4 w-4" />
                  Skip for now
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Encouragement */}
      <Card className="bg-gradient-to-r from-care-primary/10 to-care-secondary/10 border border-care-primary/20">
        <CardContent className="p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-care-primary/20 rounded-full flex items-center justify-center">
              <Brain className="h-5 w-5 text-care-primary" />
            </div>
            <div>
              <p className="font-medium text-gray-900">You're doing great!</p>
              <p className="text-sm text-gray-600">
                This activity is helping strengthen your memory and recognition skills.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
