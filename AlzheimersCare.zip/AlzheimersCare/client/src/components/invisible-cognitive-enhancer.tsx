import { useState, useEffect, useRef } from 'react';
import { useToast } from '@/hooks/use-toast';

interface CognitiveMetrics {
  memoryRetention: number;
  attentionSpan: number;
  processingSpeed: number;
  patternRecognition: number;
  responseTime: number;
  interactionQuality: number;
}

interface SubtleChallenge {
  type: 'memory' | 'attention' | 'processing' | 'pattern';
  trigger: string;
  data: any;
  startTime: number;
  difficulty: number;
}

interface UserBehavior {
  clickPatterns: number[];
  scrollSpeed: number;
  hesitationTime: number;
  navigationAccuracy: number;
  voiceResponseTime?: number;
  conversationDepth: number;
}

export default function InvisibleCognitiveEnhancer() {
  const [metrics, setMetrics] = useState<CognitiveMetrics>({
    memoryRetention: 0,
    attentionSpan: 0,
    processingSpeed: 0,
    patternRecognition: 0,
    responseTime: 0,
    interactionQuality: 0
  });

  const [activeChallenge, setActiveChallenge] = useState<SubtleChallenge | null>(null);
  const [userBehavior, setUserBehavior] = useState<UserBehavior>({
    clickPatterns: [],
    scrollSpeed: 0,
    hesitationTime: 0,
    navigationAccuracy: 0,
    conversationDepth: 0
  });

  const behaviorDataRef = useRef<any[]>([]);
  const interactionTimerRef = useRef<NodeJS.Timeout>();
  const lastActivityRef = useRef<number>(Date.now());

  // Invisible tracking of user interactions
  useEffect(() => {
    const trackMouseMovement = (e: MouseEvent) => {
      const now = Date.now();
      const timeDiff = now - lastActivityRef.current;
      
      // Measure hesitation (pauses in movement)
      if (timeDiff > 500) {
        setUserBehavior(prev => ({
          ...prev,
          hesitationTime: prev.hesitationTime + timeDiff
        }));
      }
      
      lastActivityRef.current = now;
    };

    const trackClicks = (e: MouseEvent) => {
      const now = Date.now();
      setUserBehavior(prev => ({
        ...prev,
        clickPatterns: [...prev.clickPatterns.slice(-9), now] // Keep last 10 clicks
      }));
      
      // Analyze click rhythm for cognitive state
      analyzeClickPattern();
    };

    const trackScrolling = (e: WheelEvent) => {
      const scrollSpeed = Math.abs(e.deltaY);
      setUserBehavior(prev => ({
        ...prev,
        scrollSpeed: (prev.scrollSpeed + scrollSpeed) / 2 // Running average
      }));
    };

    const trackKeyPress = (e: KeyboardEvent) => {
      // Measure typing speed and patterns
      const now = Date.now();
      if (lastActivityRef.current) {
        const typingSpeed = now - lastActivityRef.current;
        updateProcessingMetrics(typingSpeed);
      }
      lastActivityRef.current = now;
    };

    // Attach invisible listeners
    document.addEventListener('mousemove', trackMouseMovement);
    document.addEventListener('click', trackClicks);
    document.addEventListener('wheel', trackScrolling);
    document.addEventListener('keydown', trackKeyPress);

    return () => {
      document.removeEventListener('mousemove', trackMouseMovement);
      document.removeEventListener('click', trackClicks);
      document.removeEventListener('wheel', trackScrolling);
      document.removeEventListener('keydown', trackKeyPress);
    };
  }, []);

  // Inject subtle memory challenges during normal app usage
  useEffect(() => {
    const injectMemoryChallenge = () => {
      // Randomly present subtle challenges every 5-15 minutes
      const randomDelay = Math.random() * 600000 + 300000; // 5-15 minutes
      
      setTimeout(() => {
        const challengeTypes = ['color_recall', 'sequence_memory', 'pattern_recognition', 'attention_test'];
        const selectedType = challengeTypes[Math.floor(Math.random() * challengeTypes.length)];
        
        createSubtleChallenge(selectedType);
        injectMemoryChallenge(); // Schedule next challenge
      }, randomDelay);
    };

    injectMemoryChallenge();
  }, []);

  const createSubtleChallenge = (type: string) => {
    switch (type) {
      case 'color_recall':
        // Subtly change UI colors and see if user notices
        subtlyTestColorMemory();
        break;
      case 'sequence_memory':
        // Present information in sequences during normal navigation
        testSequenceMemory();
        break;
      case 'pattern_recognition':
        // Introduce subtle patterns in content layout
        testPatternRecognition();
        break;
      case 'attention_test':
        // Measure sustained attention during regular tasks
        testAttentionSpan();
        break;
    }
  };

  const subtlyTestColorMemory = () => {
    const originalColors = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444'];
    const testColor = originalColors[Math.floor(Math.random() * originalColors.length)];
    
    // Briefly flash a color in an interface element
    const elements = document.querySelectorAll('.bg-blue-500, .bg-green-500, .bg-yellow-500, .bg-red-500');
    if (elements.length > 0) {
      const element = elements[Math.floor(Math.random() * elements.length)] as HTMLElement;
      const originalColor = element.style.backgroundColor;
      
      element.style.backgroundColor = testColor;
      setTimeout(() => {
        element.style.backgroundColor = originalColor;
        // Later test if user remembers the color change
        testColorRecall(testColor);
      }, 2000);
    }
  };

  const testSequenceMemory = () => {
    // During normal app usage, present information in specific sequences
    // and later test recall through subtle navigation patterns
    const sequence = generateRandomSequence(4);
    
    setActiveChallenge({
      type: 'memory',
      trigger: 'sequence_recall',
      data: { sequence },
      startTime: Date.now(),
      difficulty: 1
    });

    // Test recall after a delay through navigation patterns
    setTimeout(() => {
      testSequenceRecall(sequence);
    }, 30000);
  };

  const testPatternRecognition = () => {
    // Introduce subtle visual patterns in the interface
    const pattern = createVisualPattern();
    
    setActiveChallenge({
      type: 'pattern',
      trigger: 'pattern_recognition',
      data: { pattern },
      startTime: Date.now(),
      difficulty: 2
    });
  };

  const testAttentionSpan = () => {
    // Measure how long user stays focused on current task
    const startTime = Date.now();
    let focusTime = 0;
    
    const checkFocus = () => {
      if (document.hasFocus()) {
        focusTime += 1000;
      }
      
      if (focusTime < 60000) { // Continue for 1 minute
        setTimeout(checkFocus, 1000);
      } else {
        updateAttentionMetrics(focusTime);
      }
    };
    
    checkFocus();
  };

  const analyzeClickPattern = () => {
    if (userBehavior.clickPatterns.length < 3) return;
    
    const recentClicks = userBehavior.clickPatterns.slice(-3);
    const intervals = [];
    
    for (let i = 1; i < recentClicks.length; i++) {
      intervals.push(recentClicks[i] - recentClicks[i - 1]);
    }
    
    const avgInterval = intervals.reduce((a, b) => a + b) / intervals.length;
    const consistency = intervals.every(interval => Math.abs(interval - avgInterval) < 200);
    
    // Update processing speed metrics based on click consistency
    setMetrics(prev => ({
      ...prev,
      processingSpeed: consistency ? Math.min(100, prev.processingSpeed + 2) : prev.processingSpeed,
      patternRecognition: consistency ? Math.min(100, prev.patternRecognition + 1) : prev.patternRecognition
    }));
  };

  const updateProcessingMetrics = (typingSpeed: number) => {
    // Analyze typing patterns for cognitive processing
    const speedScore = Math.max(0, 100 - (typingSpeed / 10)); // Faster typing = higher score
    
    setMetrics(prev => ({
      ...prev,
      processingSpeed: (prev.processingSpeed + speedScore) / 2,
      responseTime: (prev.responseTime + (1000 / typingSpeed)) / 2
    }));
  };

  const updateAttentionMetrics = (focusTime: number) => {
    const attentionScore = Math.min(100, (focusTime / 60000) * 100); // Max score for 1 minute focus
    
    setMetrics(prev => ({
      ...prev,
      attentionSpan: Math.max(prev.attentionSpan, attentionScore)
    }));
  };

  const testColorRecall = (testColor: string) => {
    // Subtly test if user noticed the color change by monitoring their behavior
    // This could be done through eye tracking or by presenting related visual cues
  };

  const testSequenceRecall = (sequence: number[]) => {
    // Test sequence memory through subtle navigation prompts
    // Monitor if user follows expected patterns
  };

  const generateRandomSequence = (length: number): number[] => {
    return Array.from({ length }, () => Math.floor(Math.random() * 9));
  };

  const createVisualPattern = () => {
    // Create subtle visual patterns in the interface
    return {
      type: 'geometric',
      elements: ['circle', 'square', 'triangle'],
      sequence: [0, 1, 2, 1, 0]
    };
  };

  // Store cognitive data for analysis
  useEffect(() => {
    const storeMetrics = async () => {
      try {
        const response = await fetch('/api/cognitive-metrics', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            patientId: 1, // Get from context
            metrics,
            userBehavior,
            timestamp: new Date().toISOString(),
            sessionDuration: Date.now() - lastActivityRef.current
          })
        });
        
        if (!response.ok) {
          console.warn('Failed to store cognitive metrics');
        }
      } catch (error) {
        console.warn('Error storing cognitive metrics:', error);
      }
    };

    // Store metrics every 5 minutes
    const interval = setInterval(storeMetrics, 300000);
    return () => clearInterval(interval);
  }, [metrics, userBehavior]);

  // Adaptive difficulty adjustment
  useEffect(() => {
    const adaptDifficulty = () => {
      const overallPerformance = Object.values(metrics).reduce((a, b) => a + b) / Object.values(metrics).length;
      
      if (overallPerformance > 80) {
        // Increase challenge difficulty
        increaseChallengeDifficulty();
      } else if (overallPerformance < 60) {
        // Decrease challenge difficulty
        decreaseChallengeDifficulty();
      }
    };

    const interval = setInterval(adaptDifficulty, 600000); // Check every 10 minutes
    return () => clearInterval(interval);
  }, [metrics]);

  const increaseChallengeDifficulty = () => {
    // Make challenges slightly more complex
  };

  const decreaseChallengeDifficulty = () => {
    // Make challenges more accessible
  };

  // This component renders nothing visible - it's completely invisible
  return null;
}

// Hook for accessing cognitive data in other components
export function useCognitiveMetrics() {
  const [metrics, setMetrics] = useState<CognitiveMetrics | null>(null);
  
  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const response = await fetch('/api/cognitive-metrics/latest');
        if (response.ok) {
          const data = await response.json();
          setMetrics(data);
        }
      } catch (error) {
        console.warn('Failed to fetch cognitive metrics');
      }
    };
    
    fetchMetrics();
    const interval = setInterval(fetchMetrics, 60000); // Update every minute
    return () => clearInterval(interval);
  }, []);
  
  return metrics;
}