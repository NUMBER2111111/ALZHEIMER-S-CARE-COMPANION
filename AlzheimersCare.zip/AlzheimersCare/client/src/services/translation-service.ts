interface TranslationCache {
  [key: string]: string;
}

interface TranslationRequest {
  text: string;
  targetLanguage: string;
  sourceLanguage?: string;
}

interface TranslationResponse {
  translatedText: string;
  sourceLanguage: string;
  targetLanguage: string;
  confidence: number;
}

class TranslationService {
  private cache: TranslationCache = {};
  private isOnline: boolean = navigator.onLine;
  private fallbackTranslations: { [key: string]: { [key: string]: string } } = {
    en: {
      welcome: "Welcome",
      hello: "Hello",
      goodbye: "Goodbye",
      yes: "Yes",
      no: "No",
      help: "Help",
      save: "Save",
      cancel: "Cancel",
      submit: "Submit",
      loading: "Loading...",
      error: "Error",
      success: "Success",
      family: "Family",
      patient: "Patient",
      care: "Care",
      memory: "Memory",
      health: "Health",
      emergency: "Emergency",
      medication: "Medication",
      settings: "Settings"
    },
    es: {
      welcome: "Bienvenido",
      hello: "Hola",
      goodbye: "Adiós",
      yes: "Sí",
      no: "No",
      help: "Ayuda",
      save: "Guardar",
      cancel: "Cancelar",
      submit: "Enviar",
      loading: "Cargando...",
      error: "Error",
      success: "Éxito",
      family: "Familia",
      patient: "Paciente",
      care: "Cuidado",
      memory: "Memoria",
      health: "Salud",
      emergency: "Emergencia",
      medication: "Medicación",
      settings: "Configuración"
    },
    fr: {
      welcome: "Bienvenue",
      hello: "Bonjour",
      goodbye: "Au revoir",
      yes: "Oui",
      no: "Non",
      help: "Aide",
      save: "Sauvegarder",
      cancel: "Annuler",
      submit: "Soumettre",
      loading: "Chargement...",
      error: "Erreur",
      success: "Succès",
      family: "Famille",
      patient: "Patient",
      care: "Soins",
      memory: "Mémoire",
      health: "Santé",
      emergency: "Urgence",
      medication: "Médicament",
      settings: "Paramètres"
    },
    de: {
      welcome: "Willkommen",
      hello: "Hallo",
      goodbye: "Auf Wiedersehen",
      yes: "Ja",
      no: "Nein",
      help: "Hilfe",
      save: "Speichern",
      cancel: "Abbrechen",
      submit: "Senden",
      loading: "Laden...",
      error: "Fehler",
      success: "Erfolg",
      family: "Familie",
      patient: "Patient",
      care: "Pflege",
      memory: "Gedächtnis",
      health: "Gesundheit",
      emergency: "Notfall",
      medication: "Medikament",
      settings: "Einstellungen"
    },
    zh: {
      welcome: "欢迎",
      hello: "你好",
      goodbye: "再见",
      yes: "是",
      no: "否",
      help: "帮助",
      save: "保存",
      cancel: "取消",
      submit: "提交",
      loading: "加载中...",
      error: "错误",
      success: "成功",
      family: "家庭",
      patient: "患者",
      care: "护理",
      memory: "记忆",
      health: "健康",
      emergency: "紧急情况",
      medication: "药物",
      settings: "设置"
    }
  };

  constructor() {
    window.addEventListener('online', () => {
      this.isOnline = true;
    });
    
    window.addEventListener('offline', () => {
      this.isOnline = false;
    });
  }

  private getCacheKey(text: string, targetLang: string, sourceLang: string = 'auto'): string {
    return `${sourceLang}-${targetLang}-${text}`;
  }

  private getFallbackTranslation(text: string, targetLanguage: string): string | null {
    const normalizedText = text.toLowerCase().trim();
    
    // Check if we have a fallback translation
    if (this.fallbackTranslations[targetLanguage]) {
      return this.fallbackTranslations[targetLanguage][normalizedText] || null;
    }
    
    return null;
  }

  async translateText(request: TranslationRequest): Promise<TranslationResponse> {
    const { text, targetLanguage, sourceLanguage = 'auto' } = request;
    
    // Return original text if target language is English and no source specified
    if (targetLanguage === 'en' && sourceLanguage === 'auto') {
      return {
        translatedText: text,
        sourceLanguage: 'en',
        targetLanguage: 'en',
        confidence: 1.0
      };
    }

    const cacheKey = this.getCacheKey(text, targetLanguage, sourceLanguage);
    
    // Check cache first
    if (this.cache[cacheKey]) {
      return {
        translatedText: this.cache[cacheKey],
        sourceLanguage: sourceLanguage,
        targetLanguage: targetLanguage,
        confidence: 0.95
      };
    }

    try {
      if (this.isOnline) {
        // Use browser-based translation API or fetch from server
        const response = await this.performOnlineTranslation(text, targetLanguage, sourceLanguage);
        
        // Cache the result
        this.cache[cacheKey] = response.translatedText;
        
        return response;
      } else {
        // Offline fallback
        const fallbackText = this.getFallbackTranslation(text, targetLanguage);
        
        if (fallbackText) {
          return {
            translatedText: fallbackText,
            sourceLanguage: sourceLanguage,
            targetLanguage: targetLanguage,
            confidence: 0.7
          };
        }
        
        // Return original text if no translation available
        return {
          translatedText: text,
          sourceLanguage: sourceLanguage,
          targetLanguage: targetLanguage,
          confidence: 0.1
        };
      }
    } catch (error) {
      console.warn('Translation failed:', error);
      
      // Try fallback translation
      const fallbackText = this.getFallbackTranslation(text, targetLanguage);
      
      return {
        translatedText: fallbackText || text,
        sourceLanguage: sourceLanguage,
        targetLanguage: targetLanguage,
        confidence: fallbackText ? 0.7 : 0.1
      };
    }
  }

  private async performOnlineTranslation(
    text: string, 
    targetLanguage: string, 
    sourceLanguage: string
  ): Promise<TranslationResponse> {
    // Try browser's built-in translation capabilities first
    if ('translation' in window && 'createTranslator' in (window as any).translation) {
      try {
        const translator = await (window as any).translation.createTranslator({
          sourceLanguage: sourceLanguage === 'auto' ? undefined : sourceLanguage,
          targetLanguage: targetLanguage
        });
        
        const translatedText = await translator.translate(text);
        
        return {
          translatedText,
          sourceLanguage: sourceLanguage,
          targetLanguage: targetLanguage,
          confidence: 0.9
        };
      } catch (error) {
        console.warn('Browser translation failed:', error);
      }
    }

    // Fallback to server-based translation
    const response = await fetch('/api/translate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text,
        targetLanguage,
        sourceLanguage
      })
    });

    if (!response.ok) {
      throw new Error(`Translation API failed: ${response.status}`);
    }

    return await response.json();
  }

  async translateVoice(audioBlob: Blob, targetLanguage: string): Promise<string> {
    try {
      // Convert speech to text first
      const transcript = await this.speechToText(audioBlob);
      
      // Translate the transcript
      const translation = await this.translateText({
        text: transcript,
        targetLanguage,
        sourceLanguage: 'auto'
      });
      
      return translation.translatedText;
    } catch (error) {
      console.error('Voice translation failed:', error);
      throw error;
    }
  }

  private async speechToText(audioBlob: Blob): Promise<string> {
    return new Promise((resolve, reject) => {
      const recognition = new (window as any).webkitSpeechRecognition() || new (window as any).SpeechRecognition();
      
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'auto';
      
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        resolve(transcript);
      };
      
      recognition.onerror = (event: any) => {
        reject(new Error(`Speech recognition failed: ${event.error}`));
      };
      
      // Create audio URL and start recognition
      const audioUrl = URL.createObjectURL(audioBlob);
      const audio = new Audio(audioUrl);
      
      audio.onloadeddata = () => {
        recognition.start();
      };
      
      audio.load();
    });
  }

  async textToSpeech(text: string, language: string): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!('speechSynthesis' in window)) {
        reject(new Error('Speech synthesis not supported'));
        return;
      }

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = language;
      utterance.rate = 0.8;
      utterance.pitch = 1.0;
      utterance.volume = 0.8;

      utterance.onend = () => resolve();
      utterance.onerror = (event) => reject(new Error(`Speech synthesis failed: ${event.error}`));

      speechSynthesis.speak(utterance);
    });
  }

  clearCache(): void {
    this.cache = {};
  }

  isTranslationAvailable(): boolean {
    return this.isOnline || Object.keys(this.fallbackTranslations).length > 0;
  }

  getSupportedLanguages(): string[] {
    return Object.keys(this.fallbackTranslations);
  }
}

// Export singleton instance
export const translationService = new TranslationService();
export type { TranslationRequest, TranslationResponse };