import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  analyzeMemory, 
  analyzeImage, 
  generateCognitiveActivity, 
  assessCognitivePerformance,
  generateInsuranceBenefits,
  analyzeVitalSigns,
  generateChessMove,
  generateCardGame,
  analyzeMedicationAdherence
} from "./services/openai";
import {
  analyzeVoiceInput,
  generateContextualResponse,
  detectEmergencyKeywords,
  generateVoicePersonality
} from "./services/advanced-voice";
import { translateText } from "./services/translation";
import { squarePaymentService, SUBSCRIPTION_PLANS } from "./services/square-payments";
import { squareSubscriptionService, CARE_COMPANION_PLAN } from "./services/square-subscription";
import { EncryptionService } from "./services/encryption";
import { handleAsyncErrors } from "./error-handler";
import { 
  insertUserSchema,
  insertPatientSchema,
  insertFacilitySchema,
  insertFamilyRelationshipSchema,
  insertFamilyMemorySchema,
  insertCognitiveActivitySchema,
  insertActivitySessionSchema,
  insertCognitiveProgressSchema,
  insertVitalSignsSchema,
  insertMedicationSchema,
  insertMedicationLogSchema,
  insertGameActivitySchema,
  insertEmergencyEventSchema,
} from "@shared/schema";
import multer from "multer";

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists by email first
      if (userData.email) {
        try {
          const allUsers = await storage.getUsersByType('family_member');
          const existingUser = allUsers.find(u => u.email === userData.email);
          if (existingUser) {
            return res.json(existingUser);
          }
          
          // Also check other user types
          const adminUsers = await storage.getUsersByType('admin');
          const existingAdmin = adminUsers.find(u => u.email === userData.email);
          if (existingAdmin) {
            return res.json(existingAdmin);
          }
        } catch (checkError) {
          console.error("Error checking existing users:", checkError);
        }
      }
      
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error: any) {
      console.error("Error creating user:", error);
      
      // Handle duplicate email constraint
      if (error.code === '23505' && error.constraint === 'users_email_unique') {
        try {
          // Find the existing user by email directly from users table
          const allUsers = await storage.getUsersByType('family_member');
          const adminUsers = await storage.getUsersByType('admin');
          const caregiverUsers = await storage.getUsersByType('caregiver');
          const allUsersList = [...allUsers, ...adminUsers, ...caregiverUsers];
          
          const existingUser = allUsersList.find(u => u.email === req.body.email);
          if (existingUser) {
            console.log("Found existing user, returning:", existingUser);
            return res.json({
              ...existingUser,
              isExisting: true,
              message: "Using existing account with this email"
            });
          }
        } catch (findError) {
          console.error("Error finding existing user:", findError);
        }
        
        return res.status(409).json({ 
          message: "Email already registered. Please use a different email or contact support.",
          code: "DUPLICATE_EMAIL",
          error: "EMAIL_ALREADY_EXISTS"
        });
      }
      
      res.status(400).json({ message: "Failed to create user" });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Patient routes
  app.post("/api/patients", async (req, res) => {
    try {
      const patientData = insertPatientSchema.parse(req.body);
      const patient = await storage.createPatient(patientData);
      res.json(patient);
    } catch (error) {
      console.error("Error creating patient:", error);
      res.status(400).json({ message: "Failed to create patient" });
    }
  });

  app.get("/api/patients/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const patient = await storage.getPatient(id);
      if (!patient) {
        return res.status(404).json({ message: "Patient not found" });
      }
      res.json(patient);
    } catch (error) {
      console.error("Error fetching patient:", error);
      res.status(500).json({ message: "Failed to fetch patient" });
    }
  });

  // Facility routes
  app.post("/api/facilities", async (req, res) => {
    try {
      const facilityData = insertFacilitySchema.parse(req.body);
      const facility = await storage.createFacility(facilityData);
      res.json(facility);
    } catch (error) {
      console.error("Error creating facility:", error);
      res.status(400).json({ message: "Failed to create facility" });
    }
  });

  app.get("/api/facilities", async (req, res) => {
    try {
      const facilities = await storage.getFacilities();
      res.json(facilities);
    } catch (error) {
      console.error("Error fetching facilities:", error);
      res.status(500).json({ message: "Failed to fetch facilities" });
    }
  });

  // Family relationship routes
  app.post("/api/family-relationships", async (req, res) => {
    try {
      const relationshipData = insertFamilyRelationshipSchema.parse(req.body);
      const relationship = await storage.createFamilyRelationship(relationshipData);
      res.json(relationship);
    } catch (error) {
      console.error("Error creating family relationship:", error);
      res.status(400).json({ message: "Failed to create family relationship" });
    }
  });

  app.get("/api/family-relationships/patient/:patientId", async (req, res) => {
    try {
      const patientId = parseInt(req.params.patientId);
      const relationships = await storage.getFamilyRelationshipsByPatient(patientId);
      res.json(relationships);
    } catch (error) {
      console.error("Error fetching family relationships:", error);
      res.status(500).json({ message: "Failed to fetch family relationships" });
    }
  });

  // Family memory routes with AI analysis
  app.post("/api/family-memories", upload.single('file'), async (req, res) => {
    try {
      const memoryData = insertFamilyMemorySchema.parse(JSON.parse(req.body.data || '{}'));
      
      let aiAnalysis = null;
      if (req.file && req.file.mimetype.startsWith('image/')) {
        // Convert buffer to base64 for AI analysis
        const base64Image = req.file.buffer.toString('base64');
        aiAnalysis = await analyzeImage(base64Image, memoryData.description || '');
        
        // Store file path in content (in real app, upload to cloud storage)
        memoryData.content = {
          ...memoryData.content as any,
          fileName: req.file.originalname,
          fileSize: req.file.size,
          mimeType: req.file.mimetype
        };
      } else if (memoryData.memoryType === 'story') {
        aiAnalysis = await analyzeMemory('story', memoryData.content, memoryData.description || '');
      }

      if (aiAnalysis) {
        memoryData.metadata = { aiAnalysis };
      }

      const memory = await storage.createFamilyMemory(memoryData);
      res.json(memory);
    } catch (error) {
      console.error("Error creating family memory:", error);
      res.status(400).json({ message: "Failed to create family memory" });
    }
  });

  app.get("/api/family-memories/patient/:patientId", async (req, res) => {
    try {
      const patientId = parseInt(req.params.patientId);
      const memories = await storage.getFamilyMemoriesByPatient(patientId);
      res.json(memories);
    } catch (error) {
      console.error("Error fetching family memories:", error);
      res.status(500).json({ message: "Failed to fetch family memories" });
    }
  });

  // AI-powered cognitive activity generation
  app.post("/api/generate-activities/:patientId", async (req, res) => {
    try {
      const patientId = parseInt(req.params.patientId);
      const { activityType } = req.body;

      const patient = await storage.getPatient(patientId);
      if (!patient) {
        return res.status(404).json({ message: "Patient not found" });
      }

      const memories = await storage.getFamilyMemoriesByPatient(patientId);
      
      // Generate activities from recent memories with AI analysis
      const activities = [];
      for (const memory of memories.slice(0, 5)) { // Process recent memories
        if (memory.metadata && (memory.metadata as any).aiAnalysis) {
          const aiAnalysis = (memory.metadata as any).aiAnalysis;
          const generatedActivity = await generateCognitiveActivity(
            patient,
            aiAnalysis,
            activityType || 'recognition'
          );

          const activityData = {
            patientId,
            activityType: generatedActivity.activityType,
            title: generatedActivity.title,
            description: generatedActivity.description,
            content: generatedActivity.content,
            difficulty: generatedActivity.difficulty,
            estimatedDuration: generatedActivity.estimatedDuration,
            sourceMemoryId: memory.id
          };

          const activity = await storage.createCognitiveActivity(activityData);
          activities.push(activity);
        }
      }

      res.json(activities);
    } catch (error) {
      console.error("Error generating activities:", error);
      res.status(500).json({ message: "Failed to generate cognitive activities" });
    }
  });

  // Cognitive activity routes
  app.get("/api/cognitive-activities/patient/:patientId", async (req, res) => {
    try {
      const patientId = parseInt(req.params.patientId);
      const activities = await storage.getCognitiveActivitiesByPatient(patientId);
      res.json(activities);
    } catch (error) {
      console.error("Error fetching cognitive activities:", error);
      res.status(500).json({ message: "Failed to fetch cognitive activities" });
    }
  });

  // Activity session routes with AI assessment
  app.post("/api/activity-sessions", async (req, res) => {
    try {
      const sessionData = insertActivitySessionSchema.parse(req.body);
      const session = await storage.createActivitySession(sessionData);
      res.json(session);
    } catch (error) {
      console.error("Error creating activity session:", error);
      res.status(400).json({ message: "Failed to create activity session" });
    }
  });

  app.patch("/api/activity-sessions/:id/complete", async (req, res) => {
    try {
      const sessionId = parseInt(req.params.id);
      const { responseData, successRate } = req.body;

      // Get the activity session and related data for AI assessment
      const session = await storage.updateActivitySession(sessionId, {
        completedAt: new Date(),
        responseData,
        successRate
      });

      // Perform AI assessment
      const activity = await storage.getCognitiveActivity(session.activityId);
      const patient = await storage.getPatient(session.patientId);
      const patientHistory = await storage.getCognitiveProgressByPatient(session.patientId);

      if (activity && patient) {
        const aiAssessment = await assessCognitivePerformance(
          activity,
          responseData,
          patientHistory
        );

        // Update session with AI analysis
        await storage.updateActivitySession(sessionId, {
          aiAnalysis: aiAssessment
        });

        // Create or update cognitive progress
        await storage.createCognitiveProgress({
          patientId: session.patientId,
          memoryRecall: aiAssessment.memoryRecall.toFixed(2),
          recognition: aiAssessment.recognition.toFixed(2),
          attention: aiAssessment.attention.toFixed(2),
          overallScore: aiAssessment.overallScore.toFixed(2),
          notes: aiAssessment.insights.join('; '),
          aiInsights: aiAssessment
        });
      }

      res.json(session);
    } catch (error) {
      console.error("Error completing activity session:", error);
      res.status(500).json({ message: "Failed to complete activity session" });
    }
  });

  // Progress tracking routes
  app.get("/api/cognitive-progress/patient/:patientId", async (req, res) => {
    try {
      const patientId = parseInt(req.params.patientId);
      const progress = await storage.getCognitiveProgressByPatient(patientId);
      res.json(progress);
    } catch (error) {
      console.error("Error fetching cognitive progress:", error);
      res.status(500).json({ message: "Failed to fetch cognitive progress" });
    }
  });

  app.get("/api/cognitive-progress/patient/:patientId/latest", async (req, res) => {
    try {
      const patientId = parseInt(req.params.patientId);
      const progress = await storage.getLatestCognitiveProgress(patientId);
      if (!progress) {
        return res.status(404).json({ message: "No progress data found" });
      }
      res.json(progress);
    } catch (error) {
      console.error("Error fetching latest progress:", error);
      res.status(500).json({ message: "Failed to fetch latest progress" });
    }
  });

  // Admin analytics and insurance benefits
  app.get("/api/admin/analytics/:facilityId", async (req, res) => {
    try {
      const facilityId = parseInt(req.params.facilityId);
      
      const facility = await storage.getFacility(facilityId);
      if (!facility) {
        return res.status(404).json({ message: "Facility not found" });
      }

      const patients = await storage.getPatientsByFacility(facilityId);
      const patientOutcomes = [];

      for (const patient of patients) {
        const progress = await storage.getCognitiveProgressByPatient(patient.id);
        const sessions = await storage.getActivitySessionsByPatient(patient.id);
        patientOutcomes.push({
          patientId: patient.id,
          progress,
          sessionCount: sessions.length,
          averageSuccessRate: sessions.reduce((sum, s) => sum + (parseFloat(s.successRate || '0')), 0) / sessions.length || 0
        });
      }

      // Generate AI-powered benefits analysis
      const benefitsAnalysis = await generateInsuranceBenefits(facility, patientOutcomes);

      res.json({
        facility,
        patientCount: patients.length,
        patientOutcomes,
        benefitsAnalysis
      });
    } catch (error) {
      console.error("Error generating admin analytics:", error);
      res.status(500).json({ message: "Failed to generate admin analytics" });
    }
  });

  // Emergency monitoring and vital signs routes
  app.post('/api/vital-signs', async (req, res) => {
    try {
      const vitalSignsData = insertVitalSignsSchema.parse(req.body);
      const vitalSigns = await storage.createVitalSigns(vitalSignsData);
      
      // AI analysis for emergency detection
      if (vitalSigns.isEmergencyAlert) {
        const analysis = await analyzeVitalSigns(vitalSigns);
        
        // Create emergency event if high risk
        if (analysis.riskLevel === 'high' || analysis.riskLevel === 'critical') {
          await storage.createEmergencyEvent({
            patientId: vitalSigns.patientId,
            eventType: 'vital_signs_alert',
            severity: analysis.riskLevel,
            description: `Vital signs emergency: ${analysis.alerts.join(', ')}`,
            vitalSignsId: vitalSigns.id,
            status: 'active',
            responseActions: analysis.emergencyActions || [],
          });
        }
      }
      
      res.json(vitalSigns);
    } catch (error) {
      console.error("Error creating vital signs:", error);
      res.status(500).json({ message: "Failed to create vital signs record" });
    }
  });

  app.get('/api/patients/:patientId/vital-signs', async (req, res) => {
    try {
      const patientId = parseInt(req.params.patientId);
      const vitalSigns = await storage.getVitalSignsByPatient(patientId);
      res.json(vitalSigns);
    } catch (error) {
      console.error("Error fetching vital signs:", error);
      res.status(500).json({ message: "Failed to fetch vital signs" });
    }
  });

  app.get('/api/patients/:patientId/vital-signs/latest', async (req, res) => {
    try {
      const patientId = parseInt(req.params.patientId);
      const latestVitalSigns = await storage.getLatestVitalSigns(patientId);
      res.json(latestVitalSigns);
    } catch (error) {
      console.error("Error fetching latest vital signs:", error);
      res.status(500).json({ message: "Failed to fetch latest vital signs" });
    }
  });

  app.get('/api/emergency-alerts', async (req, res) => {
    try {
      const patientId = req.query.patientId ? parseInt(req.query.patientId as string) : undefined;
      const alerts = await storage.getEmergencyAlerts(patientId);
      res.json(alerts);
    } catch (error) {
      console.error("Error fetching emergency alerts:", error);
      res.status(500).json({ message: "Failed to fetch emergency alerts" });
    }
  });

  // Medicine tracking routes
  app.post('/api/medications', async (req, res) => {
    try {
      const medicationData = insertMedicationSchema.parse(req.body);
      const medication = await storage.createMedication(medicationData);
      res.json(medication);
    } catch (error) {
      console.error("Error creating medication:", error);
      res.status(500).json({ message: "Failed to create medication" });
    }
  });

  app.get('/api/patients/:patientId/medications', async (req, res) => {
    try {
      const patientId = parseInt(req.params.patientId);
      const medications = await storage.getMedicationsByPatient(patientId);
      res.json(medications);
    } catch (error) {
      console.error("Error fetching medications:", error);
      res.status(500).json({ message: "Failed to fetch medications" });
    }
  });

  app.post('/api/medication-logs', async (req, res) => {
    try {
      const logData = insertMedicationLogSchema.parse(req.body);
      const log = await storage.createMedicationLog(logData);
      
      // Check for missed medications and create emergency if needed
      if (log.status === 'missed' && !log.actualTime) {
        await storage.createEmergencyEvent({
          patientId: log.patientId,
          eventType: 'medication_missed',
          severity: 'medium',
          description: `Missed medication dose`,
          medicationLogId: log.id,
          status: 'active',
          responseActions: ['Contact patient', 'Notify family', 'Schedule makeup dose'],
        });
      }
      
      res.json(log);
    } catch (error) {
      console.error("Error creating medication log:", error);
      res.status(500).json({ message: "Failed to create medication log" });
    }
  });

  app.get('/api/patients/:patientId/medication-logs', async (req, res) => {
    try {
      const patientId = parseInt(req.params.patientId);
      const logs = await storage.getMedicationLogsByPatient(patientId);
      res.json(logs);
    } catch (error) {
      console.error("Error fetching medication logs:", error);
      res.status(500).json({ message: "Failed to fetch medication logs" });
    }
  });

  app.get('/api/patients/:patientId/medication-adherence', async (req, res) => {
    try {
      const patientId = parseInt(req.params.patientId);
      const logs = await storage.getMedicationLogsByPatient(patientId);
      const analysis = await analyzeMedicationAdherence(logs);
      res.json(analysis);
    } catch (error) {
      console.error("Error analyzing medication adherence:", error);
      res.status(500).json({ message: "Failed to analyze medication adherence" });
    }
  });

  // AI Gaming routes
  app.post('/api/games', async (req, res) => {
    try {
      const gameData = insertGameActivitySchema.parse({
        ...req.body,
        status: 'in_progress'
      });
      
      // Generate initial game setup based on type
      let gameSetup = {};
      if (gameData.gameType === 'chess') {
        gameSetup = await generateChessMove({}, gameData.difficulty);
      } else if (gameData.gameType === 'cards') {
        gameSetup = await generateCardGame(gameData.gameName, gameData.difficulty);
      } else {
        gameSetup = {
          level: 1,
          score: 0,
          hint: 'Welcome to the memory game! Start by observing the pattern.'
        };
      }
      
      const game = await storage.createGameActivity({
        ...gameData,
        gameState: gameSetup,
      });
      
      res.json(game);
    } catch (error) {
      console.error("Error creating game:", error);
      res.status(500).json({ message: "Failed to create game" });
    }
  });

  app.get('/api/patients/:patientId/games', async (req, res) => {
    try {
      const patientId = parseInt(req.params.patientId);
      const games = await storage.getGameActivitiesByPatient(patientId);
      res.json(games);
    } catch (error) {
      console.error("Error fetching games:", error);
      res.status(500).json({ message: "Failed to fetch games" });
    }
  });

  app.get('/api/patients/:patientId/games/active', async (req, res) => {
    try {
      const patientId = parseInt(req.params.patientId);
      const activeGames = await storage.getActiveGames(patientId);
      res.json(activeGames);
    } catch (error) {
      console.error("Error fetching active games:", error);
      res.status(500).json({ message: "Failed to fetch active games" });
    }
  });

  app.post('/api/games/:gameId/move', async (req, res) => {
    try {
      const gameId = parseInt(req.params.gameId);
      const { move, playerMoves } = req.body;
      
      const game = await storage.updateGameActivity(gameId, {
        playerMoves: [...(playerMoves || []), move],
      });
      
      // Generate AI response
      let aiResponse;
      if (game.gameType === 'chess') {
        aiResponse = await generateChessMove(game.gameState, game.difficulty);
        await storage.updateGameActivity(gameId, {
          aiMoves: [...(game.aiMoves || []), aiResponse.move],
          gameState: Object.assign({}, game.gameState || {}, { lastMove: aiResponse.move }),
        });
      }
      
      res.json({ game, aiResponse });
    } catch (error) {
      console.error("Error processing game move:", error);
      res.status(500).json({ message: "Failed to process game move" });
    }
  });

  // Emergency response routes
  app.get('/api/emergency-events', async (req, res) => {
    try {
      const facilityId = req.query.facilityId ? parseInt(req.query.facilityId as string) : undefined;
      const events = await storage.getActiveEmergencies(facilityId);
      res.json(events);
    } catch (error) {
      console.error("Error fetching emergency events:", error);
      res.status(500).json({ message: "Failed to fetch emergency events" });
    }
  });

  app.get('/api/patients/:patientId/emergency-events', async (req, res) => {
    try {
      const patientId = parseInt(req.params.patientId);
      const events = await storage.getEmergencyEventsByPatient(patientId);
      res.json(events);
    } catch (error) {
      console.error("Error fetching patient emergency events:", error);
      res.status(500).json({ message: "Failed to fetch emergency events" });
    }
  });

  app.post('/api/emergency-events/:eventId/acknowledge', async (req, res) => {
    try {
      const eventId = parseInt(req.params.eventId);
      const { userId } = req.body;
      const event = await storage.acknowledgeEmergency(eventId, userId);
      res.json(event);
    } catch (error) {
      console.error("Error acknowledging emergency:", error);
      res.status(500).json({ message: "Failed to acknowledge emergency" });
    }
  });

  app.post('/api/emergency-events/:eventId/resolve', async (req, res) => {
    try {
      const eventId = parseInt(req.params.eventId);
      const event = await storage.resolveEmergency(eventId);
      res.json(event);
    } catch (error) {
      console.error("Error resolving emergency:", error);
      res.status(500).json({ message: "Failed to resolve emergency" });
    }
  });

  // Family Security and Encryption Routes
  
  // Send encrypted message (medical requests, admin communications, medication changes)
  app.post('/api/secure-messaging/send', handleAsyncErrors(async (req, res) => {
    const { fromUserId, toUserId, toFacilityId, messageType, content } = req.body;
    
    try {
      const success = await EncryptionService.sendSecureMessage(
        fromUserId,
        toUserId,
        toFacilityId,
        messageType,
        content
      );
      res.json({ success, message: 'Secure message sent successfully' });
    } catch (error) {
      if (error.message.includes('locked out')) {
        res.status(403).json({ message: error.message });
      } else {
        res.status(500).json({ message: 'Failed to send secure message' });
      }
    }
  }));

  // Get encrypted messages for user/facility
  app.get('/api/secure-messaging/:userId', handleAsyncErrors(async (req, res) => {
    const userId = parseInt(req.params.userId);
    const facilityId = req.query.facilityId ? parseInt(req.query.facilityId as string) : undefined;
    
    const messages = await EncryptionService.getSecureMessages(userId, facilityId);
    res.json(messages);
  }));

  // Set primary family member password
  app.post('/api/family-security/set-password', handleAsyncErrors(async (req, res) => {
    const { userId, patientId, password } = req.body;
    
    if (!password || password.length < 8) {
      res.status(400).json({ message: 'Password must be at least 8 characters long' });
      return;
    }
    
    const success = await EncryptionService.setPrimaryPassword(userId, patientId, password);
    
    if (success) {
      res.json({ success: true, message: 'Primary member password set successfully' });
    } else {
      res.status(400).json({ success: false, message: 'Failed to set password or user is not primary member' });
    }
  }));

  // Check if primary member needs password setup
  app.get('/api/family-security/needs-password/:userId/:patientId', handleAsyncErrors(async (req, res) => {
    const userId = parseInt(req.params.userId);
    const patientId = parseInt(req.params.patientId);
    
    const needsSetup = await EncryptionService.needsPasswordSetup(userId, patientId);
    res.json({ needsSetup });
  }));

  // Primary family member locks out another family member (with password)
  app.post('/api/family-security/lockout', handleAsyncErrors(async (req, res) => {
    const { primaryFamilyId, lockedOutFamilyId, patientId, lockoutType, reason, password } = req.body;
    
    const unlockCode = await EncryptionService.lockoutFamilyMember(
      primaryFamilyId,
      lockedOutFamilyId,
      patientId,
      lockoutType,
      reason,
      password
    );
    
    res.json({ 
      success: true, 
      unlockCode, 
      message: 'Family member has been locked out from medical/admin communications' 
    });
  }));

  // Check family member lockout status
  app.get('/api/family-security/lockout-status/:userId/:patientId', handleAsyncErrors(async (req, res) => {
    const userId = parseInt(req.params.userId);
    const patientId = parseInt(req.params.patientId);
    
    const isLockedOut = await EncryptionService.checkFamilyLockout(userId, patientId);
    res.json({ isLockedOut });
  }));

  // Administrative emergency unlock (requires unlock code)
  app.post('/api/family-security/admin-unlock', handleAsyncErrors(async (req, res) => {
    const { unlockCode, adminUserId } = req.body;
    
    const success = await EncryptionService.administrativeUnlock(unlockCode, adminUserId);
    
    if (success) {
      res.json({ success: true, message: 'Family member access restored by administrator' });
    } else {
      res.status(400).json({ success: false, message: 'Invalid unlock code or expired lockout' });
    }
  }));

  // Generate encryption key for secure communications
  app.post('/api/encryption/generate-key', handleAsyncErrors(async (req, res) => {
    const { userId, facilityId, keyType } = req.body;
    
    const keyId = await EncryptionService.generateEncryptionKey(userId, facilityId, keyType);
    res.json({ keyId, message: 'Encryption key generated successfully' });
  }));

  // Verify primary family member authority
  app.get('/api/family-security/verify-primary/:userId/:patientId', handleAsyncErrors(async (req, res) => {
    const userId = parseInt(req.params.userId);
    const patientId = parseInt(req.params.patientId);
    
    const isPrimary = await EncryptionService.verifyPrimaryFamilyMember(userId, patientId);
    res.json({ isPrimary });
  }));

  // Enhanced medication routes with encryption for medical data
  app.post('/api/patients/:patientId/medications/secure', handleAsyncErrors(async (req, res) => {
    const patientId = parseInt(req.params.patientId);
    const { medication, requesterId, encryptedData } = req.body;
    
    // Check if requester is locked out
    const isLockedOut = await EncryptionService.checkFamilyLockout(requesterId, patientId);
    if (isLockedOut) {
      res.status(403).json({ message: 'Access denied: Family member is locked out from medical requests' });
      return;
    }
    
    // Process encrypted medication request
    const newMedication = await storage.createMedication({
      patientId,
      ...medication
    });
    
    // Log the secure medication change
    await EncryptionService.sendSecureMessage(
      requesterId,
      null,
      1, // Facility ID
      'medication_change',
      JSON.stringify({ action: 'add_medication', medication: newMedication })
    );
    
    res.json(newMedication);
  }));

  // Enhanced admin communication routes with encryption
  app.post('/api/admin/secure-communication', handleAsyncErrors(async (req, res) => {
    const { fromUserId, message, priority, patientId } = req.body;
    
    // Check if sender is locked out
    const isLockedOut = await EncryptionService.checkFamilyLockout(fromUserId, patientId);
    if (isLockedOut) {
      res.status(403).json({ message: 'Access denied: Family member is locked out from admin communications' });
      return;
    }
    
    // Send encrypted admin communication
    await EncryptionService.sendSecureMessage(
      fromUserId,
      null,
      1, // Facility ID
      'admin_communication',
      JSON.stringify({ message, priority, patientId, timestamp: new Date().toISOString() })
    );
    
    res.json({ success: true, message: 'Secure admin communication sent' });
  }));



  // Invisible Cognitive Metrics Storage
  app.post('/api/cognitive-metrics', async (req, res) => {
    try {
      const { patientId, metrics, userBehavior, timestamp, sessionDuration } = req.body;
      
      // Store cognitive metrics in database
      const cognitiveData = {
        patientId: parseInt(patientId),
        memoryRetention: metrics.memoryRetention || 0,
        attentionSpan: metrics.attentionSpan || 0,
        processingSpeed: metrics.processingSpeed || 0,
        patternRecognition: metrics.patternRecognition || 0,
        responseTime: metrics.responseTime || 0,
        interactionQuality: metrics.interactionQuality || 0,
        behaviorData: JSON.stringify(userBehavior),
        sessionDuration,
        recordedAt: new Date(timestamp)
      };

      // Calculate overall cognitive score
      const overallScore = Object.values(metrics).reduce((a: number, b: number) => a + b, 0) / Object.values(metrics).length;
      
      // Store in cognitive progress table
      await storage.createCognitiveProgress({
        patientId: parseInt(patientId),
        sessionType: 'invisible_tracking',
        score: Math.round(overallScore),
        duration: sessionDuration,
        difficulty: 'adaptive',
        cognitiveAreas: JSON.stringify({
          memory: metrics.memoryRetention,
          attention: metrics.attentionSpan,
          processing: metrics.processingSpeed,
          patterns: metrics.patternRecognition
        }),
        improvements: JSON.stringify([
          'Background cognitive monitoring',
          'Behavioral pattern analysis',
          'Adaptive difficulty adjustment'
        ]),
        notes: 'Automatically collected through invisible interface tracking'
      });

      res.json({ success: true, overallScore: Math.round(overallScore) });
    } catch (error) {
      console.error('Error storing cognitive metrics:', error);
      res.status(500).json({ message: 'Failed to store cognitive metrics' });
    }
  });

  // Get latest cognitive metrics
  app.get('/api/cognitive-metrics/latest/:patientId?', async (req, res) => {
    try {
      const patientId = req.params.patientId ? parseInt(req.params.patientId) : 1;
      
      const latestProgress = await storage.getLatestCognitiveProgress(patientId);
      
      if (!latestProgress) {
        return res.json({
          memoryRetention: 0,
          attentionSpan: 0,
          processingSpeed: 0,
          patternRecognition: 0,
          responseTime: 0,
          interactionQuality: 0
        });
      }

      const cognitiveAreas = JSON.parse(latestProgress.cognitiveAreas || '{}');
      
      res.json({
        memoryRetention: cognitiveAreas.memory || 0,
        attentionSpan: cognitiveAreas.attention || 0,
        processingSpeed: cognitiveAreas.processing || 0,
        patternRecognition: cognitiveAreas.patterns || 0,
        responseTime: latestProgress.score || 0,
        interactionQuality: latestProgress.score || 0,
        lastUpdated: latestProgress.completedAt
      });
    } catch (error) {
      console.error('Error fetching cognitive metrics:', error);
      res.status(500).json({ message: 'Failed to fetch cognitive metrics' });
    }
  });

  // Square Payment and Subscription Routes
  
  // Start free trial
  app.post('/api/subscription/start-trial', async (req, res) => {
    try {
      const { userId, planId = 'care-companion-monthly' } = req.body;
      
      if (!userId) {
        return res.status(400).json({ message: 'User ID is required' });
      }

      const result = await squarePaymentService.startFreeTrial(userId, planId);
      res.json(result);
    } catch (error: any) {
      console.error('Error starting trial:', error);
      res.status(500).json({ message: error.message || 'Failed to start trial' });
    }
  });

  // Check subscription status
  app.get('/api/subscription/status/:userId', async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const user = await storage.getUserSubscriptionStatus(userId);
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      const trialStatus = await squarePaymentService.checkTrialExpiration(userId);
      
      res.json({
        subscriptionStatus: user.subscriptionStatus,
        planType: user.planType,
        monthlyPrice: user.monthlyPrice,
        trialStartDate: user.trialStartDate,
        trialEndDate: user.trialEndDate,
        nextBillingDate: user.nextBillingDate,
        ...trialStatus
      });
    } catch (error: any) {
      console.error('Error checking subscription status:', error);
      res.status(500).json({ message: error.message || 'Failed to check status' });
    }
  });

  // Get subscription plans
  app.get('/api/subscription/plans', async (req, res) => {
    try {
      res.json(SUBSCRIPTION_PLANS);
    } catch (error: any) {
      console.error('Error fetching plans:', error);
      res.status(500).json({ message: 'Failed to fetch plans' });
    }
  });

  // Create Square customer and subscription
  app.post('/api/subscription/create', async (req, res) => {
    try {
      const { userId, email, firstName, lastName, planId = 'care-companion-monthly', paymentMethodId } = req.body;
      
      if (!userId || !email || !paymentMethodId) {
        return res.status(400).json({ message: 'Missing required fields' });
      }

      // Create Square customer
      const customer = await squarePaymentService.createCustomer(email, firstName, lastName);
      
      // Create subscription
      const subscription = await squarePaymentService.createSubscription(
        customer.id, 
        planId, 
        paymentMethodId
      );

      // Update user record
      await storage.updateUserSubscription(userId, {
        squareCustomerId: customer.id,
        subscriptionId: subscription.id,
        subscriptionStatus: 'active',
        subscriptionStartDate: new Date(),
        nextBillingDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days from now
      });

      res.json({
        success: true,
        customerId: customer.id,
        subscriptionId: subscription.id,
        message: 'Subscription created successfully'
      });
    } catch (error: any) {
      console.error('Error creating subscription:', error);
      res.status(500).json({ message: error.message || 'Failed to create subscription' });
    }
  });

  // Cancel subscription
  app.post('/api/subscription/cancel/:userId', async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const user = await storage.getUserSubscriptionStatus(userId);
      
      if (!user || !user.subscriptionId) {
        return res.status(404).json({ message: 'No active subscription found' });
      }

      await squarePaymentService.cancelSubscription(user.subscriptionId);
      
      await storage.updateUserSubscription(userId, {
        subscriptionStatus: 'canceled'
      });

      res.json({ success: true, message: 'Subscription canceled successfully' });
    } catch (error: any) {
      console.error('Error canceling subscription:', error);
      res.status(500).json({ message: error.message || 'Failed to cancel subscription' });
    }
  });

  // Process one-time payment
  app.post('/api/payment/process', async (req, res) => {
    try {
      const { amount, currency = 'USD', sourceId, customerId } = req.body;
      
      if (!amount || !sourceId) {
        return res.status(400).json({ message: 'Amount and payment source required' });
      }

      const payment = await squarePaymentService.processPayment(
        Math.round(amount * 100), // Convert to cents
        currency,
        sourceId,
        customerId
      );

      res.json({
        success: true,
        paymentId: payment.id,
        status: payment.status,
        message: 'Payment processed successfully'
      });
    } catch (error: any) {
      console.error('Error processing payment:', error);
      res.status(500).json({ message: error.message || 'Payment failed' });
    }
  });

  // AI Photo Analysis endpoint
  app.post("/api/ai/analyze-photo", upload.single('photo'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No photo uploaded" });
      }

      const { patientId, userInputPeople, userInputContext } = req.body;
      
      if (!process.env.OPENAI_API_KEY) {
        return res.status(500).json({ message: "AI service not configured" });
      }

      // Convert image to base64
      const base64Image = req.file.buffer.toString('base64');
      
      // Analyze with OpenAI Vision
      const OpenAI = (await import('openai')).default;
      const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: `You are an AI assistant specialized in analyzing photos for Alzheimer's patients to help preserve memories. 
            Analyze the image and provide detailed information about people, objects, emotional context, and memory triggers.
            User has indicated these people might be in the photo: "${userInputPeople}"
            User context: "${userInputContext}"
            Respond with JSON in this exact format: {
              "peopleIdentified": ["person1", "person2"],
              "objectsDetected": ["object1", "object2"],
              "contextDescription": "detailed description",
              "emotionalContext": "emotional tone analysis",
              "memoryTriggers": ["trigger1", "trigger2"],
              "aiConfidence": 0.85
            }`
          },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: "Please analyze this photo for memory preservation purposes."
              },
              {
                type: "image_url",
                image_url: {
                  url: `data:image/jpeg;base64,${base64Image}`
                }
              }
            ]
          }
        ],
        response_format: { type: "json_object" },
        max_tokens: 1000,
      });

      const analysis = JSON.parse(response.choices[0].message.content || '{}');
      
      // Process user input
      const userPeople = userInputPeople ? userInputPeople.split(',').map((p: string) => p.trim()).filter(Boolean) : [];
      
      const photoAnalysis = {
        id: `photo_${Date.now()}`,
        fileName: req.file.originalname,
        peopleIdentified: analysis.peopleIdentified || [],
        objectsDetected: analysis.objectsDetected || [],
        contextDescription: analysis.contextDescription || '',
        emotionalContext: analysis.emotionalContext || '',
        memoryTriggers: analysis.memoryTriggers || [],
        aiConfidence: analysis.aiConfidence || 0.0,
        userInputPeople: userPeople,
        userInputContext: userInputContext || '',
        processingStatus: 'completed'
      };

      res.json(photoAnalysis);
    } catch (error: any) {
      console.error("Photo analysis error:", error);
      res.status(500).json({ 
        message: "Failed to analyze photo",
        processingStatus: 'error'
      });
    }
  });

  // Test initialization route
  app.post('/api/test/initialize-all', async (req, res) => {
    try {
      const { initializeAndTestAll } = await import('./test-all-systems');
      const result = await initializeAndTestAll();
      res.json(result);
    } catch (error: any) {
      console.error("Test initialization failed:", error);
      res.status(500).json({ message: "Test initialization failed", error: error.message });
    }
  });

  // Advanced Voice AI endpoints
  app.post('/api/patients/:patientId/voice/analyze', handleAsyncErrors(async (req, res) => {
    const { patientId } = req.params;
    const { transcript, conversationHistory } = req.body;
    
    if (!transcript) {
      res.status(400).json({ message: 'Transcript is required' });
      return;
    }
    
    const patient = await storage.getPatient(parseInt(patientId));
    if (!patient) {
      res.status(404).json({ message: 'Patient not found' });
      return;
    }
    
    const analysis = await analyzeVoiceInput(transcript, patient, conversationHistory);
    
    // Check for emergency situations
    const emergencyCheck = await detectEmergencyKeywords(transcript);
    if (emergencyCheck.isEmergency) {
      // Log emergency event
      await storage.createEmergencyEvent({
        patientId: parseInt(patientId),
        eventType: 'voice_emergency_detected',
        severity: emergencyCheck.confidence > 0.8 ? 'high' : 'medium',
        description: `Emergency detected in voice: ${emergencyCheck.keywords.join(', ')}`,
        status: 'active',
        alertedContacts: []
      });
    }
    
    res.json({
      analysis,
      emergency: emergencyCheck,
      timestamp: new Date().toISOString()
    });
  }));

  app.post('/api/patients/:patientId/voice/respond', handleAsyncErrors(async (req, res) => {
    const { patientId } = req.params;
    const { transcript, voiceAnalysis, conversationHistory } = req.body;
    
    if (!transcript || !voiceAnalysis) {
      res.status(400).json({ message: 'Transcript and voice analysis are required' });
      return;
    }
    
    const patient = await storage.getPatient(parseInt(patientId));
    if (!patient) {
      res.status(404).json({ message: 'Patient not found' });
      return;
    }
    
    const response = await generateContextualResponse(
      transcript, 
      voiceAnalysis, 
      patient, 
      conversationHistory
    );
    
    res.json({
      response,
      voicePersonality: voiceAnalysis.voicePersonality,
      timestamp: new Date().toISOString()
    });
  }));

  app.post('/api/patients/:patientId/voice/personality', handleAsyncErrors(async (req, res) => {
    const { patientId } = req.params;
    const { preferences, timeOfDay, recentInteractions } = req.body;
    
    const patient = await storage.getPatient(parseInt(patientId));
    if (!patient) {
      res.status(404).json({ message: 'Patient not found' });
      return;
    }
    
    const personality = await generateVoicePersonality(
      preferences || patient.medicalInfo, 
      timeOfDay || new Date().toLocaleTimeString(), 
      recentInteractions || []
    );
    
    res.json({
      personality,
      patientId: parseInt(patientId),
      timestamp: new Date().toISOString()
    });
  }));

  app.post('/api/patients/:patientId/voice/emergency-check', handleAsyncErrors(async (req, res) => {
    const { patientId } = req.params;
    const { transcript } = req.body;
    
    if (!transcript) {
      res.status(400).json({ message: 'Transcript is required' });
      return;
    }
    
    const emergencyAnalysis = await detectEmergencyKeywords(transcript);
    
    if (emergencyAnalysis.isEmergency && emergencyAnalysis.confidence > 0.7) {
      // Create emergency event
      const emergencyEvent = await storage.createEmergencyEvent({
        patientId: parseInt(patientId),
        eventType: 'voice_emergency',
        severity: emergencyAnalysis.confidence > 0.9 ? 'critical' : 'high',
        description: `Voice emergency detected: ${emergencyAnalysis.keywords.join(', ')}`,
        status: 'active',
        alertedContacts: []
      });
      
      res.json({
        emergency: true,
        analysis: emergencyAnalysis,
        emergencyEvent,
        recommendedAction: emergencyAnalysis.recommendedAction
      });
    } else {
      res.json({
        emergency: false,
        analysis: emergencyAnalysis
      });
    }
  }));

  // Square Subscription Routes
  app.post("/api/square/create-customer", async (req, res) => {
    try {
      const { email, firstName, lastName, phoneNumber } = req.body;
      
      const customer = await squareSubscriptionService.createCustomer({
        email,
        firstName,
        lastName,
        phoneNumber
      });

      res.json({ success: true, customer });
    } catch (error: any) {
      console.error('Create customer error:', error);
      res.status(500).json({ 
        success: false, 
        error: error.message || 'Failed to create customer' 
      });
    }
  });

  app.post("/api/square/create-subscription", async (req, res) => {
    try {
      const { customerId, userId } = req.body;
      
      const subscription = await squareSubscriptionService.createSubscription(customerId);
      
      // Update user record with Square subscription info
      if (userId) {
        await storage.updateUserSubscription(userId, {
          squareCustomerId: customerId,
          squareSubscriptionId: subscription?.id,
          subscriptionStatus: 'active',
          subscriptionStartDate: new Date(),
          nextBillingDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // 14 days trial
          planType: CARE_COMPANION_PLAN.id
        });
      }

      res.json({ success: true, subscription });
    } catch (error: any) {
      console.error('Create subscription error:', error);
      res.status(500).json({ 
        success: false, 
        error: error.message || 'Failed to create subscription' 
      });
    }
  });

  app.get("/api/square/subscription/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const subscription = await squareSubscriptionService.getSubscription(id);
      res.json({ success: true, subscription });
    } catch (error: any) {
      console.error('Get subscription error:', error);
      res.status(500).json({ 
        success: false, 
        error: error.message || 'Failed to get subscription' 
      });
    }
  });

  app.post("/api/square/cancel-subscription", async (req, res) => {
    try {
      const { subscriptionId, userId } = req.body;
      
      const subscription = await squareSubscriptionService.cancelSubscription(subscriptionId);
      
      // Update user record
      if (userId) {
        await storage.updateUserSubscription(userId, {
          subscriptionStatus: 'canceled'
        });
      }

      res.json({ success: true, subscription });
    } catch (error: any) {
      console.error('Cancel subscription error:', error);
      res.status(500).json({ 
        success: false, 
        error: error.message || 'Failed to cancel subscription' 
      });
    }
  });

  app.post("/api/square/pause-subscription", async (req, res) => {
    try {
      const { subscriptionId, userId } = req.body;
      
      const subscription = await squareSubscriptionService.pauseSubscription(subscriptionId);
      
      // Update user record
      if (userId) {
        await storage.updateUserSubscription(userId, {
          subscriptionStatus: 'paused'
        });
      }

      res.json({ success: true, subscription });
    } catch (error: any) {
      console.error('Pause subscription error:', error);
      res.status(500).json({ 
        success: false, 
        error: error.message || 'Failed to pause subscription' 
      });
    }
  });

  app.post("/api/square/resume-subscription", async (req, res) => {
    try {
      const { subscriptionId, userId } = req.body;
      
      const subscription = await squareSubscriptionService.resumeSubscription(subscriptionId);
      
      // Update user record
      if (userId) {
        await storage.updateUserSubscription(userId, {
          subscriptionStatus: 'active'
        });
      }

      res.json({ success: true, subscription });
    } catch (error: any) {
      console.error('Resume subscription error:', error);
      res.status(500).json({ 
        success: false, 
        error: error.message || 'Failed to resume subscription' 
      });
    }
  });

  app.get("/api/square/plans", async (req, res) => {
    try {
      res.json({ 
        success: true, 
        plans: [CARE_COMPANION_PLAN] 
      });
    } catch (error: any) {
      console.error('Get plans error:', error);
      res.status(500).json({ 
        success: false, 
        error: error.message || 'Failed to get plans' 
      });
    }
  });

  app.post("/api/square/process-payment", async (req, res) => {
    try {
      const { sourceId, amount, currency, customerId, orderId } = req.body;
      
      const payment = await squareSubscriptionService.processPayment({
        sourceId,
        amount,
        currency: currency || 'USD',
        customerId,
        orderId
      });

      res.json({ success: true, payment });
    } catch (error: any) {
      console.error('Process payment error:', error);
      res.status(500).json({ 
        success: false, 
        error: error.message || 'Failed to process payment' 
      });
    }
  });

  // Translation API endpoints
  app.post("/api/translate", async (req, res) => {
    try {
      const { text, targetLanguage, sourceLanguage } = req.body;
      
      if (!text || !targetLanguage) {
        return res.status(400).json({ 
          error: 'Text and target language are required' 
        });
      }

      const translation = await translateText({
        text,
        targetLanguage,
        sourceLanguage
      });

      res.json(translation);
    } catch (error: any) {
      console.error('Translation error:', error);
      res.status(500).json({ 
        error: 'Translation service unavailable',
        fallback: req.body.text
      });
    }
  });

  app.get("/api/supported-languages", (req, res) => {
    res.json({
      languages: [
        { code: 'en', name: 'English', nativeName: 'English' },
        { code: 'es', name: 'Spanish', nativeName: 'Español' },
        { code: 'fr', name: 'French', nativeName: 'Français' },
        { code: 'de', name: 'German', nativeName: 'Deutsch' },
        { code: 'it', name: 'Italian', nativeName: 'Italiano' },
        { code: 'pt', name: 'Portuguese', nativeName: 'Português' },
        { code: 'ru', name: 'Russian', nativeName: 'Русский' },
        { code: 'zh', name: 'Chinese', nativeName: '中文' },
        { code: 'ja', name: 'Japanese', nativeName: '日本語' },
        { code: 'ko', name: 'Korean', nativeName: '한국어' },
        { code: 'ar', name: 'Arabic', nativeName: 'العربية' },
        { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी' },
        { code: 'th', name: 'Thai', nativeName: 'ไทย' },
        { code: 'vi', name: 'Vietnamese', nativeName: 'Tiếng Việt' },
        { code: 'nl', name: 'Dutch', nativeName: 'Nederlands' },
        { code: 'sv', name: 'Swedish', nativeName: 'Svenska' },
        { code: 'da', name: 'Danish', nativeName: 'Dansk' },
        { code: 'no', name: 'Norwegian', nativeName: 'Norsk' },
        { code: 'fi', name: 'Finnish', nativeName: 'Suomi' },
        { code: 'pl', name: 'Polish', nativeName: 'Polski' }
      ]
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
