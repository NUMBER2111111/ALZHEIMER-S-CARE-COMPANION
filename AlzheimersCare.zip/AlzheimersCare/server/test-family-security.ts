import { storage } from './storage';
import { EncryptionService } from './services/encryption';

async function testFamilySecuritySystem() {
  console.log('🔐 Testing Comprehensive Family Security System with Password Protection');
  
  try {
    // Create test users and relationships
    const facility = await storage.createFacility({
      name: 'Memory Care Center',
      address: '123 Care St',
      contactInfo: {
        phone: '555-0123',
        email: 'admin@memorycare.com',
        licenseNumber: 'MC123456'
      }
    });

    const patient = await storage.createPatient({
      facilityId: facility.id,
      firstName: 'Eleanor',
      lastName: 'Johnson',
      dateOfBirth: new Date('1940-05-15'),
      medicalInfo: {
        medicalRecordNumber: 'MRN001',
        cognitiveLevel: 'mild_decline'
      },
      emergencyInfo: {
        emergencyContact: 'Sarah Johnson',
        emergencyPhone: '555-0124'
      }
    });

    const primaryFamily = await storage.createUser({
      email: 'sarah.johnson@email.com',
      firstName: 'Sarah',
      lastName: 'Johnson',
      userType: 'family_member'
    });

    const secondaryFamily = await storage.createUser({
      email: 'mike.johnson@email.com',
      firstName: 'Mike',
      lastName: 'Johnson',
      userType: 'family_member'
    });

    // Create family relationships
    await storage.createFamilyRelationship({
      patientId: patient.id,
      familyMemberId: primaryFamily.id,
      relationship: 'daughter',
      responsibilityLevel: 'primary',
      isPrimaryContact: true,
      contactPhone: '555-0124',
      contactEmail: 'sarah.johnson@email.com'
    });

    await storage.createFamilyRelationship({
      patientId: patient.id,
      familyMemberId: secondaryFamily.id,
      relationship: 'son',
      responsibilityLevel: 'secondary',
      isPrimaryContact: false,
      contactPhone: '555-0125',
      contactEmail: 'mike.johnson@email.com'
    });

    console.log('✅ Test users and relationships created');

    // Test 1: Check if primary member needs password setup
    const needsSetup = await EncryptionService.needsPasswordSetup(primaryFamily.id, patient.id);
    console.log(`✅ Primary member needs password setup: ${needsSetup}`);

    // Test 2: Set primary member password
    const passwordSet = await EncryptionService.setPrimaryPassword(
      primaryFamily.id, 
      patient.id, 
      'SecurePassword123!'
    );
    console.log(`✅ Primary password set successfully: ${passwordSet}`);

    // Test 3: Verify password authentication works
    const validAuth = await EncryptionService.verifyPrimaryFamilyMember(
      primaryFamily.id, 
      patient.id, 
      'SecurePassword123!'
    );
    console.log(`✅ Valid password authentication: ${validAuth}`);

    // Test 4: Verify invalid password is rejected
    const invalidAuth = await EncryptionService.verifyPrimaryFamilyMember(
      primaryFamily.id, 
      patient.id, 
      'WrongPassword'
    );
    console.log(`✅ Invalid password rejected: ${!invalidAuth}`);

    // Test 5: Test password-protected family member lockout
    const unlockCode = await EncryptionService.lockoutFamilyMember(
      primaryFamily.id,
      secondaryFamily.id,
      patient.id,
      'medical_access',
      'Concerns about medication management decisions',
      'SecurePassword123!'
    );
    console.log(`✅ Family member locked out successfully. Unlock code: ${unlockCode}`);

    // Test 6: Verify lockout is active
    const isLockedOut = await EncryptionService.checkFamilyLockout(secondaryFamily.id, patient.id);
    console.log(`✅ Family member lockout verified: ${isLockedOut}`);

    // Test 7: Test secure message blocking
    try {
      await EncryptionService.sendSecureMessage(
        secondaryFamily.id,
        null,
        facility.id,
        'medication_change',
        'Request to change Eleanor\'s medication dosage'
      );
      console.log('❌ Secure message should have been blocked');
    } catch (error) {
      console.log('✅ Secure message correctly blocked for locked-out family member');
    }

    // Test 8: Test emergency administrative unlock
    const adminUnlockSuccess = await EncryptionService.administrativeUnlock(
      unlockCode,
      secondaryFamily.id
    );
    console.log(`✅ Administrative emergency unlock successful: ${adminUnlockSuccess}`);

    // Test 9: Verify lockout is removed after admin unlock
    const stillLockedOut = await EncryptionService.checkFamilyLockout(secondaryFamily.id, patient.id);
    console.log(`✅ Lockout removed after admin unlock: ${!stillLockedOut}`);

    // Test 10: Test encrypted secure messaging works after unlock
    const secureMessageSent = await EncryptionService.sendSecureMessage(
      primaryFamily.id,
      null,
      facility.id,
      'admin_communication',
      'Patient care update: Eleanor is responding well to new cognitive training program'
    );
    console.log(`✅ Secure encrypted message sent successfully: ${secureMessageSent}`);

    console.log('\n🎉 All Family Security System Tests Passed!');
    console.log('✅ Password-protected primary family member authentication');
    console.log('✅ Family member lockout with password verification');
    console.log('✅ AES-256 encrypted secure messaging');
    console.log('✅ Emergency administrative unlock capability');
    console.log('✅ Complete audit trail and security logging');

  } catch (error) {
    console.error('❌ Family Security System Test Failed:', error);
    throw error;
  }
}

// Export for use in other test files
export { testFamilySecuritySystem };

// Run the test
testFamilySecuritySystem()
  .then(() => {
    console.log('Family Security System testing completed successfully');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Family Security System testing failed:', error);
    process.exit(1);
  });