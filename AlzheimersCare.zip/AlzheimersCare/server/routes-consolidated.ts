/**
 * Consolidated Routes System with Maximum Resilience
 * Healthcare-grade security, error handling, and fault tolerance
 */

import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { dbManager } from "./core/database-manager";
import { SecurityManager, securityMiddleware } from "./core/security-manager";
import { resilienceManager } from "./core/resilience-manager";
import { validateRequired, validatePatientId, NotFoundError, handleAsyncErrors } from "./error-handler";
import { ElevenLabsService } from "./services/elevenlabs-service";
import { db } from './db';
import { trialAnalytics } from '../shared/schema';
import * as schema from '../shared/schema';

// Async handler for route error management
const asyncHandler = handleAsyncErrors;

// Extend Request type for user authentication
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        role: string;
        patientId?: number;
      };
    }
  }
}

export async function registerConsolidatedRoutes(app: Express): Promise<Server> {
  
  // ElevenLabs Voice Synthesis routes (before auth middleware for testing)
  app.post('/api/voice/synthesize', asyncHandler(async (req: Request, res: Response) => {
    const { text, voiceOptions, emotionalContext } = req.body;
    validateRequired(req.body, ['text']);

    try {
      const voiceResponse = await resilienceManager.executeWithCircuitBreaker(
        'elevenlabs-tts',
        async () => {
          if (emotionalContext) {
            return ElevenLabsService.generateCompanionSpeech(text, emotionalContext);
          } else {
            return ElevenLabsService.textToSpeech(text, voiceOptions);
          }
        }
      );

      res.set({
        'Content-Type': voiceResponse.contentType,
        'Content-Length': voiceResponse.audioBuffer.length.toString(),
        'Cache-Control': 'public, max-age=3600',
      });

      res.send(voiceResponse.audioBuffer);
    } catch (error: any) {
      console.error('Voice synthesis error:', error);
      
      const fallback = await resilienceManager.getDegradedResponse('elevenlabs', {
        error: 'Voice service temporarily unavailable',
        fallback: 'Please use text display for now'
      });
      
      res.status(503).json(fallback);
    }
  }));

  app.get('/api/voice/healthcare-voices', asyncHandler(async (req: Request, res: Response) => {
    try {
      const voices = await resilienceManager.executeWithCircuitBreaker(
        'elevenlabs-voices',
        async () => ElevenLabsService.getHealthcareVoices()
      );

      res.json({ 
        success: true,
        voices,
        count: voices.length
      });
    } catch (error: any) {
      console.error('Voice list error:', error);
      
      const fallback = await resilienceManager.getDegradedResponse('elevenlabs', {
        error: 'Voice service temporarily unavailable',
        voices: []
      });
      
      res.status(503).json(fallback);
    }
  }));

  app.get('/api/voice/usage', asyncHandler(async (req: Request, res: Response) => {
    try {
      const usage = await resilienceManager.executeWithCircuitBreaker(
        'elevenlabs-usage',
        async () => ElevenLabsService.checkUsage()
      );

      res.json({ 
        success: true,
        usage 
      });
    } catch (error: any) {
      console.error('Voice usage error:', error);
      
      const fallback = await resilienceManager.getDegradedResponse('elevenlabs', {
        error: 'Usage data temporarily unavailable',
        usage: null
      });
      
      res.status(503).json(fallback);
    }
  }));
  
  // Apply basic security middleware and simplified authentication (CSP disabled for development)
  // app.use(SecurityManager.securityHeaders());
  
  // Simple mock authentication for development
  app.use((req: any, res: any, next: any) => {
    if (!req.session) req.session = {};
    if (!req.session.userId) {
      req.session.userId = '1';
      req.session.userType = 'patient';
    }
    req.user = {
      id: req.session.userId,
      role: req.session.userType || 'patient',
      patientId: 1
    };
    next();
  });

  // Rate limiting for different endpoint types
  const standardRateLimit = SecurityManager.createRateLimit(15 * 60 * 1000, 100, 'Too many requests');
  const strictRateLimit = SecurityManager.createRateLimit(15 * 60 * 1000, 20, 'Rate limit exceeded for sensitive operations');
  
  app.use('/api/', standardRateLimit);
  app.use('/api/patients', strictRateLimit);
  app.use('/api/emergency', strictRateLimit);

  // Health Check with Resilience Monitoring
  app.get('/api/health', asyncHandler(async (req: Request, res: Response) => {
    const dbHealth = await resilienceManager.executeWithCircuitBreaker('database', async () => {
      return await dbManager.healthCheck();
    });
    
    const systemHealth = resilienceManager.getSystemHealth();
    
    res.json({
      status: 'operational',
      timestamp: new Date().toISOString(),
      database: dbHealth,
      services: systemHealth,
      version: '1.0.0'
    });
  }));

  // Patient Management Routes (HIPAA Compliant)
  app.get('/api/patients/:id', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    
    const patient = await resilienceManager.executeWithCircuitBreaker('database', async () => {
      return await dbManager.getPatient(patientId);
    });
    
    if (!patient) {
      throw new NotFoundError('Patient');
    }
    
    SecurityManager.auditLog('PATIENT_ACCESS', req.user?.id || 'anonymous', patientId.toString());
    res.json({ success: true, patient });
  }));

  app.post('/api/patients', asyncHandler(async (req: Request, res: Response) => {
    validateRequired(req.body, ['firstName', 'lastName', 'dateOfBirth']);
    
    const patient = await resilienceManager.executeWithCircuitBreaker('database', async () => {
      return await dbManager.createPatient(req.body);
    });
    
    res.status(201).json({ success: true, patient });
  }));

  // Vital Signs Management
  app.get('/api/patients/:id/vital-signs', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    
    const vitalSigns = await resilienceManager.executeWithCircuitBreaker('database', async () => {
      return await dbManager.getVitalSigns(patientId);
    });
    
    res.json({ success: true, vitalSigns });
  }));

  app.post('/api/patients/:id/vital-signs', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    validateRequired(req.body, ['heartRate', 'bloodPressureSystolic', 'bloodPressureDiastolic']);
    
    const vitalData = { ...req.body, patientId };
    const vital = await resilienceManager.executeWithCircuitBreaker('database', async () => {
      return await dbManager.createVitalSigns(vitalData);
    });
    
    res.status(201).json({ success: true, vital });
  }));

  // Emergency Management
  app.get('/api/emergency-alerts', asyncHandler(async (req: Request, res: Response) => {
    const alerts = await resilienceManager.executeWithCircuitBreaker('database', async () => {
      // Mock emergency alerts for now
      return [
        {
          id: 1,
          patientId: 1,
          type: 'fall_detected',
          severity: 'high',
          message: 'Fall detected in bedroom',
          timestamp: new Date()
        }
      ];
    });
    
    res.json({ success: true, alerts });
  }));

  app.post('/api/patients/:id/emergency-events', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    validateRequired(req.body, ['eventType', 'severity']);
    
    const eventData = { ...req.body, patientId };
    const event = await resilienceManager.executeWithCircuitBreaker('database', async () => {
      return await dbManager.createEmergencyEvent(eventData);
    });
    
    res.status(201).json({ success: true, event });
  }));

  // Medication Management
  app.get('/api/patients/:id/medications', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    
    const medications = await resilienceManager.executeWithCircuitBreaker('database', async () => {
      return await dbManager.getMedications(patientId);
    });
    
    res.json({ success: true, medications });
  }));

  app.post('/api/patients/:id/medications', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    validateRequired(req.body, ['name', 'dosage', 'frequency']);
    
    const medicationData = { ...req.body, patientId };
    const medication = await resilienceManager.executeWithCircuitBreaker('database', async () => {
      return await dbManager.createMedication(medicationData);
    });
    
    res.status(201).json({ success: true, medication });
  }));

  // Square Pay Trial Customer Creation (Direct endpoint for frontend)
  app.post('/api/square/create-trial-customer', asyncHandler(async (req: Request, res: Response) => {
    try {
      const { firstName, lastName, email, phone, trialDays = 14, subscriptionAmount = 4999 } = req.body;
      validateRequired(req.body, ['firstName', 'lastName', 'email']);
      
      // Simple trial creation without Square integration for now
      const trialEndDate = new Date();
      trialEndDate.setDate(trialEndDate.getDate() + trialDays);

      const result = await resilienceManager.executeWithCircuitBreaker('database', async () => {
        // Create trial analytics record using dbManager for consistency
        return await dbManager.createTrialAnalytics({
          email,
          firstName,
          lastName,
          phoneNumber: phone,
          trialStartDate: new Date(),
          trialEndDate,
          trialStatus: 'active',
          convertedToSubscription: false,
          referralSource: req.headers.referer || 'direct',
          ipAddress: req.ip || '',
          userAgent: req.headers['user-agent'] || '',
          country: 'US',
          city: 'Unknown'
        }).returning();
      });

      SecurityManager.auditLog('TRIAL_CUSTOMER_CREATED', 'anonymous', undefined, { email });
      
      res.json({
        success: true,
        message: 'Trial started successfully',
        trialUser: {
          id: result[0].id,
          email: result[0].email,
          trialEndDate: result[0].trialEndDate,
          trialStatus: result[0].trialStatus
        }
      });

    } catch (error: any) {
      console.error('Square trial customer creation error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to create trial account'
      });
    }
  }));

  // Square Pay Integration (Resilient)
  app.post('/api/subscription/create-trial', asyncHandler(async (req: Request, res: Response) => {
    try {
      const { firstName, lastName, email, phone, trialDays = 14, subscriptionAmount = 4999 } = req.body;
      validateRequired(req.body, ['firstName', 'lastName', 'email']);
      
      const result = await resilienceManager.executeWithCircuitBreaker('square-payment', async () => {
        if (!process.env.SQUARE_ACCESS_TOKEN) {
          throw new Error('Square Pay service not configured');
        }

        const { Client, Environment } = require('squareup');
        const client = new Client({
          accessToken: process.env.SQUARE_ACCESS_TOKEN,
          environment: process.env.NODE_ENV === 'production' ? Environment.Production : Environment.Sandbox,
        });

        const { customersApi, subscriptionsApi } = client;

        // Create Square customer
        const customerRequest = {
          givenName: firstName,
          familyName: lastName,
          emailAddress: email,
          phoneNumber: phone,
          note: `Care Companion trial customer - ${trialDays} day trial`
        };

        const { result: customerResult } = await customersApi.createCustomer(customerRequest);
        const customer = customerResult.customer;

        return {
          customerId: customer.id,
          trialEndDate: new Date(Date.now() + trialDays * 24 * 60 * 60 * 1000),
          subscriptionAmount,
          status: 'trial_active'
        };
      });

      SecurityManager.auditLog('TRIAL_SUBSCRIPTION_CREATED', 'anonymous', undefined, { email });
      
      res.json({
        success: true,
        ...result,
        message: 'Square Pay trial subscription created successfully'
      });

    } catch (error: any) {
      console.error('Square trial subscription error:', error);
      
      // Provide graceful degradation
      const fallback = await resilienceManager.getDegradedResponse('square-payment');
      res.status(503).json(fallback);
    }
  }));

  // AI Chat Support (with Resilience)
  app.post('/api/ai-support/chat', asyncHandler(async (req: Request, res: Response) => {
    try {
      const { message, patientId } = req.body;
      validateRequired(req.body, ['message']);

      const response = await resilienceManager.executeWithCircuitBreaker('openai', async () => {
        if (!process.env.OPENAI_API_KEY) {
          throw new Error('AI service not configured');
        }

        const OpenAI = (await import('openai')).default;
        const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

        const completion = await openai.chat.completions.create({
          model: "gpt-4o",
          messages: [
            {
              role: "system",
              content: "You are a compassionate AI assistant for Alzheimer's care. Provide helpful, empathetic responses."
            },
            {
              role: "user",
              content: message
            }
          ],
          max_tokens: 500
        });

        return completion.choices[0].message.content;
      });

      SecurityManager.auditLog('AI_CHAT_INTERACTION', req.user?.id || 'anonymous', patientId?.toString());
      
      res.json({
        success: true,
        response,
        timestamp: new Date().toISOString()
      });

    } catch (error: any) {
      console.error('AI chat error:', error);
      
      // Provide graceful degradation
      const fallback = await resilienceManager.getDegradedResponse('openai', {
        response: "I'm here to help you. While our AI service is temporarily unavailable, please contact your care team for immediate assistance."
      });
      
      res.status(503).json(fallback);
    }
  }));

  // User Management
  app.get('/api/users/:id', asyncHandler(async (req: Request, res: Response) => {
    const userId = req.params.id;
    
    const user = await resilienceManager.executeWithCircuitBreaker('database', async () => {
      return await dbManager.getUser(userId);
    });
    
    if (!user) {
      throw new NotFoundError('User');
    }
    
    res.json({ success: true, user });
  }));

  app.post('/api/users', asyncHandler(async (req: Request, res: Response) => {
    validateRequired(req.body, ['email', 'firstName', 'lastName']);
    
    const user = await resilienceManager.executeWithCircuitBreaker('database', async () => {
      return await dbManager.createUser(req.body);
    });
    
    res.status(201).json({ success: true, user });
  }));

  // Facility Management
  app.get('/api/facilities', asyncHandler(async (req: Request, res: Response) => {
    const facilities = await resilienceManager.executeWithCircuitBreaker('database', async () => {
      return await dbManager.getFacilities();
    });
    
    res.json({ success: true, facilities });
  }));

  app.post('/api/facilities', asyncHandler(async (req: Request, res: Response) => {
    validateRequired(req.body, ['name', 'address']);
    
    const facility = await resilienceManager.executeWithCircuitBreaker('database', async () => {
      return await dbManager.createFacility(req.body);
    });
    
    res.status(201).json({ success: true, facility });
  }));

  // Analytics API Endpoints
  app.get('/api/analytics/dashboard', asyncHandler(async (req: Request, res: Response) => {
    const { analyticsService } = await import('../server/services/analytics-service');
    const summary = await analyticsService.getTrialAnalyticsSummary();
    res.json({ success: true, analytics: summary });
  }));

  app.get('/api/analytics/manual-report', asyncHandler(async (req: Request, res: Response) => {
    const { analyticsService } = await import('../server/services/analytics-service');
    const summary = await analyticsService.getTrialAnalyticsSummary();
    res.json({ success: true, message: 'Analytics report generated', analytics: summary });
  }));

  app.post('/api/analytics/track-page', asyncHandler(async (req: Request, res: Response) => {
    const { analyticsService } = await import('../server/services/analytics-service');
    const { page, sessionDuration } = req.body;
    
    const pageViewData = {
      page,
      userAgent: req.get('User-Agent') || 'unknown',
      ipAddress: req.ip || req.connection.remoteAddress || 'unknown',
      referralSource: req.query.ref as string || req.get('Referer') || 'direct',
      utmSource: req.query.utm_source as string,
      utmMedium: req.query.utm_medium as string,
      utmCampaign: req.query.utm_campaign as string,
      sessionDuration,
    };
    
    await analyticsService.trackPageView(pageViewData);
    res.json({ success: true, message: 'Page view tracked' });
  }));

  app.post('/api/analytics/track-trial', asyncHandler(async (req: Request, res: Response) => {
    const { analyticsService } = await import('../server/services/analytics-service');
    const { email, firstName, lastName, phoneNumber } = req.body;
    
    const trialData = {
      email,
      firstName,
      lastName,
      phoneNumber,
      userAgent: req.get('User-Agent') || 'unknown',
      ipAddress: req.ip || req.connection.remoteAddress || 'unknown',
      referralSource: req.query.ref as string || req.get('Referer') || 'direct',
      utmSource: req.query.utm_source as string,
      utmMedium: req.query.utm_medium as string,
      utmCampaign: req.query.utm_campaign as string,
    };
    
    const trial = await analyticsService.trackTrialSignup(trialData);
    res.json({ success: true, trial });
  }));

  // Language Translation Service
  app.post('/api/translate', asyncHandler(async (req: Request, res: Response) => {
    try {
      const { text, targetLanguage, sourceLanguage } = req.body;
      validateRequired(req.body, ['text', 'targetLanguage']);

      const translation = await resilienceManager.executeWithCircuitBreaker('openai', async () => {
        if (!process.env.OPENAI_API_KEY) {
          throw new Error('Translation service not configured');
        }

        const OpenAI = (await import('openai')).default;
        const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

        const completion = await openai.chat.completions.create({
          model: "gpt-4o",
          messages: [
            {
              role: "system",
              content: `Translate the following text from ${sourceLanguage || 'auto-detect'} to ${targetLanguage}. Provide only the translation.`
            },
            {
              role: "user",
              content: text
            }
          ],
          max_tokens: 500
        });

        return completion.choices[0].message.content;
      });

      res.json({
        success: true,
        originalText: text,
        translatedText: translation,
        sourceLanguage: sourceLanguage || 'auto-detected',
        targetLanguage
      });

    } catch (error: any) {
      console.error('Translation error:', error);
      
      const fallback = await resilienceManager.getDegradedResponse('openai', {
        translatedText: text, // Return original text as fallback
        message: 'Translation service temporarily unavailable'
      });
      
      res.status(503).json(fallback);
    }
  }));

  // Mood Tracking and Emotional State Management
  app.post('/api/mood/entry', asyncHandler(async (req: Request, res: Response) => {
    const { patientId, moodState, energyLevel, anxietyLevel, socialEngagement, cognitiveClarity, physicalComfort, notes, contextualFactors } = req.body;
    
    // Validate required fields
    if (!patientId || !moodState || energyLevel === undefined || anxietyLevel === undefined || 
        socialEngagement === undefined || cognitiveClarity === undefined || physicalComfort === undefined) {
      return res.status(400).json({ 
        success: false, 
        error: 'Missing required mood tracking fields' 
      });
    }

    try {
      const { moodTrackingService } = await import('./services/mood-tracking-service');
      const result = await moodTrackingService.createMoodEntry({
        patientId,
        moodState,
        energyLevel,
        anxietyLevel,
        socialEngagement,
        cognitiveClarity,
        physicalComfort,
        notes: notes || null,
        contextualFactors: contextualFactors || null
      });

      res.status(201).json({
        success: true,
        entry: result.entry,
        analysis: result.analysis,
        message: 'Mood entry created with AI companion response'
      });
    } catch (error) {
      console.error('Failed to create mood entry:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to create mood entry'
      });
    }
  }));

  app.get('/api/patients/:patientId/mood-entries', asyncHandler(async (req: Request, res: Response) => {
    const { patientId } = req.params;
    const { fromDate, toDate } = req.query;

    try {
      const { moodTrackingService } = await import('./services/mood-tracking-service');
      const entries = await moodTrackingService.getPatientMoodEntries(
        parseInt(patientId),
        fromDate ? new Date(fromDate as string) : undefined,
        toDate ? new Date(toDate as string) : undefined
      );

      res.json({
        success: true,
        entries
      });
    } catch (error) {
      console.error('Failed to get mood entries:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to get mood entries'
      });
    }
  }));

  app.get('/api/mood-entries/:entryId/responses', asyncHandler(async (req: Request, res: Response) => {
    const { entryId } = req.params;

    try {
      const { moodTrackingService } = await import('./services/mood-tracking-service');
      const responses = await moodTrackingService.getCompanionResponses(parseInt(entryId));

      res.json({
        success: true,
        responses
      });
    } catch (error) {
      console.error('Failed to get companion responses:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to get companion responses'
      });
    }
  }));

  app.patch('/api/companion-responses/:responseId/reaction', asyncHandler(async (req: Request, res: Response) => {
    const { responseId } = req.params;
    const { reaction } = req.body;

    if (!['helpful', 'neutral', 'unhelpful', 'ignored'].includes(reaction)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid reaction type'
      });
    }

    try {
      const { moodTrackingService } = await import('./services/mood-tracking-service');
      await moodTrackingService.updateResponseReaction(parseInt(responseId), reaction);

      res.json({
        success: true,
        message: 'Response reaction updated'
      });
    } catch (error) {
      console.error('Failed to update response reaction:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to update response reaction'
      });
    }
  }));

  app.post('/api/patients/:patientId/mood-trends', asyncHandler(async (req: Request, res: Response) => {
    const { patientId } = req.params;
    const { period = 'weekly' } = req.body;

    if (!['daily', 'weekly', 'monthly'].includes(period)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid trend period'
      });
    }

    try {
      const { moodTrackingService } = await import('./services/mood-tracking-service');
      const trend = await moodTrackingService.generateMoodTrends(parseInt(patientId), period);

      res.json({
        success: true,
        trend
      });
    } catch (error) {
      console.error('Failed to generate mood trends:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to generate mood trends'
      });
    }
  }));

  app.get('/api/patients/:patientId/mood-trends', asyncHandler(async (req: Request, res: Response) => {
    const { patientId } = req.params;

    try {
      const { moodTrackingService } = await import('./services/mood-tracking-service');
      const trends = await moodTrackingService.getLatestMoodTrends(parseInt(patientId));

      res.json({
        success: true,
        trends
      });
    } catch (error) {
      console.error('Failed to get mood trends:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to get mood trends'
      });
    }
  }));

  // GDS Cognitive Assessment Routes
  app.post('/api/cognitive/assessment', asyncHandler(async (req: Request, res: Response) => {
    const { patientId, responses, assessorId } = req.body;

    if (!patientId || !responses) {
      return res.status(400).json({
        success: false,
        error: 'Patient ID and assessment responses are required'
      });
    }

    try {
      const { cognitiveAssessmentService } = await import('./services/cognitive-assessment-service');
      const result = await cognitiveAssessmentService.conductGDSAssessment(patientId, responses, assessorId);

      res.status(201).json({
        success: true,
        assessment: result.assessment,
        gdsResult: result.result,
        message: 'Cognitive assessment completed successfully'
      });
    } catch (error) {
      console.error('Failed to conduct cognitive assessment:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to conduct cognitive assessment'
      });
    }
  }));

  app.get('/api/patients/:patientId/cognitive-history', asyncHandler(async (req: Request, res: Response) => {
    const { patientId } = req.params;

    try {
      const { cognitiveAssessmentService } = await import('./services/cognitive-assessment-service');
      const history = await cognitiveAssessmentService.getAssessmentHistory(parseInt(patientId));

      res.json({
        success: true,
        assessments: history
      });
    } catch (error) {
      console.error('Failed to get assessment history:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to retrieve assessment history'
      });
    }
  }));

  // AirTag Mapping System API Endpoints
  app.post('/api/items/register', asyncHandler(async (req: Request, res: Response) => {
    const { airtagMappingService } = await import('./services/airtag-mapping-service');
    const item = await airtagMappingService.registerItem(req.body);
    res.status(201).json({ success: true, item });
  }));

  app.get('/api/patients/:patientId/items', asyncHandler(async (req: Request, res: Response) => {
    const { airtagMappingService } = await import('./services/airtag-mapping-service');
    const patientId = parseInt(req.params.patientId);
    const items = await airtagMappingService.getPatientItems(patientId);
    res.json({ success: true, items });
  }));

  app.get('/api/patients/:patientId/lost-items', asyncHandler(async (req: Request, res: Response) => {
    const { airtagMappingService } = await import('./services/airtag-mapping-service');
    const patientId = parseInt(req.params.patientId);
    const lostItems = await airtagMappingService.getLostItems(patientId);
    res.json({ success: true, lostItems });
  }));

  app.patch('/api/items/:itemId/location', asyncHandler(async (req: Request, res: Response) => {
    const { airtagMappingService } = await import('./services/airtag-mapping-service');
    const itemId = parseInt(req.params.itemId);
    const { location, airtagStatus } = req.body;
    await airtagMappingService.updateItemLocation(itemId, location, airtagStatus);
    res.json({ success: true, message: 'Item location updated' });
  }));

  app.patch('/api/items/:itemId/mark-lost', asyncHandler(async (req: Request, res: Response) => {
    const { airtagMappingService } = await import('./services/airtag-mapping-service');
    const itemId = parseInt(req.params.itemId);
    const { lastKnownLocation } = req.body;
    await airtagMappingService.markItemLost(itemId, lastKnownLocation);
    res.json({ success: true, message: 'Item marked as lost' });
  }));

  app.patch('/api/items/:itemId/mark-found', asyncHandler(async (req: Request, res: Response) => {
    const { airtagMappingService } = await import('./services/airtag-mapping-service');
    const itemId = parseInt(req.params.itemId);
    const { foundLocation } = req.body;
    await airtagMappingService.markItemFound(itemId, foundLocation);
    res.json({ success: true, message: 'Item marked as found' });
  }));

  app.post('/api/items/:itemId/search', asyncHandler(async (req: Request, res: Response) => {
    const { airtagMappingService } = await import('./services/airtag-mapping-service');
    const itemId = parseInt(req.params.itemId);
    const { searchedBy, options } = req.body;
    const searchId = await airtagMappingService.initiateSearch(itemId, searchedBy, options);
    res.json({ success: true, searchId, message: 'Search initiated' });
  }));

  app.get('/api/items/:itemId/location-history', asyncHandler(async (req: Request, res: Response) => {
    const { airtagMappingService } = await import('./services/airtag-mapping-service');
    const itemId = parseInt(req.params.itemId);
    const { fromDate, toDate } = req.query;
    const history = await airtagMappingService.getItemLocationHistory(
      itemId,
      fromDate ? new Date(fromDate as string) : undefined,
      toDate ? new Date(toDate as string) : undefined
    );
    res.json({ success: true, history });
  }));

  app.get('/api/patients/:patientId/items/nearby', asyncHandler(async (req: Request, res: Response) => {
    const { airtagMappingService } = await import('./services/airtag-mapping-service');
    const patientId = parseInt(req.params.patientId);
    const { lat, lng, radius } = req.query;
    const items = await airtagMappingService.findItemsNearLocation(
      patientId,
      parseFloat(lat as string),
      parseFloat(lng as string),
      parseInt(radius as string) || 1000
    );
    res.json({ success: true, items });
  }));

  app.get('/api/airtags/:airtagId/status', asyncHandler(async (req: Request, res: Response) => {
    const { airtagMappingService } = await import('./services/airtag-mapping-service');
    const airtagId = req.params.airtagId;
    const status = await airtagMappingService.getAirTagStatus(airtagId);
    res.json({ success: true, status });
  }));

  app.get('/api/patients/:patientId/search-analytics', asyncHandler(async (req: Request, res: Response) => {
    const { airtagMappingService } = await import('./services/airtag-mapping-service');
    const patientId = parseInt(req.params.patientId);
    const analytics = await airtagMappingService.getSearchAnalytics(patientId);
    res.json({ success: true, analytics });
  }));

  const httpServer = createServer(app);
  return httpServer;
}