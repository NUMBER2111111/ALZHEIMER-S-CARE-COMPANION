import express, { type Request, Response, NextFunction } from "express";
import { setupVite, serveStatic, log } from "./vite";
import { globalErrorHandler } from "./error-handler";
import { registerConsolidatedRoutes } from "./routes-consolidated";

const app = express();

// Configure trust proxy for Replit environment
app.set('trust proxy', true);

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Initialize automated analytics reporting
async function initializeAnalytics() {
  try {
    const { EmailReportingService } = await import('./services/email-reporting-service');
    EmailReportingService.initializeScheduledReports();
    console.log('[analytics] Automated reporting initialized - 8:00 AM, 9:00 AM, and 8:00 PM daily');
  } catch (error) {
    console.error('[analytics] Failed to initialize reporting:', error);
  }
}

// Start analytics after a short delay to ensure all services are ready
setTimeout(initializeAnalytics, 5000);

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

// Basic API routes for health checking
app.get('/api/health', (req: Request, res: Response) => {
  res.json({ 
    status: 'ok', 
    message: 'Care Companion API is running',
    timestamp: new Date().toISOString()
  });
});

app.get('/api/test', (req: Request, res: Response) => {
  res.json({ 
    message: 'API test successful',
    environment: app.get("env") || 'development'
  });
});

// Register all API routes
registerConsolidatedRoutes(app).then((httpServer) => {
  log("Routes registered successfully");
}).catch((error) => {
  console.error("Failed to register routes:", error);
});

// Error handling middleware
app.use(globalErrorHandler);

// Create server with proper port configuration
const PORT = parseInt(process.env.PORT || '5000', 10);
const server = app.listen(PORT, "0.0.0.0", () => {
  log(`Care Companion server running on port ${PORT}`);
});

// Setup Vite for development
if (app.get("env") === "development") {
  setupVite(app, server);
} else {
  serveStatic(app);
}