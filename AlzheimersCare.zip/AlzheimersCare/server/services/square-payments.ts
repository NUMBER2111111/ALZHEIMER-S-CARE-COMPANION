import { storage } from '../storage';

// Mock Square client for development
const squareClient = {
  customersApi: {
    createCustomer: async (data: any) => ({ result: { customer: { id: 'mock-customer-id' } } }),
  },
  subscriptionsApi: {
    createSubscription: async (data: any) => ({ result: { subscription: { id: 'mock-sub-id' } } }),
    retrieveSubscription: async (id: string) => ({ result: { subscription: { id } } }),
    cancelSubscription: async (id: string) => ({ result: { subscription: { id, status: 'CANCELED' } } }),
  },
  paymentsApi: {
    createPayment: async (data: any) => ({ result: { payment: { id: 'mock-payment-id' } } }),
  }
};

export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number; // in cents
  currency: string;
  interval: 'MONTHLY' | 'YEARLY';
  trialDays: number;
}

export const SUBSCRIPTION_PLANS: SubscriptionPlan[] = [
  {
    id: 'care-companion-monthly',
    name: 'AI Care Companion',
    price: 4999, // $49.99
    currency: 'USD',
    interval: 'MONTHLY',
    trialDays: 14
  }
];

export class SquarePaymentService {
  private customersApi = squareClient.customersApi;
  private subscriptionsApi = squareClient.subscriptionsApi;
  private paymentsApi = squareClient.paymentsApi;
  private catalogApi = squareClient.catalogApi;

  async createCustomer(email: string, firstName?: string, lastName?: string) {
    try {
      const { result } = await this.customersApi.createCustomer({
        emailAddress: email,
        givenName: firstName,
        familyName: lastName,
      });
      return result.customer;
    } catch (error) {
      console.error('Error creating Square customer:', error);
      throw error;
    }
  }

  async createSubscription(customerId: string, planId: string, paymentMethodId: string) {
    try {
      const plan = SUBSCRIPTION_PLANS.find(p => p.id === planId);
      if (!plan) {
        throw new Error('Invalid subscription plan');
      }

      // Create subscription with trial period
      const trialEndDate = new Date();
      trialEndDate.setDate(trialEndDate.getDate() + plan.trialDays);

      const subscriptionRequest = {
        locationId: process.env.SQUARE_LOCATION_ID,
        customerId,
        planId: planId,
        priceOverrideMoney: {
          amount: BigInt(plan.price),
          currency: plan.currency
        },
        phases: [
          {
            ordinal: BigInt(0),
            orderTemplateId: planId,
            planPhaseUid: 'trial-phase',
            pricing: {
              type: 'STATIC',
              priceMoney: {
                amount: BigInt(0), // Free trial
                currency: plan.currency
              }
            }
          },
          {
            ordinal: BigInt(1),
            orderTemplateId: planId,
            planPhaseUid: 'billing-phase',
            pricing: {
              type: 'STATIC',
              priceMoney: {
                amount: BigInt(plan.price),
                currency: plan.currency
              }
            }
          }
        ]
      };

      const { result } = await this.subscriptionsApi.createSubscription(subscriptionRequest);
      return result.subscription;
    } catch (error) {
      console.error('Error creating Square subscription:', error);
      throw error;
    }
  }

  async getSubscription(subscriptionId: string) {
    try {
      const { result } = await this.subscriptionsApi.retrieveSubscription(subscriptionId);
      return result.subscription;
    } catch (error) {
      console.error('Error retrieving Square subscription:', error);
      throw error;
    }
  }

  async cancelSubscription(subscriptionId: string) {
    try {
      const { result } = await this.subscriptionsApi.cancelSubscription(subscriptionId, {});
      return result.subscription;
    } catch (error) {
      console.error('Error canceling Square subscription:', error);
      throw error;
    }
  }

  async updateSubscription(subscriptionId: string, updates: any) {
    try {
      const { result } = await this.subscriptionsApi.updateSubscription(subscriptionId, {
        subscription: updates
      });
      return result.subscription;
    } catch (error) {
      console.error('Error updating Square subscription:', error);
      throw error;
    }
  }

  async processPayment(amount: number, currency: string, sourceId: string, customerId?: string) {
    try {
      const { result } = await this.paymentsApi.createPayment({
        sourceId,
        amountMoney: {
          amount: BigInt(amount),
          currency
        },
        customerId,
        idempotencyKey: this.generateIdempotencyKey(),
        autocomplete: true
      });
      return result.payment;
    } catch (error) {
      console.error('Error processing Square payment:', error);
      throw error;
    }
  }

  async startFreeTrial(userId: number, planId: string) {
    try {
      const user = await storage.getUser(userId);
      if (!user) {
        throw new Error('User not found');
      }

      const plan = SUBSCRIPTION_PLANS.find(p => p.id === planId);
      if (!plan) {
        throw new Error('Invalid subscription plan');
      }

      // Set trial dates
      const trialStartDate = new Date();
      const trialEndDate = new Date();
      trialEndDate.setDate(trialEndDate.getDate() + plan.trialDays);

      // Update user subscription status
      await storage.updateUserSubscription(userId, {
        subscriptionStatus: 'trial',
        trialStartDate,
        trialEndDate,
        planType: planId.split('-')[0], // 'basic', 'premium', 'enterprise'
        monthlyPrice: plan.price
      });

      return {
        success: true,
        trialEndDate,
        message: `Your ${plan.trialDays}-day free trial has started!`
      };
    } catch (error) {
      console.error('Error starting free trial:', error);
      throw error;
    }
  }

  async checkTrialExpiration(userId: number) {
    try {
      const user = await storage.getUser(userId);
      if (!user) {
        return { expired: false };
      }

      if (user.subscriptionStatus === 'trial' && user.trialEndDate) {
        const now = new Date();
        const expired = now > user.trialEndDate;
        
        return {
          expired,
          trialEndDate: user.trialEndDate,
          daysRemaining: expired ? 0 : Math.ceil((user.trialEndDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
        };
      }

      return { expired: false };
    } catch (error) {
      console.error('Error checking trial expiration:', error);
      throw error;
    }
  }

  private generateIdempotencyKey(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

export const squarePaymentService = new SquarePaymentService();