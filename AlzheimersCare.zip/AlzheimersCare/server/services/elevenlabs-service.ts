/**
 * ElevenLabs Voice Service
 * Professional-grade text-to-speech for Care Companion AI
 * Includes fallback to browser speech synthesis if API is restricted
 */

const ELEVENLABS_API_AVAILABLE = !!process.env.ELEVENLABS_API_KEY;

if (!ELEVENLABS_API_AVAILABLE) {
  console.warn('ElevenLabs API key not found - voice synthesis will fall back to browser text-to-speech');
}

export interface VoiceOptions {
  voiceId?: string;
  stability?: number;
  similarityBoost?: number;
  style?: number;
  useSpeakerBoost?: boolean;
}

export interface VoiceResponse {
  audioBuffer: Buffer;
  contentType: string;
  duration?: number;
}

export class ElevenLabsService {
  // Default voice settings optimized for healthcare companion
  private static readonly DEFAULT_VOICE_ID = "21m00Tcm4TlvDq8ikWAM"; // Rachel - warm, friendly female voice
  private static readonly HEALTHCARE_SETTINGS = {
    stability: 0.75,
    similarityBoost: 0.85,
    style: 0.3,
    useSpeakerBoost: true,
  };

  /**
   * Convert text to speech using ElevenLabs REST API with circuit breaker
   */
  static async textToSpeech(text: string, options: VoiceOptions = {}): Promise<VoiceResponse> {
    if (!ELEVENLABS_API_AVAILABLE) {
      throw new Error('ElevenLabs API not available - use browser fallback');
    }

    try {
      const voiceSettings = {
        ...this.HEALTHCARE_SETTINGS,
        ...options,
      };

      const voiceId = options.voiceId || this.DEFAULT_VOICE_ID;
      
      const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
        method: 'POST',
        headers: {
          'Accept': 'audio/mpeg',
          'Content-Type': 'application/json',
          'xi-api-key': process.env.ELEVENLABS_API_KEY!,
        },
        body: JSON.stringify({
          text: text,
          model_id: "eleven_monolingual_v1",
          voice_settings: {
            stability: voiceSettings.stability,
            similarity_boost: voiceSettings.similarityBoost,
            style: voiceSettings.style,
            use_speaker_boost: voiceSettings.useSpeakerBoost,
          },
        }),
      });

      if (!response.ok) {
        const errorData = await response.text();
        console.error(`ElevenLabs API error: ${response.status} - ${errorData}`);
        
        // Handle specific API restrictions
        if (response.status === 401) {
          throw new Error('ElevenLabs API key is invalid or restricted');
        }
        if (response.status === 429) {
          throw new Error('ElevenLabs API rate limit exceeded - free tier limit reached');
        }
        if (response.status === 422) {
          throw new Error('ElevenLabs API request validation failed');
        }
        
        throw new Error(`ElevenLabs API error: ${response.status} - ${errorData}`);
      }

      const audioBuffer = Buffer.from(await response.arrayBuffer());

      return {
        audioBuffer,
        contentType: 'audio/mpeg',
        duration: this.estimateDuration(text),
      };
    } catch (error) {
      console.error('ElevenLabs TTS Error:', error);
      
      // If it's a rate limit or restriction error, provide specific guidance
      if (error instanceof Error && error.message.includes('restricted')) {
        throw new Error('ElevenLabs API key restricted - please check your API key permissions');
      }
      if (error instanceof Error && error.message.includes('rate limit')) {
        throw new Error('ElevenLabs API rate limit exceeded - try again later');
      }
      
      throw new Error('ElevenLabs API temporarily unavailable - using browser fallback');
    }
  }

  /**
   * Get available voices for healthcare use
   */
  static async getHealthcareVoices() {
    try {
      const response = await fetch('https://api.elevenlabs.io/v1/voices', {
        headers: {
          'xi-api-key': process.env.ELEVENLABS_API_KEY!,
        },
      });

      if (!response.ok) {
        throw new Error(`ElevenLabs API error: ${response.status}`);
      }

      const data = await response.json();
      
      // Filter for voices suitable for healthcare companion
      const healthcareVoices = data.voices.filter((voice: any) => 
        voice.category === 'premade'
      ).map((voice: any) => ({
        id: voice.voice_id,
        name: voice.name,
        description: voice.description,
        gender: voice.labels?.gender,
        age: voice.labels?.age,
        accent: voice.labels?.accent,
        useCase: voice.labels?.['use case'],
      }));

      return healthcareVoices;
    } catch (error) {
      console.error('Error fetching voices:', error);
      return [];
    }
  }

  /**
   * Generate companion response with emotion-aware voice
   */
  static async generateCompanionSpeech(
    text: string, 
    emotionalContext: 'calm' | 'encouraging' | 'concerned' | 'emergency' = 'calm'
  ): Promise<VoiceResponse> {
    const voiceSettings = this.getEmotionalVoiceSettings(emotionalContext);
    
    return this.textToSpeech(text, voiceSettings);
  }

  /**
   * Get voice settings based on emotional context
   */
  private static getEmotionalVoiceSettings(context: string): VoiceOptions {
    switch (context) {
      case 'encouraging':
        return {
          stability: 0.8,
          similarityBoost: 0.9,
          style: 0.5,
          useSpeakerBoost: true,
        };
      case 'concerned':
        return {
          stability: 0.9,
          similarityBoost: 0.8,
          style: 0.2,
          useSpeakerBoost: true,
        };
      case 'emergency':
        return {
          stability: 0.95,
          similarityBoost: 0.7,
          style: 0.1,
          useSpeakerBoost: true,
        };
      default: // calm
        return this.HEALTHCARE_SETTINGS;
    }
  }

  /**
   * Estimate audio duration based on text length
   */
  private static estimateDuration(text: string): number {
    // Average speaking rate: ~150 words per minute
    const wordCount = text.split(/\s+/).length;
    const wordsPerMinute = 150;
    return Math.ceil((wordCount / wordsPerMinute) * 60);
  }

  /**
   * Check API usage and limits
   */
  static async checkUsage() {
    try {
      const response = await fetch('https://api.elevenlabs.io/v1/user', {
        headers: {
          'xi-api-key': process.env.ELEVENLABS_API_KEY!,
        },
      });

      if (!response.ok) {
        throw new Error(`ElevenLabs API error: ${response.status}`);
      }

      const user = await response.json();
      return {
        charactersUsed: user.subscription?.character_count || 0,
        charactersLimit: user.subscription?.character_limit || 10000,
        nextResetDate: user.subscription?.next_character_reset_unix,
      };
    } catch (error) {
      console.error('Error checking usage:', error);
      return null;
    }
  }
}