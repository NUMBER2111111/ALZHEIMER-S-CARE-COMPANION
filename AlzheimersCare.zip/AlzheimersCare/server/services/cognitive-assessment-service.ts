/**
 * Global Deterioration Scale (GDS) Cognitive Assessment Service
 * Based on BC Health Guidelines for standardized cognitive evaluation
 * Healthcare-grade assessment with detailed stage classification
 */

import { db } from "../db";
import { cognitiveAssessments, cognitiveProgress, patients, type InsertCognitiveAssessment, type CognitiveAssessment } from "@shared/schema";
import { eq, desc, and, gte, lte } from "drizzle-orm";
import OpenAI from "openai";

const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

/**
 * Global Deterioration Scale (GDS) Stage Definitions
 * Based on BC Health Guidelines
 */
export interface GDSStage {
  stage: number;
  title: string;
  description: string;
  characteristics: string[];
  duration: string;
  functionalImpact: string;
  interventions: string[];
}

export const GDS_STAGES: GDSStage[] = [
  {
    stage: 1,
    title: "No Cognitive Decline",
    description: "Normal cognitive function",
    characteristics: [
      "No subjective complaints of memory loss",
      "No memory deficits evident on clinical interview",
      "Normal cognitive function for age"
    ],
    duration: "Stable",
    functionalImpact: "None",
    interventions: ["Maintain healthy lifestyle", "Regular cognitive stimulation", "Preventive care"]
  },
  {
    stage: 2,
    title: "Very Mild Cognitive Decline",
    description: "Subjective complaints of memory deficits",
    characteristics: [
      "Complaints of forgetting names and locations of objects",
      "Subjective work difficulties",
      "No objective evidence of memory deficits on clinical interview",
      "No deficits in employment or social situations"
    ],
    duration: "15 years",
    functionalImpact: "Minimal",
    interventions: ["Cognitive training", "Memory strategies", "Lifestyle optimization"]
  },
  {
    stage: 3,
    title: "Mild Cognitive Decline",
    description: "Early confusional stage",
    characteristics: [
      "Decreased performance in demanding employment and social settings",
      "Getting lost when traveling to unfamiliar location",
      "Difficulty remembering names when introduced to new people",
      "Concentration difficulties may be evident on clinical testing"
    ],
    duration: "7 years",
    functionalImpact: "Mild interference with complex tasks",
    interventions: ["Structured routines", "Environmental modifications", "Family education"]
  },
  {
    stage: 4,
    title: "Moderate Cognitive Decline",
    description: "Late confusional stage",
    characteristics: [
      "Decreased knowledge of current and recent events",
      "Some deficit in memory of one's personal history",
      "Concentration deficit elicited on serial subtractions",
      "Decreased ability to travel, handle finances, etc."
    ],
    duration: "2 years",
    functionalImpact: "Assistance needed for complex tasks",
    interventions: ["Daily structure", "Safety planning", "Caregiver support"]
  },
  {
    stage: 5,
    title: "Moderately Severe Cognitive Decline",
    description: "Early dementia stage",
    characteristics: [
      "Patients can no longer survive without some assistance",
      "Unable to recall a major relevant aspect of their current lives",
      "Frequently disoriented to time or place",
      "Has difficulty counting backward from 40 by 4s or from 20 by 2s"
    ],
    duration: "1.5 years",
    functionalImpact: "Assistance needed for daily activities",
    interventions: ["24-hour supervision planning", "Behavioral interventions", "Medical management"]
  },
  {
    stage: 6,
    title: "Severe Cognitive Decline",
    description: "Middle dementia stage",
    characteristics: [
      "May occasionally forget the name of the spouse or primary caregiver",
      "Will be largely unaware of all recent events and experiences",
      "Requires some assistance with activities of daily living",
      "Sleep-wake cycle frequently disturbed"
    ],
    duration: "2.5 years",
    functionalImpact: "Extensive assistance required",
    interventions: ["Comprehensive care planning", "Behavioral management", "Family counseling"]
  },
  {
    stage: 7,
    title: "Very Severe Cognitive Decline",
    description: "Late dementia stage",
    characteristics: [
      "Frequently cannot recognize spouse or primary caregiver",
      "Largely incapable of caring for himself or herself",
      "Frequently incontinent of urine",
      "Requires assistance walking and eventually loses ability to walk"
    ],
    duration: "Variable",
    functionalImpact: "Total care required",
    interventions: ["Palliative care planning", "Comfort measures", "End-of-life planning"]
  }
];

/**
 * Cognitive Assessment Questions for GDS Evaluation
 */
export interface AssessmentQuestion {
  id: string;
  category: string;
  question: string;
  type: "scale" | "boolean" | "multiple_choice";
  options?: string[];
  gdsRelevance: number[];
}

export const ASSESSMENT_QUESTIONS: AssessmentQuestion[] = [
  {
    id: "memory_complaints",
    category: "Subjective Memory",
    question: "Do you have concerns about your memory?",
    type: "scale",
    gdsRelevance: [1, 2, 3]
  },
  {
    id: "work_performance",
    category: "Functional Performance",
    question: "Have you noticed changes in your work or daily task performance?",
    type: "scale",
    gdsRelevance: [2, 3, 4]
  },
  {
    id: "navigation_difficulty",
    category: "Spatial Orientation",
    question: "Do you get lost in unfamiliar places?",
    type: "boolean",
    gdsRelevance: [3, 4]
  },
  {
    id: "name_recall",
    category: "Memory Function",
    question: "Do you have difficulty remembering names of new people?",
    type: "boolean",
    gdsRelevance: [3, 4]
  },
  {
    id: "current_events",
    category: "Recent Memory",
    question: "How well do you keep track of current events and recent happenings?",
    type: "scale",
    gdsRelevance: [4, 5]
  },
  {
    id: "personal_history",
    category: "Remote Memory",
    question: "Do you have difficulty recalling important events from your past?",
    type: "scale",
    gdsRelevance: [4, 5]
  },
  {
    id: "financial_management",
    category: "Executive Function",
    question: "Can you independently manage your finances and bills?",
    type: "boolean",
    gdsRelevance: [4, 5, 6]
  },
  {
    id: "time_orientation",
    category: "Orientation",
    question: "Do you know what day, month, and year it is?",
    type: "boolean",
    gdsRelevance: [5, 6, 7]
  },
  {
    id: "caregiver_recognition",
    category: "Person Recognition",
    question: "Do you always recognize your family members and close friends?",
    type: "boolean",
    gdsRelevance: [6, 7]
  },
  {
    id: "daily_living",
    category: "Activities of Daily Living",
    question: "Can you independently perform daily activities like bathing, dressing, eating?",
    type: "scale",
    gdsRelevance: [5, 6, 7]
  }
];

/**
 * Assessment Result with GDS Stage Classification
 */
export interface GDSAssessmentResult {
  gdsStage: number;
  stageTitle: string;
  confidence: number;
  cognitiveScore: number;
  functionalScore: number;
  recommendations: string[];
  riskFactors: string[];
  nextAssessmentDate: Date;
  interventionPlan: string[];
}

class CognitiveAssessmentService {
  /**
   * Conduct comprehensive GDS cognitive assessment
   */
  async conductGDSAssessment(
    patientId: number,
    responses: Record<string, any>,
    assessorId?: number
  ): Promise<{ assessment: CognitiveAssessment; result: GDSAssessmentResult }> {
    try {
      // Analyze responses and determine GDS stage
      const result = await this.analyzeGDSResponses(responses);
      
      // Create assessment record
      const assessmentData: InsertCognitiveAssessment = {
        patientId,
        assessorId,
        assessmentType: "GDS",
        responses: responses,
        gdsStage: result.gdsStage,
        cognitiveScore: result.cognitiveScore,
        functionalScore: result.functionalScore,
        recommendations: result.recommendations,
        nextAssessmentDate: result.nextAssessmentDate
      };

      const [assessment] = await db
        .insert(cognitiveAssessments)
        .values(assessmentData)
        .returning();

      // Update cognitive progress tracking
      await this.updateCognitiveProgress(patientId, result);

      return { assessment, result };
    } catch (error) {
      console.error("Failed to conduct GDS assessment:", error);
      throw new Error("Failed to conduct cognitive assessment");
    }
  }

  /**
   * Analyze assessment responses using GDS criteria
   */
  private async analyzeGDSResponses(responses: Record<string, any>): Promise<GDSAssessmentResult> {
    try {
      // Calculate scores based on GDS criteria
      const scores = this.calculateGDSScores(responses);
      const gdsStage = this.determineGDSStage(scores);
      const stageInfo = GDS_STAGES[gdsStage - 1];

      // Generate AI-enhanced analysis if available
      let aiAnalysis = null;
      if (openai) {
        try {
          aiAnalysis = await this.generateAIAnalysis(responses, gdsStage);
        } catch (error) {
          console.warn("AI analysis unavailable, using clinical guidelines");
        }
      }

      // Generate recommendations based on stage
      const recommendations = this.generateStageRecommendations(gdsStage, scores);
      const riskFactors = this.identifyRiskFactors(responses, gdsStage);
      const nextAssessmentDate = this.calculateNextAssessmentDate(gdsStage);

      return {
        gdsStage,
        stageTitle: stageInfo.title,
        confidence: scores.confidence,
        cognitiveScore: scores.cognitive,
        functionalScore: scores.functional,
        recommendations: aiAnalysis?.recommendations || recommendations,
        riskFactors: aiAnalysis?.riskFactors || riskFactors,
        nextAssessmentDate,
        interventionPlan: stageInfo.interventions
      };
    } catch (error) {
      console.error("Failed to analyze GDS responses:", error);
      throw new Error("Failed to analyze assessment responses");
    }
  }

  /**
   * Calculate cognitive and functional scores
   */
  private calculateGDSScores(responses: Record<string, any>): {
    cognitive: number;
    functional: number;
    confidence: number;
  } {
    let cognitiveTotal = 0;
    let functionalTotal = 0;
    let cognitiveCount = 0;
    let functionalCount = 0;

    for (const [questionId, response] of Object.entries(responses)) {
      const question = ASSESSMENT_QUESTIONS.find(q => q.id === questionId);
      if (!question) continue;

      const score = this.normalizeResponse(response, question.type);
      
      if (question.category.includes('Memory') || question.category.includes('Orientation')) {
        cognitiveTotal += score;
        cognitiveCount++;
      } else {
        functionalTotal += score;
        functionalCount++;
      }
    }

    const cognitive = cognitiveCount > 0 ? cognitiveTotal / cognitiveCount : 50;
    const functional = functionalCount > 0 ? functionalTotal / functionalCount : 50;
    const confidence = Math.min(95, 70 + (Object.keys(responses).length * 2));

    return { cognitive, functional, confidence };
  }

  /**
   * Determine GDS stage based on assessment scores
   */
  private determineGDSStage(scores: { cognitive: number; functional: number }): number {
    const avgScore = (scores.cognitive + scores.functional) / 2;

    if (avgScore >= 90) return 1;      // No cognitive decline
    if (avgScore >= 80) return 2;      // Very mild decline
    if (avgScore >= 70) return 3;      // Mild decline
    if (avgScore >= 60) return 4;      // Moderate decline
    if (avgScore >= 45) return 5;      // Moderately severe decline
    if (avgScore >= 30) return 6;      // Severe decline
    return 7;                          // Very severe decline
  }

  /**
   * Generate AI-enhanced analysis of assessment
   */
  private async generateAIAnalysis(responses: Record<string, any>, gdsStage: number): Promise<{
    recommendations: string[];
    riskFactors: string[];
  }> {
    if (!openai) throw new Error("OpenAI not available");

    const prompt = `Analyze this cognitive assessment for a patient with GDS Stage ${gdsStage}:

Assessment Responses: ${JSON.stringify(responses, null, 2)}
Current GDS Stage: ${gdsStage} - ${GDS_STAGES[gdsStage - 1].title}

Provide detailed analysis focusing on:
1. Specific cognitive domain impairments
2. Functional impact assessment
3. Risk factors for progression
4. Evidence-based intervention recommendations
5. Caregiver support needs

Format as JSON: {
  "recommendations": ["specific intervention 1", "specific intervention 2", ...],
  "riskFactors": ["risk factor 1", "risk factor 2", ...]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      max_tokens: 1000
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  }

  /**
   * Generate stage-appropriate recommendations
   */
  private generateStageRecommendations(gdsStage: number, scores: any): string[] {
    const stageInfo = GDS_STAGES[gdsStage - 1];
    const baseRecommendations = [...stageInfo.interventions];

    // Add score-specific recommendations
    if (scores.cognitive < 70) {
      baseRecommendations.push("Cognitive rehabilitation therapy", "Memory training exercises");
    }
    if (scores.functional < 60) {
      baseRecommendations.push("Occupational therapy assessment", "Environmental modifications");
    }

    return baseRecommendations;
  }

  /**
   * Identify risk factors for progression
   */
  private identifyRiskFactors(responses: Record<string, any>, gdsStage: number): string[] {
    const riskFactors = [];

    if (responses.work_performance && responses.work_performance < 3) {
      riskFactors.push("Rapid functional decline");
    }
    if (responses.time_orientation === false) {
      riskFactors.push("Temporal disorientation");
    }
    if (responses.caregiver_recognition === false) {
      riskFactors.push("Severe cognitive impairment");
    }
    if (gdsStage >= 5) {
      riskFactors.push("High care needs", "Safety concerns");
    }

    return riskFactors;
  }

  /**
   * Calculate next assessment date based on GDS stage
   */
  private calculateNextAssessmentDate(gdsStage: number): Date {
    const now = new Date();
    let monthsToAdd = 12; // Default annual assessment

    // More frequent monitoring for advancing stages
    if (gdsStage >= 5) monthsToAdd = 3;      // Quarterly
    else if (gdsStage >= 3) monthsToAdd = 6; // Semi-annual

    now.setMonth(now.getMonth() + monthsToAdd);
    return now;
  }

  /**
   * Update cognitive progress tracking
   */
  private async updateCognitiveProgress(patientId: number, result: GDSAssessmentResult): Promise<void> {
    try {
      await db.insert(cognitiveProgress).values({
        patientId,
        assessmentDate: new Date(),
        cognitiveScore: result.cognitiveScore,
        functionalScore: result.functionalScore,
        gdsStage: result.gdsStage,
        recommendations: result.recommendations,
        riskFactors: result.riskFactors
      });
    } catch (error) {
      console.error("Failed to update cognitive progress:", error);
    }
  }

  /**
   * Normalize response to 0-100 scale
   */
  private normalizeResponse(response: any, type: string): number {
    if (type === "boolean") {
      return response ? 100 : 0;
    }
    if (type === "scale") {
      return Math.max(0, Math.min(100, response * 20)); // Assuming 1-5 scale
    }
    return 50; // Default neutral score
  }

  /**
   * Get patient's assessment history
   */
  async getAssessmentHistory(patientId: number): Promise<CognitiveAssessment[]> {
    try {
      return await db
        .select()
        .from(cognitiveAssessments)
        .where(eq(cognitiveAssessments.patientId, patientId))
        .orderBy(desc(cognitiveAssessments.createdAt));
    } catch (error) {
      console.error("Failed to get assessment history:", error);
      throw new Error("Failed to retrieve assessment history");
    }
  }

  /**
   * Get latest GDS stage for patient
   */
  async getLatestGDSStage(patientId: number): Promise<{ stage: number; assessment: CognitiveAssessment } | null> {
    try {
      const [latest] = await db
        .select()
        .from(cognitiveAssessments)
        .where(eq(cognitiveAssessments.patientId, patientId))
        .orderBy(desc(cognitiveAssessments.createdAt))
        .limit(1);

      if (!latest) return null;

      return {
        stage: latest.gdsStage || 1,
        assessment: latest
      };
    } catch (error) {
      console.error("Failed to get latest GDS stage:", error);
      return null;
    }
  }
}

export const cognitiveAssessmentService = new CognitiveAssessmentService();