import { Request, Response } from 'express';
import Stripe from 'stripe';

// Secure payment service using Stripe directly (more secure than squareup)
class SecurePaymentService {
  private stripe: Stripe | null = null;

  constructor() {
    if (process.env.STRIPE_SECRET_KEY) {
      this.stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
        apiVersion: '2024-06-20',
        typescript: true,
      });
    }
  }

  async createPaymentIntent(amount: number, currency: string = 'usd') {
    if (!this.stripe) {
      throw new Error('Stripe not configured');
    }

    return await this.stripe.paymentIntents.create({
      amount: Math.round(amount * 100),
      currency,
      automatic_payment_methods: {
        enabled: true,
      },
    });
  }

  async createCustomer(email: string, name?: string) {
    if (!this.stripe) {
      throw new Error('Stripe not configured');
    }

    return await this.stripe.customers.create({
      email,
      name,
    });
  }

  async createSubscription(customerId: string, priceId: string) {
    if (!this.stripe) {
      throw new Error('Stripe not configured');
    }

    return await this.stripe.subscriptions.create({
      customer: customerId,
      items: [{ price: priceId }],
      payment_behavior: 'default_incomplete',
      payment_settings: { save_default_payment_method: 'on_subscription' },
      expand: ['latest_invoice.payment_intent'],
    });
  }

  async cancelSubscription(subscriptionId: string) {
    if (!this.stripe) {
      throw new Error('Stripe not configured');
    }

    return await this.stripe.subscriptions.cancel(subscriptionId);
  }

  async retrieveSubscription(subscriptionId: string) {
    if (!this.stripe) {
      throw new Error('Stripe not configured');
    }

    return await this.stripe.subscriptions.retrieve(subscriptionId);
  }

  isConfigured(): boolean {
    return this.stripe !== null;
  }
}

export const securePaymentService = new SecurePaymentService();
export default SecurePaymentService;