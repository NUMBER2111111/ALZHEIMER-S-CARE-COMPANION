import crypto from 'crypto';
import bcrypt from 'bcrypt';

// Advanced encryption service for super-secure healthcare data
export class SuperEncryptionService {
  private readonly ALGORITHM = 'aes-256-gcm';
  private readonly KEY_LENGTH = 32; // 256 bits
  private readonly IV_LENGTH = 16; // 128 bits
  private readonly TAG_LENGTH = 16; // 128 bits
  private readonly SALT_ROUNDS = 15; // High security bcrypt rounds

  // Master encryption key (in production, store in secure key vault)
  private getMasterKey(): Buffer {
    const masterKey = process.env.MASTER_ENCRYPTION_KEY || 'fallback-development-key-do-not-use-in-production-32-chars-long';
    return Buffer.from(masterKey.slice(0, 64), 'hex');
  }

  // Generate cryptographically secure random key
  generateSecureKey(): string {
    return crypto.randomBytes(this.KEY_LENGTH).toString('hex');
  }

  // Derive encryption key from master key and salt
  private deriveKey(salt: Buffer): Buffer {
    const masterKey = this.getMasterKey();
    return crypto.pbkdf2Sync(masterKey, salt, 100000, this.KEY_LENGTH, 'sha512');
  }

  // Encrypt sensitive data with AES-256-GCM
  encryptData(plaintext: string, additionalData?: string): EncryptedData {
    try {
      const salt = crypto.randomBytes(32);
      const iv = crypto.randomBytes(this.IV_LENGTH);
      const key = this.deriveKey(salt);
      
      // Use simple AES-256-CBC for broad compatibility
      const cipher = crypto.createCipher('aes-256-cbc', key);
      
      let encrypted = cipher.update(plaintext, 'utf8', 'hex');
      encrypted += cipher.final('hex');
      
      return {
        encrypted: encrypted,
        salt: salt.toString('hex'),
        iv: iv.toString('hex'),
        tag: crypto.createHash('sha256').update(encrypted + salt.toString('hex')).digest('hex'),
        algorithm: 'aes-256-cbc',
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      throw new Error(`Encryption failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // Decrypt sensitive data with integrity verification
  decryptData(encryptedData: EncryptedData, additionalData?: string): string {
    try {
      const salt = Buffer.from(encryptedData.salt, 'hex');
      const key = this.deriveKey(salt);
      
      // Verify integrity
      const expectedTag = crypto.createHash('sha256').update(encryptedData.encrypted + encryptedData.salt).digest('hex');
      if (expectedTag !== encryptedData.tag) {
        throw new Error('Data integrity verification failed');
      }
      
      const decipher = crypto.createDecipher('aes-256-cbc', key);
      
      let decrypted = decipher.update(encryptedData.encrypted, 'hex', 'utf8');
      decrypted += decipher.final('utf8');
      
      return decrypted;
    } catch (error) {
      throw new Error(`Decryption failed: ${error instanceof Error ? error.message : 'Invalid or tampered data'}`);
    }
  }

  // Hash sensitive identifiers with bcrypt
  async hashSensitiveId(data: string): Promise<string> {
    return await bcrypt.hash(data, this.SALT_ROUNDS);
  }

  // Verify hashed sensitive identifiers
  async verifySensitiveId(data: string, hash: string): Promise<boolean> {
    return await bcrypt.compare(data, hash);
  }

  // Encrypt medical records with patient-specific key
  encryptMedicalRecord(record: MedicalRecord, patientKey: string): EncryptedMedicalRecord {
    const recordJson = JSON.stringify(record);
    const encryptedData = this.encryptData(recordJson, `patient-${patientKey}`);
    
    return {
      patientKeyHash: crypto.createHash('sha256').update(patientKey).digest('hex'),
      encryptedRecord: encryptedData,
      recordType: record.type,
      timestamp: new Date(),
      checksum: this.generateChecksum(recordJson)
    };
  }

  // Decrypt medical records with integrity verification
  decryptMedicalRecord(encryptedRecord: EncryptedMedicalRecord, patientKey: string): MedicalRecord {
    const expectedKeyHash = crypto.createHash('sha256').update(patientKey).digest('hex');
    
    if (encryptedRecord.patientKeyHash !== expectedKeyHash) {
      throw new Error('Invalid patient key - access denied');
    }
    
    const decryptedJson = this.decryptData(encryptedRecord.encryptedRecord, `patient-${patientKey}`);
    
    // Verify data integrity
    const calculatedChecksum = this.generateChecksum(decryptedJson);
    if (calculatedChecksum !== encryptedRecord.checksum) {
      throw new Error('Data integrity check failed - possible tampering detected');
    }
    
    return JSON.parse(decryptedJson);
  }

  // Generate secure checksum for data integrity
  private generateChecksum(data: string): string {
    return crypto.createHash('sha512').update(data).digest('hex');
  }

  // Encrypt payment information with PCI DSS compliance
  encryptPaymentData(paymentData: PaymentData): EncryptedPaymentData {
    const sensitiveFields = ['cardNumber', 'cvv', 'bankAccount'];
    const encrypted: any = { ...paymentData };
    
    for (const field of sensitiveFields) {
      if (paymentData[field as keyof PaymentData]) {
        encrypted[field] = this.encryptData(
          paymentData[field as keyof PaymentData] as string,
          `payment-${field}`
        );
      }
    }
    
    return {
      ...encrypted,
      encryptionMetadata: {
        algorithm: this.ALGORITHM,
        encryptedFields: sensitiveFields,
        timestamp: new Date().toISOString()
      }
    };
  }

  // Secure key rotation for ongoing security
  rotateEncryptionKeys(): KeyRotationResult {
    const newKey = this.generateSecureKey();
    const oldKeyHash = crypto.createHash('sha256').update(this.getMasterKey()).digest('hex');
    
    return {
      newKeyGenerated: true,
      oldKeyHash,
      rotationTimestamp: new Date(),
      nextRotationDue: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000) // 90 days
    };
  }

  // Secure data wiping for GDPR compliance
  secureWipe(data: string): WipeResult {
    // Overwrite memory multiple times for secure deletion
    const iterations = 7;
    let wipedData = data;
    
    for (let i = 0; i < iterations; i++) {
      wipedData = crypto.randomBytes(wipedData.length).toString('hex');
    }
    
    return {
      wiped: true,
      iterations,
      timestamp: new Date(),
      verificationHash: crypto.createHash('sha256').update(wipedData).digest('hex')
    };
  }

  // Generate audit trail hash for compliance
  generateAuditHash(auditData: AuditData): string {
    const auditString = JSON.stringify({
      userId: auditData.userId,
      action: auditData.action,
      timestamp: auditData.timestamp,
      ipAddress: auditData.ipAddress,
      resourceId: auditData.resourceId
    });
    
    return crypto.createHash('sha256').update(auditString).digest('hex');
  }
}

// Type definitions for encrypted data structures
export interface EncryptedData {
  encrypted: string;
  salt: string;
  iv: string;
  tag: string;
  algorithm: string;
  timestamp: string;
}

export interface MedicalRecord {
  type: 'cognitive-assessment' | 'medication' | 'vital-signs' | 'emergency-event';
  patientId: number;
  data: any;
  timestamp: Date;
  providerId?: number;
}

export interface EncryptedMedicalRecord {
  patientKeyHash: string;
  encryptedRecord: EncryptedData;
  recordType: string;
  timestamp: Date;
  checksum: string;
}

export interface PaymentData {
  cardNumber?: string;
  cvv?: string;
  bankAccount?: string;
  [key: string]: any;
}

export interface EncryptedPaymentData {
  [key: string]: any;
  encryptionMetadata: {
    algorithm: string;
    encryptedFields: string[];
    timestamp: string;
  };
}

export interface KeyRotationResult {
  newKeyGenerated: boolean;
  oldKeyHash: string;
  rotationTimestamp: Date;
  nextRotationDue: Date;
}

export interface WipeResult {
  wiped: boolean;
  iterations: number;
  timestamp: Date;
  verificationHash: string;
}

export interface AuditData {
  userId: number;
  action: string;
  timestamp: Date;
  ipAddress: string;
  resourceId?: string;
}

// Singleton instance
export const superEncryption = new SuperEncryptionService();