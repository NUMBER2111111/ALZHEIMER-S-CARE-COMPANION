// Temporarily disabled Square SDK until import issues are resolved
// import squareConnect from 'squareup';
import { storage } from '../storage';

// Mock Square client for now - will be re-enabled once imports are fixed
const mockSquareClient = {
  customersApi: {
    async createCustomer(data: any) {
      return { result: { customer: { id: `cust_${Date.now()}` } } };
    }
  },
  subscriptionsApi: {
    async createSubscription(data: any) {
      return { result: { subscription: { id: `sub_${Date.now()}` } } };
    },
    async retrieveSubscription(id: string) {
      return { result: { subscription: { id } } };
    },
    async cancelSubscription(id: string) {
      return { result: { subscription: { id } } };
    },
    async searchSubscriptions(data: any) {
      return { result: { subscriptions: [] } };
    }
  },
  paymentsApi: {
    async createPayment(data: any) {
      return { result: { payment: { id: `pay_${Date.now()}` } } };
    }
  }
};

const { customersApi, subscriptionsApi, paymentsApi } = mockSquareClient;

export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  currency: string;
  intervalUnit: 'MONTH' | 'YEAR';
  intervalCount: number;
  trialPeriodDays?: number;
}

// Care Companion subscription plan
export const CARE_COMPANION_PLAN: SubscriptionPlan = {
  id: 'care-companion-monthly',
  name: 'Care Companion Monthly',
  price: 4999, // $49.99 in cents
  currency: 'USD',
  intervalUnit: 'MONTH',
  intervalCount: 1,
  trialPeriodDays: 14
};

export class SquareSubscriptionService {
  
  async createCustomer(userData: {
    email: string;
    firstName?: string;
    lastName?: string;
    phoneNumber?: string;
  }) {
    try {
      const { result } = await customersApi.createCustomer({
        givenName: userData.firstName,
        familyName: userData.lastName,
        emailAddress: userData.email,
        phoneNumber: userData.phoneNumber,
      });

      return result.customer;
    } catch (error: any) {
      console.error('Square API Error:', error);
      throw new Error(`Square API Error: ${error.message || 'Unknown error'}`);
    }
  }

  async createSubscription(customerId: string, planId: string = CARE_COMPANION_PLAN.id) {
    try {
      // First, create or get the subscription plan in Square catalog
      await this.ensureSubscriptionPlan();

      const { result } = await subscriptionsApi.createSubscription({
        locationId: process.env.SQUARE_LOCATION_ID!,
        planVariationId: planId,
        customerId: customerId,
        startDate: new Date().toISOString().split('T')[0], // Today's date
        chargedThroughDate: this.getTrialEndDate(),
        status: 'ACTIVE',
        invoiceRequestMethod: 'EMAIL',
        priceOverrideMoney: {
          amount: BigInt(CARE_COMPANION_PLAN.price),
          currency: CARE_COMPANION_PLAN.currency,
        },
      });

      return result.subscription;
    } catch (error: any) {
      console.error('Square Subscription Error:', error);
      throw new Error(`Square Subscription Error: ${error.message || 'Unknown error'}`);
    }
  }

  async getSubscription(subscriptionId: string) {
    try {
      const { result } = await subscriptionsApi.retrieveSubscription(subscriptionId);
      return result.subscription;
    } catch (error: any) {
      console.error('Square API Error:', error);
      throw new Error(`Square API Error: ${error.message || 'Unknown error'}`);
    }
  }

  async cancelSubscription(subscriptionId: string) {
    try {
      const { result } = await subscriptionsApi.cancelSubscription(subscriptionId);
      return result.subscription;
    } catch (error: any) {
      console.error('Square API Error:', error);
      throw new Error(`Square API Error: ${error.message || 'Unknown error'}`);
    }
  }

  async pauseSubscription(subscriptionId: string) {
    try {
      const { result } = await subscriptionsApi.pauseSubscription(subscriptionId, {
        pauseEffectiveDate: new Date().toISOString().split('T')[0],
        pauseReason: 'CUSTOMER_CHOICE',
      });
      return result.subscription;
    } catch (error: any) {
      console.error('Square API Error:', error);
      throw new Error(`Square API Error: ${error.message || 'Unknown error'}`);
    }
  }

  async resumeSubscription(subscriptionId: string) {
    try {
      const { result } = await subscriptionsApi.resumeSubscription(subscriptionId, {
        resumeEffectiveDate: new Date().toISOString().split('T')[0],
      });
      return result.subscription;
    } catch (error: any) {
      console.error('Square API Error:', error);
      throw new Error(`Square API Error: ${error.message || 'Unknown error'}`);
    }
  }

  async processPayment(paymentData: {
    sourceId: string;
    amount: number;
    currency: string;
    customerId?: string;
    orderId?: string;
  }) {
    try {
      const { result } = await paymentsApi.createPayment({
        sourceId: paymentData.sourceId,
        idempotencyKey: this.generateIdempotencyKey(),
        amountMoney: {
          amount: BigInt(paymentData.amount),
          currency: paymentData.currency,
        },
        customerId: paymentData.customerId,
        orderId: paymentData.orderId,
        autocomplete: true,
      });

      return result.payment;
    } catch (error: any) {
      console.error('Square Payment Error:', error);
      throw new Error(`Square Payment Error: ${error.message || 'Unknown error'}`);
    }
  }

  private async ensureSubscriptionPlan() {
    // Plan creation will be handled through Square Dashboard
    // For now, we'll proceed with subscription creation using existing plans
    console.log('Subscription plan should be configured in Square Dashboard');
  }

  private getTrialEndDate(): string {
    const trialEnd = new Date();
    trialEnd.setDate(trialEnd.getDate() + (CARE_COMPANION_PLAN.trialPeriodDays || 14));
    return trialEnd.toISOString().split('T')[0];
  }

  private generateIdempotencyKey(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  async getCustomerSubscriptions(customerId: string) {
    try {
      const { result } = await subscriptionsApi.searchSubscriptions({
        query: {
          filter: {
            customerIds: [customerId],
          },
        },
      });

      return result.subscriptions || [];
    } catch (error: any) {
      console.error('Square API Error:', error);
      throw new Error(`Square API Error: ${error.message || 'Unknown error'}`);
    }
  }

  async updateSubscriptionCard(subscriptionId: string, cardId: string) {
    try {
      const { result } = await subscriptionsApi.updateSubscription(subscriptionId, {
        subscription: {
          cardId: cardId,
        },
      });

      return result.subscription;
    } catch (error: any) {
      console.error('Square API Error:', error);
      throw new Error(`Square API Error: ${error.message || 'Unknown error'}`);
    }
  }
}

export const squareSubscriptionService = new SquareSubscriptionService();