import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "",
});

export interface MemoryAnalysis {
  tags: string[];
  emotions: string[];
  people: string[];
  locations: string[];
  timeFrames: string[];
  cognitiveValue: number; // 0-100
  activitySuggestions: string[];
}

export interface CognitiveActivityGeneration {
  activityType: string;
  title: string;
  description: string;
  difficulty: 'easy' | 'medium' | 'hard';
  estimatedDuration: number;
  content: any;
}

export interface CognitiveAssessment {
  memoryRecall: number;
  recognition: number;
  attention: number;
  overallScore: number;
  insights: string[];
  recommendations: string[];
}

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
export async function analyzeMemory(
  memoryType: string,
  content: any,
  description?: string
): Promise<MemoryAnalysis> {
  try {
    const prompt = `
    Analyze this family memory for an Alzheimer's patient cognitive training program.
    
    Memory Type: ${memoryType}
    Description: ${description || 'Not provided'}
    Content: ${JSON.stringify(content)}
    
    Provide analysis in JSON format with:
    - tags: relevant keywords and themes
    - emotions: emotional context identified
    - people: people mentioned or visible
    - locations: places mentioned or visible
    - timeFrames: estimated time periods
    - cognitiveValue: therapeutic value score (0-100)
    - activitySuggestions: specific cognitive training activities this memory could generate
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert in Alzheimer's care and cognitive therapy. Analyze family memories to create personalized therapeutic content.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || '{}') as MemoryAnalysis;
  } catch (error) {
    console.error("Error analyzing memory:", error);
    throw new Error("Failed to analyze memory with AI");
  }
}

export async function analyzeImage(base64Image: string, context?: string): Promise<MemoryAnalysis> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert in Alzheimer's care analyzing family photos for cognitive therapy. Provide detailed analysis for personalized care.",
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: `Analyze this family photo for Alzheimer's cognitive training. Context: ${context || 'Family memory photo'}. Provide JSON response with: tags, emotions, people, locations, timeFrames, cognitiveValue (0-100), activitySuggestions.`,
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`,
              },
            },
          ],
        },
      ],
      response_format: { type: "json_object" },
      max_tokens: 500,
    });

    return JSON.parse(response.choices[0].message.content || '{}') as MemoryAnalysis;
  } catch (error) {
    console.error("Error analyzing image:", error);
    throw new Error("Failed to analyze image with AI");
  }
}

export async function generateCognitiveActivity(
  patientProfile: any,
  memoryAnalysis: MemoryAnalysis,
  activityType: string
): Promise<CognitiveActivityGeneration> {
  try {
    const prompt = `
    Generate a personalized cognitive training activity for an Alzheimer's patient.
    
    Patient Profile: ${JSON.stringify(patientProfile)}
    Memory Analysis: ${JSON.stringify(memoryAnalysis)}
    Activity Type: ${activityType}
    
    Create a specific, engaging activity in JSON format with:
    - activityType: type of cognitive exercise
    - title: engaging activity title
    - description: clear instructions for patient
    - difficulty: easy/medium/hard based on patient capability
    - estimatedDuration: minutes to complete
    - content: detailed activity data (questions, images, interactions)
    
    Make it personal, therapeutic, and appropriate for Alzheimer's care.
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a cognitive therapy specialist creating personalized activities for Alzheimer's patients using their family memories.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || '{}') as CognitiveActivityGeneration;
  } catch (error) {
    console.error("Error generating activity:", error);
    throw new Error("Failed to generate cognitive activity");
  }
}

export async function assessCognitivePerformance(
  activityData: any,
  responseData: any,
  patientHistory?: any
): Promise<CognitiveAssessment> {
  try {
    const prompt = `
    Assess cognitive performance from this activity session for an Alzheimer's patient.
    
    Activity Data: ${JSON.stringify(activityData)}
    Patient Responses: ${JSON.stringify(responseData)}
    Patient History: ${JSON.stringify(patientHistory || {})}
    
    Provide assessment in JSON format with:
    - memoryRecall: score 0-100
    - recognition: score 0-100  
    - attention: score 0-100
    - overallScore: composite score 0-100
    - insights: key observations about cognitive state
    - recommendations: suggestions for future activities and care
    
    Be compassionate but accurate in assessment for medical care planning.
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a cognitive assessment specialist analyzing Alzheimer's patient performance for medical care planning.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || '{}') as CognitiveAssessment;
  } catch (error) {
    console.error("Error assessing performance:", error);
    throw new Error("Failed to assess cognitive performance");
  }
}

export async function generateInsuranceBenefits(
  facilityData: any,
  patientOutcomes: any[]
): Promise<any> {
  try {
    const prompt = `
    Generate insurance benefits analysis for a care facility using AI-powered cognitive therapy.
    
    Facility Data: ${JSON.stringify(facilityData)}
    Patient Outcomes: ${JSON.stringify(patientOutcomes)}
    
    Provide analysis in JSON format with:
    - roiMetrics: return on investment calculations
    - careQualityImprovements: measurable improvements in care
    - staffEfficiencyGains: productivity improvements
    - insuranceReimbursements: potential reimbursement amounts
    - complianceMetrics: healthcare compliance improvements
    - recommendations: strategic recommendations for maximizing benefits
    
    Focus on measurable financial and care outcomes for healthcare administration.
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a healthcare administration specialist analyzing ROI and benefits for AI-powered cognitive therapy programs.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || '{}');
  } catch (error) {
    console.error("Error generating benefits analysis:", error);
    throw new Error("Failed to generate insurance benefits analysis");
  }
}

// Emergency monitoring AI analysis
export async function analyzeVitalSigns(vitalSigns: any): Promise<{
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  alerts: string[];
  recommendations: string[];
  emergencyActions?: string[];
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `You are a medical AI assistant specializing in emergency monitoring for Alzheimer's patients.
          Analyze vital signs data and determine risk levels, alerts, and recommendations.
          Consider the patient's condition and provide appropriate emergency protocols.
          Respond with JSON containing riskLevel, alerts, recommendations, and emergencyActions if needed.`,
        },
        {
          role: "user",
          content: `Analyze these vital signs for emergency conditions:
          
          Heart Rate: ${vitalSigns.heartRate}
          Blood Pressure: ${vitalSigns.bloodPressureSystolic}/${vitalSigns.bloodPressureDiastolic}
          Oxygen Saturation: ${vitalSigns.oxygenSaturation}
          Temperature: ${vitalSigns.temperature}
          Alert Type: ${vitalSigns.alertType}
          
          Determine risk level and provide medical recommendations.`,
        },
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    console.error("Error analyzing vital signs:", error);
    throw new Error("Failed to analyze vital signs");
  }
}

// AI Gaming for cognitive engagement
export async function generateChessMove(gameState: any, difficulty: string): Promise<{
  move: string;
  explanation: string;
  cognitiveChallenge: string;
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `You are an AI chess opponent designed for Alzheimer's patients' cognitive training.
          Generate appropriate moves based on difficulty level and provide educational explanations.
          Focus on cognitive engagement and gentle challenge rather than winning.
          Respond with JSON containing move, explanation, and cognitiveChallenge.`,
        },
        {
          role: "user",
          content: `Current chess position: ${JSON.stringify(gameState)}
          Difficulty: ${difficulty}
          
          Generate next move with cognitive training focus.`,
        },
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error: any) {
    console.error("Error generating chess move:", error);
    // Return fallback chess setup if AI generation fails
    return {
      board: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
      currentPlayer: 'white',
      moves: [],
      hint: 'Start by moving a pawn or knight. Good opening moves include e4, d4, or Nf3.',
      difficulty: difficulty
    };
  }
}

export async function generateCardGame(gameType: string, difficulty: string): Promise<{
  gameSetup: any;
  instructions: string;
  cognitiveGoals: string[];
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `You are an AI game master for cognitive training card games for Alzheimer's patients.
          Create engaging card games that promote memory, attention, and cognitive function.
          Respond with JSON containing gameSetup, instructions, and cognitiveGoals.`,
        },
        {
          role: "user",
          content: `Create a ${gameType} card game with ${difficulty} difficulty.
          Focus on cognitive benefits and patient engagement.`,
        },
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error: any) {
    console.error("Error generating card game:", error);
    // Return fallback card game setup if AI generation fails
    return {
      gameSetup: {
        deck: [],
        playerHand: [],
        dealerHand: [],
        gamePhase: 'start',
        difficulty: difficulty,
        gameType: gameType
      },
      hint: 'Welcome to the card game! Click to begin your hand.'
    };
  }
}

// Medicine adherence AI analysis
export async function analyzeMedicationAdherence(medicationLogs: any[]): Promise<{
  adherenceScore: number;
  patterns: string[];
  riskFactors: string[];
  recommendations: string[];
  interventions: string[];
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `You are a pharmaceutical AI specialist analyzing medication adherence for Alzheimer's patients.
          Identify patterns, risk factors, and provide intervention recommendations.
          Respond with JSON containing adherenceScore, patterns, riskFactors, recommendations, and interventions.`,
        },
        {
          role: "user",
          content: `Analyze medication adherence data:
          
          ${JSON.stringify(medicationLogs)}
          
          Provide comprehensive adherence analysis and recommendations.`,
        },
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    console.error("Error analyzing medication adherence:", error);
    throw new Error("Failed to analyze medication adherence");
  }
}
