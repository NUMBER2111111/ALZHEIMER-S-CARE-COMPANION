import crypto from 'crypto';
import bcrypt from 'bcrypt';
import { db } from '../db';
import { encryptionKeys, secureMessageLogs, familyLockoutLogs, familyRelationships } from '@shared/schema';
import { eq, and } from 'drizzle-orm';

const ENCRYPTION_ALGORITHM = 'aes-256-gcm';
const KEY_LENGTH = 32; // 256 bits
const IV_LENGTH = 16; // 128 bits
const TAG_LENGTH = 16; // 128 bits

export interface EncryptionResult {
  encryptedData: string;
  keyId: string;
  iv: string;
  tag: string;
}

export interface DecryptionResult {
  decryptedData: string;
  verified: boolean;
}

export class EncryptionService {
  // Generate a new encryption key for a user/facility
  static async generateEncryptionKey(
    userId: number | null,
    facilityId: number | null,
    keyType: 'family_medical' | 'admin_communication' | 'medication_data'
  ): Promise<string> {
    const keyId = `${keyType}_${userId || facilityId}_${Date.now()}_${crypto.randomUUID()}`;
    const rawKey = crypto.randomBytes(KEY_LENGTH);
    const keyHash = crypto.createHash('sha256').update(rawKey).digest('hex');
    
    // Encrypt the key with a master key from environment
    const masterKey = process.env.MASTER_ENCRYPTION_KEY || crypto.randomBytes(32).toString('hex');
    const masterKeyBuffer = crypto.scryptSync(masterKey, 'salt', 32);
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-cbc', masterKeyBuffer, iv);
    let encryptedKey = cipher.update(rawKey.toString('hex'), 'utf8', 'hex');
    encryptedKey += cipher.final('hex');
    encryptedKey = iv.toString('hex') + ':' + encryptedKey;

    await db.insert(encryptionKeys).values({
      keyId,
      userId,
      facilityId,
      keyType,
      encryptedKey,
      keyHash,
      isActive: true,
      expiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // 1 year
    });

    return keyId;
  }

  // Encrypt sensitive data (medical info, medication data, etc.)
  static async encryptData(
    data: string,
    keyId: string
  ): Promise<EncryptionResult> {
    const [keyRecord] = await db
      .select()
      .from(encryptionKeys)
      .where(and(eq(encryptionKeys.keyId, keyId), eq(encryptionKeys.isActive, true)));

    if (!keyRecord) {
      throw new Error('Encryption key not found or inactive');
    }

    // Decrypt the stored key
    const masterKey = process.env.MASTER_ENCRYPTION_KEY || crypto.randomBytes(32).toString('hex');
    const masterKeyBuffer = crypto.scryptSync(masterKey, 'salt', 32);
    const [ivHex, encryptedKeyData] = keyRecord.encryptedKey.split(':');
    const keyIv = Buffer.from(ivHex, 'hex');
    const decipher = crypto.createDecipheriv('aes-256-cbc', masterKeyBuffer, keyIv);
    let decryptedKey = decipher.update(encryptedKeyData, 'hex', 'utf8');
    decryptedKey += decipher.final('utf8');

    const key = Buffer.from(decryptedKey, 'hex');
    const dataIv = crypto.randomBytes(IV_LENGTH);
    const cipher = crypto.createCipheriv('aes-256-cbc', key, dataIv);

    let encryptedData = cipher.update(data, 'utf8', 'hex');
    encryptedData += cipher.final('hex');
    return {
      encryptedData,
      keyId,
      iv: dataIv.toString('hex'),
      tag: '', // Simplified for compatibility
    };
  }

  // Decrypt sensitive data
  static async decryptData(
    encryptedData: string,
    keyId: string,
    iv: string,
    tag: string
  ): Promise<DecryptionResult> {
    const [keyRecord] = await db
      .select()
      .from(encryptionKeys)
      .where(and(eq(encryptionKeys.keyId, keyId), eq(encryptionKeys.isActive, true)));

    if (!keyRecord) {
      throw new Error('Encryption key not found or inactive');
    }

    try {
      // Decrypt the stored key
      const masterKey = process.env.MASTER_ENCRYPTION_KEY || crypto.randomBytes(32).toString('hex');
      const masterKeyBuffer = crypto.scryptSync(masterKey, 'salt', 32);
      const [ivHex, encryptedKeyData] = keyRecord.encryptedKey.split(':');
      const keyIv = Buffer.from(ivHex, 'hex');
      const decipher = crypto.createDecipheriv('aes-256-cbc', masterKeyBuffer, keyIv);
      let decryptedKey = decipher.update(encryptedKeyData, 'hex', 'utf8');
      decryptedKey += decipher.final('utf8');

      const key = Buffer.from(decryptedKey, 'hex');
      const dataIv = Buffer.from(iv, 'hex');
      const decipher2 = crypto.createDecipheriv('aes-256-cbc', key, dataIv);

      let decryptedData = decipher2.update(encryptedData, 'hex', 'utf8');
      decryptedData += decipher2.final('utf8');

      return {
        decryptedData,
        verified: true,
      };
    } catch (error) {
      console.error('Decryption failed:', error);
      return {
        decryptedData: '',
        verified: false,
      };
    }
  }

  // Send encrypted message between family/admin
  static async sendSecureMessage(
    fromUserId: number,
    toUserId: number | null,
    toFacilityId: number | null,
    messageType: 'medical_request' | 'admin_communication' | 'medication_change',
    content: string
  ): Promise<boolean> {
    // Check if sender is locked out
    const isBlocked = await this.checkFamilyLockout(fromUserId, toUserId || 0);
    if (isBlocked) {
      throw new Error('User is locked out from sending medical/admin communications');
    }

    // Determine appropriate encryption key
    const keyType = messageType === 'medication_change' ? 'medication_data' : 
                   messageType === 'admin_communication' ? 'admin_communication' : 'family_medical';

    // Get or create encryption key
    let keyId: string;
    const [existingKey] = await db
      .select()
      .from(encryptionKeys)
      .where(and(
        eq(encryptionKeys.keyType, keyType),
        toUserId ? eq(encryptionKeys.userId, toUserId) : eq(encryptionKeys.facilityId, toFacilityId!),
        eq(encryptionKeys.isActive, true)
      ));

    if (existingKey) {
      keyId = existingKey.keyId;
    } else {
      keyId = await this.generateEncryptionKey(toUserId, toFacilityId, keyType);
    }

    // Encrypt the message
    const encrypted = await this.encryptData(content, keyId);

    // Store the encrypted message
    await db.insert(secureMessageLogs).values({
      fromUserId,
      toUserId,
      toFacilityId,
      messageType,
      encryptedContent: JSON.stringify(encrypted),
      encryptionKeyId: keyId,
      isBlocked: false,
    });

    return true;
  }

  // Check if a family member is locked out
  static async checkFamilyLockout(
    userId: number,
    patientId: number
  ): Promise<boolean> {
    const [lockout] = await db
      .select()
      .from(familyLockoutLogs)
      .where(and(
        eq(familyLockoutLogs.lockedOutFamilyId, userId),
        eq(familyLockoutLogs.patientId, patientId),
        eq(familyLockoutLogs.isActive, true)
      ));

    return !!lockout;
  }

  // Primary family member locks out another family member
  static async lockoutFamilyMember(
    primaryFamilyId: number,
    lockedOutFamilyId: number,
    patientId: number,
    lockoutType: 'medical_access' | 'communication' | 'full_lockout',
    reason: string,
    password?: string
  ): Promise<string> {
    // Verify primary family member has authority with password
    const isPrimary = await this.verifyPrimaryFamilyMember(primaryFamilyId, patientId, password);
    if (!isPrimary) {
      throw new Error('Only primary family members with valid password can lock out other family members');
    }

    // Generate emergency unlock code for administrators
    const unlockCode = crypto.randomBytes(16).toString('hex').toUpperCase();

    await db.insert(familyLockoutLogs).values({
      patientId,
      primaryFamilyId,
      lockedOutFamilyId,
      lockoutType,
      reason,
      isActive: true,
      unlockCode,
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
    });

    // Block existing secure messages from locked out user
    await db.update(secureMessageLogs)
      .set({ 
        isBlocked: true, 
        blockedBy: primaryFamilyId,
        blockedReason: `Family member locked out: ${reason}`
      })
      .where(eq(secureMessageLogs.fromUserId, lockedOutFamilyId));

    return unlockCode;
  }

  // Set password for primary family member
  static async setPrimaryPassword(
    userId: number,
    patientId: number,
    password: string
  ): Promise<boolean> {
    const hashedPassword = await bcrypt.hash(password, 12);
    const expiresAt = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000); // 90 days

    const [updated] = await db
      .update(familyRelationships)
      .set({ 
        primaryPassword: hashedPassword,
        passwordExpiresAt: expiresAt,
        lastSecurityCheck: new Date()
      })
      .where(and(
        eq(familyRelationships.familyMemberId, userId),
        eq(familyRelationships.patientId, patientId),
        eq(familyRelationships.isPrimaryContact, true)
      ))
      .returning();

    return !!updated;
  }

  // Verify primary family member with password
  static async verifyPrimaryFamilyMember(
    userId: number,
    patientId: number,
    password?: string
  ): Promise<boolean> {
    const [relationship] = await db
      .select()
      .from(familyRelationships)
      .where(and(
        eq(familyRelationships.familyMemberId, userId),
        eq(familyRelationships.patientId, patientId),
        eq(familyRelationships.isPrimaryContact, true)
      ));

    if (!relationship) {
      return false;
    }

    // If password is required but not provided
    if (relationship.primaryPassword && !password) {
      return false;
    }

    // Check password if set
    if (relationship.primaryPassword && password) {
      // Check if password expired
      if (relationship.passwordExpiresAt && new Date() > relationship.passwordExpiresAt) {
        return false;
      }

      const isValidPassword = await bcrypt.compare(password, relationship.primaryPassword);
      if (!isValidPassword) {
        return false;
      }
    }

    return true;
  }

  // Check if primary member needs to set password
  static async needsPasswordSetup(
    userId: number,
    patientId: number
  ): Promise<boolean> {
    const [relationship] = await db
      .select()
      .from(familyRelationships)
      .where(and(
        eq(familyRelationships.familyMemberId, userId),
        eq(familyRelationships.patientId, patientId),
        eq(familyRelationships.isPrimaryContact, true)
      ));

    return !!(relationship?.isPrimaryContact && !relationship?.primaryPassword);
  }

  // Administrative unlock (emergency use only)
  static async administrativeUnlock(
    unlockCode: string,
    adminUserId: number
  ): Promise<boolean> {
    const [lockout] = await db
      .select()
      .from(familyLockoutLogs)
      .where(and(
        eq(familyLockoutLogs.unlockCode, unlockCode),
        eq(familyLockoutLogs.isActive, true)
      ));

    if (!lockout) {
      return false;
    }

    // Deactivate the lockout
    await db.update(familyLockoutLogs)
      .set({ isActive: false })
      .where(eq(familyLockoutLogs.id, lockout.id));

    // Unblock messages
    await db.update(secureMessageLogs)
      .set({ 
        isBlocked: false,
        blockedReason: `Administratively unlocked by user ${adminUserId}`
      })
      .where(eq(secureMessageLogs.fromUserId, lockout.lockedOutFamilyId));

    return true;
  }

  // Get encrypted messages for a user
  static async getSecureMessages(
    userId: number,
    facilityId?: number
  ): Promise<any[]> {
    const messages = await db
      .select()
      .from(secureMessageLogs)
      .where(
        facilityId 
          ? eq(secureMessageLogs.toFacilityId, facilityId)
          : eq(secureMessageLogs.toUserId, userId)
      );

    // Decrypt messages
    const decryptedMessages = await Promise.all(
      messages.map(async (msg) => {
        const encryptedData = JSON.parse(msg.encryptedContent);
        const decrypted = await this.decryptData(
          encryptedData.encryptedData,
          encryptedData.keyId,
          encryptedData.iv,
          encryptedData.tag
        );

        return {
          ...msg,
          content: decrypted.verified ? decrypted.decryptedData : '[DECRYPTION_FAILED]',
          verified: decrypted.verified,
        };
      })
    );

    return decryptedMessages;
  }
}