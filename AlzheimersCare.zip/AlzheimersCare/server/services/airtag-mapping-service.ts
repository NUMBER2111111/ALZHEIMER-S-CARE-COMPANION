/**
 * AirTag Mapping Service - Comprehensive item tracking with Apple AirTag integration
 * Healthcare-grade precision for Alzheimer's patients and families
 */

import { db } from '../db';
import { 
  lostItems, 
  itemLocationHistory, 
  itemSearchEvents,
  type LostItem,
  type InsertLostItem,
  type ItemLocationHistory,
  type InsertItemLocationHistory,
  type InsertItemSearchEvent
} from '../../shared/schema';
import { eq, and, desc, gte, lte, ne, sql } from 'drizzle-orm';

export interface LocationData {
  lat: number;
  lng: number;
  address?: string;
  accuracy?: number;
  timestamp?: Date;
}

export interface AirTagStatus {
  batteryLevel?: number;
  signalStrength?: number;
  isConnected: boolean;
  lastSeen?: Date;
}

export interface SearchOptions {
  radius?: number;
  priority?: 'low' | 'medium' | 'high' | 'critical';
  notifyFamily?: boolean;
  searchType?: 'manual' | 'automated' | 'family_initiated' | 'geofence_trigger';
}

class AirTagMappingService {
  
  // Register a new item with optional AirTag
  async registerItem(itemData: InsertLostItem): Promise<LostItem> {
    try {
      const [newItem] = await db
        .insert(lostItems)
        .values({
          ...itemData,
          itemStatus: 'active',
          createdAt: new Date(),
          updatedAt: new Date(),
        })
        .returning();

      // If AirTag ID provided, mark as connected
      if (itemData.airtagId) {
        await this.updateAirTagConnection(newItem.id, true);
      }

      return newItem;
    } catch (error) {
      throw new Error(`Failed to register item: ${error.message}`);
    }
  }

  // Get all items for a patient
  async getPatientItems(patientId: number): Promise<LostItem[]> {
    try {
      return await db
        .select()
        .from(lostItems)
        .where(eq(lostItems.patientId, patientId))
        .orderBy(desc(lostItems.updatedAt));
    } catch (error) {
      throw new Error(`Failed to fetch patient items: ${error.message}`);
    }
  }

  // Get lost items (status = 'lost')
  async getLostItems(patientId: number): Promise<LostItem[]> {
    try {
      return await db
        .select()
        .from(lostItems)
        .where(
          and(
            eq(lostItems.patientId, patientId),
            eq(lostItems.itemStatus, 'lost')
          )
        )
        .orderBy(desc(lostItems.lostDate));
    } catch (error) {
      throw new Error(`Failed to fetch lost items: ${error.message}`);
    }
  }

  // Update item location (from AirTag or manual)
  async updateItemLocation(
    itemId: number, 
    location: LocationData, 
    airtagStatus?: AirTagStatus
  ): Promise<void> {
    try {
      // Update item's current location
      await db
        .update(lostItems)
        .set({
          currentLocation: location,
          lastKnownLocation: location,
          updatedAt: new Date(),
        })
        .where(eq(lostItems.id, itemId));

      // Record location history
      await db.insert(itemLocationHistory).values({
        itemId,
        location,
        batteryLevel: airtagStatus?.batteryLevel,
        signalStrength: airtagStatus?.signalStrength,
        detectedBy: airtagStatus ? 'airtag' : 'manual',
        isStationary: this.calculateIfStationary(itemId, location),
        recordedAt: new Date(),
      });

      // Check if item was previously lost and now found
      const item = await this.getItemById(itemId);
      if (item?.itemStatus === 'lost') {
        await this.markItemFound(itemId, location);
      }

    } catch (error) {
      throw new Error(`Failed to update item location: ${error.message}`);
    }
  }

  // Mark item as lost
  async markItemLost(itemId: number, lastKnownLocation?: LocationData): Promise<void> {
    try {
      await db
        .update(lostItems)
        .set({
          itemStatus: 'lost',
          lostDate: new Date(),
          lastKnownLocation: lastKnownLocation || null,
          familyNotified: false,
          updatedAt: new Date(),
        })
        .where(eq(lostItems.id, itemId));

      // Trigger automatic search
      await this.initiateSearch(itemId, 1, { searchType: 'automated' }); // System user ID
    } catch (error) {
      throw new Error(`Failed to mark item as lost: ${error.message}`);
    }
  }

  // Mark item as found
  async markItemFound(itemId: number, foundLocation: LocationData): Promise<void> {
    try {
      await db
        .update(lostItems)
        .set({
          itemStatus: 'found',
          foundDate: new Date(),
          currentLocation: foundLocation,
          updatedAt: new Date(),
        })
        .where(eq(lostItems.id, itemId));

      // Complete any active searches
      await this.completeActiveSearches(itemId, foundLocation);
    } catch (error) {
      throw new Error(`Failed to mark item as found: ${error.message}`);
    }
  }

  // Initiate search for lost item
  async initiateSearch(
    itemId: number, 
    searchedBy: number, 
    options: SearchOptions = {}
  ): Promise<number> {
    try {
      const item = await this.getItemById(itemId);
      if (!item) throw new Error('Item not found');

      const [searchEvent] = await db
        .insert(itemSearchEvents)
        .values({
          itemId,
          searchedBy,
          searchType: options.searchType || 'manual',
          searchRadius: options.radius || item.searchRadius || 100,
          searchStatus: 'active',
          createdAt: new Date(),
        })
        .returning();

      // Notify family if requested
      if (options.notifyFamily) {
        await this.notifyFamilyOfLostItem(itemId);
      }

      return searchEvent.id;
    } catch (error) {
      throw new Error(`Failed to initiate search: ${error.message}`);
    }
  }

  // Get item location history
  async getItemLocationHistory(
    itemId: number, 
    fromDate?: Date, 
    toDate?: Date
  ): Promise<ItemLocationHistory[]> {
    try {
      let query = db
        .select()
        .from(itemLocationHistory)
        .where(eq(itemLocationHistory.itemId, itemId));

      if (fromDate && toDate) {
        query = query.where(
          and(
            gte(itemLocationHistory.recordedAt, fromDate),
            lte(itemLocationHistory.recordedAt, toDate)
          )
        );
      }

      return await query.orderBy(desc(itemLocationHistory.recordedAt));
    } catch (error) {
      throw new Error(`Failed to fetch location history: ${error.message}`);
    }
  }

  // Find items near location
  async findItemsNearLocation(
    patientId: number,
    centerLat: number,
    centerLng: number,
    radiusMeters: number = 1000
  ): Promise<LostItem[]> {
    try {
      // Using Haversine formula for distance calculation
      const items = await db
        .select()
        .from(lostItems)
        .where(
          and(
            eq(lostItems.patientId, patientId),
            ne(lostItems.itemStatus, 'inactive')
          )
        );

      return items.filter(item => {
        if (!item.currentLocation) return false;
        const location = item.currentLocation as LocationData;
        const distance = this.calculateDistance(
          centerLat, centerLng,
          location.lat, location.lng
        );
        return distance <= radiusMeters;
      });
    } catch (error) {
      throw new Error(`Failed to find nearby items: ${error.message}`);
    }
  }

  // Update AirTag connection status
  async updateAirTagConnection(itemId: number, isConnected: boolean): Promise<void> {
    try {
      await db
        .update(lostItems)
        .set({
          isAirtagConnected: isConnected,
          updatedAt: new Date(),
        })
        .where(eq(lostItems.id, itemId));
    } catch (error) {
      throw new Error(`Failed to update AirTag connection: ${error.message}`);
    }
  }

  // Get AirTag device status
  async getAirTagStatus(airtagId: string): Promise<AirTagStatus | null> {
    try {
      const [item] = await db
        .select()
        .from(lostItems)
        .where(eq(lostItems.airtagId, airtagId))
        .limit(1);

      if (!item) return null;

      // Get latest location history for battery/signal info
      const [latestLocation] = await db
        .select()
        .from(itemLocationHistory)
        .where(eq(itemLocationHistory.itemId, item.id))
        .orderBy(desc(itemLocationHistory.recordedAt))
        .limit(1);

      return {
        batteryLevel: latestLocation?.batteryLevel || undefined,
        signalStrength: latestLocation?.signalStrength || undefined,
        isConnected: item.isAirtagConnected || false,
        lastSeen: latestLocation?.recordedAt || undefined,
      };
    } catch (error) {
      throw new Error(`Failed to get AirTag status: ${error.message}`);
    }
  }

  // Get search analytics
  async getSearchAnalytics(patientId: number): Promise<{
    totalSearches: number;
    successfulSearches: number;
    averageSearchTime: number;
    topLostItems: string[];
  }> {
    try {
      const searches = await db
        .select({
          itemFound: itemSearchEvents.itemFound,
          searchDuration: itemSearchEvents.searchDuration,
          itemName: lostItems.itemName,
        })
        .from(itemSearchEvents)
        .innerJoin(lostItems, eq(itemSearchEvents.itemId, lostItems.id))
        .where(eq(lostItems.patientId, patientId));

      const totalSearches = searches.length;
      const successfulSearches = searches.filter(s => s.itemFound).length;
      const averageSearchTime = searches
        .filter(s => s.searchDuration)
        .reduce((sum, s) => sum + (s.searchDuration || 0), 0) / totalSearches || 0;

      // Count most frequently lost items
      const itemCounts = searches.reduce((acc, search) => {
        acc[search.itemName] = (acc[search.itemName] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      const topLostItems = Object.entries(itemCounts)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 5)
        .map(([name]) => name);

      return {
        totalSearches,
        successfulSearches,
        averageSearchTime: Math.round(averageSearchTime),
        topLostItems,
      };
    } catch (error) {
      throw new Error(`Failed to get search analytics: ${error.message}`);
    }
  }

  // Private helper methods
  private async getItemById(itemId: number): Promise<LostItem | null> {
    const [item] = await db
      .select()
      .from(lostItems)
      .where(eq(lostItems.id, itemId))
      .limit(1);
    return item || null;
  }

  private async calculateIfStationary(itemId: number, newLocation: LocationData): Promise<boolean> {
    const [lastLocation] = await db
      .select()
      .from(itemLocationHistory)
      .where(eq(itemLocationHistory.itemId, itemId))
      .orderBy(desc(itemLocationHistory.recordedAt))
      .limit(1);

    if (!lastLocation) return true;

    const lastPos = lastLocation.location as LocationData;
    const distance = this.calculateDistance(
      lastPos.lat, lastPos.lng,
      newLocation.lat, newLocation.lng
    );

    return distance < 10; // Less than 10 meters = stationary
  }

  private calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
    const R = 6371e3; // Earth's radius in meters
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lng2 - lng1) * Math.PI / 180;

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    return R * c;
  }

  private async completeActiveSearches(itemId: number, foundLocation: LocationData): Promise<void> {
    await db
      .update(itemSearchEvents)
      .set({
        searchStatus: 'completed',
        itemFound: true,
        foundLocation,
        completedAt: new Date(),
      })
      .where(
        and(
          eq(itemSearchEvents.itemId, itemId),
          eq(itemSearchEvents.searchStatus, 'active')
        )
      );
  }

  private async notifyFamilyOfLostItem(itemId: number): Promise<void> {
    // Mark family as notified
    await db
      .update(lostItems)
      .set({
        familyNotified: true,
        updatedAt: new Date(),
      })
      .where(eq(lostItems.id, itemId));
    
    // Family notification logic would be implemented here
    // This could integrate with the existing emergency notification system
  }
}

export const airtagMappingService = new AirTagMappingService();