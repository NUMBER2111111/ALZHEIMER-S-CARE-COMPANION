/**
 * Analytics Service for Trial and User Tracking
 * Comprehensive data collection and analysis for business intelligence
 */

import { db } from '../db';
import { trialAnalytics, dailyAnalyticsSummary } from '../../shared/schema';
import { SecurityManager } from '../core/security-manager';
import { eq, desc, gte, lte, count, avg, sum } from 'drizzle-orm';

export class AnalyticsService {
  private static instance: AnalyticsService;

  static getInstance(): AnalyticsService {
    if (!AnalyticsService.instance) {
      AnalyticsService.instance = new AnalyticsService();
    }
    return AnalyticsService.instance;
  }

  // Trial Analytics Tracking
  async trackTrialSignup(trialData: {
    email: string;
    firstName?: string;
    lastName?: string;
    phoneNumber?: string;
    referralSource?: string;
    ipAddress?: string;
    userAgent?: string;
    country?: string;
    city?: string;
  }): Promise<any> {
    try {
      const trialEndDate = new Date();
      trialEndDate.setDate(trialEndDate.getDate() + 14); // 14-day trial

      const [trial] = await db.insert(trialAnalytics).values({
        email: trialData.email,
        firstName: trialData.firstName || null,
        lastName: trialData.lastName || null,
        phoneNumber: trialData.phoneNumber || null,
        trialStartDate: new Date(),
        trialEndDate,
        trialStatus: 'active',
        convertedToSubscription: false,
        referralSource: trialData.referralSource || 'direct',
        ipAddress: trialData.ipAddress || '',
        userAgent: trialData.userAgent || '',
        country: trialData.country || 'US',
        city: trialData.city || 'Unknown',
        loginCount: 0,
        sessionDuration: 0
      }).returning();

      SecurityManager.auditLog('TRIAL_SIGNUP_TRACKED', 'system', undefined, {
        email: trialData.email,
        trialId: trial.id
      });

      return trial;
    } catch (error: any) {
      console.error('Analytics tracking error:', error);
      throw new Error('Failed to track trial signup');
    }
  }

  // Page View Tracking
  async trackPageView(data: {
    page: string;
    userId?: string;
    sessionId?: string;
    userAgent?: string;
    ipAddress?: string;
  }): Promise<void> {
    try {
      SecurityManager.auditLog('PAGE_VIEW_TRACKED', data.userId || 'anonymous', undefined, {
        page: data.page,
        sessionId: data.sessionId
      });
    } catch (error: any) {
      console.error('Page view tracking error:', error);
    }
  }

  // Get Trial Analytics Summary
  async getTrialAnalyticsSummary(): Promise<{
    totalTrials: number;
    activeTrials: number;
    convertedTrials: number;
    conversionRate: number;
    averageSessionDuration: number;
    topReferralSources: any[];
  }> {
    try {
      const totalTrials = await db.select({ count: count() }).from(trialAnalytics);
      const activeTrials = await db.select({ count: count() })
        .from(trialAnalytics)
        .where(eq(trialAnalytics.trialStatus, 'active'));
      
      const convertedTrials = await db.select({ count: count() })
        .from(trialAnalytics)
        .where(eq(trialAnalytics.convertedToSubscription, true));

      const avgSession = await db.select({ avg: avg(trialAnalytics.sessionDuration) })
        .from(trialAnalytics);

      const conversionRate = totalTrials[0].count > 0 
        ? (convertedTrials[0].count / totalTrials[0].count) * 100 
        : 0;

      return {
        totalTrials: totalTrials[0].count || 0,
        activeTrials: activeTrials[0].count || 0,
        convertedTrials: convertedTrials[0].count || 0,
        conversionRate: Math.round(conversionRate * 100) / 100,
        averageSessionDuration: Math.round((avgSession[0].avg || 0) * 100) / 100,
        topReferralSources: []
      };
    } catch (error: any) {
      console.error('Analytics summary error:', error);
      return {
        totalTrials: 0,
        activeTrials: 0,
        convertedTrials: 0,
        conversionRate: 0,
        averageSessionDuration: 0,
        topReferralSources: []
      };
    }
  }

  // Get Recent Trial Signups
  async getRecentTrialSignups(limit: number = 10): Promise<any[]> {
    try {
      return await db.select()
        .from(trialAnalytics)
        .orderBy(desc(trialAnalytics.createdAt))
        .limit(limit);
    } catch (error: any) {
      console.error('Recent trials error:', error);
      return [];
    }
  }

  // Update Trial Status
  async updateTrialStatus(trialId: number, status: string, additionalData?: any): Promise<void> {
    try {
      await db.update(trialAnalytics)
        .set({
          trialStatus: status,
          updatedAt: new Date(),
          ...additionalData
        })
        .where(eq(trialAnalytics.id, trialId));

      SecurityManager.auditLog('TRIAL_STATUS_UPDATED', 'system', undefined, {
        trialId,
        newStatus: status
      });
    } catch (error: any) {
      console.error('Trial status update error:', error);
    }
  }
}

export const analyticsService = AnalyticsService.getInstance();