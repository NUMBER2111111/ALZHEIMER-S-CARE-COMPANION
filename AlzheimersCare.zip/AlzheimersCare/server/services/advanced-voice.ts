import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface VoiceAnalysis {
  emotionalState: {
    primary: 'joy' | 'sadness' | 'anger' | 'fear' | 'surprise' | 'neutral';
    intensity: number; // 0-1
    confidence: number; // 0-1
  };
  cognitiveMarkers: {
    clarity: number; // 0-1
    coherence: number; // 0-1
    memoryIndicators: string[];
  };
  urgencyLevel: 'low' | 'medium' | 'high' | 'emergency';
  personalizedResponse: string;
  voicePersonality: {
    tone: 'caring' | 'professional' | 'cheerful' | 'calm';
    pace: 'slow' | 'normal' | 'fast';
    warmth: number; // 0-1
  };
}

export async function analyzeVoiceInput(
  transcript: string,
  patientContext: any,
  conversationHistory?: Array<{ user: string; ai: string; timestamp: Date }>
): Promise<VoiceAnalysis> {
  try {
    const contextPrompt = `
You are an advanced AI voice companion for Alzheimer's patients. Analyze this voice input and provide detailed insights:

Patient Context: ${JSON.stringify(patientContext, null, 2)}
Recent Conversation: ${conversationHistory ? JSON.stringify(conversationHistory.slice(-3), null, 2) : 'None'}

User said: "${transcript}"

Provide a comprehensive analysis including:
1. Emotional state detection
2. Cognitive clarity assessment
3. Urgency level evaluation
4. Personalized response generation
5. Voice personality recommendations

Respond in JSON format with the structure:
{
  "emotionalState": {
    "primary": "emotion",
    "intensity": 0.8,
    "confidence": 0.9
  },
  "cognitiveMarkers": {
    "clarity": 0.7,
    "coherence": 0.8,
    "memoryIndicators": ["mentions recent events", "clear speech patterns"]
  },
  "urgencyLevel": "medium",
  "personalizedResponse": "caring response text",
  "voicePersonality": {
    "tone": "caring",
    "pace": "normal",
    "warmth": 0.8
  }
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are an expert in emotional AI and geriatric care, specializing in voice analysis for Alzheimer's patients."
        },
        {
          role: "user",
          content: contextPrompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3
    });

    const analysis = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      emotionalState: {
        primary: analysis.emotionalState?.primary || 'neutral',
        intensity: analysis.emotionalState?.intensity || 0.5,
        confidence: analysis.emotionalState?.confidence || 0.5
      },
      cognitiveMarkers: {
        clarity: analysis.cognitiveMarkers?.clarity || 0.7,
        coherence: analysis.cognitiveMarkers?.coherence || 0.7,
        memoryIndicators: analysis.cognitiveMarkers?.memoryIndicators || []
      },
      urgencyLevel: analysis.urgencyLevel || 'medium',
      personalizedResponse: analysis.personalizedResponse || "I'm here to help you. How can I assist you today?",
      voicePersonality: {
        tone: analysis.voicePersonality?.tone || 'caring',
        pace: analysis.voicePersonality?.pace || 'normal',
        warmth: analysis.voicePersonality?.warmth || 0.8
      }
    };

  } catch (error) {
    console.error('Advanced voice analysis error:', error);
    
    // Fallback analysis
    return {
      emotionalState: {
        primary: 'neutral',
        intensity: 0.5,
        confidence: 0.3
      },
      cognitiveMarkers: {
        clarity: 0.7,
        coherence: 0.7,
        memoryIndicators: []
      },
      urgencyLevel: 'medium',
      personalizedResponse: "I'm here to help you. How are you feeling today?",
      voicePersonality: {
        tone: 'caring',
        pace: 'normal',
        warmth: 0.8
      }
    };
  }
}

export async function generateContextualResponse(
  userInput: string,
  voiceAnalysis: VoiceAnalysis,
  patientContext: any,
  conversationHistory?: Array<{ user: string; ai: string; timestamp: Date }>
): Promise<string> {
  try {
    const responsePrompt = `
Generate a personalized response for an Alzheimer's patient based on this analysis:

Voice Analysis: ${JSON.stringify(voiceAnalysis, null, 2)}
Patient Context: ${JSON.stringify(patientContext, null, 2)}
User Input: "${userInput}"
Recent Conversation: ${conversationHistory ? JSON.stringify(conversationHistory.slice(-3), null, 2) : 'None'}

Create a response that:
- Matches the recommended voice personality
- Addresses the emotional state appropriately
- Provides cognitive support if needed
- Uses simple, clear language
- Shows empathy and understanding
- Offers specific help if urgency is detected

Keep response under 100 words and naturally conversational.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are a caring AI companion specializing in Alzheimer's patient support. Provide warm, clear, and helpful responses."
        },
        {
          role: "user",
          content: responsePrompt
        }
      ],
      temperature: 0.7,
      max_tokens: 200
    });

    return response.choices[0].message.content || voiceAnalysis.personalizedResponse;

  } catch (error) {
    console.error('Contextual response generation error:', error);
    return voiceAnalysis.personalizedResponse;
  }
}

export async function detectEmergencyKeywords(transcript: string): Promise<{
  isEmergency: boolean;
  confidence: number;
  keywords: string[];
  recommendedAction: string;
}> {
  try {
    const emergencyPrompt = `
Analyze this transcript for emergency situations or urgent medical needs:

Transcript: "${transcript}"

Look for:
- Medical emergencies (pain, breathing, heart, fall, injury)
- Psychological distress (confused, lost, scared, help)
- Safety concerns (fire, intruder, stuck, can't move)
- Medication issues (overdose, missed doses, side effects)

Respond in JSON format:
{
  "isEmergency": boolean,
  "confidence": 0.9,
  "keywords": ["detected emergency words"],
  "recommendedAction": "specific action to take"
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are an emergency detection system for elderly care. Be highly sensitive to potential emergencies while avoiding false alarms."
        },
        {
          role: "user",
          content: emergencyPrompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.1
    });

    const analysis = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      isEmergency: analysis.isEmergency || false,
      confidence: analysis.confidence || 0,
      keywords: analysis.keywords || [],
      recommendedAction: analysis.recommendedAction || 'Continue normal conversation'
    };

  } catch (error) {
    console.error('Emergency detection error:', error);
    
    // Fallback emergency detection using keywords
    const emergencyKeywords = [
      'help', 'emergency', 'pain', 'hurt', 'fall', 'fell', 'bleeding',
      'breathing', 'chest pain', 'heart', 'dizzy', 'confused', 'lost',
      'fire', 'smoke', 'intruder', 'stuck', 'trapped', 'overdose'
    ];
    
    const foundKeywords = emergencyKeywords.filter(keyword => 
      transcript.toLowerCase().includes(keyword)
    );
    
    return {
      isEmergency: foundKeywords.length > 0,
      confidence: foundKeywords.length > 0 ? 0.7 : 0,
      keywords: foundKeywords,
      recommendedAction: foundKeywords.length > 0 
        ? 'Alert caregivers and emergency contacts immediately'
        : 'Continue normal conversation'
    };
  }
}

export async function generateVoicePersonality(
  patientPreferences: any,
  timeOfDay: string,
  recentInteractions: any[]
): Promise<{
  voiceName: string;
  rate: number;
  pitch: number;
  volume: number;
  emotionalTone: string;
  greetingStyle: string;
}> {
  try {
    const personalityPrompt = `
Generate an optimal voice personality for this patient:

Patient Preferences: ${JSON.stringify(patientPreferences, null, 2)}
Time of Day: ${timeOfDay}
Recent Interactions: ${JSON.stringify(recentInteractions.slice(-5), null, 2)}

Create voice settings that:
- Match patient's preferred interaction style
- Adapt to current time and energy levels
- Consider recent conversation patterns
- Optimize for clarity and comfort

Respond in JSON format:
{
  "voiceName": "Caring Companion",
  "rate": 0.9,
  "pitch": 1.1,
  "volume": 0.8,
  "emotionalTone": "warm and patient",
  "greetingStyle": "friendly and familiar"
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are a voice personality specialist for elderly care AI systems."
        },
        {
          role: "user",
          content: personalityPrompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.5
    });

    const personality = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      voiceName: personality.voiceName || 'Caring Companion',
      rate: personality.rate || 0.9,
      pitch: personality.pitch || 1.1,
      volume: personality.volume || 0.8,
      emotionalTone: personality.emotionalTone || 'warm and patient',
      greetingStyle: personality.greetingStyle || 'friendly and familiar'
    };

  } catch (error) {
    console.error('Voice personality generation error:', error);
    
    // Fallback personality based on time of day
    const isEvening = new Date().getHours() > 18;
    const isMorning = new Date().getHours() < 12;
    
    return {
      voiceName: 'Caring Companion',
      rate: isEvening ? 0.8 : isMorning ? 0.9 : 0.85,
      pitch: isEvening ? 1.0 : isMorning ? 1.1 : 1.05,
      volume: 0.8,
      emotionalTone: isEvening ? 'calm and soothing' : isMorning ? 'gentle and encouraging' : 'warm and supportive',
      greetingStyle: isEvening ? 'peaceful' : isMorning ? 'energizing' : 'friendly'
    };
  }
}