import OpenAI from "openai";
import { storage } from "../storage";
import type { 
  MoodEntry, 
  InsertMoodEntry, 
  CompanionResponse, 
  InsertCompanionResponse 
} from "@shared/schema";

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY 
});

export interface MoodAnalysis {
  emotionalState: string;
  empathyLevel: 'low' | 'moderate' | 'high' | 'very_high';
  suggestedActions: string[];
  responseType: 'supportive' | 'encouraging' | 'calming' | 'engaging' | 'emergency';
  riskLevel: 'low' | 'moderate' | 'high' | 'critical';
}

export interface CompanionPersonality {
  warmth: number; // 1-10
  empathy: number; // 1-10
  encouragement: number; // 1-10
  patience: number; // 1-10
  wisdom: number; // 1-10
}

export class MoodCompanionService {
  private defaultPersonality: CompanionPersonality = {
    warmth: 9,
    empathy: 10,
    encouragement: 8,
    patience: 10,
    wisdom: 7
  };

  async analyzeMoodEntry(moodEntry: MoodEntry): Promise<MoodAnalysis> {
    try {
      const analysisPrompt = `
        As an AI companion for Alzheimer's patients, analyze this mood entry and provide compassionate insights:
        
        Mood Level: ${moodEntry.moodLevel}/10
        Emotional State: ${moodEntry.emotionalState}
        Energy: ${moodEntry.energy}/10
        Anxiety: ${moodEntry.anxiety}/10
        Social Connection: ${moodEntry.socialConnection}/10
        Physical Comfort: ${moodEntry.physicalComfort}/10
        Cognitive Clarity: ${moodEntry.cognitiveClarity}/10
        Notes: ${moodEntry.notes || 'None'}
        Triggers: ${moodEntry.triggers ? JSON.stringify(moodEntry.triggers) : 'None'}
        Voice Analysis: ${moodEntry.voiceAnalysis ? JSON.stringify(moodEntry.voiceAnalysis) : 'None'}

        Provide analysis in JSON format with:
        - emotionalState: brief emotional summary
        - empathyLevel: low/moderate/high/very_high
        - suggestedActions: array of 3-5 helpful actions
        - responseType: supportive/encouraging/calming/engaging/emergency
        - riskLevel: low/moderate/high/critical
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are a compassionate AI companion specializing in Alzheimer's care. Provide empathetic, professional analysis focused on emotional support and cognitive well-being."
          },
          {
            role: "user",
            content: analysisPrompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.7
      });

      const analysisResult = JSON.parse(response.choices[0].message.content || '{}');
      
      return {
        emotionalState: analysisResult.emotionalState || moodEntry.emotionalState,
        empathyLevel: analysisResult.empathyLevel || 'moderate',
        suggestedActions: analysisResult.suggestedActions || [],
        responseType: analysisResult.responseType || 'supportive',
        riskLevel: analysisResult.riskLevel || 'low'
      };
    } catch (error) {
      console.error('Error analyzing mood entry:', error);
      return {
        emotionalState: moodEntry.emotionalState,
        empathyLevel: 'moderate',
        suggestedActions: ['Take deep breaths', 'Listen to calming music', 'Speak with a loved one'],
        responseType: 'supportive',
        riskLevel: 'low'
      };
    }
  }

  async generateCompanionResponse(
    moodEntry: MoodEntry, 
    analysis: MoodAnalysis,
    personality: CompanionPersonality = this.defaultPersonality
  ): Promise<string> {
    try {
      const responsePrompt = `
        Generate a compassionate response for an Alzheimer's patient based on their mood entry and analysis.
        
        Patient Context:
        - Mood Level: ${moodEntry.moodLevel}/10
        - Emotional State: ${analysis.emotionalState}
        - Risk Level: ${analysis.riskLevel}
        - Response Type Needed: ${analysis.responseType}
        
        Companion Personality:
        - Warmth: ${personality.warmth}/10
        - Empathy: ${personality.empathy}/10
        - Encouragement: ${personality.encouragement}/10
        - Patience: ${personality.patience}/10
        - Wisdom: ${personality.wisdom}/10
        
        Guidelines:
        - Use simple, clear language
        - Be warm and encouraging
        - Acknowledge their feelings
        - Offer gentle suggestions
        - Keep response 2-3 sentences
        - Be appropriate for Alzheimer's patients
        - Sound natural and conversational
        
        Generate a caring response that matches the ${analysis.responseType} tone.
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are a gentle, wise AI companion who speaks with warmth and understanding to Alzheimer's patients. Your responses should feel like talking to a caring friend or family member."
          },
          {
            role: "user",
            content: responsePrompt
          }
        ],
        temperature: 0.8,
        max_tokens: 150
      });

      return response.choices[0].message.content || "I'm here with you, and I care about how you're feeling. You're not alone.";
    } catch (error) {
      console.error('Error generating companion response:', error);
      return "I'm here with you, and I care about how you're feeling. You're not alone.";
    }
  }

  async createMoodEntry(insertMoodEntry: InsertMoodEntry): Promise<MoodEntry> {
    return await storage.createMoodEntry(insertMoodEntry);
  }

  async processCompanionResponse(patientId: number, moodEntryId: number): Promise<CompanionResponse> {
    try {
      // Get the mood entry
      const moodEntry = await storage.getMoodEntriesByPatient(patientId, 1);
      if (!moodEntry.length) {
        throw new Error('Mood entry not found');
      }

      const entry = moodEntry[0];
      
      // Analyze the mood entry
      const analysis = await this.analyzeMoodEntry(entry);
      
      // Generate compassionate response
      const responseContent = await this.generateCompanionResponse(entry, analysis);
      
      // Create companion response record
      const companionResponse: InsertCompanionResponse = {
        patientId,
        moodEntryId,
        responseType: analysis.responseType,
        responseContent,
        empathyLevel: analysis.empathyLevel,
        aiInsights: JSON.stringify({
          analysis,
          suggestedActions: analysis.suggestedActions,
          riskLevel: analysis.riskLevel
        }),
        responseActions: analysis.suggestedActions,
        wasDelivered: false
      };

      return await storage.createCompanionResponse(companionResponse);
    } catch (error) {
      console.error('Error processing companion response:', error);
      throw error;
    }
  }

  async getMoodTrends(patientId: number, days: number = 7): Promise<MoodEntry[]> {
    return await storage.getMoodTrends(patientId, days);
  }

  async getLatestMoodEntry(patientId: number): Promise<MoodEntry | undefined> {
    return await storage.getLatestMoodEntry(patientId);
  }

  async markResponseDelivered(responseId: number, reaction?: string): Promise<CompanionResponse> {
    return await storage.updateCompanionResponseDelivery(responseId, true, reaction);
  }

  async getCompanionResponses(moodEntryId: number): Promise<CompanionResponse[]> {
    return await storage.getCompanionResponsesByMoodEntry(moodEntryId);
  }

  // Emergency response for critical mood states
  async handleEmergencyMood(patientId: number, moodEntry: MoodEntry): Promise<void> {
    const analysis = await this.analyzeMoodEntry(moodEntry);
    
    if (analysis.riskLevel === 'critical') {
      console.log(`EMERGENCY: Critical mood detected for patient ${patientId}`);
      // Integration point for emergency notification system
      // Could trigger family alerts, care team notifications, etc.
    }
  }
}

export const moodCompanionService = new MoodCompanionService();