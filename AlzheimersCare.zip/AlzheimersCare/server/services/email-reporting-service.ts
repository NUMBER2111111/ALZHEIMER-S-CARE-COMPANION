import { AnalyticsService } from './analytics-service';
import cron from 'node-cron';

interface EmailConfig {
  recipient: string;
  sendgridApiKey?: string;
  fromEmail: string;
}

export class EmailReportingService {
  private static config: EmailConfig = {
    recipient: 'owner@example.com', // Will be configured via environment
    fromEmail: 'analytics@carecompanion.app',
    sendgridApiKey: process.env.SENDGRID_API_KEY,
  };

  // Initialize automated reporting schedule
  static initializeScheduledReports() {
    console.log('Initializing automated analytics reporting...');
    
    // Morning report at 8:00 AM daily
    cron.schedule('0 8 * * *', async () => {
      console.log('Sending 8:00 AM analytics report...');
      await this.sendDailyReport('morning');
    }, {
      timezone: 'America/New_York'
    });

    // Second morning report at 9:00 AM daily
    cron.schedule('0 9 * * *', async () => {
      console.log('Sending 9:00 AM analytics report...');
      await this.sendDailyReport('morning');
    }, {
      timezone: 'America/New_York'
    });

    // Evening report at 8:00 PM daily
    cron.schedule('0 20 * * *', async () => {
      console.log('Sending evening analytics report...');
      await this.sendDailyReport('evening');
    }, {
      timezone: 'America/New_York'
    });

    console.log('Automated reporting scheduled: 8:00 AM, 9:00 AM, and 8:00 PM daily');
  }

  // Generate and send comprehensive daily report
  static async sendDailyReport(period: 'morning' | 'evening') {
    try {
      const report = await AnalyticsService.generateAnalyticsReport();
      const htmlContent = this.generateReportHTML(report, period);
      const subject = `Care Companion Analytics - ${period.charAt(0).toUpperCase() + period.slice(1)} Report ${new Date().toLocaleDateString()}`;

      await this.sendEmail({
        to: this.config.recipient,
        subject,
        html: htmlContent,
      });

      console.log(`${period} analytics report sent successfully`);
    } catch (error) {
      console.error(`Error sending ${period} report:`, error);
    }
  }

  // Generate comprehensive HTML report
  private static generateReportHTML(report: any, period: string): string {
    const { summary, traffic, recentActivity } = report;
    
    return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Care Companion Analytics Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header { text-align: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 2px solid #0ea5e9; }
        .header h1 { color: #0ea5e9; margin: 0; font-size: 28px; }
        .header .subtitle { color: #64748b; font-size: 16px; margin-top: 5px; }
        .metrics { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .metric-card { background: linear-gradient(135deg, #0ea5e9, #06b6d4); color: white; padding: 20px; border-radius: 8px; text-align: center; }
        .metric-card h3 { margin: 0 0 10px 0; font-size: 14px; opacity: 0.9; }
        .metric-card .value { font-size: 32px; font-weight: bold; margin: 0; }
        .metric-card .change { font-size: 12px; margin-top: 5px; opacity: 0.8; }
        .section { margin-bottom: 30px; }
        .section h2 { color: #1e293b; margin-bottom: 15px; font-size: 20px; }
        .table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        .table th, .table td { padding: 12px; text-align: left; border-bottom: 1px solid #e2e8f0; }
        .table th { background-color: #f8fafc; font-weight: 600; color: #475569; }
        .table tr:hover { background-color: #f8fafc; }
        .status-active { color: #059669; font-weight: 600; }
        .status-converted { color: #dc2626; font-weight: 600; }
        .status-expired { color: #9ca3af; font-weight: 600; }
        .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #e2e8f0; color: #64748b; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Care Companion Analytics</h1>
            <div class="subtitle">${period.charAt(0).toUpperCase() + period.slice(1)} Report - ${new Date().toLocaleDateString('en-US', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}</div>
        </div>

        <div class="metrics">
            <div class="metric-card">
                <h3>Total Trials Started</h3>
                <div class="value">${summary.totalTrialsStarted}</div>
                <div class="change">Last 30 days</div>
            </div>
            <div class="metric-card">
                <h3>Active Trials</h3>
                <div class="value">${summary.activeTrials}</div>
                <div class="change">Currently active</div>
            </div>
            <div class="metric-card">
                <h3>Conversion Rate</h3>
                <div class="value">${summary.conversionRate}%</div>
                <div class="change">${summary.convertedTrials} converted</div>
            </div>
            <div class="metric-card">
                <h3>Revenue</h3>
                <div class="value">$${summary.estimatedRevenue.toFixed(2)}</div>
                <div class="change">From conversions</div>
            </div>
        </div>

        <div class="section">
            <h2>📊 Traffic Sources</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Source</th>
                        <th>Trial Signups</th>
                        <th>Percentage</th>
                    </tr>
                </thead>
                <tbody>
                    ${traffic.topReferralSources.map(source => `
                        <tr>
                            <td>${source.source || 'Direct'}</td>
                            <td>${source.count}</td>
                            <td>${((source.count / summary.totalTrialsStarted) * 100).toFixed(1)}%</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>

        <div class="section">
            <h2>🌍 Geographic Distribution</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Country</th>
                        <th>Trial Signups</th>
                        <th>Percentage</th>
                    </tr>
                </thead>
                <tbody>
                    ${traffic.topCountries.map(country => `
                        <tr>
                            <td>${country.country || 'Unknown'}</td>
                            <td>${country.count}</td>
                            <td>${((country.count / summary.totalTrialsStarted) * 100).toFixed(1)}%</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>

        <div class="section">
            <h2>🕒 Recent Trial Activity</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Customer</th>
                        <th>Email</th>
                        <th>Start Date</th>
                        <th>Status</th>
                        <th>Source</th>
                        <th>Location</th>
                    </tr>
                </thead>
                <tbody>
                    ${recentActivity.map(trial => `
                        <tr>
                            <td>${trial.firstName} ${trial.lastName}</td>
                            <td>${trial.email}</td>
                            <td>${new Date(trial.trialStartDate).toLocaleDateString()}</td>
                            <td class="status-${trial.trialStatus}">${trial.trialStatus}</td>
                            <td>${trial.referralSource || 'Direct'}</td>
                            <td>${trial.country || 'Unknown'}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>

        <div class="section">
            <h2>📈 Key Insights</h2>
            <ul style="line-height: 1.6; color: #475569;">
                <li><strong>Best performing source:</strong> ${traffic.topReferralSources[0]?.source || 'Direct'} (${traffic.topReferralSources[0]?.count || 0} signups)</li>
                <li><strong>Top geographic market:</strong> ${traffic.topCountries[0]?.country || 'Unknown'} (${traffic.topCountries[0]?.count || 0} signups)</li>
                <li><strong>Trial completion rate:</strong> ${summary.conversionRate}% converting to paid subscriptions</li>
                <li><strong>Revenue potential:</strong> ${summary.activeTrials} active trials worth up to $${(summary.activeTrials * 49.99).toFixed(2)} if converted</li>
            </ul>
        </div>

        <div class="footer">
            <p>Care Companion Analytics • Generated ${new Date().toLocaleString()} • Automated ${period} report</p>
            <p>This report includes all trial signups, conversions, traffic sources, and user activity data.</p>
        </div>
    </div>
</body>
</html>`;
  }

  // Send email using available service
  private static async sendEmail(emailData: { to: string; subject: string; html: string }) {
    try {
      if (this.config.sendgridApiKey) {
        await this.sendWithSendGrid(emailData);
      } else {
        // Fallback: log email content for now
        console.log('Email would be sent:', emailData.subject);
        console.log('HTML length:', emailData.html.length, 'characters');
        
        // In production, you'd want to configure SendGrid or another email service
        console.log('Configure SENDGRID_API_KEY environment variable to enable email delivery');
      }
    } catch (error) {
      console.error('Error sending email:', error);
    }
  }

  // Send email via SendGrid
  private static async sendWithSendGrid(emailData: { to: string; subject: string; html: string }) {
    try {
      const sgMail = require('@sendgrid/mail');
      sgMail.setApiKey(this.config.sendgridApiKey);

      const msg = {
        to: emailData.to,
        from: this.config.fromEmail,
        subject: emailData.subject,
        html: emailData.html,
      };

      await sgMail.send(msg);
      console.log('Email sent successfully via SendGrid');
    } catch (error) {
      console.error('SendGrid error:', error);
      throw error;
    }
  }

  // Manual report generation (for testing or on-demand reports)
  static async generateManualReport() {
    console.log('Generating manual analytics report...');
    await this.sendDailyReport('manual');
  }

  // Update email configuration
  static updateConfig(newConfig: Partial<EmailConfig>) {
    this.config = { ...this.config, ...newConfig };
    console.log('Email reporting configuration updated');
  }
}