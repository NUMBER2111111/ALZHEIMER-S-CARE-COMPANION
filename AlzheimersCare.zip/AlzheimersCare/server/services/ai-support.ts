import OpenAI from 'openai';

if (!process.env.OPENAI_API_KEY) {
  throw new Error('OPENAI_API_KEY environment variable is required');
}

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp?: Date;
  category?: string;
}

interface UserContext {
  email?: string;
  subscriptionStatus?: string;
  timestamp?: string;
}

interface AISupportResponse {
  content: string;
  category: 'billing' | 'technical' | 'general';
  followUpActions?: string[];
  escalationNeeded?: boolean;
}

export async function generateAISupportResponse(
  userMessage: string,
  chatHistory: ChatMessage[] = [],
  userContext: UserContext = {}
): Promise<AISupportResponse> {
  try {
    // Build context from chat history
    const conversationContext = chatHistory
      .slice(-5) // Last 5 messages for context
      .map(msg => `${msg.role}: ${msg.content}`)
      .join('\n');

    // Determine message category
    const category = categorizeMessage(userMessage);

    // Build system prompt based on category
    const systemPrompt = buildSystemPrompt(category, userContext);

    // Create the conversation messages
    const messages: any[] = [
      { role: 'system', content: systemPrompt },
      ...(conversationContext ? [{ role: 'assistant', content: `Previous conversation:\n${conversationContext}` }] : []),
      { role: 'user', content: userMessage }
    ];

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o', // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages,
      max_tokens: 500,
      temperature: 0.7,
      response_format: { type: "json_object" }
    });

    const response = completion.choices[0].message.content;
    if (!response) {
      throw new Error('No response from OpenAI');
    }

    const parsedResponse = JSON.parse(response);

    return {
      content: parsedResponse.response || 'I apologize, but I\'m having trouble understanding your request. Could you please rephrase it?',
      category: parsedResponse.category || category,
      followUpActions: parsedResponse.followUpActions || [],
      escalationNeeded: parsedResponse.escalationNeeded || false
    };

  } catch (error) {
    console.error('AI Support Generation Error:', error);
    
    // Fallback response
    return {
      content: "I apologize, but I'm experiencing technical difficulties right now. For immediate assistance, please contact our support team at support@carecompanion.com or call 1-800-CARE-AI. Our team is available 24/7 to help you.",
      category: 'technical',
      followUpActions: [
        'Contact human support: support@carecompanion.com',
        'Call: 1-800-CARE-AI',
        'Check our help documentation'
      ],
      escalationNeeded: true
    };
  }
}

function categorizeMessage(message: string): 'billing' | 'technical' | 'general' {
  const billingKeywords = [
    'bill', 'billing', 'payment', 'charge', 'subscription', 'trial', 'cancel',
    'refund', 'credit card', 'invoice', 'price', 'cost', 'fee', 'money'
  ];
  
  const technicalKeywords = [
    'error', 'bug', 'issue', 'problem', 'not working', 'broken', 'login',
    'password', 'access', 'device', 'connection', 'slow', 'crash'
  ];

  const lowerMessage = message.toLowerCase();
  
  if (billingKeywords.some(keyword => lowerMessage.includes(keyword))) {
    return 'billing';
  }
  
  if (technicalKeywords.some(keyword => lowerMessage.includes(keyword))) {
    return 'technical';
  }
  
  return 'general';
}

function buildSystemPrompt(category: string, userContext: UserContext): string {
  const basePrompt = `You are an AI support assistant for Care Companion, an AI-powered Alzheimer's care platform. 

IMPORTANT: Always respond with valid JSON in this exact format:
{
  "response": "your helpful response text here",
  "category": "${category}",
  "followUpActions": ["action1", "action2"],
  "escalationNeeded": false
}

Company Information:
- Care Companion is a comprehensive AI-powered care platform for Alzheimer's patients
- Pricing: $49.99/month with 14-day free trial
- Features include: AI voice companion, cognitive training, family connections, emergency monitoring, medication tracking
- Platform includes military-grade security and HIPAA compliance
- Support: support@carecompanion.com, 1-800-CARE-AI

User Context:
- Email: ${userContext.email || 'Not provided'}
- Subscription Status: ${userContext.subscriptionStatus || 'Unknown'}
- Current Time: ${userContext.timestamp || new Date().toISOString()}`;

  switch (category) {
    case 'billing':
      return `${basePrompt}

BILLING EXPERTISE:
- Trial Period: 14 days free, then automatically converts to $49.99/month
- Cancellation: Can cancel anytime during trial or subscription
- Refunds: Pro-rated refunds available within 30 days
- Payment Methods: Credit/debit cards via secure Stripe processing
- Billing Cycle: Monthly on the same date as subscription start
- Trial users are charged after 14 days unless cancelled

Handle billing questions with empathy and clear explanations. If the user wants to cancel or has billing disputes, acknowledge their concern and provide clear next steps.`;

    case 'technical':
      return `${basePrompt}

TECHNICAL EXPERTISE:
- Platform Requirements: Modern web browser, stable internet, optional: smart devices for enhanced monitoring
- Supported Devices: iOS/Android smartphones, smart watches, home monitoring devices
- Common Issues: Browser compatibility, device connections, audio/microphone setup
- AI Features: Voice recognition requires microphone permissions and good audio quality
- Security: All data encrypted, HIPAA compliant, secure family access controls

Provide step-by-step troubleshooting when possible. If the issue seems complex, suggest escalation to technical support.`;

    default:
      return `${basePrompt}

GENERAL SUPPORT:
- Be helpful, empathetic, and professional
- Provide clear information about platform features and benefits
- Guide users to appropriate resources
- Focus on how Care Companion can help with Alzheimer's care needs
- If unsure about specific details, suggest contacting human support

Remember: This platform helps families provide better care for loved ones with Alzheimer's. Be compassionate and understanding.`;
  }
}

export default { generateAISupportResponse };