/**
 * Mood Tracking Service - Comprehensive emotional state tracking with compassionate AI companion feedback
 * Healthcare-grade mood analysis and personalized AI responses for Alzheimer's patients
 */

import { db } from "../db";
import { 
  moodEntries, 
  companionResponses, 
  moodTrends,
  type InsertMoodEntry,
  type MoodEntry,
  type InsertCompanionResponse,
  type CompanionResponse,
  type InsertMoodTrend,
  type MoodTrend
} from "@shared/schema";
import { eq, desc, and, gte, lte, avg, count } from "drizzle-orm";
import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface MoodAnalysisResult {
  emotionalAnalysis: {
    dominantEmotion: string;
    emotionalIntensity: number;
    stressIndicators: string[];
    positiveFactors: string[];
  };
  riskAssessment: {
    depressionRisk: 'low' | 'moderate' | 'high' | 'critical';
    anxietyLevel: 'low' | 'moderate' | 'high' | 'severe';
    emergencyKeywords: string[];
    requiresIntervention: boolean;
  };
  personalizedResponse: {
    responseType: 'empathetic' | 'encouraging' | 'suggestion' | 'emergency_alert';
    empathyLevel: number;
    responseText: string;
    suggestedActions: string[];
    personalityTraits: Record<string, any>;
  };
}

export interface MoodTrendAnalysis {
  averageMoodScore: number;
  moodVariability: number;
  dominantMood: string;
  improvementAreas: string[];
  wellnessRecommendations: string[];
  trendsInsights: string[];
}

class MoodTrackingService {
  /**
   * Create a new mood entry with comprehensive emotional analysis
   */
  async createMoodEntry(moodData: InsertMoodEntry): Promise<{ entry: MoodEntry; analysis: MoodAnalysisResult }> {
    try {
      // Perform AI analysis of the mood entry
      const analysis = await this.analyzeMoodWithAI(moodData);
      
      // Create mood entry with AI analysis
      const [entry] = await db
        .insert(moodEntries)
        .values({
          patientId: moodData.patientId,
          moodState: moodData.moodState,
          energyLevel: moodData.energyLevel,
          anxietyLevel: moodData.anxietyLevel,
          socialEngagement: moodData.socialEngagement,
          cognitiveClarity: moodData.cognitiveClarity,
          physicalComfort: moodData.physicalComfort,
          notes: moodData.notes,
          contextualFactors: moodData.contextualFactors ? {
            ...moodData.contextualFactors,
            analysisTimestamp: new Date().toISOString(),
            riskLevel: analysis.riskAssessment.depressionRisk
          } : null
        })
        .returning();

      // Generate compassionate AI companion response
      await this.generateCompanionResponse(entry.id, entry.patientId, analysis);

      return { entry, analysis };
    } catch (error) {
      console.error("Failed to create mood entry:", error);
      throw new Error(`Failed to create mood entry: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Generate compassionate AI companion response based on mood analysis
   */
  private async generateCompanionResponse(moodEntryId: number, patientId: number, analysis: MoodAnalysisResult): Promise<CompanionResponse> {
    try {
      const responseData: InsertCompanionResponse = {
        moodEntryId,
        patientId,
        responseType: analysis.personalizedResponse.responseType,
        responseText: analysis.personalizedResponse.responseText,
        empathyLevel: analysis.personalizedResponse.empathyLevel,
        suggestedActions: analysis.personalizedResponse.suggestedActions,
        personalityTraits: analysis.personalizedResponse.personalityTraits,
        emergencyKeywordsDetected: analysis.riskAssessment.emergencyKeywords,
        confidenceScore: "0.95"
      };

      const [response] = await db
        .insert(companionResponses)
        .values(responseData)
        .returning();

      return response;
    } catch (error) {
      console.error("Failed to generate companion response:", error);
      throw new Error(`Failed to generate companion response: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Analyze mood entry using OpenAI for emotional intelligence and risk assessment
   */
  private async analyzeMoodWithAI(moodData: InsertMoodEntry): Promise<MoodAnalysisResult> {
    try {
      const prompt = this.buildAnalysisPrompt(moodData);
      
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `You are a compassionate AI companion specialized in Alzheimer's care and emotional support. 
            Analyze the mood data and provide empathetic, personalized responses. Focus on emotional validation, 
            gentle encouragement, and practical wellness suggestions. Always maintain a warm, understanding tone.
            Respond with valid JSON in the specified format.`
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.7
      });

      const analysisResult = JSON.parse(response.choices[0].message.content || '{}');
      return this.validateAndFormatAnalysis(analysisResult);
    } catch (error) {
      console.error("AI analysis failed:", error);
      // Fallback to rule-based analysis
      return this.generateFallbackAnalysis(moodData);
    }
  }

  /**
   * Build comprehensive analysis prompt for OpenAI
   */
  private buildAnalysisPrompt(moodData: InsertMoodEntry): string {
    return `
    Analyze this mood entry from an Alzheimer's patient and provide compassionate feedback:
    
    Mood State: ${moodData.moodState}
    Energy Level: ${moodData.energyLevel}/10
    Anxiety Level: ${moodData.anxietyLevel}/10
    Social Engagement: ${moodData.socialEngagement}/10
    Cognitive Clarity: ${moodData.cognitiveClarity}/10
    Physical Comfort: ${moodData.physicalComfort}/10
    Notes: ${moodData.notes || 'None provided'}
    Context: ${JSON.stringify(moodData.contextualFactors || {})}
    
    Provide analysis in this JSON format:
    {
      "emotionalAnalysis": {
        "dominantEmotion": "primary emotion detected",
        "emotionalIntensity": 1-10,
        "stressIndicators": ["list of stress factors"],
        "positiveFactors": ["list of positive elements"]
      },
      "riskAssessment": {
        "depressionRisk": "low|moderate|high|critical",
        "anxietyLevel": "low|moderate|high|severe",
        "emergencyKeywords": ["concerning phrases if any"],
        "requiresIntervention": boolean
      },
      "personalizedResponse": {
        "responseType": "empathetic|encouraging|suggestion|emergency_alert",
        "empathyLevel": 1-10,
        "responseText": "warm, personalized response (2-3 sentences)",
        "suggestedActions": ["practical wellness suggestions"],
        "personalityTraits": {
          "tone": "warm|gentle|encouraging",
          "approach": "validating|supportive|motivating"
        }
      }
    }
    `;
  }

  /**
   * Validate and format AI analysis results
   */
  private validateAndFormatAnalysis(analysisResult: any): MoodAnalysisResult {
    return {
      emotionalAnalysis: {
        dominantEmotion: analysisResult.emotionalAnalysis?.dominantEmotion || 'neutral',
        emotionalIntensity: Math.min(10, Math.max(1, analysisResult.emotionalAnalysis?.emotionalIntensity || 5)),
        stressIndicators: Array.isArray(analysisResult.emotionalAnalysis?.stressIndicators) 
          ? analysisResult.emotionalAnalysis.stressIndicators : [],
        positiveFactors: Array.isArray(analysisResult.emotionalAnalysis?.positiveFactors)
          ? analysisResult.emotionalAnalysis.positiveFactors : []
      },
      riskAssessment: {
        depressionRisk: ['low', 'moderate', 'high', 'critical'].includes(analysisResult.riskAssessment?.depressionRisk)
          ? analysisResult.riskAssessment.depressionRisk : 'low',
        anxietyLevel: ['low', 'moderate', 'high', 'severe'].includes(analysisResult.riskAssessment?.anxietyLevel)
          ? analysisResult.riskAssessment.anxietyLevel : 'low',
        emergencyKeywords: Array.isArray(analysisResult.riskAssessment?.emergencyKeywords)
          ? analysisResult.riskAssessment.emergencyKeywords : [],
        requiresIntervention: Boolean(analysisResult.riskAssessment?.requiresIntervention)
      },
      personalizedResponse: {
        responseType: ['empathetic', 'encouraging', 'suggestion', 'emergency_alert'].includes(analysisResult.personalizedResponse?.responseType)
          ? analysisResult.personalizedResponse.responseType : 'empathetic',
        empathyLevel: Math.min(10, Math.max(1, analysisResult.personalizedResponse?.empathyLevel || 8)),
        responseText: analysisResult.personalizedResponse?.responseText || 'I understand how you\'re feeling. You\'re not alone in this.',
        suggestedActions: Array.isArray(analysisResult.personalizedResponse?.suggestedActions)
          ? analysisResult.personalizedResponse.suggestedActions : [],
        personalityTraits: analysisResult.personalizedResponse?.personalityTraits || { tone: 'warm', approach: 'supportive' }
      }
    };
  }

  /**
   * Fallback analysis when AI is unavailable
   */
  private generateFallbackAnalysis(moodData: InsertMoodEntry): MoodAnalysisResult {
    const avgScore = (moodData.energyLevel + moodData.socialEngagement + moodData.cognitiveClarity + moodData.physicalComfort) / 4;
    const anxietyHigh = moodData.anxietyLevel > 7;
    const lowMood = avgScore < 4;

    return {
      emotionalAnalysis: {
        dominantEmotion: lowMood ? 'concerned' : 'stable',
        emotionalIntensity: Math.round(avgScore),
        stressIndicators: anxietyHigh ? ['High anxiety level detected'] : [],
        positiveFactors: avgScore > 6 ? ['Good overall wellness scores'] : []
      },
      riskAssessment: {
        depressionRisk: lowMood ? 'moderate' : 'low',
        anxietyLevel: anxietyHigh ? 'high' : 'moderate',
        emergencyKeywords: [],
        requiresIntervention: lowMood && anxietyHigh
      },
      personalizedResponse: {
        responseType: lowMood ? 'empathetic' : 'encouraging',
        empathyLevel: 8,
        responseText: lowMood 
          ? "I can see you're having a challenging time right now. Your feelings are valid, and I'm here to support you."
          : "It's wonderful to see you're doing well today. Keep taking care of yourself.",
        suggestedActions: lowMood 
          ? ['Take some deep breaths', 'Consider gentle movement', 'Reach out to a loved one']
          : ['Continue your positive activities', 'Share your good mood with others'],
        personalityTraits: { tone: 'warm', approach: 'supportive' }
      }
    };
  }

  /**
   * Get mood entries for a patient with optional date range
   */
  async getPatientMoodEntries(patientId: number, fromDate?: Date, toDate?: Date): Promise<MoodEntry[]> {
    try {
      let query = db
        .select()
        .from(moodEntries)
        .where(eq(moodEntries.patientId, patientId))
        .orderBy(desc(moodEntries.createdAt));

      if (fromDate && toDate) {
        return await db
          .select()
          .from(moodEntries)
          .where(
            and(
              eq(moodEntries.patientId, patientId),
              gte(moodEntries.createdAt, fromDate),
              lte(moodEntries.createdAt, toDate)
            )
          )
          .orderBy(desc(moodEntries.createdAt));
      }

      return await query;
    } catch (error) {
      console.error("Failed to get patient mood entries:", error);
      throw new Error(`Failed to get patient mood entries: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Get companion responses for a mood entry
   */
  async getCompanionResponses(moodEntryId: number): Promise<CompanionResponse[]> {
    try {
      return await db
        .select()
        .from(companionResponses)
        .where(eq(companionResponses.moodEntryId, moodEntryId))
        .orderBy(desc(companionResponses.createdAt));
    } catch (error) {
      console.error("Failed to get companion responses:", error);
      throw new Error(`Failed to get companion responses: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Update user reaction to companion response
   */
  async updateResponseReaction(responseId: number, reaction: 'helpful' | 'neutral' | 'unhelpful' | 'ignored'): Promise<void> {
    try {
      await db
        .update(companionResponses)
        .set({ userReaction: reaction })
        .where(eq(companionResponses.id, responseId));
    } catch (error) {
      console.error("Failed to update response reaction:", error);
      throw new Error(`Failed to update response reaction: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Generate mood trends analysis for a patient
   */
  async generateMoodTrends(patientId: number, period: 'daily' | 'weekly' | 'monthly' = 'weekly'): Promise<MoodTrend> {
    try {
      const daysBack = period === 'daily' ? 1 : period === 'weekly' ? 7 : 30;
      const fromDate = new Date();
      fromDate.setDate(fromDate.getDate() - daysBack);

      const entries = await this.getPatientMoodEntries(patientId, fromDate, new Date());
      const analysis = await this.analyzeMoodTrends(entries, period);

      const trendData: InsertMoodTrend = {
        patientId,
        trendPeriod: period,
        averageMoodScore: analysis.averageMoodScore.toString(),
        moodVariability: analysis.moodVariability.toString(),
        dominantMood: analysis.dominantMood,
        improvementAreas: analysis.improvementAreas,
        wellnessRecommendations: analysis.wellnessRecommendations,
        trendsAnalysis: analysis.trendsInsights
      };

      const [trend] = await db
        .insert(moodTrends)
        .values(trendData)
        .returning();

      return trend;
    } catch (error) {
      console.error("Failed to generate mood trends:", error);
      throw new Error(`Failed to generate mood trends: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Analyze mood trends from historical data
   */
  private async analyzeMoodTrends(entries: MoodEntry[], period: string): Promise<MoodTrendAnalysis> {
    if (entries.length === 0) {
      return {
        averageMoodScore: 5.0,
        moodVariability: 0,
        dominantMood: 'neutral',
        improvementAreas: ['Increase mood tracking frequency'],
        wellnessRecommendations: ['Start daily mood check-ins'],
        trendsInsights: ['Not enough data for analysis']
      };
    }

    // Calculate averages
    const totalEntries = entries.length;
    const avgEnergy = entries.reduce((sum, e) => sum + e.energyLevel, 0) / totalEntries;
    const avgAnxiety = entries.reduce((sum, e) => sum + e.anxietyLevel, 0) / totalEntries;
    const avgSocial = entries.reduce((sum, e) => sum + e.socialEngagement, 0) / totalEntries;
    const avgCognitive = entries.reduce((sum, e) => sum + e.cognitiveClarity, 0) / totalEntries;
    const avgPhysical = entries.reduce((sum, e) => sum + e.physicalComfort, 0) / totalEntries;

    const averageMoodScore = (avgEnergy + avgSocial + avgCognitive + avgPhysical - avgAnxiety) / 4;

    // Calculate mood variability
    const moodScores = entries.map(e => (e.energyLevel + e.socialEngagement + e.cognitiveClarity + e.physicalComfort - e.anxietyLevel) / 4);
    const variance = moodScores.reduce((sum, score) => sum + Math.pow(score - averageMoodScore, 2), 0) / totalEntries;
    const moodVariability = Math.sqrt(variance);

    // Determine dominant mood
    const moodCounts: Record<string, number> = {};
    entries.forEach(e => {
      moodCounts[e.moodState] = (moodCounts[e.moodState] || 0) + 1;
    });
    const dominantMood = Object.entries(moodCounts).reduce((a, b) => moodCounts[a[0]] > moodCounts[b[0]] ? a : b)[0];

    // Generate insights
    const improvementAreas = [];
    const wellnessRecommendations = [];
    const trendsInsights = [];

    if (avgAnxiety > 6) {
      improvementAreas.push('Anxiety management');
      wellnessRecommendations.push('Practice deep breathing exercises');
    }
    if (avgEnergy < 5) {
      improvementAreas.push('Energy levels');
      wellnessRecommendations.push('Consider gentle physical activity');
    }
    if (avgSocial < 5) {
      improvementAreas.push('Social engagement');
      wellnessRecommendations.push('Schedule regular family calls');
    }

    trendsInsights.push(`Average mood score: ${averageMoodScore.toFixed(1)}/10 over the last ${period}`);
    trendsInsights.push(`Mood variability: ${moodVariability < 2 ? 'Low' : moodVariability < 4 ? 'Moderate' : 'High'}`);
    trendsInsights.push(`Most common mood: ${dominantMood}`);

    return {
      averageMoodScore: Number(averageMoodScore.toFixed(2)),
      moodVariability: Number(moodVariability.toFixed(2)),
      dominantMood,
      improvementAreas,
      wellnessRecommendations,
      trendsInsights
    };
  }

  /**
   * Get latest mood trends for a patient
   */
  async getLatestMoodTrends(patientId: number): Promise<MoodTrend[]> {
    try {
      return await db
        .select()
        .from(moodTrends)
        .where(eq(moodTrends.patientId, patientId))
        .orderBy(desc(moodTrends.calculatedAt))
        .limit(3);
    } catch (error) {
      console.error("Failed to get latest mood trends:", error);
      throw new Error(`Failed to get latest mood trends: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
}

export const moodTrackingService = new MoodTrackingService();