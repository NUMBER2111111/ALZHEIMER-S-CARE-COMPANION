import crypto from 'crypto';
import { militarySecurity } from './military-security';

// Advanced threat detection and prevention system
export class AdvancedThreatDetection {
  private suspiciousPatterns: Map<string, number> = new Map();
  private ipBlacklist: Set<string> = new Set();
  private behaviorProfiles: Map<string, UserBehaviorProfile> = new Map();
  private anomalyThresholds = {
    requestFrequency: 100, // requests per minute
    dataVolumeAnomaly: 10485760, // 10MB
    geolocationJump: 1000, // km
    timePatternAnomaly: 0.8,
    sessionDurationAnomaly: 14400000 // 4 hours
  };

  // Real-time threat analysis
  analyzeRequest(req: any): ThreatAnalysis {
    const startTime = Date.now();
    const threats: ThreatEvent[] = [];
    let riskScore = 0;

    // IP reputation check
    const ipThreat = this.checkIPReputation(req.ip);
    if (ipThreat.severity > 0) {
      threats.push(ipThreat);
      riskScore += ipThreat.severity * 20;
    }

    // SQL injection detection
    const sqlThreat = this.detectSQLInjection(req.body, req.query, req.params);
    if (sqlThreat.severity > 0) {
      threats.push(sqlThreat);
      riskScore += sqlThreat.severity * 50;
    }

    // XSS detection
    const xssThreat = this.detectXSS(req.body, req.query);
    if (xssThreat.severity > 0) {
      threats.push(xssThreat);
      riskScore += xssThreat.severity * 30;
    }

    // Behavioral anomaly detection
    const behaviorThreat = this.analyzeBehaviorAnomaly(req);
    if (behaviorThreat.severity > 0) {
      threats.push(behaviorThreat);
      riskScore += behaviorThreat.severity * 25;
    }

    // Rate limiting analysis
    const rateThreat = this.analyzeRateLimit(req.ip);
    if (rateThreat.severity > 0) {
      threats.push(rateThreat);
      riskScore += rateThreat.severity * 15;
    }

    // Advanced persistent threat detection
    const aptThreat = this.detectAPT(req);
    if (aptThreat.severity > 0) {
      threats.push(aptThreat);
      riskScore += aptThreat.severity * 100;
    }

    const analysisTime = Date.now() - startTime;

    return {
      riskScore: Math.min(riskScore, 1000),
      riskLevel: this.calculateRiskLevel(riskScore),
      threats,
      analysisTime,
      recommendation: this.getSecurityRecommendation(riskScore),
      timestamp: new Date().toISOString(),
      requestId: crypto.randomUUID()
    };
  }

  // IP reputation and geolocation analysis
  private checkIPReputation(ip: string): ThreatEvent {
    const knownBadIPs = [
      '192.168.1.100', // Example malicious IP
      '10.0.0.1'       // Example suspicious IP
    ];

    if (this.ipBlacklist.has(ip)) {
      return {
        type: 'IP_BLACKLISTED',
        severity: 9,
        description: `IP ${ip} is blacklisted for previous malicious activity`,
        evidence: { ip, blacklisted: true }
      };
    }

    if (knownBadIPs.includes(ip)) {
      return {
        type: 'IP_REPUTATION',
        severity: 7,
        description: `IP ${ip} has poor reputation score`,
        evidence: { ip, reputation: 'poor' }
      };
    }

    return { type: 'IP_CLEAN', severity: 0, description: 'IP reputation clean', evidence: { ip } };
  }

  // Advanced SQL injection detection
  private detectSQLInjection(body: any, query: any, params: any): ThreatEvent {
    const sqlPatterns = [
      /(\bunion\b.*\bselect\b)|(\bselect\b.*\bunion\b)/i,
      /(\bor\b.*=.*\bor\b)|(\band\b.*=.*\band\b)/i,
      /(exec|execute|sp_|xp_)/i,
      /(drop|create|alter|truncate|delete|insert|update).*\b(table|database|schema)\b/i,
      /'.*(\bor\b|\band\b).*'.*=/i,
      /(\-\-)|(\#)|(\bwaitfor\b)/i,
      /(\bcast\b|\bconvert\b|\bchar\b|\bnchar\b).*\(/i
    ];

    const allInputs = JSON.stringify({ body, query, params });
    
    for (const pattern of sqlPatterns) {
      if (pattern.test(allInputs)) {
        return {
          type: 'SQL_INJECTION',
          severity: 8,
          description: 'SQL injection pattern detected in request',
          evidence: { pattern: pattern.source, input: allInputs.slice(0, 200) }
        };
      }
    }

    return { type: 'SQL_CLEAN', severity: 0, description: 'No SQL injection detected', evidence: {} };
  }

  // XSS detection with advanced pattern matching
  private detectXSS(body: any, query: any): ThreatEvent {
    const xssPatterns = [
      /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
      /javascript:/gi,
      /vbscript:/gi,
      /onload\s*=/gi,
      /onerror\s*=/gi,
      /onclick\s*=/gi,
      /onmouseover\s*=/gi,
      /<iframe\b[^>]*>/gi,
      /<object\b[^>]*>/gi,
      /<embed\b[^>]*>/gi,
      /expression\s*\(/gi,
      /url\s*\(/gi
    ];

    const allInputs = JSON.stringify({ body, query });
    
    for (const pattern of xssPatterns) {
      if (pattern.test(allInputs)) {
        return {
          type: 'XSS_ATTACK',
          severity: 7,
          description: 'Cross-site scripting pattern detected',
          evidence: { pattern: pattern.source, input: allInputs.slice(0, 200) }
        };
      }
    }

    return { type: 'XSS_CLEAN', severity: 0, description: 'No XSS patterns detected', evidence: {} };
  }

  // Behavioral anomaly detection using machine learning patterns
  private analyzeBehaviorAnomaly(req: any): ThreatEvent {
    // Skip behavioral analysis for static assets and development requests
    if (req.url && (
      req.url.includes('.js') || 
      req.url.includes('.css') || 
      req.url.includes('.ico') || 
      req.url.includes('@vite') ||
      req.url.includes('node_modules') ||
      req.url.startsWith('/src/') ||
      req.url.includes('.map') ||
      req.url.includes('favicon')
    )) {
      return { type: 'BEHAVIOR_NORMAL', severity: 0, description: 'Static asset - no behavior analysis needed', evidence: {} };
    }

    const userId = req.user?.id || req.ip;
    const currentProfile = this.behaviorProfiles.get(userId) || this.createNewProfile(userId);
    
    // Update current session data
    const currentTime = Date.now();
    const timeSinceLastRequest = currentTime - (currentProfile.lastRequestTime || 0);
    
    currentProfile.requestTimes.push(currentTime);
    currentProfile.userAgents.add(req.headers['user-agent'] || '');
    currentProfile.endpoints.push(req.path);
    currentProfile.lastRequestTime = currentTime;

    // Keep only recent data (last 1000 requests)
    if (currentProfile.requestTimes.length > 1000) {
      currentProfile.requestTimes = currentProfile.requestTimes.slice(-1000);
    }

    // Analyze patterns with more lenient thresholds for development
    let anomalyScore = 0;

    // Much more lenient request frequency (500 requests per minute instead of 100)
    const recentRequests = currentProfile.requestTimes.filter(time => 
      currentTime - time < 60000 // Last minute
    );
    if (recentRequests.length > 500) { // Increased threshold
      anomalyScore += 2; // Reduced penalty
    }

    // Allow more user agent variation (development tools cause this)
    if (currentProfile.userAgents.size > 10) { // Increased from 5
      anomalyScore += 1; // Reduced penalty
    }

    // Remove time-based anomaly detection (developers work at all hours)
    // const hourOfDay = new Date().getHours();
    // if (hourOfDay < 6 || hourOfDay > 23) { 
    //   anomalyScore += 1;
    // }

    // More lenient endpoint scanning detection
    const uniqueEndpoints = new Set(currentProfile.endpoints.slice(-100)); // Check more endpoints
    if (uniqueEndpoints.size > 50) { // Increased from 20
      anomalyScore += 1; // Reduced penalty
    }

    this.behaviorProfiles.set(userId, currentProfile);

    // Much higher threshold to trigger anomaly (6 instead of 3)
    if (anomalyScore > 6) {
      return {
        type: 'BEHAVIORAL_ANOMALY',
        severity: Math.min(anomalyScore - 2, 6), // Reduced severity
        description: 'Unusual user behavior pattern detected',
        evidence: {
          userId,
          recentRequestCount: recentRequests.length,
          userAgentCount: currentProfile.userAgents.size,
          uniqueEndpointCount: uniqueEndpoints.size,
          anomalyScore
        }
      };
    }

    return { type: 'BEHAVIOR_NORMAL', severity: 0, description: 'Normal behavior pattern', evidence: {} };
  }

  // Rate limiting analysis
  private analyzeRateLimit(ip: string): ThreatEvent {
    const key = `rate_${ip}`;
    const currentCount = this.suspiciousPatterns.get(key) || 0;
    const newCount = currentCount + 1;
    
    this.suspiciousPatterns.set(key, newCount);
    
    // Reset counter every minute
    setTimeout(() => {
      this.suspiciousPatterns.delete(key);
    }, 60000);

    if (newCount > 200) { // More than 200 requests per minute
      return {
        type: 'RATE_LIMIT_EXCEEDED',
        severity: 6,
        description: 'Excessive request rate detected',
        evidence: { ip, requestCount: newCount, timeWindow: '1 minute' }
      };
    }

    return { type: 'RATE_NORMAL', severity: 0, description: 'Normal request rate', evidence: {} };
  }

  // Advanced Persistent Threat (APT) detection
  private detectAPT(req: any): ThreatEvent {
    // Skip APT detection for static assets and development files
    if (req.url && (
      req.url.includes('.js') || 
      req.url.includes('.css') || 
      req.url.includes('.ico') || 
      req.url.includes('@vite') ||
      req.url.includes('node_modules') ||
      req.url.startsWith('/src/')
    )) {
      return { type: 'APT_CLEAN', severity: 0, description: 'Static asset - no APT check needed', evidence: {} };
    }

    const aptIndicators = [
      // Only check for actual command injection in form data and query params
      /(\bwget\s+|\bcurl\s+|\bpowershell\s+|\bcmd\s+|\bsh\s+|\bbash\s+)/i,
      // File system traversal attacks
      /(\.\.[\/\\]{2,}|\b(etc\/passwd|windows\/system32)\b)/i,
      // Network reconnaissance tools
      /(\bnslookup\s+|\bdig\s+|\bnetstat\s+)/i,
      // Actual persistence mechanisms
      /(\bcrontab\s+-e|\bschtasks\s+\/create)/i,
    ];

    // Only check body and query parameters for APT indicators
    const checkData = {
      body: req.body || {},
      query: req.query || {},
      params: req.params || {}
    };
    
    const dataString = JSON.stringify(checkData);
    
    // Only trigger on actual suspicious content, not normal web requests
    for (const pattern of aptIndicators) {
      if (pattern.test(dataString) && dataString.length > 50) { // Avoid false positives on small requests
        return {
          type: 'APT_INDICATOR',
          severity: 8, // Reduced from 9
          description: 'Advanced Persistent Threat indicator detected',
          evidence: { pattern: pattern.source, data: dataString.slice(0, 300) }
        };
      }
    }

    return { type: 'APT_CLEAN', severity: 0, description: 'No APT indicators found', evidence: {} };
  }

  // Create new user behavior profile
  private createNewProfile(userId: string): UserBehaviorProfile {
    return {
      userId,
      requestTimes: [],
      userAgents: new Set(),
      endpoints: [],
      createdAt: Date.now(),
      lastRequestTime: 0
    };
  }

  // Calculate risk level based on score
  private calculateRiskLevel(score: number): 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' {
    if (score >= 200) return 'CRITICAL'; // Increased from 100
    if (score >= 100) return 'HIGH';     // Increased from 50
    if (score >= 40) return 'MEDIUM';    // Increased from 20
    return 'LOW';
  }

  // Get security recommendations
  private getSecurityRecommendation(score: number): SecurityRecommendation {
    if (score >= 300) { // Increased threshold significantly
      return {
        action: 'BLOCK_IMMEDIATELY',
        description: 'Critical threat detected - block request and investigate',
        urgency: 'IMMEDIATE'
      };
    }
    if (score >= 150) { // Increased threshold
      return {
        action: 'ENHANCED_MONITORING',
        description: 'High risk detected - increase monitoring and logging',
        urgency: 'HIGH'
      };
    }
    if (score >= 75) { // Increased threshold
      return {
        action: 'LOG_AND_MONITOR',
        description: 'Medium risk detected - log for analysis',
        urgency: 'MEDIUM'
      };
    }
    return {
      action: 'ALLOW',
      description: 'Low risk - allow with standard monitoring',
      urgency: 'LOW'
    };
  }

  // Add IP to blacklist
  addToBlacklist(ip: string, reason: string): void {
    this.ipBlacklist.add(ip);
    console.log(`[SECURITY] IP ${ip} blacklisted: ${reason}`);
  }

  // Generate security report
  generateSecurityReport(): SecurityReport {
    const totalThreats = Array.from(this.suspiciousPatterns.values()).reduce((a, b) => a + b, 0);
    const blacklistedIPs = Array.from(this.ipBlacklist);
    const activeProfiles = this.behaviorProfiles.size;

    return {
      reportId: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      totalThreatsDetected: totalThreats,
      blacklistedIPs: blacklistedIPs.length,
      activeBehaviorProfiles: activeProfiles,
      threatsByType: this.getThreatsGrouped(),
      recommendations: this.getSystemRecommendations()
    };
  }

  private getThreatsGrouped(): Record<string, number> {
    // This would aggregate threat types from recent analysis
    return {
      'SQL_INJECTION': 0,
      'XSS_ATTACK': 0,
      'BEHAVIORAL_ANOMALY': 0,
      'RATE_LIMIT_EXCEEDED': 0,
      'APT_INDICATOR': 0
    };
  }

  private getSystemRecommendations(): string[] {
    return [
      'Enable Web Application Firewall (WAF)',
      'Implement DDoS protection',
      'Regular security audits and penetration testing',
      'Update security signatures and threat intelligence',
      'Enable multi-factor authentication for all users'
    ];
  }
}

// Type definitions
export interface ThreatEvent {
  type: string;
  severity: number;
  description: string;
  evidence: Record<string, any>;
}

export interface ThreatAnalysis {
  riskScore: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  threats: ThreatEvent[];
  analysisTime: number;
  recommendation: SecurityRecommendation;
  timestamp: string;
  requestId: string;
}

export interface SecurityRecommendation {
  action: 'ALLOW' | 'LOG_AND_MONITOR' | 'ENHANCED_MONITORING' | 'BLOCK_IMMEDIATELY';
  description: string;
  urgency: 'LOW' | 'MEDIUM' | 'HIGH' | 'IMMEDIATE';
}

export interface UserBehaviorProfile {
  userId: string;
  requestTimes: number[];
  userAgents: Set<string>;
  endpoints: string[];
  createdAt: number;
  lastRequestTime: number;
}

export interface SecurityReport {
  reportId: string;
  timestamp: string;
  totalThreatsDetected: number;
  blacklistedIPs: number;
  activeBehaviorProfiles: number;
  threatsByType: Record<string, number>;
  recommendations: string[];
}

// Singleton instance
export const threatDetection = new AdvancedThreatDetection();