import { db } from '../db';
import { 
  familyRelationships, 
  users, 
  emergencyEvents,
  geofenceViolations,
  patientLocations
} from '@shared/schema';
import { eq, and, or } from 'drizzle-orm';

interface EmergencyContact {
  id: number;
  name: string;
  phone: string;
  email: string;
  relationship: string;
  priority: number; // 1 = primary, 2 = secondary, etc.
  responsibilityLevel: string;
}

interface EmergencyAlert {
  patientId: number;
  patientName: string;
  alertType: 'geofence_violation' | 'vital_emergency' | 'medication_missed' | 'fall_detected' | 'panic_button';
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  location?: {
    lat: number;
    lng: number;
    address?: string;
  };
  vitalSigns?: {
    heartRate?: number;
    bloodPressure?: string;
    oxygenSaturation?: number;
    temperature?: number;
  };
  timestamp: Date;
}

interface NotificationAttempt {
  contactId: number;
  method: 'call' | 'sms' | 'email';
  status: 'pending' | 'sent' | 'delivered' | 'acknowledged' | 'failed';
  timestamp: Date;
  responseTime?: number;
}

class EmergencyNotificationService {
  private activeAlerts: Map<string, {
    alert: EmergencyAlert;
    attempts: NotificationAttempt[];
    acknowledgedBy?: number;
    startTime: Date;
  }> = new Map();

  async triggerEmergencyAlert(alert: EmergencyAlert): Promise<void> {
    const alertId = `${alert.patientId}-${alert.alertType}-${Date.now()}`;
    
    // Get emergency contacts for patient
    const contacts = await this.getEmergencyContacts(alert.patientId);
    
    if (contacts.length === 0) {
      console.error(`No emergency contacts found for patient ${alert.patientId}`);
      return;
    }

    // Store alert in active alerts
    this.activeAlerts.set(alertId, {
      alert,
      attempts: [],
      startTime: new Date()
    });

    // Create emergency event record
    await this.createEmergencyEvent(alert);

    // Start notification cascade
    await this.startNotificationCascade(alertId, contacts);
  }

  private async getEmergencyContacts(patientId: number): Promise<EmergencyContact[]> {
    const relationships = await db
      .select({
        familyMember: users,
        relationship: familyRelationships
      })
      .from(familyRelationships)
      .innerJoin(users, eq(familyRelationships.familyMemberId, users.id))
      .where(
        and(
          eq(familyRelationships.patientId, patientId),
          eq(familyRelationships.canAccessMedical, true)
        )
      );

    return relationships.map((rel, index) => ({
      id: rel.familyMember.id,
      name: `${rel.familyMember.firstName} ${rel.familyMember.lastName}`,
      phone: this.extractPhoneFromUser(rel.familyMember),
      email: rel.familyMember.email || '',
      relationship: rel.relationship.relationship,
      priority: rel.relationship.isPrimaryContact ? 1 : 2,
      responsibilityLevel: rel.relationship.responsibilityLevel
    })).sort((a, b) => a.priority - b.priority);
  }

  private extractPhoneFromUser(user: any): string {
    // In a real implementation, phone would be a separate field
    // For now, extract from email or use a default pattern
    return user.phoneNumber || '+1234567890'; // Placeholder
  }

  private async startNotificationCascade(alertId: string, contacts: EmergencyContact[]): Promise<void> {
    const alertData = this.activeAlerts.get(alertId);
    if (!alertData) return;

    const { alert } = alertData;

    // Sort contacts by priority
    const prioritizedContacts = contacts.sort((a, b) => a.priority - b.priority);

    // Start with primary contacts
    await this.notifyContactsWithRetry(alertId, prioritizedContacts, alert);
  }

  private async notifyContactsWithRetry(
    alertId: string, 
    contacts: EmergencyContact[], 
    alert: EmergencyAlert
  ): Promise<void> {
    const alertData = this.activeAlerts.get(alertId);
    if (!alertData) return;

    // Try primary contacts first (priority 1)
    const primaryContacts = contacts.filter(c => c.priority === 1);
    
    for (const contact of primaryContacts) {
      await this.attemptContactNotification(alertId, contact, alert, 'urgent');
    }

    // Wait for acknowledgment or timeout
    const acknowledged = await this.waitForAcknowledgment(alertId, 120000); // 2 minutes

    if (!acknowledged) {
      // Escalate to secondary contacts
      const secondaryContacts = contacts.filter(c => c.priority > 1);
      
      for (const contact of secondaryContacts) {
        await this.attemptContactNotification(alertId, contact, alert, 'escalated');
      }

      // Continue retrying until acknowledged
      await this.continuousRetryUntilAcknowledged(alertId, contacts, alert);
    }
  }

  private async attemptContactNotification(
    alertId: string,
    contact: EmergencyContact,
    alert: EmergencyAlert,
    urgencyLevel: 'normal' | 'urgent' | 'escalated'
  ): Promise<void> {
    const alertData = this.activeAlerts.get(alertId);
    if (!alertData) return;

    // Call first for high-severity alerts
    if (alert.severity === 'critical' || alert.severity === 'high') {
      await this.makeEmergencyCall(alertId, contact, alert);
      await this.delay(5000); // 5 second delay
    }

    // Send SMS
    await this.sendEmergencySMS(alertId, contact, alert, urgencyLevel);
    await this.delay(2000); // 2 second delay

    // Send email for documentation
    await this.sendEmergencyEmail(alertId, contact, alert);
  }

  private async makeEmergencyCall(
    alertId: string,
    contact: EmergencyContact,
    alert: EmergencyAlert
  ): Promise<void> {
    const attempt: NotificationAttempt = {
      contactId: contact.id,
      method: 'call',
      status: 'pending',
      timestamp: new Date()
    };

    try {
      // In a real implementation, integrate with Twilio Voice API
      const callMessage = this.generateCallMessage(alert, contact);
      
      console.log(`[Emergency Call] Calling ${contact.name} at ${contact.phone}`);
      console.log(`[Call Message] ${callMessage}`);

      // Simulate call attempt
      attempt.status = 'sent';
      
      // Log the attempt
      const alertData = this.activeAlerts.get(alertId);
      if (alertData) {
        alertData.attempts.push(attempt);
      }

      // In real implementation:
      // const call = await twilioClient.calls.create({
      //   to: contact.phone,
      //   from: process.env.TWILIO_PHONE_NUMBER,
      //   twiml: `<Response><Say voice="alice">${callMessage}</Say><Gather timeout="10" numDigits="1"><Say>Press 1 to acknowledge this alert</Say></Gather></Response>`
      // });

    } catch (error) {
      console.error(`Emergency call failed for ${contact.name}:`, error);
      attempt.status = 'failed';
    }
  }

  private async sendEmergencySMS(
    alertId: string,
    contact: EmergencyContact,
    alert: EmergencyAlert,
    urgencyLevel: string
  ): Promise<void> {
    const attempt: NotificationAttempt = {
      contactId: contact.id,
      method: 'sms',
      status: 'pending',
      timestamp: new Date()
    };

    try {
      const smsMessage = this.generateSMSMessage(alert, contact, urgencyLevel);
      
      console.log(`[Emergency SMS] Texting ${contact.name} at ${contact.phone}`);
      console.log(`[SMS Message] ${smsMessage}`);

      // Simulate SMS sending
      attempt.status = 'sent';
      
      // Log the attempt
      const alertData = this.activeAlerts.get(alertId);
      if (alertData) {
        alertData.attempts.push(attempt);
      }

      // In real implementation:
      // await twilioClient.messages.create({
      //   to: contact.phone,
      //   from: process.env.TWILIO_PHONE_NUMBER,
      //   body: smsMessage
      // });

    } catch (error) {
      console.error(`Emergency SMS failed for ${contact.name}:`, error);
      attempt.status = 'failed';
    }
  }

  private async sendEmergencyEmail(
    alertId: string,
    contact: EmergencyContact,
    alert: EmergencyAlert
  ): Promise<void> {
    const attempt: NotificationAttempt = {
      contactId: contact.id,
      method: 'email',
      status: 'pending',
      timestamp: new Date()
    };

    try {
      const emailContent = this.generateEmailContent(alert, contact);
      
      console.log(`[Emergency Email] Emailing ${contact.name} at ${contact.email}`);
      console.log(`[Email Subject] ${emailContent.subject}`);

      // Simulate email sending
      attempt.status = 'sent';
      
      // Log the attempt
      const alertData = this.activeAlerts.get(alertId);
      if (alertData) {
        alertData.attempts.push(attempt);
      }

      // In real implementation:
      // await emailService.sendEmail({
      //   to: contact.email,
      //   subject: emailContent.subject,
      //   html: emailContent.html
      // });

    } catch (error) {
      console.error(`Emergency email failed for ${contact.name}:`, error);
      attempt.status = 'failed';
    }
  }

  private generateCallMessage(alert: EmergencyAlert, contact: EmergencyContact): string {
    const severity = alert.severity.toUpperCase();
    const location = alert.location 
      ? `Location: ${alert.location.address || `${alert.location.lat}, ${alert.location.lng}`}` 
      : '';

    return `EMERGENCY ALERT for ${alert.patientName}. ${severity} priority. ${alert.description}. ${location}. Please respond immediately by pressing 1 or calling Care Companion emergency line.`;
  }

  private generateSMSMessage(alert: EmergencyAlert, contact: EmergencyContact, urgencyLevel: string): string {
    const urgencyPrefix = urgencyLevel === 'escalated' ? '🚨 ESCALATED ALERT' : '⚠️ EMERGENCY ALERT';
    const location = alert.location 
      ? `\nLocation: ${alert.location.address || `${alert.location.lat}, ${alert.location.lng}`}` 
      : '';
    const vitals = alert.vitalSigns 
      ? `\nVitals: HR:${alert.vitalSigns.heartRate} BP:${alert.vitalSigns.bloodPressure} O2:${alert.vitalSigns.oxygenSaturation}%` 
      : '';

    return `${urgencyPrefix}\n\nPatient: ${alert.patientName}\nType: ${alert.alertType.replace('_', ' ').toUpperCase()}\nDetails: ${alert.description}${location}${vitals}\n\nRespond immediately: Reply ACK to acknowledge\nCall Care Companion: 1-800-CARE-AI`;
  }

  private generateEmailContent(alert: EmergencyAlert, contact: EmergencyContact) {
    const subject = `🚨 EMERGENCY ALERT - ${alert.patientName} - ${alert.severity.toUpperCase()} Priority`;
    
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #dc2626; color: white; padding: 20px; text-align: center;">
          <h1>🚨 EMERGENCY ALERT</h1>
          <p style="font-size: 18px; margin: 0;">Immediate Attention Required</p>
        </div>
        
        <div style="padding: 20px; background: #f9f9f9;">
          <h2>Alert Details</h2>
          <table style="width: 100%; border-collapse: collapse;">
            <tr><td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Patient:</strong></td><td style="padding: 8px; border-bottom: 1px solid #ddd;">${alert.patientName}</td></tr>
            <tr><td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Alert Type:</strong></td><td style="padding: 8px; border-bottom: 1px solid #ddd;">${alert.alertType.replace('_', ' ').toUpperCase()}</td></tr>
            <tr><td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Severity:</strong></td><td style="padding: 8px; border-bottom: 1px solid #ddd;">${alert.severity.toUpperCase()}</td></tr>
            <tr><td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Time:</strong></td><td style="padding: 8px; border-bottom: 1px solid #ddd;">${alert.timestamp.toLocaleString()}</td></tr>
            <tr><td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Description:</strong></td><td style="padding: 8px; border-bottom: 1px solid #ddd;">${alert.description}</td></tr>
          </table>
          
          ${alert.location ? `
          <h3>Location Information</h3>
          <p><strong>Coordinates:</strong> ${alert.location.lat}, ${alert.location.lng}</p>
          ${alert.location.address ? `<p><strong>Address:</strong> ${alert.location.address}</p>` : ''}
          ` : ''}
          
          ${alert.vitalSigns ? `
          <h3>Vital Signs</h3>
          <table style="width: 100%; border-collapse: collapse;">
            ${alert.vitalSigns.heartRate ? `<tr><td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Heart Rate:</strong></td><td style="padding: 8px; border-bottom: 1px solid #ddd;">${alert.vitalSigns.heartRate} bpm</td></tr>` : ''}
            ${alert.vitalSigns.bloodPressure ? `<tr><td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Blood Pressure:</strong></td><td style="padding: 8px; border-bottom: 1px solid #ddd;">${alert.vitalSigns.bloodPressure}</td></tr>` : ''}
            ${alert.vitalSigns.oxygenSaturation ? `<tr><td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Oxygen Saturation:</strong></td><td style="padding: 8px; border-bottom: 1px solid #ddd;">${alert.vitalSigns.oxygenSaturation}%</td></tr>` : ''}
            ${alert.vitalSigns.temperature ? `<tr><td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Temperature:</strong></td><td style="padding: 8px; border-bottom: 1px solid #ddd;">${alert.vitalSigns.temperature}°F</td></tr>` : ''}
          </table>
          ` : ''}
        </div>
        
        <div style="padding: 20px; background: #dc2626; color: white; text-align: center;">
          <h3>IMMEDIATE ACTION REQUIRED</h3>
          <p>1. Call <strong>1-800-CARE-AI</strong> to acknowledge this alert</p>
          <p>2. Check on ${alert.patientName} immediately</p>
          <p>3. Contact emergency services if needed: <strong>911</strong></p>
        </div>
      </div>
    `;

    return { subject, html };
  }

  private async waitForAcknowledgment(alertId: string, timeoutMs: number): Promise<boolean> {
    return new Promise((resolve) => {
      const startTime = Date.now();
      
      const checkAcknowledgment = () => {
        const alertData = this.activeAlerts.get(alertId);
        
        if (alertData?.acknowledgedBy) {
          resolve(true);
          return;
        }
        
        if (Date.now() - startTime >= timeoutMs) {
          resolve(false);
          return;
        }
        
        setTimeout(checkAcknowledgment, 1000); // Check every second
      };
      
      checkAcknowledgment();
    });
  }

  private async continuousRetryUntilAcknowledged(
    alertId: string, 
    contacts: EmergencyContact[], 
    alert: EmergencyAlert
  ): Promise<void> {
    const maxRetries = 10; // Maximum 10 retry cycles
    let retryCount = 0;

    while (retryCount < maxRetries) {
      const alertData = this.activeAlerts.get(alertId);
      if (alertData?.acknowledgedBy) {
        break; // Alert acknowledged, stop retrying
      }

      retryCount++;
      console.log(`[Emergency Retry] Attempt ${retryCount} for alert ${alertId}`);

      // Increase urgency with each retry
      const urgencyLevel = retryCount > 3 ? 'escalated' : 'urgent';

      // Contact all available contacts
      for (const contact of contacts) {
        await this.attemptContactNotification(alertId, contact, alert, urgencyLevel);
        await this.delay(10000); // 10 seconds between contacts
      }

      // Wait longer between retry cycles
      await this.delay(60000); // 1 minute between retry cycles
    }

    if (retryCount >= maxRetries) {
      console.error(`[Emergency Alert] Maximum retries reached for alert ${alertId}. Manual intervention required.`);
      // In production, this would trigger additional escalation procedures
    }
  }

  async acknowledgeAlert(alertId: string, acknowledgedBy: number): Promise<boolean> {
    const alertData = this.activeAlerts.get(alertId);
    if (!alertData) {
      return false;
    }

    alertData.acknowledgedBy = acknowledgedBy;
    
    // Update database
    await this.updateEmergencyEventAcknowledgment(alertData.alert, acknowledgedBy);
    
    console.log(`[Emergency Alert] Alert ${alertId} acknowledged by user ${acknowledgedBy}`);
    
    // Clean up active alert after 5 minutes
    setTimeout(() => {
      this.activeAlerts.delete(alertId);
    }, 300000);

    return true;
  }

  private async createEmergencyEvent(alert: EmergencyAlert): Promise<void> {
    try {
      await db.insert(emergencyEvents).values({
        patientId: alert.patientId,
        eventType: alert.alertType,
        severity: alert.severity,
        description: alert.description,
        status: 'active',
        location: alert.location ? JSON.stringify(alert.location) : null,
        vitalSignsSnapshot: alert.vitalSigns ? JSON.stringify(alert.vitalSigns) : null,
        notificationsSent: [],
        responseTime: null
      });
    } catch (error) {
      console.error('Failed to create emergency event:', error);
    }
  }

  private async updateEmergencyEventAcknowledgment(alert: EmergencyAlert, acknowledgedBy: number): Promise<void> {
    try {
      // Update the most recent emergency event for this patient and alert type
      await db.update(emergencyEvents)
        .set({
          status: 'acknowledged',
          acknowledgedBy,
          acknowledgedAt: new Date(),
          responseTime: Date.now() - alert.timestamp.getTime()
        })
        .where(
          and(
            eq(emergencyEvents.patientId, alert.patientId),
            eq(emergencyEvents.eventType, alert.alertType),
            eq(emergencyEvents.status, 'active')
          )
        );
    } catch (error) {
      console.error('Failed to update emergency event acknowledgment:', error);
    }
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Public method to get active alerts for monitoring
  getActiveAlerts(): Array<{alertId: string, alert: EmergencyAlert, attempts: NotificationAttempt[], startTime: Date}> {
    return Array.from(this.activeAlerts.entries()).map(([alertId, data]) => ({
      alertId,
      ...data
    }));
  }
}

export const emergencyNotificationService = new EmergencyNotificationService();
export default emergencyNotificationService;