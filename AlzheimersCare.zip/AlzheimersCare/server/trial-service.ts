// Simple trial service for Stripe subscription management
export class TrialService {
  private trialUsers: Map<string, any> = new Map();

  createTrialUser(trialData: any): any {
    const trialUser = {
      id: Date.now().toString(),
      ...trialData,
      createdAt: new Date()
    };
    this.trialUsers.set(trialUser.customerId, trialUser);
    return trialUser;
  }

  updateTrialUserStatus(subscriptionId: string, status: string): void {
    for (const [customerId, user] of this.trialUsers) {
      if (user.subscriptionId === subscriptionId) {
        user.status = status;
        user.updatedAt = new Date();
        this.trialUsers.set(customerId, user);
        break;
      }
    }
  }

  getTrialUser(customerId: string): any {
    return this.trialUsers.get(customerId);
  }

  getAllTrialUsers(): any[] {
    return Array.from(this.trialUsers.values());
  }
}

export const trialService = new TrialService();