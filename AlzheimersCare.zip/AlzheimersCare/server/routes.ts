import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { dbManager } from "./core/database-manager";
import { asyncHandler, validateRequired, validatePatientId, NotFoundError } from "./core/error-manager";
import { AuthenticationMiddleware } from "./middleware/authentication";
import { RateLimitMiddleware } from "./middleware/rate-limiting";
import { CorsSecurityMiddleware } from "./middleware/cors-security";
import { db } from './db';
import { trialAnalytics } from '../shared/schema';
import { eq } from 'drizzle-orm';

/**
 * Streamlined routes with consolidated error handling and database operations
 * Maximum resilience and efficiency through centralized management
 */
export async function registerRoutes(app: Express): Promise<Server> {
  
  // Apply global security middleware
  app.use(CorsSecurityMiddleware.corsPolicy);
  app.use(CorsSecurityMiddleware.securityHeaders);
  app.use(CorsSecurityMiddleware.sanitizeInput);
  app.use(CorsSecurityMiddleware.validatePayload);
  app.use(RateLimitMiddleware.standardRateLimit);
  app.use(AuthenticationMiddleware.loadUser);
  app.use(AuthenticationMiddleware.auditAccess);
  
  // Healthcare Core Routes - Patient Management (PROTECTED)
  app.get('/api/patients/:id', 
    AuthenticationMiddleware.requireAuth,
    AuthenticationMiddleware.validatePatientAccess,
    RateLimitMiddleware.patientDataRateLimit,
    asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    const patient = await dbManager.getPatient(patientId);
    
    if (!patient) {
      throw new NotFoundError('Patient');
    }
    
    res.json({ success: true, patient });
  }));

  app.post('/api/patients', 
    AuthenticationMiddleware.requireAuth,
    AuthenticationMiddleware.requireRole(['admin', 'family']),
    RateLimitMiddleware.strictRateLimit,
    asyncHandler(async (req: Request, res: Response) => {
    validateRequired(req.body, ['firstName', 'lastName', 'dateOfBirth']);
    const patient = await dbManager.createPatient(req.body);
    res.status(201).json({ success: true, patient });
  }));

  // Vital Signs Management
  app.get('/api/patients/:id/vital-signs', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    const vitalSigns = await dbManager.getVitalSignsByPatient(patientId);
    res.json({ success: true, vitalSigns });
  }));

  app.post('/api/patients/:id/vital-signs', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    validateRequired(req.body, ['heartRate', 'bloodPressure', 'temperature']);
    
    const vitalSignsData = { ...req.body, patientId };
    const vitalSigns = await dbManager.createVitalSigns(vitalSignsData);
    res.status(201).json({ success: true, vitalSigns });
  }));

  app.get('/api/patients/:id/latest-vitals', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    const latestVitals = await dbManager.getLatestVitalSigns(patientId);
    res.json({ success: true, latestVitals });
  }));

  app.get('/api/emergency-alerts', asyncHandler(async (req: Request, res: Response) => {
    const patientId = req.query.patientId ? parseInt(req.query.patientId as string) : undefined;
    const alerts = await dbManager.getEmergencyAlerts(patientId);
    res.json({ success: true, alerts });
  }));

  // Medication Management
  app.get('/api/patients/:id/medications', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    const medications = await dbManager.getMedicationsByPatient(patientId);
    res.json({ success: true, medications });
  }));

  app.post('/api/patients/:id/medications', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    validateRequired(req.body, ['name', 'dosage', 'frequency']);
    
    const medicationData = { ...req.body, patientId };
    const medication = await dbManager.createMedication(medicationData);
    res.status(201).json({ success: true, medication });
  }));

  app.get('/api/patients/:id/medication-logs', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    const logs = await dbManager.getMedicationLogsByPatient(patientId);
    res.json({ success: true, logs });
  }));

  app.post('/api/patients/:id/medication-logs', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    validateRequired(req.body, ['medicationId', 'status']);
    
    const logData = { ...req.body, patientId };
    const log = await dbManager.createMedicationLog(logData);
    res.status(201).json({ success: true, log });
  }));

  app.get('/api/patients/:id/missed-medications', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    const missedMeds = await dbManager.getMissedMedications(patientId);
    res.json({ success: true, missedMedications: missedMeds });
  }));

  // Cognitive Activities and Progress
  app.get('/api/patients/:id/cognitive-activities', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    const activities = await dbManager.getCognitiveActivitiesByPatient(patientId);
    res.json({ success: true, activities });
  }));

  app.post('/api/patients/:id/cognitive-activities', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    validateRequired(req.body, ['activityType', 'difficulty']);
    
    const activityData = { ...req.body, patientId };
    const activity = await dbManager.createCognitiveActivity(activityData);
    res.status(201).json({ success: true, activity });
  }));

  app.get('/api/patients/:id/cognitive-progress', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    const progress = await dbManager.getCognitiveProgressByPatient(patientId);
    res.json({ success: true, progress });
  }));

  app.post('/api/patients/:id/cognitive-progress', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    validateRequired(req.body, ['assessmentDate']);
    
    const progressData = { ...req.body, patientId };
    const progress = await dbManager.createCognitiveProgress(progressData);
    res.status(201).json({ success: true, progress });
  }));

  app.get('/api/patients/:id/latest-cognitive-progress', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    const latestProgress = await dbManager.getLatestCognitiveProgress(patientId);
    res.json({ success: true, latestProgress });
  }));

  // Emergency Event Management
  app.get('/api/patients/:id/emergency-events', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    const events = await dbManager.getEmergencyEventsByPatient(patientId);
    res.json({ success: true, events });
  }));

  app.post('/api/patients/:id/emergency-events', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    validateRequired(req.body, ['eventType', 'severity']);
    
    const eventData = { ...req.body, patientId, status: 'active' };
    const event = await dbManager.createEmergencyEvent(eventData);
    res.status(201).json({ success: true, event });
  }));

  app.get('/api/active-emergencies', asyncHandler(async (req: Request, res: Response) => {
    const facilityId = req.query.facilityId ? parseInt(req.query.facilityId as string) : undefined;
    const emergencies = await dbManager.getActiveEmergencies(facilityId);
    res.json({ success: true, emergencies });
  }));

  app.patch('/api/emergency-events/:id/acknowledge', asyncHandler(async (req: Request, res: Response) => {
    const eventId = parseInt(req.params.id);
    const userId = req.body.userId || 1;
    
    const event = await dbManager.acknowledgeEmergency(eventId, userId);
    res.json({ success: true, event });
  }));

  app.patch('/api/emergency-events/:id/resolve', asyncHandler(async (req: Request, res: Response) => {
    const eventId = parseInt(req.params.id);
    const event = await dbManager.resolveEmergency(eventId);
    res.json({ success: true, event });
  }));

  // Family and Memory Management
  app.get('/api/patients/:id/family-relationships', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    const relationships = await dbManager.getFamilyRelationshipsByPatient(patientId);
    res.json({ success: true, relationships });
  }));

  app.post('/api/patients/:id/family-relationships', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    validateRequired(req.body, ['familyMemberId', 'relationshipType']);
    
    const relationshipData = { ...req.body, patientId };
    const relationship = await dbManager.createFamilyRelationship(relationshipData);
    res.status(201).json({ success: true, relationship });
  }));

  app.get('/api/patients/:id/family-memories', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    const memories = await dbManager.getFamilyMemoriesByPatient(patientId);
    res.json({ success: true, memories });
  }));

  app.post('/api/patients/:id/family-memories', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    validateRequired(req.body, ['title', 'description']);
    
    const memoryData = { ...req.body, patientId };
    const memory = await dbManager.createFamilyMemory(memoryData);
    res.status(201).json({ success: true, memory });
  }));

  app.get('/api/family-memories/:id', asyncHandler(async (req: Request, res: Response) => {
    const memoryId = parseInt(req.params.id);
    const memory = await dbManager.getFamilyMemory(memoryId);
    
    if (!memory) {
      throw new NotFoundError('Family memory');
    }
    
    res.json({ success: true, memory });
  }));

  // Gaming Activities
  app.get('/api/patients/:id/game-activities', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    const games = await dbManager.getGameActivitiesByPatient(patientId);
    res.json({ success: true, games });
  }));

  app.post('/api/patients/:id/game-activities', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    validateRequired(req.body, ['gameType', 'difficulty']);
    
    const gameData = { ...req.body, patientId, status: 'active' };
    const game = await dbManager.createGameActivity(gameData);
    res.status(201).json({ success: true, game });
  }));

  app.patch('/api/game-activities/:id', asyncHandler(async (req: Request, res: Response) => {
    const gameId = parseInt(req.params.id);
    const game = await dbManager.updateGameActivity(gameId, req.body);
    res.json({ success: true, game });
  }));

  app.get('/api/patients/:id/active-games', asyncHandler(async (req: Request, res: Response) => {
    const patientId = validatePatientId(req.params.id);
    const activeGames = await dbManager.getActiveGames(patientId);
    res.json({ success: true, activeGames });
  }));

  // User and Facility Management
  app.get('/api/users/:id', asyncHandler(async (req: Request, res: Response) => {
    const userId = parseInt(req.params.id);
    const user = await dbManager.getUser(userId);
    
    if (!user) {
      throw new NotFoundError('User');
    }
    
    res.json({ success: true, user });
  }));

  app.post('/api/users', asyncHandler(async (req: Request, res: Response) => {
    validateRequired(req.body, ['email', 'firstName', 'lastName', 'userType']);
    const user = await dbManager.createUser(req.body);
    res.status(201).json({ success: true, user });
  }));

  app.get('/api/users', asyncHandler(async (req: Request, res: Response) => {
    const userType = req.query.type as string;
    if (userType) {
      const users = await dbManager.getUsersByType(userType);
      res.json({ success: true, users });
    } else {
      res.status(400).json({ success: false, error: 'User type required' });
    }
  }));

  app.get('/api/facilities', asyncHandler(async (req: Request, res: Response) => {
    const facilities = await dbManager.getFacilities();
    res.json({ success: true, facilities });
  }));

  app.post('/api/facilities', asyncHandler(async (req: Request, res: Response) => {
    validateRequired(req.body, ['name', 'address']);
    const facility = await dbManager.createFacility(req.body);
    res.status(201).json({ success: true, facility });
  }));

  app.get('/api/facilities/:id', asyncHandler(async (req: Request, res: Response) => {
    const facilityId = parseInt(req.params.id);
    const facility = await dbManager.getFacility(facilityId);
    
    if (!facility) {
      throw new NotFoundError('Facility');
    }
    
    res.json({ success: true, facility });
  }));

  app.get('/api/facilities/:id/patients', asyncHandler(async (req: Request, res: Response) => {
    const facilityId = parseInt(req.params.id);
    const patients = await dbManager.getPatientsByFacility(facilityId);
    res.json({ success: true, patients });
  }));

  // Subscription Management
  app.patch('/api/users/:id/subscription', asyncHandler(async (req: Request, res: Response) => {
    const userId = parseInt(req.params.id);
    const user = await dbManager.updateUserSubscription(userId, req.body);
    res.json({ success: true, user });
  }));

  app.get('/api/users/:id/subscription-status', asyncHandler(async (req: Request, res: Response) => {
    const userId = parseInt(req.params.id);
    const user = await dbManager.getUserSubscriptionStatus(userId);
    
    if (!user) {
      throw new NotFoundError('User');
    }
    
    res.json({ 
      success: true, 
      subscriptionStatus: {
        status: user.subscriptionStatus,
        trialEndsAt: user.trialEndDate,
        subscriptionId: user.subscriptionId
      }
    });
  }));

  app.get('/api/expired-trials', asyncHandler(async (req: Request, res: Response) => {
    const expiredUsers = await dbManager.getExpiredTrials();
    res.json({ success: true, expiredUsers });
  }));

  // Square Payment Integration
  app.post('/api/square/test-connection', asyncHandler(async (req: Request, res: Response) => {
    // Simple connectivity test
    res.json({ success: true, message: 'Square API connection active' });
  }));

  app.post('/api/square/create-customer', asyncHandler(async (req: Request, res: Response) => {
    validateRequired(req.body, ['email', 'firstName', 'lastName']);
    
    // Mock Square customer creation for now
    const customerId = `cust_${Date.now()}`;
    res.json({ 
      success: true, 
      customer: { id: customerId }
    });
  }));

  // Square Pay trial subscription routes
  app.post('/api/subscription/create-trial', asyncHandler(async (req: Request, res: Response) => {
    try {
      const { firstName, lastName, email, phone, trialDays = 14, subscriptionAmount = 4999 } = req.body;
      
      validateRequired(req.body, ['firstName', 'lastName', 'email']);
      
      if (!process.env.SQUARE_ACCESS_TOKEN) {
        return res.status(503).json({ error: 'Square Pay service not configured' });
      }

      // Import Square client
      const { Client, Environment } = require('squareup');
      const client = new Client({
        accessToken: process.env.SQUARE_ACCESS_TOKEN,
        environment: process.env.NODE_ENV === 'production' ? Environment.Production : Environment.Sandbox,
      });

      const { customersApi, subscriptionsApi } = client;

      // Create Square customer
      const customerRequest = {
        givenName: firstName,
        familyName: lastName,
        emailAddress: email,
        phoneNumber: phone,
        note: `Care Companion trial customer - ${trialDays} day trial`
      };

      const { result: customerResult } = await customersApi.createCustomer(customerRequest);
      const customer = customerResult.customer;

      // Create subscription with trial period
      const subscriptionRequest = {
        locationId: process.env.SQUARE_LOCATION_ID,
        planId: process.env.SQUARE_PLAN_ID || 'care-companion-monthly',
        customerId: customer.id,
        startDate: new Date().toISOString().split('T')[0],
        taxPercentage: '0',
        priceOverrideMoney: {
          amount: BigInt(subscriptionAmount),
          currency: 'USD'
        },
        cardId: null, // Will be set when customer provides payment method
        timezone: 'America/New_York',
        source: {
          name: 'Care Companion Trial'
        }
      };

      const { result: subscriptionResult } = await subscriptionsApi.createSubscription(subscriptionRequest);
      const subscription = subscriptionResult.subscription;

      // Store trial user data
      const trialRecord = {
        customerId: customer.id,
        subscriptionId: subscription.id,
        email,
        firstName,
        lastName,
        phone,
        trialStartDate: new Date(),
        trialEndDate: new Date(Date.now() + trialDays * 24 * 60 * 60 * 1000),
        subscriptionAmount,
        status: 'trial_active',
        paymentProvider: 'square'
      };

      console.log('Square trial subscription created:', trialRecord);

      res.json({
        success: true,
        customerId: customer.id,
        subscriptionId: subscription.id,
        trialEndDate: trialRecord.trialEndDate,
        message: 'Square Pay trial subscription created successfully',
        paymentProvider: 'square'
      });

    } catch (error: any) {
      console.error('Square trial subscription creation error:', error);
      res.status(500).json({ 
        error: 'Failed to create Square trial subscription',
        message: error.message 
      });
    }
  }));

  app.post('/api/subscription/cancel-trial', asyncHandler(async (req: Request, res: Response) => {
    try {
      const { subscriptionId } = req.body;
      
      validateRequired(req.body, ['subscriptionId']);
      
      if (!process.env.STRIPE_SECRET_KEY) {
        return res.status(503).json({ error: 'Payment service not configured' });
      }

      const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

      // Cancel the subscription immediately
      const canceledSubscription = await stripe.subscriptions.cancel(subscriptionId);

      // Update trial user status (simplified for now)
      console.log('Trial subscription canceled:', subscriptionId);

      res.json({
        success: true,
        message: 'Trial subscription canceled successfully',
        canceledAt: canceledSubscription.canceled_at
      });

    } catch (error: any) {
      console.error('Trial cancellation error:', error);
      res.status(500).json({ 
        error: 'Failed to cancel trial subscription',
        message: error.message 
      });
    }
  }));

  app.get('/api/subscription/trial-status/:customerId', asyncHandler(async (req: Request, res: Response) => {
    try {
      const { customerId } = req.params;
      
      if (!process.env.STRIPE_SECRET_KEY) {
        return res.status(503).json({ error: 'Payment service not configured' });
      }

      const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

      // Get customer's subscriptions
      const subscriptions = await stripe.subscriptions.list({
        customer: customerId,
        status: 'all',
        limit: 10
      });

      const activeSubscription = subscriptions.data.find((sub: any) => 
        sub.status === 'trialing' || sub.status === 'active'
      );

      if (!activeSubscription) {
        return res.json({
          hasActiveTrial: false,
          status: 'no_subscription'
        });
      }

      const isTrialing = activeSubscription.status === 'trialing';
      const trialEnd = activeSubscription.trial_end ? new Date(activeSubscription.trial_end * 1000) : null;
      const daysRemaining = trialEnd ? Math.ceil((trialEnd.getTime() - Date.now()) / (1000 * 60 * 60 * 24)) : 0;

      res.json({
        hasActiveTrial: isTrialing,
        status: activeSubscription.status,
        subscriptionId: activeSubscription.id,
        trialEndDate: trialEnd,
        daysRemaining: Math.max(0, daysRemaining),
        currentPeriodEnd: new Date(activeSubscription.current_period_end * 1000)
      });

    } catch (error: any) {
      console.error('Trial status check error:', error);
      res.status(500).json({ 
        error: 'Failed to check trial status',
        message: error.message 
      });
    }
  }));

  app.get('/api/square/subscription-plans', asyncHandler(async (req: Request, res: Response) => {
    const plans = [
      {
        id: 'care_companion_monthly',
        name: 'Care Companion Monthly',
        price: 49.99,
        currency: 'USD',
        intervalUnit: 'MONTH',
        intervalCount: 1,
        trialPeriodDays: 14
      }
    ];
    res.json({ success: true, plans });
  }));

  // Translation Services
  app.post('/api/translate', asyncHandler(async (req: Request, res: Response) => {
    validateRequired(req.body, ['text', 'targetLanguage']);
    
    // Mock translation for now - would integrate with actual service
    const translation = {
      originalText: req.body.text,
      translatedText: `[${req.body.targetLanguage}] ${req.body.text}`,
      sourceLanguage: req.body.sourceLanguage || 'auto',
      targetLanguage: req.body.targetLanguage,
      confidence: 0.95
    };
    
    res.json({ success: true, translation });
  }));

  app.get('/api/supported-languages', asyncHandler(async (req: Request, res: Response) => {
    const languages = [
      { code: 'en', name: 'English' },
      { code: 'es', name: 'Spanish' },
      { code: 'fr', name: 'French' },
      { code: 'de', name: 'German' },
      { code: 'it', name: 'Italian' },
      { code: 'pt', name: 'Portuguese' },
      { code: 'ru', name: 'Russian' },
      { code: 'zh', name: 'Chinese' },
      { code: 'ja', name: 'Japanese' },
      { code: 'ko', name: 'Korean' },
      { code: 'ar', name: 'Arabic' },
      { code: 'hi', name: 'Hindi' }
    ];
    res.json({ success: true, languages });
  }));

  // Health check endpoint
  app.get('/api/health', asyncHandler(async (req: Request, res: Response) => {
    const dbHealthy = await dbManager.healthCheck();
    
    res.json({
      success: true,
      status: dbHealthy ? 'healthy' : 'degraded',
      services: {
        database: dbHealthy ? 'connected' : 'disconnected',
        server: 'running'
      },
      timestamp: new Date().toISOString()
    });
  }));

  // AI Support Chat Routes
  app.post('/api/ai-support/chat', asyncHandler(async (req: Request, res: Response) => {
    const { message, chatHistory, userContext } = req.body;

    if (!message) {
      return res.status(400).json({ success: false, message: 'Message is required' });
    }

    try {
      const { generateAISupportResponse } = await import('./services/ai-support');
      const aiResponse = await generateAISupportResponse(message, chatHistory, userContext);
      
      // Log the support interaction
      console.log('[AI Support]', {
        userEmail: userContext?.email,
        message: message.substring(0, 100),
        category: aiResponse.category,
        timestamp: new Date().toISOString()
      });

      res.json({
        success: true,
        response: aiResponse.content,
        category: aiResponse.category,
        followUpActions: aiResponse.followUpActions
      });
    } catch (error) {
      console.error('AI Support Error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to generate AI response'
      });
    }
  }));

  // Square Pay Trial Customer Creation
  app.post('/api/square/create-trial-customer', asyncHandler(async (req: Request, res: Response) => {
    const { firstName, lastName, email, phone, trialDays = 14, subscriptionAmount = 4999 } = req.body;

    if (!firstName || !lastName || !email || !phone) {
      return res.status(400).json({ success: false, message: 'Missing required fields' });
    }

    try {
      // Check if user already has an active trial using analytics table
      const [existingTrial] = await db
        .select()
        .from(trialAnalytics)
        .where(eq(trialAnalytics.email, email))
        .limit(1);

      if (existingTrial) {
        return res.status(400).json({
          success: false,
          message: 'This email has already been used for a trial. Please contact support for assistance.'
        });
      }

      // Create trial analytics record
      const trialEndDate = new Date();
      trialEndDate.setDate(trialEndDate.getDate() + trialDays);

      const [trialRecord] = await db
        .insert(trialAnalytics)
        .values({
          email,
          firstName,
          lastName,
          phoneNumber: phone,
          trialStartDate: new Date(),
          trialEndDate,
          subscriptionAmount,
          trialStatus: 'active',
          convertedToSubscription: false,
          referralSource: req.headers.referer || 'direct',
          ipAddress: req.ip || '',
          userAgent: req.headers['user-agent'] || '',
          country: 'US', // Default, could be enhanced with IP geolocation
          city: 'Unknown'
        })
        .returning();

      console.log('Trial user created successfully:', trialRecord);

      res.json({
        success: true,
        message: 'Trial started successfully',
        trialUser: {
          id: trialRecord.id,
          email: trialRecord.email,
          trialEndDate: trialRecord.trialEndDate,
          trialStatus: trialRecord.trialStatus
        }
      });
    } catch (error) {
      console.error('Square Trial Creation Error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to create trial account'
      });
    }
  }));

  // Trial User Management Routes
  app.post('/api/trial/start', asyncHandler(async (req: Request, res: Response) => {
    const { email, firstName, lastName, phoneNumber, paymentMethodId, ipAddress, userAgent } = req.body;

    if (!email || !firstName || !lastName || !paymentMethodId) {
      return res.status(400).json({ success: false, message: 'Missing required fields' });
    }

    try {
      // Check if user already has an active trial
      const existingTrial = await db.select()
        .from(trialUsers)
        .where(eq(trialUsers.email, email))
        .limit(1);

      if (existingTrial.length > 0 && existingTrial[0].hasUsedTrial) {
        return res.status(400).json({
          success: false,
          message: 'This email has already been used for a trial. Please contact support for assistance.'
        });
      }

      // Create trial user
      const trialEndDate = new Date();
      trialEndDate.setDate(trialEndDate.getDate() + 14); // 14-day trial

      const [trialUser] = await db.insert(trialUsers)
        .values({
          email,
          firstName,
          lastName,
          phoneNumber,
          ipAddress: ipAddress || 'unknown',
          userAgent,
          trialEndDate,
          paymentMethodId,
          subscriptionStatus: 'trial',
          hasUsedTrial: true
        })
        .returning();

      // Store payment method
      await db.insert(paymentMethods)
        .values({
          trialUserId: trialUser.id,
          stripePaymentMethodId: paymentMethodId,
          isDefault: true
        });

      // Log billing event
      await db.insert(billingEvents)
        .values({
          trialUserId: trialUser.id,
          eventType: 'trial_start',
          description: `Trial started for ${email}`,
          metadata: { trialEndDate: trialEndDate.toISOString() }
        });

      res.json({
        success: true,
        message: 'Trial started successfully',
        trialUser: {
          id: trialUser.id,
          email: trialUser.email,
          trialEndDate: trialUser.trialEndDate
        }
      });
    } catch (error) {
      console.error('Trial Start Error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to start trial'
      });
    }
  }));

  // Get trial users for admin
  app.get('/api/admin/trial-users', asyncHandler(async (req: Request, res: Response) => {
    try {
      const users = await db.select()
        .from(trialUsers)
        .orderBy(desc(trialUsers.createdAt))
        .limit(100);

      res.json({
        success: true,
        users
      });
    } catch (error) {
      console.error('Get Trial Users Error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to retrieve trial users'
      });
    }
  }));

  // Location Tracking Routes
  app.post('/api/patients/location', asyncHandler(async (req: Request, res: Response) => {
    const { patientId, location, familyMemberId } = req.body;

    if (!patientId || !location || !location.lat || !location.lng) {
      return res.status(400).json({ success: false, message: 'Missing required location data' });
    }

    try {
      const [savedLocation] = await db.insert(patientLocations)
        .values({
          patientId,
          latitude: location.lat.toString(),
          longitude: location.lng.toString(),
          accuracy: location.accuracy ? location.accuracy.toString() : null,
          source: location.source || 'gps',
          familyMemberId,
          timestamp: new Date(location.timestamp || Date.now())
        })
        .returning();

      res.json({
        success: true,
        location: savedLocation
      });
    } catch (error) {
      console.error('Save Location Error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to save location'
      });
    }
  }));

  // Geofence Settings Routes
  app.put('/api/patients/:id/geofence', asyncHandler(async (req: Request, res: Response) => {
    const patientId = parseInt(req.params.id);
    const { centerLat, centerLng, radius, enabled, alertContacts, emergencyContacts, familyMemberId } = req.body;

    if (!patientId || !centerLat || !centerLng || !radius) {
      return res.status(400).json({ success: false, message: 'Missing required geofence data' });
    }

    try {
      // Check if geofence settings exist
      const existing = await db.select()
        .from(geofenceSettings)
        .where(eq(geofenceSettings.patientId, patientId))
        .limit(1);

      let result;
      if (existing.length > 0) {
        // Update existing
        [result] = await db.update(geofenceSettings)
          .set({
            centerLatitude: centerLat.toString(),
            centerLongitude: centerLng.toString(),
            radius,
            enabled,
            alertContacts,
            emergencyContacts,
            familyMemberId,
            updatedAt: new Date()
          })
          .where(eq(geofenceSettings.patientId, patientId))
          .returning();
      } else {
        // Create new
        [result] = await db.insert(geofenceSettings)
          .values({
            patientId,
            centerLatitude: centerLat.toString(),
            centerLongitude: centerLng.toString(),
            radius,
            enabled,
            alertContacts,
            emergencyContacts,
            familyMemberId
          })
          .returning();
      }

      res.json({
        success: true,
        geofence: result
      });
    } catch (error) {
      console.error('Save Geofence Error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to save geofence settings'
      });
    }
  }));

  // Geofence Violation Routes
  app.post('/api/geofence/violation', asyncHandler(async (req: Request, res: Response) => {
    const { patientId, location, geofenceCenter, radius, distance, familyMemberId } = req.body;

    try {
      // Save location first
      const [savedLocation] = await db.insert(patientLocations)
        .values({
          patientId,
          latitude: location.lat.toString(),
          longitude: location.lng.toString(),
          accuracy: location.accuracy ? location.accuracy.toString() : null,
          source: location.source || 'gps',
          familyMemberId
        })
        .returning();

      // Get geofence settings
      const [geofence] = await db.select()
        .from(geofenceSettings)
        .where(eq(geofenceSettings.patientId, patientId))
        .limit(1);

      // Create violation record
      const [violation] = await db.insert(geofenceViolations)
        .values({
          patientId,
          locationId: savedLocation.id,
          geofenceId: geofence?.id,
          distance: distance.toString()
        })
        .returning();

      res.json({
        success: true,
        violation,
        location: savedLocation
      });
    } catch (error) {
      console.error('Geofence Violation Error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to record geofence violation'
      });
    }
  }));

  // Emergency Notification Routes
  app.post('/api/emergency/notify', asyncHandler(async (req: Request, res: Response) => {
    const { patientId, type, contacts, location, distance } = req.body;

    try {
      // Log emergency notification
      console.log('[Emergency Notification]', {
        patientId,
        type,
        contactCount: contacts?.length || 0,
        location: location ? `${location.lat}, ${location.lng}` : 'unknown',
        distance: distance || 'unknown',
        timestamp: new Date().toISOString()
      });

      // In a real implementation, this would:
      // 1. Send SMS/email notifications to emergency contacts
      // 2. Create emergency event record
      // 3. Potentially contact emergency services if configured
      // 4. Send push notifications to family member apps

      res.json({
        success: true,
        message: 'Emergency notifications sent',
        notificationsSent: contacts?.length || 0
      });
    } catch (error) {
      console.error('Emergency Notification Error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to send emergency notifications'
      });
    }
  }));

  // Emergency Alert Routes with Continuous Retry
  app.post('/api/emergency/trigger-alert', asyncHandler(async (req: Request, res: Response) => {
    const { patientId, alertType, severity, description, location, vitalSigns } = req.body;

    if (!patientId || !alertType || !severity) {
      return res.status(400).json({ success: false, message: 'Missing required alert data' });
    }

    try {
      const { emergencyNotificationService } = await import('./services/emergency-notification');
      
      const alert = {
        patientId,
        patientName: 'Patient Name', // In real app, fetch from database
        alertType,
        severity,
        description,
        location,
        vitalSigns,
        timestamp: new Date()
      };

      await emergencyNotificationService.triggerEmergencyAlert(alert);

      res.json({
        success: true,
        message: 'Emergency alert triggered and notifications started'
      });
    } catch (error) {
      console.error('Emergency Alert Trigger Error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to trigger emergency alert'
      });
    }
  }));

  // Acknowledge Emergency Alert
  app.post('/api/emergency/acknowledge/:alertId', asyncHandler(async (req: Request, res: Response) => {
    const { alertId } = req.params;
    const { acknowledgedBy } = req.body;

    if (!acknowledgedBy) {
      return res.status(400).json({ success: false, message: 'acknowledgedBy is required' });
    }

    try {
      const { emergencyNotificationService } = await import('./services/emergency-notification');
      
      const acknowledged = await emergencyNotificationService.acknowledgeAlert(alertId, acknowledgedBy);

      if (acknowledged) {
        res.json({
          success: true,
          message: 'Emergency alert acknowledged successfully'
        });
      } else {
        res.status(404).json({
          success: false,
          message: 'Alert not found or already acknowledged'
        });
      }
    } catch (error) {
      console.error('Emergency Acknowledgment Error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to acknowledge emergency alert'
      });
    }
  }));

  // Get Active Emergency Alerts
  app.get('/api/emergency/active-alerts', asyncHandler(async (req: Request, res: Response) => {
    try {
      const { emergencyNotificationService } = await import('./services/emergency-notification');
      
      const activeAlerts = emergencyNotificationService.getActiveAlerts();

      res.json({
        success: true,
        alerts: activeAlerts
      });
    } catch (error) {
      console.error('Get Active Alerts Error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to retrieve active alerts'
      });
    }
  }));

  // Premium Feature Management
  app.get('/api/users/:id/premium-features', asyncHandler(async (req: Request, res: Response) => {
    const userId = parseInt(req.params.id);

    try {
      const features = await db.select()
        .from(premiumFeatures)
        .where(eq(premiumFeatures.userId, userId));

      res.json({
        success: true,
        features
      });
    } catch (error) {
      console.error('Get Premium Features Error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to retrieve premium features'
      });
    }
  }));

  // Insurance Application Routes
  app.post('/api/insurance/submit-application', asyncHandler(async (req: Request, res: Response) => {
    const { formData, estimatedCoverage, submissionDate } = req.body;

    if (!formData || !formData.firstName || !formData.lastName || !formData.insuranceCarrier) {
      return res.status(400).json({ success: false, message: 'Missing required form data' });
    }

    try {
      // Store insurance application
      const applicationData = {
        ...formData,
        estimatedCoverage,
        submissionDate,
        status: 'submitted',
        applicationId: `INS-${Date.now()}`,
        createdAt: new Date()
      };

      // Log application submission
      console.log('[Insurance Application]', {
        applicationId: applicationData.applicationId,
        patientName: `${formData.firstName} ${formData.lastName}`,
        insuranceType: formData.insuranceType,
        carrier: formData.insuranceCarrier,
        estimatedCoverage,
        timestamp: submissionDate
      });

      // In a real implementation, this would:
      // 1. Store in database
      // 2. Generate PDF application forms
      // 3. Send to insurance processing team
      // 4. Send confirmation email to user
      // 5. Create case in CRM system

      res.json({
        success: true,
        applicationId: applicationData.applicationId,
        message: 'Insurance application submitted successfully',
        estimatedProcessingTime: '5-7 business days'
      });
    } catch (error) {
      console.error('Insurance Application Error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to submit insurance application'
      });
    }
  }));

  // Insurance Verification Routes
  app.post('/api/insurance/verify-coverage', asyncHandler(async (req: Request, res: Response) => {
    const { insuranceType, carrier, policyNumber, diagnosis } = req.body;

    try {
      // Mock coverage verification logic
      let coveragePercentage = 0;
      let eligibleServices = [];

      switch (insuranceType) {
        case 'medicare':
          coveragePercentage = 85;
          eligibleServices = [
            'Remote Patient Monitoring (RPM)',
            'Chronic Care Management (CCM)',
            'Behavioral Health Integration (BHI)'
          ];
          break;
        case 'medicaid':
          coveragePercentage = 90;
          eligibleServices = [
            'Remote Patient Monitoring',
            'Personal Care Services',
            'Long-term Care Support'
          ];
          break;
        case 'private':
          coveragePercentage = 70;
          eligibleServices = [
            'Telehealth Services',
            'Chronic Disease Management',
            'Care Coordination'
          ];
          break;
        default:
          coveragePercentage = 60;
          eligibleServices = ['Basic Monitoring Services'];
      }

      const monthlyPrice = 49.99;
      const coveredAmount = monthlyPrice * (coveragePercentage / 100);
      const outOfPocket = monthlyPrice - coveredAmount;

      res.json({
        success: true,
        coverage: {
          percentage: coveragePercentage,
          monthlyPrice,
          coveredAmount: coveredAmount.toFixed(2),
          outOfPocket: outOfPocket.toFixed(2),
          eligibleServices,
          requiresPreAuth: insuranceType !== 'medicare',
          processingTime: insuranceType === 'medicare' ? '3-5 days' : '5-10 days'
        }
      });
    } catch (error) {
      console.error('Insurance Verification Error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to verify insurance coverage'
      });
    }
  }));

  // Mood Tracking and AI Companion Routes
  app.post('/api/mood/entry', 
    AuthenticationMiddleware.requireAuth,
    AuthenticationMiddleware.validatePatientAccess,
    RateLimitMiddleware.standardRateLimit,
    asyncHandler(async (req: Request, res: Response) => {
    const { moodCompanionService } = await import('./services/mood-companion');
    
    validateRequired(req.body, ['patientId', 'moodLevel', 'emotionalState']);
    
    // Create mood entry
    const moodEntry = await moodCompanionService.createMoodEntry(req.body);
    
    // Process AI companion response
    const companionResponse = await moodCompanionService.processCompanionResponse(
      moodEntry.patientId, 
      moodEntry.id
    );
    
    res.status(201).json({ 
      success: true, 
      moodEntry,
      companionResponse 
    });
  }));

  app.get('/api/mood/trends/:patientId', 
    AuthenticationMiddleware.requireAuth,
    AuthenticationMiddleware.validatePatientAccess,
    RateLimitMiddleware.standardRateLimit,
    asyncHandler(async (req: Request, res: Response) => {
    const { moodCompanionService } = await import('./services/mood-companion');
    
    const patientId = validatePatientId(req.params.patientId);
    const days = parseInt(req.query.days as string) || 7;
    
    const trends = await moodCompanionService.getMoodTrends(patientId, days);
    
    res.json({ success: true, trends });
  }));

  app.get('/api/mood/latest/:patientId', 
    AuthenticationMiddleware.requireAuth,
    AuthenticationMiddleware.validatePatientAccess,
    RateLimitMiddleware.standardRateLimit,
    asyncHandler(async (req: Request, res: Response) => {
    const { moodCompanionService } = await import('./services/mood-companion');
    
    const patientId = validatePatientId(req.params.patientId);
    const latestEntry = await moodCompanionService.getLatestMoodEntry(patientId);
    
    res.json({ success: true, latestEntry });
  }));

  app.get('/api/mood/responses/:moodEntryId', 
    AuthenticationMiddleware.requireAuth,
    RateLimitMiddleware.standardRateLimit,
    asyncHandler(async (req: Request, res: Response) => {
    const { moodCompanionService } = await import('./services/mood-companion');
    
    const moodEntryId = parseInt(req.params.moodEntryId);
    if (isNaN(moodEntryId)) {
      return res.status(400).json({ success: false, message: 'Invalid mood entry ID' });
    }
    
    const responses = await moodCompanionService.getCompanionResponses(moodEntryId);
    
    res.json({ success: true, responses });
  }));

  app.post('/api/mood/response/:responseId/delivered', 
    AuthenticationMiddleware.requireAuth,
    RateLimitMiddleware.standardRateLimit,
    asyncHandler(async (req: Request, res: Response) => {
    const { moodCompanionService } = await import('./services/mood-companion');
    
    const responseId = parseInt(req.params.responseId);
    const { reaction } = req.body;
    
    if (isNaN(responseId)) {
      return res.status(400).json({ success: false, message: 'Invalid response ID' });
    }
    
    const updatedResponse = await moodCompanionService.markResponseDelivered(responseId, reaction);
    
    res.json({ success: true, response: updatedResponse });
  }));

  // Voice Synthesis Routes with Error Handling
  app.post('/api/voice/synthesize', 
    RateLimitMiddleware.standardRateLimit,
    asyncHandler(async (req: Request, res: Response) => {
    try {
      const { text, options = {} } = req.body;
      
      if (!text || typeof text !== 'string') {
        return res.status(400).json({ 
          error: 'Text is required and must be a string',
          fallback: true 
        });
      }

      const { ElevenLabsService } = await import('./services/elevenlabs-service');
      const audioResponse = await ElevenLabsService.textToSpeech(text, options);
      
      res.set({
        'Content-Type': audioResponse.contentType,
        'Content-Length': audioResponse.audioBuffer.length.toString(),
        'X-Audio-Duration': audioResponse.duration?.toString() || '0',
      });
      
      res.send(audioResponse.audioBuffer);
    } catch (error) {
      console.warn('Voice synthesis error, suggesting browser fallback:', error);
      
      // Return fallback instruction instead of audio
      res.status(503).json({
        error: 'Voice synthesis temporarily unavailable',
        fallback: true,
        message: 'Using browser text-to-speech instead',
        text: req.body.text
      });
    }
  }));

  // Voice Status Endpoint
  app.get('/api/voice/status', asyncHandler(async (req: Request, res: Response) => {
    try {
      const { ElevenLabsService } = await import('./services/elevenlabs-service');
      const voices = await ElevenLabsService.getHealthcareVoices();
      
      res.json({
        available: true,
        provider: 'ElevenLabs',
        voices: voices.slice(0, 5),
        status: 'operational'
      });
    } catch (error) {
      res.json({
        available: false,
        provider: 'Browser Fallback',
        voices: [],
        status: 'fallback',
        reason: 'ElevenLabs API unavailable'
      });
    }
  }));

  const httpServer = createServer(app);
  return httpServer;
}