import { db } from './db';
import { storage } from './storage';
import { withDatabaseErrorHandling } from './error-handler';

export async function initializeDatabase() {
  try {
    console.log('Initializing database with test data...');
    
    // Create test facility
    const facility = await withDatabaseErrorHandling(() =>
      storage.createFacility({
        name: 'Sunrise Care Center',
        address: '123 Care Lane, Medical City, MC 12345',
        contactInfo: {
          phone: '555-0123',
          email: 'info@sunrisecare.com'
        }
      })
    );

    // Create test patient
    const patient = await withDatabaseErrorHandling(() =>
      storage.createPatient({
        firstName: 'Jeff',
        lastName: 'BYRR',
        dateOfBirth: new Date('1950-05-15'),
        medicalInfo: {
          conditions: ['Alzheimer\'s Disease', 'Hypertension'],
          allergies: ['Penicillin'],
          medications: ['Donepezil', 'Lisinopril']
        },
        emergencyInfo: {
          primaryContact: 'Sarah BYRR',
          phone: '555-0234',
          relationship: 'Daughter'
        },
        facilityId: facility.id
      })
    );

    // Create cognitive activities
    const activities = [
      {
        title: 'Memory Photo Match',
        description: 'Match family photos with names and relationships',
        activityType: 'memory_recall',
        difficulty: 'easy',
        content: {
          photos: ['family1.jpg', 'family2.jpg', 'family3.jpg'],
          matches: ['Sarah', 'Michael', 'Emma']
        },
        estimatedDuration: 15
      },
      {
        title: 'Word Association Challenge',
        description: 'Connect related words and concepts',
        activityType: 'cognitive_flexibility',
        difficulty: 'medium',
        content: {
          words: ['Summer', 'Beach', 'Vacation', 'Family'],
          associations: ['Hot', 'Sand', 'Travel', 'Love']
        },
        estimatedDuration: 20
      },
      {
        title: 'Pattern Recognition Game',
        description: 'Identify patterns in sequences and shapes',
        activityType: 'attention',
        difficulty: 'hard',
        content: {
          patterns: ['ABAB', 'AABB', 'ABCABC'],
          shapes: ['circle', 'square', 'triangle']
        },
        estimatedDuration: 25
      }
    ];

    for (const activity of activities) {
      await withDatabaseErrorHandling(() =>
        storage.createCognitiveActivity({
          patientId: patient.id,
          ...activity
        })
      );
    }

    // Create initial vital signs
    await withDatabaseErrorHandling(() =>
      storage.createVitalSigns({
        patientId: patient.id,
        heartRate: 72,
        bloodPressureSystolic: 120,
        bloodPressureDiastolic: 80,
        oxygenSaturation: 98,
        temperature: 98.6,
        isEmergencyAlert: false
      })
    );

    // Create sample medications
    const medications = [
      {
        name: 'Donepezil',
        dosage: '10mg',
        frequency: 'Once daily',
        timeSlots: ['08:00'],
        instructions: 'Take with breakfast',
        isActive: true
      },
      {
        name: 'Lisinopril',
        dosage: '5mg',
        frequency: 'Once daily',
        timeSlots: ['08:00'],
        instructions: 'Take with water',
        isActive: true
      },
      {
        name: 'Vitamin D3',
        dosage: '1000 IU',
        frequency: 'Once daily',
        timeSlots: ['12:00'],
        instructions: 'Take with lunch',
        isActive: true
      }
    ];

    for (const medication of medications) {
      await withDatabaseErrorHandling(() =>
        storage.createMedication({
          patientId: patient.id,
          ...medication
        })
      );
    }

    // Create family memories
    const memories = [
      {
        title: 'Summer Beach Vacation 1985',
        description: 'Family trip to Ocean City with Sarah and Michael. Built sandcastles and collected seashells.',
        memoryType: 'story',
        content: {
          story: 'It was a beautiful sunny day when we arrived at the beach. The children ran straight to the water while I set up our umbrella. We spent hours building elaborate sandcastles and searching for the perfect seashells.',
          emotions: ['joy', 'nostalgia', 'love'],
          people: ['Sarah', 'Michael', 'spouse'],
          location: 'Ocean City Beach'
        },
        familyMemberId: patient.id // In real app, this would be a family member
      },
      {
        title: 'Sarah\'s High School Graduation',
        description: 'Proud moment watching Sarah graduate valedictorian',
        memoryType: 'milestone',
        content: {
          story: 'Sarah worked so hard throughout high school. Seeing her walk across that stage as valedictorian was one of the proudest moments of my life.',
          emotions: ['pride', 'joy', 'accomplishment'],
          people: ['Sarah'],
          location: 'Lincoln High School'
        },
        familyMemberId: patient.id
      }
    ];

    for (const memory of memories) {
      await withDatabaseErrorHandling(() =>
        storage.createFamilyMemory({
          patientId: patient.id,
          ...memory
        })
      );
    }

    // Create initial cognitive progress
    await withDatabaseErrorHandling(() =>
      storage.createCognitiveProgress({
        patientId: patient.id,
        memoryRecall: '75.5',
        recognition: '82.0',
        attention: '68.5',
        overallScore: '75.3',
        notes: 'Good performance on memory tasks. Attention span could be improved with regular exercises.',
        aiInsights: {
          strengths: ['Visual memory', 'Long-term recall'],
          challenges: ['Sustained attention', 'Working memory'],
          recommendations: ['Daily brain games', 'Structured activities', 'Family photo sessions']
        }
      })
    );

    console.log('Database initialized successfully with test data');
    return { success: true, patientId: patient.id, facilityId: facility.id };
    
  } catch (error) {
    console.error('Database initialization failed:', error);
    throw error;
  }
}

export async function checkDatabaseHealth() {
  try {
    // Test basic database connectivity
    const patients = await storage.getPatientsByFacility(1);
    const facilities = await storage.getFacilities();
    
    console.log('Database health check passed:', {
      patientsCount: patients.length,
      facilitiesCount: facilities.length
    });
    
    return { healthy: true, stats: { patients: patients.length, facilities: facilities.length } };
  } catch (error) {
    console.error('Database health check failed:', error);
    return { healthy: false, error: error.message };
  }
}