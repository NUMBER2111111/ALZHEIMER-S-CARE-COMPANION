import { db } from './db';
import { trialAnalytics, dailyAnalytics } from '../shared/schema';
import { eq, gte, lte, count, desc } from 'drizzle-orm';

// Generate comprehensive analytics report for today
async function generateTodaysAnalytics() {
  try {
    console.log('=== CARE COMPANION ANALYTICS REPORT ===');
    console.log(`Generated: ${new Date().toLocaleString()}`);
    console.log('==========================================');

    // Get date ranges
    const today = new Date();
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

    console.log('\n📊 TRIAL SIGNUP METRICS (Last 30 Days)');
    console.log('=====================================');

    // Total trials in last 30 days
    const [totalTrials] = await db
      .select({ count: count() })
      .from(trialAnalytics)
      .where(gte(trialAnalytics.trialStartDate, thirtyDaysAgo));

    // Active trials
    const [activeTrials] = await db
      .select({ count: count() })
      .from(trialAnalytics)
      .where(eq(trialAnalytics.trialStatus, 'active'));

    // Converted trials
    const [convertedTrials] = await db
      .select({ count: count() })
      .from(trialAnalytics)
      .where(eq(trialAnalytics.convertedToSubscription, true));

    // Expired trials
    const [expiredTrials] = await db
      .select({ count: count() })
      .from(trialAnalytics)
      .where(eq(trialAnalytics.trialStatus, 'expired'));

    const conversionRate = totalTrials.count > 0 ? (convertedTrials.count / totalTrials.count) * 100 : 0;
    const revenue = convertedTrials.count * 49.99;

    console.log(`• Total Trials Started: ${totalTrials.count}`);
    console.log(`• Active Trials: ${activeTrials.count}`);
    console.log(`• Converted to Paid: ${convertedTrials.count}`);
    console.log(`• Expired Trials: ${expiredTrials.count}`);
    console.log(`• Conversion Rate: ${conversionRate.toFixed(2)}%`);
    console.log(`• Revenue Generated: $${revenue.toFixed(2)}`);

    console.log('\n🌍 TOP TRAFFIC SOURCES');
    console.log('======================');

    // Top referral sources
    const topSources = await db
      .select({
        source: trialAnalytics.referralSource,
        count: count(),
      })
      .from(trialAnalytics)
      .where(gte(trialAnalytics.trialStartDate, thirtyDaysAgo))
      .groupBy(trialAnalytics.referralSource)
      .orderBy(desc(count()))
      .limit(5);

    if (topSources.length > 0) {
      topSources.forEach((source, index) => {
        const percentage = totalTrials.count > 0 ? ((source.count / totalTrials.count) * 100).toFixed(1) : '0.0';
        console.log(`${index + 1}. ${source.source || 'Direct'}: ${source.count} signups (${percentage}%)`);
      });
    } else {
      console.log('• No traffic source data available yet');
    }

    console.log('\n🗺️  GEOGRAPHIC DISTRIBUTION');
    console.log('============================');

    // Top countries
    const topCountries = await db
      .select({
        country: trialAnalytics.country,
        count: count(),
      })
      .from(trialAnalytics)
      .where(gte(trialAnalytics.trialStartDate, thirtyDaysAgo))
      .groupBy(trialAnalytics.country)
      .orderBy(desc(count()))
      .limit(5);

    if (topCountries.length > 0) {
      topCountries.forEach((country, index) => {
        const percentage = totalTrials.count > 0 ? ((country.count / totalTrials.count) * 100).toFixed(1) : '0.0';
        console.log(`${index + 1}. ${country.country || 'Unknown'}: ${country.count} signups (${percentage}%)`);
      });
    } else {
      console.log('• No geographic data available yet');
    }

    console.log('\n⏰ RECENT TRIAL ACTIVITY (Last 7 Days)');
    console.log('======================================');

    // Recent trials
    const recentTrials = await db
      .select({
        email: trialAnalytics.email,
        firstName: trialAnalytics.firstName,
        lastName: trialAnalytics.lastName,
        trialStartDate: trialAnalytics.trialStartDate,
        trialStatus: trialAnalytics.trialStatus,
        referralSource: trialAnalytics.referralSource,
        country: trialAnalytics.country,
      })
      .from(trialAnalytics)
      .where(gte(trialAnalytics.trialStartDate, sevenDaysAgo))
      .orderBy(desc(trialAnalytics.trialStartDate))
      .limit(10);

    if (recentTrials.length > 0) {
      recentTrials.forEach((trial, index) => {
        const date = new Date(trial.trialStartDate).toLocaleDateString();
        const status = trial.trialStatus.toUpperCase();
        console.log(`${index + 1}. ${trial.firstName} ${trial.lastName} (${trial.email})`);
        console.log(`   Started: ${date} | Status: ${status} | Source: ${trial.referralSource || 'Direct'} | Location: ${trial.country || 'Unknown'}`);
      });
    } else {
      console.log('• No recent trial activity in the last 7 days');
    }

    console.log('\n💡 KEY INSIGHTS');
    console.log('===============');
    console.log(`• Best performing source: ${topSources[0]?.source || 'Direct'} (${topSources[0]?.count || 0} signups)`);
    console.log(`• Top geographic market: ${topCountries[0]?.country || 'Unknown'} (${topCountries[0]?.count || 0} signups)`);
    console.log(`• Revenue potential: ${activeTrials.count} active trials worth up to $${(activeTrials.count * 49.99).toFixed(2)} if converted`);
    console.log(`• Average daily signups: ${(totalTrials.count / 30).toFixed(1)} trials per day`);
    
    if (conversionRate > 0) {
      console.log(`• Trial completion rate: ${conversionRate.toFixed(2)}% converting to paid subscriptions`);
    } else {
      console.log('• Trial completion rate: No conversions yet - new platform');
    }

    console.log('\n📧 AUTOMATED REPORTING');
    console.log('======================');
    console.log('• Morning reports: 8:00 AM and 9:00 AM daily');
    console.log('• Evening reports: 8:00 PM daily');
    console.log('• Email delivery: Configured (check SENDGRID_API_KEY)');
    console.log('• Analytics tracking: Active for all trial signups');

    console.log('\n==========================================');
    console.log('Report complete. Next automated report at 9:00 AM or 8:00 PM.');
    console.log('==========================================\n');

    return {
      summary: {
        totalTrialsStarted: totalTrials.count,
        activeTrials: activeTrials.count,
        convertedTrials: convertedTrials.count,
        expiredTrials: expiredTrials.count,
        conversionRate: Math.round(conversionRate * 100) / 100,
        estimatedRevenue: revenue,
      },
      traffic: {
        topReferralSources: topSources,
        topCountries: topCountries,
      },
      recentActivity: recentTrials,
      insights: {
        bestSource: topSources[0]?.source || 'Direct',
        topMarket: topCountries[0]?.country || 'Unknown',
        dailyAverage: Math.round((totalTrials.count / 30) * 10) / 10,
      }
    };

  } catch (error) {
    console.error('Error generating analytics report:', error);
    console.log('\n⚠️  ANALYTICS REPORT ERROR');
    console.log('==========================');
    console.log('• Database connection issue or empty analytics tables');
    console.log('• This is normal for a new platform with no trial data yet');
    console.log('• Analytics will populate as users sign up for trials');
    
    return {
      summary: {
        totalTrialsStarted: 0,
        activeTrials: 0,
        convertedTrials: 0,
        expiredTrials: 0,
        conversionRate: 0,
        estimatedRevenue: 0,
      },
      error: 'No analytics data available yet',
    };
  }
}

// Run the analytics report
generateTodaysAnalytics();