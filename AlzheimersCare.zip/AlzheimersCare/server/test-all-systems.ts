import { initializeDatabase, checkDatabaseHealth } from './db-init';
import { storage } from './storage';
import { analyzeMemory, generateCognitiveActivity, assessCognitivePerformance } from './services/openai';
import { withDatabaseErrorHandling, withAIServiceErrorHandling } from './error-handler';

export async function runComprehensiveSystemTests() {
  console.log('Starting comprehensive system tests...');
  const results = {
    database: { passed: false, errors: [] as string[] },
    storage: { passed: false, errors: [] as string[] },
    aiServices: { passed: false, errors: [] as string[] },
    apiEndpoints: { passed: false, errors: [] as string[] },
    errorHandling: { passed: false, errors: [] as string[] }
  };

  // Test 1: Database Health and Initialization
  try {
    const healthCheck = await checkDatabaseHealth();
    if (healthCheck.healthy) {
      console.log('✓ Database health check passed');
      results.database.passed = true;
    } else {
      results.database.errors.push('Database health check failed');
    }
  } catch (error) {
    results.database.errors.push(`Database test failed: ${error.message}`);
  }

  // Test 2: Storage Operations
  try {
    await withDatabaseErrorHandling(async () => {
      const facilities = await storage.getFacilities();
      const patients = await storage.getPatientsByFacility(1);
      const vitals = await storage.getVitalSignsByPatient(1);
      console.log('✓ Storage operations test passed');
      results.storage.passed = true;
    });
  } catch (error) {
    results.storage.errors.push(`Storage test failed: ${error.message}`);
  }

  // Test 3: AI Services
  try {
    await withAIServiceErrorHandling(async () => {
      const testMemory = "A wonderful day at the beach with family";
      const analysis = await analyzeMemory('story', { text: testMemory }, testMemory);
      if (analysis && analysis.tags && analysis.emotions) {
        console.log('✓ AI memory analysis test passed');
        
        const activity = await generateCognitiveActivity(analysis, 'medium', ['memory_recall']);
        if (activity && activity.title) {
          console.log('✓ AI activity generation test passed');
          results.aiServices.passed = true;
        }
      }
    }, 'memory-analysis');
  } catch (error) {
    results.aiServices.errors.push(`AI services test failed: ${error.message}`);
  }

  // Test 4: Error Handling Resilience
  try {
    // Test invalid patient ID handling
    try {
      await storage.getPatient(-1);
    } catch (error) {
      // Expected error
    }

    // Test invalid vital signs
    try {
      await storage.createVitalSigns({
        patientId: 999999,
        heartRate: -50, // Invalid
        bloodPressureSystolic: 500, // Invalid
        bloodPressureDiastolic: 300, // Invalid
        oxygenSaturation: 150, // Invalid
        temperature: 200, // Invalid
        isEmergencyAlert: false
      });
    } catch (error) {
      // Expected error
    }

    console.log('✓ Error handling resilience test passed');
    results.errorHandling.passed = true;
  } catch (error) {
    results.errorHandling.errors.push(`Error handling test failed: ${error.message}`);
  }

  // Test 5: API Endpoint Simulation
  try {
    // Simulate critical API operations
    const patient = await storage.getPatient(1);
    if (patient) {
      const medications = await storage.getMedicationsByPatient(patient.id);
      const emergencyEvents = await storage.getEmergencyEventsByPatient(patient.id);
      const gameActivities = await storage.getGameActivitiesByPatient(patient.id);
      console.log('✓ API endpoints simulation test passed');
      results.apiEndpoints.passed = true;
    }
  } catch (error) {
    results.apiEndpoints.errors.push(`API endpoints test failed: ${error.message}`);
  }

  // Generate test report
  const totalTests = Object.keys(results).length;
  const passedTests = Object.values(results).filter(r => r.passed).length;
  const failedTests = totalTests - passedTests;

  console.log('\n=== COMPREHENSIVE SYSTEM TEST REPORT ===');
  console.log(`Total Tests: ${totalTests}`);
  console.log(`Passed: ${passedTests}`);
  console.log(`Failed: ${failedTests}`);
  console.log(`Success Rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

  if (failedTests > 0) {
    console.log('\n=== FAILURES ===');
    Object.entries(results).forEach(([test, result]) => {
      if (!result.passed && result.errors.length > 0) {
        console.log(`${test}:`);
        result.errors.forEach(error => console.log(`  - ${error}`));
      }
    });
  }

  return {
    success: failedTests === 0,
    summary: { totalTests, passedTests, failedTests },
    results
  };
}

export async function testRobustComponents() {
  console.log('Testing robust component integrations...');
  
  const componentTests = {
    emergencyMonitor: false,
    medicineTracker: false,
    aiGaming: false,
    patientCompanion: false
  };

  try {
    // Test Emergency Monitor data flows
    const vitals = await storage.getVitalSignsByPatient(1);
    const alerts = await storage.getEmergencyAlerts(1);
    componentTests.emergencyMonitor = true;
    console.log('✓ Emergency Monitor component test passed');

    // Test Medicine Tracker data flows
    const medications = await storage.getMedicationsByPatient(1);
    const logs = await storage.getMedicationLogsByPatient(1);
    componentTests.medicineTracker = true;
    console.log('✓ Medicine Tracker component test passed');

    // Test AI Gaming data flows
    const games = await storage.getGameActivitiesByPatient(1);
    const activeGames = await storage.getActiveGames(1);
    componentTests.aiGaming = true;
    console.log('✓ AI Gaming component test passed');

    // Test Patient Companion data integration
    const patient = await storage.getPatient(1);
    const progress = await storage.getLatestCognitiveProgress(1);
    const activities = await storage.getCognitiveActivitiesByPatient(1);
    componentTests.patientCompanion = true;
    console.log('✓ Patient Companion component test passed');

  } catch (error) {
    console.error('Component integration test failed:', error);
  }

  return componentTests;
}

export async function initializeAndTestAll() {
  try {
    console.log('Initializing comprehensive testing suite...');
    
    // Initialize database if needed
    await initializeDatabase();
    
    // Run all system tests
    const systemTests = await runComprehensiveSystemTests();
    
    // Test component integrations
    const componentTests = await testRobustComponents();
    
    console.log('\n=== FINAL TEST SUMMARY ===');
    console.log('System Tests:', systemTests.success ? 'PASSED' : 'FAILED');
    console.log('Component Tests:', Object.values(componentTests).every(Boolean) ? 'PASSED' : 'FAILED');
    
    return {
      systemTests,
      componentTests,
      overallSuccess: systemTests.success && Object.values(componentTests).every(Boolean)
    };
    
  } catch (error) {
    console.error('Test initialization failed:', error);
    return { error: error.message, overallSuccess: false };
  }
}