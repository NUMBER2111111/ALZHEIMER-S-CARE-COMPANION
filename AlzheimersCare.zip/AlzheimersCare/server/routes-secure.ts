import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { RobustArchitecture } from "./core/robust-architecture";
import { securePaymentService } from "./services/secure-payments";
import comprehensiveSecurity from "./middleware/comprehensive-security";
import { validateRequired, validatePatientId, handleAsyncErrors } from "./error-handler";

// Secure routes implementation with comprehensive protection
export async function registerSecureRoutes(app: Express): Promise<Server> {
  // Initialize robust architecture
  const robustArch = new RobustArchitecture(app);
  
  // Apply comprehensive security middleware
  app.use(comprehensiveSecurity.securityHeaders);
  app.use(comprehensiveSecurity.auditLogger);
  app.use(comprehensiveSecurity.sanitizeInput);
  app.use(comprehensiveSecurity.strictRateLimit);

  // Setup robust system routes
  robustArch.setupRobustRoutes();

  // Enhanced health endpoint with comprehensive checks
  app.get('/api/health/comprehensive', 
    comprehensiveSecurity.apiRateLimit,
    handleAsyncErrors(async (req, res) => {
      const systemHealth = await robustArch.performHealthCheck();
      const validationResults = await robustArch.validateSystemIntegrity();
      
      res.json({
        ...systemHealth,
        validation: validationResults,
        deployment: {
          ready: validationResults.isValid && systemHealth.status === 'healthy',
          environment: process.env.NODE_ENV,
          version: '1.0.0'
        }
      });
    })
  );

  // Secure patient data routes with enhanced validation
  app.get('/api/patients/:id', 
    comprehensiveSecurity.apiRateLimit,
    comprehensiveSecurity.validatePatientId,
    handleAsyncErrors(async (req, res) => {
      const patientId = parseInt(req.params.id);
      const patient = await storage.getPatient(patientId);
      
      if (!patient) {
        return res.status(404).json({ error: 'Patient not found' });
      }
      
      res.json(patient);
    })
  );

  // Secure mood tracking routes
  app.post('/api/mood/entry',
    comprehensiveSecurity.authRateLimit,
    comprehensiveSecurity.validateRequiredFields(['patientId', 'moodLevel', 'emotionalState']),
    handleAsyncErrors(async (req, res) => {
      const moodEntry = await storage.createMoodEntry(req.body);
      res.status(201).json({ success: true, moodEntry });
    })
  );

  app.get('/api/mood/trends/:patientId',
    comprehensiveSecurity.apiRateLimit,
    comprehensiveSecurity.validatePatientId,
    handleAsyncErrors(async (req, res) => {
      const patientId = parseInt(req.params.patientId);
      const days = parseInt(req.query.days as string) || 7;
      const trends = await storage.getMoodTrends(patientId, days);
      res.json({ success: true, trends });
    })
  );

  // Secure payment routes with enhanced security
  app.post('/api/payments/create-intent',
    comprehensiveSecurity.authRateLimit,
    comprehensiveSecurity.validateRequiredFields(['amount']),
    handleAsyncErrors(async (req, res) => {
      if (!securePaymentService.isConfigured()) {
        return res.status(503).json({ error: 'Payment service not available' });
      }
      
      const { amount, currency = 'usd' } = req.body;
      const paymentIntent = await securePaymentService.createPaymentIntent(amount, currency);
      
      res.json({
        clientSecret: paymentIntent.client_secret,
        amount: paymentIntent.amount
      });
    })
  );

  app.post('/api/subscription/create',
    comprehensiveSecurity.authRateLimit,
    comprehensiveSecurity.validateRequiredFields(['email']),
    handleAsyncErrors(async (req, res) => {
      if (!securePaymentService.isConfigured()) {
        return res.status(503).json({ error: 'Payment service not available' });
      }
      
      const { email, name } = req.body;
      const customer = await securePaymentService.createCustomer(email, name);
      
      // Use environment variable for price ID
      const priceId = process.env.STRIPE_PRICE_ID || 'price_1234567890';
      const subscription = await securePaymentService.createSubscription(customer.id, priceId);
      
      res.json({
        subscriptionId: subscription.id,
        clientSecret: subscription.latest_invoice?.payment_intent?.client_secret
      });
    })
  );

  // Enhanced emergency response routes
  app.post('/api/emergency/alert',
    comprehensiveSecurity.authRateLimit,
    comprehensiveSecurity.validateRequiredFields(['patientId', 'alertType']),
    handleAsyncErrors(async (req, res) => {
      const { patientId, alertType, severity = 'medium', location } = req.body;
      
      const emergencyEvent = await storage.createEmergencyEvent({
        patientId: parseInt(patientId),
        eventType: alertType,
        severity,
        location,
        status: 'active',
        createdAt: new Date()
      });
      
      // Trigger emergency notification system
      console.log(`EMERGENCY ALERT: ${alertType} for patient ${patientId}`);
      
      res.status(201).json({
        success: true,
        alertId: emergencyEvent.id,
        message: 'Emergency alert created and notifications sent'
      });
    })
  );

  // Secure family communication routes
  app.get('/api/family/dashboard/:patientId',
    comprehensiveSecurity.apiRateLimit,
    comprehensiveSecurity.validatePatientId,
    handleAsyncErrors(async (req, res) => {
      const patientId = parseInt(req.params.patientId);
      
      const [patient, vitals, moodTrends, emergencyEvents] = await Promise.all([
        storage.getPatient(patientId),
        storage.getLatestVitals(patientId),
        storage.getMoodTrends(patientId, 7),
        storage.getEmergencyEvents(patientId, 10)
      ]);
      
      res.json({
        patient,
        currentVitals: vitals,
        moodTrends,
        recentEvents: emergencyEvents,
        lastUpdated: new Date().toISOString()
      });
    })
  );

  // AI companion routes with security
  app.post('/api/ai/chat',
    comprehensiveSecurity.authRateLimit,
    comprehensiveSecurity.validateRequiredFields(['message', 'patientId']),
    handleAsyncErrors(async (req, res) => {
      const { message, patientId } = req.body;
      
      // Validate message content
      if (message.length > 1000) {
        return res.status(400).json({ error: 'Message too long' });
      }
      
      // Process with AI service (would integrate with OpenAI)
      const response = {
        message: `I understand you're saying: "${message}". How are you feeling today?`,
        timestamp: new Date().toISOString(),
        patientId
      };
      
      res.json(response);
    })
  );

  // Comprehensive system monitoring
  app.get('/api/admin/system-status',
    comprehensiveSecurity.strictRateLimit,
    handleAsyncErrors(async (req, res) => {
      const systemStatus = {
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        environment: process.env.NODE_ENV,
        services: {
          database: true, // Would check actual database
          ai: !!process.env.OPENAI_API_KEY,
          payments: securePaymentService.isConfigured()
        },
        timestamp: new Date().toISOString()
      };
      
      res.json(systemStatus);
    })
  );

  // Error handling middleware
  app.use(comprehensiveSecurity.errorHandler);

  const httpServer = createServer(app);
  
  console.log('🔒 Secure routes registered with comprehensive protection');
  return httpServer;
}