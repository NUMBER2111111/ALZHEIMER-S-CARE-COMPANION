import { Request, Response, NextFunction } from 'express';

interface RateLimitStore {
  [key: string]: {
    count: number;
    resetTime: number;
  };
}

export class RateLimitMiddleware {
  private static store: RateLimitStore = {};
  
  // General API rate limiting
  static createRateLimit(windowMs: number, maxRequests: number) {
    return (req: Request, res: Response, next: NextFunction) => {
      const key = `${req.ip}:${req.path}`;
      const now = Date.now();
      
      // Clean expired entries
      if (this.store[key] && now > this.store[key].resetTime) {
        delete this.store[key];
      }
      
      // Initialize or increment counter
      if (!this.store[key]) {
        this.store[key] = {
          count: 1,
          resetTime: now + windowMs
        };
      } else {
        this.store[key].count++;
      }
      
      // Check rate limit
      if (this.store[key].count > maxRequests) {
        const resetIn = Math.ceil((this.store[key].resetTime - now) / 1000);
        
        res.set({
          'X-RateLimit-Limit': maxRequests.toString(),
          'X-RateLimit-Remaining': '0',
          'X-RateLimit-Reset': resetIn.toString()
        });
        
        return res.status(429).json({
          error: 'Rate limit exceeded',
          message: `Too many requests. Try again in ${resetIn} seconds.`,
          retryAfter: resetIn
        });
      }
      
      // Set rate limit headers
      const remaining = Math.max(0, maxRequests - this.store[key].count);
      const resetIn = Math.ceil((this.store[key].resetTime - now) / 1000);
      
      res.set({
        'X-RateLimit-Limit': maxRequests.toString(),
        'X-RateLimit-Remaining': remaining.toString(),
        'X-RateLimit-Reset': resetIn.toString()
      });
      
      next();
    };
  }
  
  // Strict rate limiting for sensitive endpoints
  static strictRateLimit = this.createRateLimit(60000, 10); // 10 requests per minute
  
  // Standard rate limiting for API endpoints
  static standardRateLimit = this.createRateLimit(60000, 100); // 100 requests per minute
  
  // Authentication attempts rate limiting
  static authRateLimit = this.createRateLimit(900000, 5); // 5 attempts per 15 minutes
  
  // Patient data access rate limiting
  static patientDataRateLimit = this.createRateLimit(60000, 50); // 50 requests per minute
}