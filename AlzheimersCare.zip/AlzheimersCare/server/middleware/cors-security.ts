import { Request, Response, NextFunction } from 'express';

export class CorsSecurityMiddleware {
  
  // CORS configuration for healthcare data protection
  static corsPolicy(req: Request, res: Response, next: NextFunction) {
    const allowedOrigins = [
      'http://localhost:5000',
      'https://localhost:5000',
      'http://127.0.0.1:5000',
      'https://127.0.0.1:5000'
    ];

    const origin = req.headers.origin;
    
    if (allowedOrigins.includes(origin as string)) {
      res.setHeader('Access-Control-Allow-Origin', origin as string);
    }
    
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Max-Age', '86400'); // 24 hours
    
    // Handle preflight requests
    if (req.method === 'OPTIONS') {
      return res.status(200).end();
    }
    
    next();
  }

  // Security headers for HIPAA compliance
  static securityHeaders(req: Request, res: Response, next: NextFunction) {
    // Prevent XSS attacks
    res.setHeader('X-XSS-Protection', '1; mode=block');
    
    // Prevent MIME type sniffing
    res.setHeader('X-Content-Type-Options', 'nosniff');
    
    // Prevent clickjacking
    res.setHeader('X-Frame-Options', 'DENY');
    
    // Enforce HTTPS
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
    
    // Content Security Policy
    res.setHeader('Content-Security-Policy', 
      "default-src 'self'; " +
      "script-src 'self' 'unsafe-inline' 'unsafe-eval'; " +
      "style-src 'self' 'unsafe-inline'; " +
      "img-src 'self' data: https:; " +
      "connect-src 'self' https://api.openai.com https://connect.squareup.com; " +
      "font-src 'self' data:; " +
      "media-src 'self'; " +
      "object-src 'none'; " +
      "base-uri 'self'; " +
      "form-action 'self'"
    );
    
    // Referrer Policy
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    
    // Permissions Policy
    res.setHeader('Permissions-Policy', 
      'camera=(), microphone=(), geolocation=(), payment=()'
    );
    
    // Remove server information
    res.removeHeader('X-Powered-By');
    res.removeHeader('Server');
    
    next();
  }

  // Input sanitization middleware
  static sanitizeInput(req: Request, res: Response, next: NextFunction) {
    if (req.body) {
      req.body = CorsSecurityMiddleware.sanitizeObject(req.body);
    }
    
    if (req.query) {
      req.query = CorsSecurityMiddleware.sanitizeObject(req.query);
    }
    
    if (req.params) {
      req.params = CorsSecurityMiddleware.sanitizeObject(req.params);
    }
    
    next();
  }

  // Sanitize object recursively
  private static sanitizeObject(obj: any): any {
    if (obj === null || obj === undefined) {
      return obj;
    }
    
    if (typeof obj === 'string') {
      return obj
        .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
        .replace(/javascript:/gi, '')
        .replace(/on\w+\s*=/gi, '')
        .replace(/(<|>|"|'|&)/g, (match) => {
          const entities: { [key: string]: string } = {
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#x27;',
            '&': '&amp;'
          };
          return entities[match] || match;
        });
    }
    
    if (Array.isArray(obj)) {
      return obj.map(item => CorsSecurityMiddleware.sanitizeObject(item));
    }
    
    if (typeof obj === 'object') {
      const sanitized: any = {};
      for (const key in obj) {
        if (obj.hasOwnProperty(key)) {
          sanitized[key] = CorsSecurityMiddleware.sanitizeObject(obj[key]);
        }
      }
      return sanitized;
    }
    
    return obj;
  }

  // Validate JSON payload size and structure
  static validatePayload(req: Request, res: Response, next: NextFunction) {
    const contentLength = parseInt(req.headers['content-length'] || '0');
    
    // Limit payload size to 10MB for healthcare data
    if (contentLength > 10 * 1024 * 1024) {
      return res.status(413).json({
        error: 'Payload too large',
        message: 'Request payload exceeds maximum allowed size'
      });
    }
    
    // Validate JSON structure for POST/PUT requests
    if (['POST', 'PUT', 'PATCH'].includes(req.method)) {
      if (!req.headers['content-type']?.includes('application/json')) {
        return res.status(415).json({
          error: 'Unsupported media type',
          message: 'Content-Type must be application/json'
        });
      }
    }
    
    next();
  }
}