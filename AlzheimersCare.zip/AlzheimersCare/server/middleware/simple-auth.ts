import { Request, Response, NextFunction } from 'express';

interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    role: string;
    patientId?: number;
  };
  session?: {
    userId?: string;
    userType?: string;
  };
}

export class SimpleAuth {
  
  // Mock session for development - allows app to function
  static mockSession(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    // Create a mock user session for development
    if (!req.session) {
      req.session = {};
    }
    
    // Mock user for patient companion
    if (!req.session.userId) {
      req.session.userId = '1';
      req.session.userType = 'patient';
    }
    
    req.user = {
      id: req.session.userId,
      role: req.session.userType || 'patient',
      patientId: 1
    };
    
    next();
  }
  
  // Optional authentication - doesn't block requests
  static optionalAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    if (req.session?.userId) {
      req.user = {
        id: req.session.userId,
        role: req.session.userType || 'patient',
        patientId: parseInt(req.session.userId) || 1
      };
    }
    next();
  }
  
  // Required authentication for sensitive endpoints
  static requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    if (!req.session?.userId) {
      return res.status(401).json({
        error: 'Authentication required',
        message: 'Please log in to access this resource'
      });
    }
    
    req.user = {
      id: req.session.userId,
      role: req.session.userType || 'patient',
      patientId: parseInt(req.session.userId) || 1
    };
    
    next();
  }
}