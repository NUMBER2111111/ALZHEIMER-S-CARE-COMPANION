import { Request, Response, NextFunction } from 'express';
import { superEncryption } from '../services/super-encryption';
import { militarySecurity } from '../services/military-security';
import { threatDetection } from '../services/advanced-threat-detection';
import { storage } from '../storage';

// Enhanced security middleware for healthcare data protection
export class SecurityMiddleware {
  
  // Military-grade threat analysis middleware
  static async militaryThreatAnalysis(req: Request, res: Response, next: NextFunction) {
    try {
      // Perform comprehensive threat analysis
      const threatAnalysis = threatDetection.analyzeRequest(req);
      
      // Add security headers
      res.setHeader('X-Threat-Analysis', threatAnalysis.requestId);
      res.setHeader('X-Risk-Level', threatAnalysis.riskLevel);
      
      // Handle threats based on risk level
      if (threatAnalysis.riskLevel === 'CRITICAL') {
        console.log(`[CRITICAL THREAT] Blocked request from ${req.ip}:`, threatAnalysis);
        return res.status(403).json({
          error: 'Security threat detected',
          message: 'Request blocked for security reasons',
          requestId: threatAnalysis.requestId
        });
      }
      
      if (threatAnalysis.riskLevel === 'HIGH') {
        console.log(`[HIGH THREAT] Enhanced monitoring for ${req.ip}:`, threatAnalysis);
        // Continue but with enhanced logging
      }
      
      // Store threat analysis for audit
      (req as any).threatAnalysis = threatAnalysis;
      
      next();
    } catch (error) {
      console.error('Threat analysis error:', error);
      next(); // Continue on analysis error
    }
  }

  // Request sanitization and validation
  static sanitizeRequest(req: Request, res: Response, next: NextFunction) {
    // Remove potentially dangerous characters from request body
    if (req.body) {
      req.body = SecurityMiddleware.sanitizeObject(req.body);
    }
    
    // Validate content type for data endpoints
    if (req.method === 'POST' || req.method === 'PUT') {
      const contentType = req.headers['content-type'];
      if (!contentType || !contentType.includes('application/json')) {
        return res.status(400).json({
          error: 'Invalid content type',
          message: 'Content-Type must be application/json'
        });
      }
    }
    
    next();
  }

  // Recursive object sanitization
  private static sanitizeObject(obj: any): any {
    if (typeof obj === 'string') {
      return obj.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
                .replace(/javascript:/gi, '')
                .replace(/vbscript:/gi, '')
                .replace(/onload=/gi, '')
                .replace(/onerror=/gi, '');
    }
    
    if (Array.isArray(obj)) {
      return obj.map(item => SecurityMiddleware.sanitizeObject(item));
    }
    
    if (obj && typeof obj === 'object') {
      const sanitized: any = {};
      for (const [key, value] of Object.entries(obj)) {
        sanitized[key] = SecurityMiddleware.sanitizeObject(value);
      }
      return sanitized;
    }
    
    return obj;
  }

  // Audit logging for compliance
  static async auditLog(req: Request, res: Response, next: NextFunction) {
    const startTime = Date.now();
    const originalSend = res.send;
    
    // Capture response data
    res.send = function(data) {
      const duration = Date.now() - startTime;
      const auditData = {
        userId: req.body?.userId || req.params?.userId || 0,
        action: `${req.method} ${req.path}`,
        timestamp: new Date(),
        ipAddress: req.ip || req.connection.remoteAddress || 'unknown',
        userAgent: req.headers['user-agent'] || '',
        statusCode: res.statusCode,
        duration,
        resourceId: req.params?.patientId || req.body?.patientId
      };
      
      // Generate audit hash for tamper detection
      const auditHash = superEncryption.generateAuditHash(auditData);
      
      // Log sensitive operations
      const sensitiveEndpoints = [
        '/api/patients',
        '/api/cognitive-progress',
        '/api/vital-signs',
        '/api/medications',
        '/api/emergency-events',
        '/api/subscription'
      ];
      
      const isSensitive = sensitiveEndpoints.some(endpoint => req.path.includes(endpoint));
      
      if (isSensitive || res.statusCode >= 400) {
        console.log(`[AUDIT] ${JSON.stringify({ ...auditData, auditHash })}`);
      }
      
      return originalSend.call(this, data);
    };
    
    next();
  }

  // HIPAA compliance headers
  static hipaaHeaders(req: Request, res: Response, next: NextFunction) {
    // Enhanced security headers for healthcare data
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    
    // Custom HIPAA compliance headers
    res.setHeader('X-Healthcare-Data', 'encrypted');
    res.setHeader('X-Data-Classification', 'confidential');
    res.setHeader('X-Audit-Required', 'true');
    
    next();
  }

  // Patient data access validation
  static async validatePatientAccess(req: Request, res: Response, next: NextFunction) {
    try {
      const patientId = parseInt(req.params.patientId || req.body.patientId);
      const userId = parseInt(req.body.userId || req.params.userId || '0');
      
      if (!patientId || !userId) {
        return res.status(400).json({
          error: 'Access validation failed',
          message: 'Patient ID and User ID are required'
        });
      }
      
      // Check if user has access to this patient's data
      const hasAccess = await SecurityMiddleware.checkPatientAccess(userId, patientId);
      
      if (!hasAccess) {
        return res.status(403).json({
          error: 'Access denied',
          message: 'You do not have permission to access this patient data'
        });
      }
      
      next();
    } catch (error) {
      console.error('Patient access validation error:', error);
      res.status(500).json({
        error: 'Access validation error',
        message: 'Unable to validate access permissions'
      });
    }
  }

  // Check patient access permissions
  private static async checkPatientAccess(userId: number, patientId: number): Promise<boolean> {
    try {
      const user = await storage.getUser(userId);
      if (!user) return false;
      
      // Admin users have access to all patients in their facility
      if (user.userType === 'admin') {
        const patient = await storage.getPatient(patientId);
        return patient?.facilityId === user.facilityId;
      }
      
      // Family members have access to their related patients
      if (user.userType === 'family') {
        const relationships = await storage.getFamilyRelationshipsByMember(userId);
        return relationships.some(rel => rel.patientId === patientId);
      }
      
      // Patients can only access their own data
      if (user.userType === 'patient') {
        return userId === patientId;
      }
      
      return false;
    } catch (error) {
      console.error('Error checking patient access:', error);
      return false;
    }
  }

  // Data encryption middleware
  static encryptSensitiveData(req: Request, res: Response, next: NextFunction) {
    const originalSend = res.send;
    
    res.send = function(data) {
      try {
        if (typeof data === 'string') {
          const parsedData = JSON.parse(data);
          
          // Encrypt sensitive fields in response
          const encryptedData = SecurityMiddleware.encryptResponseData(parsedData);
          return originalSend.call(this, JSON.stringify(encryptedData));
        }
        
        return originalSend.call(this, data);
      } catch (error) {
        console.error('Response encryption error:', error);
        return originalSend.call(this, data);
      }
    };
    
    next();
  }

  // Encrypt sensitive fields in API responses
  private static encryptResponseData(data: any): any {
    if (!data || typeof data !== 'object') return data;
    
    const sensitiveFields = [
      'medicalInfo',
      'emergencyInfo',
      'personalInfo',
      'paymentInfo',
      'notes',
      'observations'
    ];
    
    if (Array.isArray(data)) {
      return data.map(item => SecurityMiddleware.encryptResponseData(item));
    }
    
    const result = { ...data };
    
    for (const field of sensitiveFields) {
      if (result[field] && typeof result[field] === 'string') {
        try {
          result[field] = superEncryption.encryptData(result[field], `response-${field}`);
        } catch (error) {
          console.error(`Failed to encrypt field ${field}:`, error);
        }
      }
    }
    
    return result;
  }
}

// Export configured middleware
export const securityConfig = {
  sanitize: SecurityMiddleware.sanitizeRequest,
  audit: SecurityMiddleware.auditLog,
  hipaa: SecurityMiddleware.hipaaHeaders,
  patientAccess: SecurityMiddleware.validatePatientAccess,
  encrypt: SecurityMiddleware.encryptSensitiveData
};