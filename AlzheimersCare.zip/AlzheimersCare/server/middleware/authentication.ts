import { Request, Response, NextFunction } from 'express';
import { storage } from '../storage';

interface AuthenticatedRequest extends Request {
  user?: any;
  session?: any;
}

export class AuthenticationMiddleware {
  
  // Require authentication for all requests
  static requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    if (!req.session?.userId) {
      return res.status(401).json({
        error: 'Authentication required',
        message: 'Please log in to access this resource'
      });
    }
    next();
  }

  // Load user data into request
  static async loadUser(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      if (req.session?.userId) {
        const user = await storage.getUser(req.session.userId);
        if (user) {
          req.user = user;
        }
      }
      next();
    } catch (error) {
      console.error('Error loading user:', error);
      next();
    }
  }

  // Role-based access control
  static requireRole(allowedRoles: string[]) {
    return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
      if (!req.user) {
        return res.status(401).json({
          error: 'Authentication required',
          message: 'Please log in to access this resource'
        });
      }

      if (!allowedRoles.includes(req.user.userType)) {
        return res.status(403).json({
          error: 'Access denied',
          message: 'Insufficient permissions to access this resource'
        });
      }

      next();
    };
  }

  // Validate patient access permissions
  static async validatePatientAccess(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const patientId = parseInt(req.params.id);
      if (!patientId) {
        return res.status(400).json({
          error: 'Invalid patient ID',
          message: 'Patient ID must be a valid number'
        });
      }

      // Admin users can access all patients
      if (req.user?.userType === 'admin') {
        return next();
      }

      // Family members can only access their own patients
      if (req.user?.userType === 'family') {
        // Check if user has access to this patient through family relationships
        const relationships = await storage.getFamilyRelationshipsByMember(req.user.id);
        const hasAccess = relationships.some(rel => rel.patientId === patientId);
        
        if (!hasAccess) {
          return res.status(403).json({
            error: 'Access denied',
            message: 'You do not have permission to access this patient'
          });
        }
      }

      next();
    } catch (error) {
      console.error('Error validating patient access:', error);
      res.status(500).json({
        error: 'Internal server error',
        message: 'Unable to validate patient access'
      });
    }
  }

  // Audit log all access attempts
  static auditAccess(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    const auditData = {
      userId: req.user?.id || null,
      method: req.method,
      path: req.path,
      ip: req.ip,
      userAgent: req.get('User-Agent'),
      timestamp: new Date().toISOString()
    };

    console.log('[AUDIT]', JSON.stringify(auditData));
    
    // Store in database for compliance
    // TODO: Implement audit log storage
    
    next();
  }
}