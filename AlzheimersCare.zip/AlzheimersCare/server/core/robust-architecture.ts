import { Express, Request, Response, NextFunction } from 'express';
import { systemValidator } from '../test-all-systems-comprehensive';
import { securityScanner } from './security-scanner';

// Robust architecture implementation with comprehensive error handling
class RobustArchitecture {
  private app: Express;
  private healthChecks: Map<string, () => Promise<boolean>> = new Map();
  private criticalServices: Set<string> = new Set();

  constructor(app: Express) {
    this.app = app;
    this.initializeHealthChecks();
    this.setupGlobalErrorHandling();
    this.implementCircuitBreakers();
  }

  private initializeHealthChecks() {
    // Database health check
    this.healthChecks.set('database', async () => {
      try {
        const { db } = await import('../db');
        await db.execute('SELECT 1');
        return true;
      } catch {
        return false;
      }
    });

    // OpenAI service health check
    this.healthChecks.set('openai', async () => {
      return !!process.env.OPENAI_API_KEY;
    });

    // Payment service health check
    this.healthChecks.set('payments', async () => {
      return !!process.env.STRIPE_SECRET_KEY;
    });

    this.criticalServices.add('database');
  }

  private setupGlobalErrorHandling() {
    // Unhandled promise rejection handler
    process.on('unhandledRejection', (reason, promise) => {
      console.error('Unhandled Rejection at:', promise, 'reason:', reason);
      this.logCriticalError('unhandledRejection', reason);
    });

    // Uncaught exception handler
    process.on('uncaughtException', (error) => {
      console.error('Uncaught Exception:', error);
      this.logCriticalError('uncaughtException', error);
      
      // Graceful shutdown
      this.gracefulShutdown();
    });
  }

  private implementCircuitBreakers() {
    const circuitBreakers = new Map();
    
    // Circuit breaker for external API calls
    const createCircuitBreaker = (serviceName: string, threshold: number = 5) => {
      return {
        failures: 0,
        lastFailureTime: 0,
        state: 'closed', // closed, open, half-open
        threshold,
        timeout: 60000, // 1 minute
        
        async call<T>(fn: () => Promise<T>): Promise<T> {
          if (this.state === 'open') {
            if (Date.now() - this.lastFailureTime > this.timeout) {
              this.state = 'half-open';
            } else {
              throw new Error(`Circuit breaker open for ${serviceName}`);
            }
          }
          
          try {
            const result = await fn();
            if (this.state === 'half-open') {
              this.state = 'closed';
              this.failures = 0;
            }
            return result;
          } catch (error) {
            this.failures++;
            this.lastFailureTime = Date.now();
            
            if (this.failures >= this.threshold) {
              this.state = 'open';
            }
            throw error;
          }
        }
      };
    };

    circuitBreakers.set('openai', createCircuitBreaker('OpenAI'));
    circuitBreakers.set('stripe', createCircuitBreaker('Stripe'));
  }

  async performHealthCheck(): Promise<{
    status: 'healthy' | 'degraded' | 'unhealthy';
    services: Record<string, boolean>;
    timestamp: string;
  }> {
    const serviceStatuses: Record<string, boolean> = {};
    let healthyCount = 0;
    let criticalFailures = 0;

    for (const [serviceName, healthCheck] of this.healthChecks) {
      try {
        const isHealthy = await healthCheck();
        serviceStatuses[serviceName] = isHealthy;
        
        if (isHealthy) {
          healthyCount++;
        } else if (this.criticalServices.has(serviceName)) {
          criticalFailures++;
        }
      } catch (error) {
        serviceStatuses[serviceName] = false;
        if (this.criticalServices.has(serviceName)) {
          criticalFailures++;
        }
      }
    }

    const totalServices = this.healthChecks.size;
    let status: 'healthy' | 'degraded' | 'unhealthy';

    if (criticalFailures > 0) {
      status = 'unhealthy';
    } else if (healthyCount === totalServices) {
      status = 'healthy';
    } else {
      status = 'degraded';
    }

    return {
      status,
      services: serviceStatuses,
      timestamp: new Date().toISOString()
    };
  }

  private logCriticalError(type: string, error: any) {
    const errorLog = {
      timestamp: new Date().toISOString(),
      type,
      error: error.toString(),
      stack: error.stack,
      pid: process.pid,
      memory: process.memoryUsage(),
      uptime: process.uptime()
    };

    console.error('[CRITICAL ERROR]', JSON.stringify(errorLog, null, 2));
  }

  private gracefulShutdown() {
    console.log('Initiating graceful shutdown...');
    
    // Close server connections
    process.exit(1);
  }

  async validateSystemIntegrity(): Promise<{
    isValid: boolean;
    issues: string[];
    recommendations: string[];
  }> {
    const issues: string[] = [];
    const recommendations: string[] = [];

    // Run comprehensive tests
    const systemHealth = await systemValidator.runComprehensiveTests();
    const securityScan = await securityScanner.runComprehensiveScan();

    // Check system health
    if (systemHealth.healthPercentage < 80) {
      issues.push(`System health at ${systemHealth.healthPercentage}% - below recommended 80%`);
      recommendations.push('Address failing system components before deployment');
    }

    // Check security issues
    if (securityScan.summary.critical > 0) {
      issues.push(`${securityScan.summary.critical} critical security issues detected`);
      recommendations.push('Resolve all critical security vulnerabilities');
    }

    if (securityScan.summary.high > 3) {
      issues.push(`${securityScan.summary.high} high-severity security issues detected`);
      recommendations.push('Address high-severity security issues');
    }

    // Check environment configuration
    const requiredEnvVars = ['DATABASE_URL', 'OPENAI_API_KEY', 'SESSION_SECRET'];
    const missingEnvVars = requiredEnvVars.filter(envVar => !process.env[envVar]);
    
    if (missingEnvVars.length > 0) {
      issues.push(`Missing required environment variables: ${missingEnvVars.join(', ')}`);
      recommendations.push('Configure all required environment variables');
    }

    const isValid = issues.length === 0;

    return {
      isValid,
      issues,
      recommendations: [...recommendations, ...systemHealth.recommendations]
    };
  }

  setupRobustRoutes() {
    // Enhanced health endpoint
    this.app.get('/api/system/health', async (req: Request, res: Response) => {
      try {
        const health = await this.performHealthCheck();
        const statusCode = health.status === 'healthy' ? 200 : 
                          health.status === 'degraded' ? 200 : 503;
        
        res.status(statusCode).json(health);
      } catch (error) {
        res.status(500).json({
          status: 'error',
          message: 'Health check failed',
          timestamp: new Date().toISOString()
        });
      }
    });

    // System validation endpoint
    this.app.get('/api/system/validate', async (req: Request, res: Response) => {
      try {
        const validation = await this.validateSystemIntegrity();
        res.json(validation);
      } catch (error) {
        res.status(500).json({
          isValid: false,
          issues: ['System validation failed'],
          recommendations: ['Check server logs and restart if necessary']
        });
      }
    });

    // Security scan endpoint
    this.app.get('/api/system/security-scan', async (req: Request, res: Response) => {
      try {
        const scanResults = await securityScanner.runComprehensiveScan();
        res.json(scanResults);
      } catch (error) {
        res.status(500).json({
          summary: { total: 0, critical: 0, high: 0, medium: 0, low: 0 },
          issues: [],
          recommendations: ['Security scan failed - check system configuration']
        });
      }
    });
  }
}

export { RobustArchitecture };
export default RobustArchitecture;