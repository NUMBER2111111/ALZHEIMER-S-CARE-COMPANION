import type { Request, Response, NextFunction } from 'express';

export interface AppError extends Error {
  statusCode: number;
  isOperational: boolean;
  code?: string;
  service?: string;
}

export class BaseError extends Error implements AppError {
  statusCode: number;
  isOperational = true;
  code?: string;
  service?: string;

  constructor(message: string, statusCode: number, code?: string, service?: string) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
    this.service = service;
    Error.captureStackTrace(this, this.constructor);
  }
}



export class ValidationError extends BaseError {
  constructor(message: string, field?: string) {
    super(`Validation failed: ${message}${field ? ` (field: ${field})` : ''}`, 400, 'VALIDATION_ERROR');
  }
}

export class DatabaseError extends BaseError {
  constructor(message: string, originalError?: Error) {
    super(`Database operation failed: ${message}`, 500, 'DATABASE_ERROR');
    if (originalError) {
      this.stack = originalError.stack;
    }
  }
}

export class AIServiceError extends BaseError {
  constructor(message: string, service?: string) {
    super(`AI service error: ${message}`, 503, 'AI_SERVICE_ERROR', service);
  }
}

export class PaymentError extends BaseError {
  constructor(message: string, code?: string) {
    super(`Payment processing failed: ${message}`, 402, code || 'PAYMENT_ERROR', 'square');
  }
}

export class NotFoundError extends BaseError {
  constructor(resource: string) {
    super(`${resource} not found`, 404, 'NOT_FOUND');
  }
}

export class AuthenticationError extends BaseError {
  constructor(message = 'Authentication required') {
    super(message, 401, 'AUTH_ERROR');
  }
}

export class AuthorizationError extends BaseError {
  constructor(message = 'Insufficient permissions') {
    super(message, 403, 'FORBIDDEN');
  }
}

/**
 * Centralized error handling middleware with comprehensive logging and response formatting
 */
export function globalErrorHandler(
  err: AppError | Error,
  req: Request,
  res: Response,
  next: NextFunction
): void {
  // Convert unknown errors to AppError
  let error: AppError;
  if (err instanceof BaseError) {
    error = err;
  } else {
    error = new BaseError('Internal server error', 500, 'INTERNAL_ERROR');
    error.stack = err.stack;
  }

  // Log error with context
  const errorContext = {
    url: req.url,
    method: req.method,
    ip: req.ip,
    userAgent: req.get('User-Agent'),
    timestamp: new Date().toISOString(),
    error: {
      message: error.message,
      statusCode: error.statusCode,
      code: error.code,
      service: error.service,
      stack: error.stack
    }
  };

  if (error.statusCode >= 500) {
    console.error('🚨 Server Error:', JSON.stringify(errorContext, null, 2));
  } else {
    console.warn('⚠️  Client Error:', JSON.stringify(errorContext, null, 2));
  }

  // Send appropriate response
  const response = {
    success: false,
    error: {
      message: error.message,
      code: error.code,
      ...(process.env.NODE_ENV === 'development' && { stack: error.stack })
    }
  };

  res.status(error.statusCode).json(response);
}

/**
 * Async error wrapper to catch promise rejections
 */
export function asyncHandler(fn: Function) {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

/**
 * Database operation wrapper with automatic error handling
 */
export async function withDatabaseErrorHandling<T>(
  operation: () => Promise<T>,
  context?: string
): Promise<T> {
  try {
    return await operation();
  } catch (error: any) {
    const message = context ? `${context}: ${error.message}` : error.message;
    throw new DatabaseError(message, error);
  }
}

/**
 * AI service operation wrapper with automatic error handling
 */
export async function withAIServiceErrorHandling<T>(
  operation: () => Promise<T>,
  service: string
): Promise<T> {
  try {
    return await operation();
  } catch (error: any) {
    throw new AIServiceError(error.message, service);
  }
}

/**
 * Validation helper for required fields
 */
export function validateRequired(data: any, fields: string[]): void {
  const missing = fields.filter(field => !data[field]);
  if (missing.length > 0) {
    throw new ValidationError(`Missing required fields: ${missing.join(', ')}`);
  }
}

/**
 * Patient ID validation with proper error handling
 */
export function validatePatientId(patientId: any): number {
  const id = parseInt(patientId);
  if (isNaN(id) || id <= 0) {
    throw new ValidationError('Invalid patient ID', 'patientId');
  }
  return id;
}

/**
 * Rate limiting error
 */
export class RateLimitError extends BaseError {
  constructor(message = 'Too many requests') {
    super(message, 429, 'RATE_LIMIT');
  }
}

/**
 * Security error for threat detection
 */
export class SecurityError extends BaseError {
  constructor(message: string, threat?: string) {
    super(`Security violation: ${message}`, 403, 'SECURITY_ERROR');
    this.service = threat;
  }
}