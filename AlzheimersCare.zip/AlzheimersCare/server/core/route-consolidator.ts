import type { Express, Request, Response } from 'express';
import { asyncHandler, validateRequired, validatePatientId } from './error-manager';
import { serviceManager } from './service-manager';
import { storage } from '../storage';

/**
 * Consolidated route handlers with improved error handling and validation
 * Reduces code duplication and improves maintainability
 */
export class RouteConsolidator {
  static registerHealthcareRoutes(app: Express): void {
    // Patient management routes
    app.get('/api/patients/:id', asyncHandler(this.getPatient));
    app.post('/api/patients', asyncHandler(this.createPatient));
    app.get('/api/patients/:id/vital-signs', asyncHandler(this.getVitalSigns));
    app.post('/api/patients/:id/vital-signs', asyncHandler(this.createVitalSigns));
    
    // Medication management
    app.get('/api/patients/:id/medications', asyncHandler(this.getMedications));
    app.post('/api/patients/:id/medications', asyncHandler(this.createMedication));
    app.get('/api/patients/:id/medication-logs', asyncHandler(this.getMedicationLogs));
    app.post('/api/patients/:id/medication-logs', asyncHandler(this.createMedicationLog));
    
    // Cognitive activities
    app.get('/api/patients/:id/cognitive-activities', asyncHandler(this.getCognitiveActivities));
    app.post('/api/patients/:id/cognitive-activities', asyncHandler(this.createCognitiveActivity));
    app.get('/api/patients/:id/cognitive-progress', asyncHandler(this.getCognitiveProgress));
    app.post('/api/patients/:id/cognitive-progress', asyncHandler(this.createCognitiveProgress));
    
    // Emergency management
    app.get('/api/patients/:id/emergency-events', asyncHandler(this.getEmergencyEvents));
    app.post('/api/patients/:id/emergency-events', asyncHandler(this.createEmergencyEvent));
    app.patch('/api/emergency-events/:id/acknowledge', asyncHandler(this.acknowledgeEmergency));
    app.patch('/api/emergency-events/:id/resolve', asyncHandler(this.resolveEmergency));
  }

  static registerAIRoutes(app: Express): void {
    // AI analysis and processing
    app.post('/api/ai/analyze-photo', asyncHandler(this.analyzePhoto));
    app.post('/api/ai/process-voice', asyncHandler(this.processVoice));
    app.post('/api/ai/cognitive-assessment', asyncHandler(this.cognitiveAssessment));
    app.post('/api/ai/health-prediction', asyncHandler(this.healthPrediction));
    
    // Translation services
    app.post('/api/ai/translate', asyncHandler(this.translateText));
    app.get('/api/ai/supported-languages', asyncHandler(this.getSupportedLanguages));
  }

  static registerPaymentRoutes(app: Express): void {
    // Square payment integration
    app.post('/api/square/create-customer', asyncHandler(this.createSquareCustomer));
    app.post('/api/square/create-subscription', asyncHandler(this.createSubscription));
    app.get('/api/square/subscription/:id', asyncHandler(this.getSubscription));
    app.patch('/api/square/subscription/:id/pause', asyncHandler(this.pauseSubscription));
    app.patch('/api/square/subscription/:id/resume', asyncHandler(this.resumeSubscription));
    app.delete('/api/square/subscription/:id', asyncHandler(this.cancelSubscription));
  }

  // Patient management handlers
  private static async getPatient(req: Request, res: Response): Promise<void> {
    const patientId = validatePatientId(req.params.id);
    const patient = await storage.getPatient(patientId);
    
    if (!patient) {
      res.status(404).json({ success: false, error: 'Patient not found' });
      return;
    }
    
    res.json({ success: true, patient });
  }

  private static async createPatient(req: Request, res: Response): Promise<void> {
    validateRequired(req.body, ['firstName', 'lastName', 'dateOfBirth']);
    
    const patient = await storage.createPatient(req.body);
    res.status(201).json({ success: true, patient });
  }

  private static async getVitalSigns(req: Request, res: Response): Promise<void> {
    const patientId = validatePatientId(req.params.id);
    const vitalSigns = await storage.getVitalSignsByPatient(patientId);
    res.json({ success: true, vitalSigns });
  }

  private static async createVitalSigns(req: Request, res: Response): Promise<void> {
    const patientId = validatePatientId(req.params.id);
    validateRequired(req.body, ['heartRate', 'bloodPressure', 'temperature']);
    
    const vitalSignsData = { ...req.body, patientId };
    const vitalSigns = await storage.createVitalSigns(vitalSignsData);
    
    res.status(201).json({ success: true, vitalSigns });
  }

  // Medication management handlers
  private static async getMedications(req: Request, res: Response): Promise<void> {
    const patientId = validatePatientId(req.params.id);
    const medications = await storage.getMedicationsByPatient(patientId);
    res.json({ success: true, medications });
  }

  private static async createMedication(req: Request, res: Response): Promise<void> {
    const patientId = validatePatientId(req.params.id);
    validateRequired(req.body, ['name', 'dosage', 'frequency']);
    
    const medicationData = { ...req.body, patientId };
    const medication = await storage.createMedication(medicationData);
    
    res.status(201).json({ success: true, medication });
  }

  private static async getMedicationLogs(req: Request, res: Response): Promise<void> {
    const patientId = validatePatientId(req.params.id);
    const logs = await storage.getMedicationLogsByPatient(patientId);
    res.json({ success: true, logs });
  }

  private static async createMedicationLog(req: Request, res: Response): Promise<void> {
    const patientId = validatePatientId(req.params.id);
    validateRequired(req.body, ['medicationId', 'status']);
    
    const logData = { ...req.body, patientId };
    const log = await storage.createMedicationLog(logData);
    
    res.status(201).json({ success: true, log });
  }

  // AI service handlers
  private static async analyzePhoto(req: Request, res: Response): Promise<void> {
    validateRequired(req.body, ['imageData']);
    
    const openaiService = serviceManager.getService('openai');
    const analysis = await openaiService.analyzeImage(req.body.imageData);
    
    res.json({ success: true, analysis });
  }

  private static async processVoice(req: Request, res: Response): Promise<void> {
    validateRequired(req.body, ['audioData']);
    
    const voiceService = serviceManager.getService('voice');
    const result = await voiceService.processAudio(req.body.audioData);
    
    res.json({ success: true, result });
  }

  private static async cognitiveAssessment(req: Request, res: Response): Promise<void> {
    const patientId = validatePatientId(req.body.patientId);
    validateRequired(req.body, ['assessmentData']);
    
    const openaiService = serviceManager.getService('openai');
    const assessment = await openaiService.analyzeCognitiveFunction(req.body.assessmentData);
    
    // Store assessment results
    const progressData = {
      patientId,
      ...assessment,
      notes: req.body.notes || null
    };
    
    const progress = await storage.createCognitiveProgress(progressData);
    res.json({ success: true, assessment, progress });
  }

  private static async translateText(req: Request, res: Response): Promise<void> {
    validateRequired(req.body, ['text', 'targetLanguage']);
    
    const translationService = serviceManager.getService('translation');
    const translation = await translationService.translate(
      req.body.text,
      req.body.targetLanguage,
      req.body.sourceLanguage
    );
    
    res.json({ success: true, translation });
  }

  private static async getSupportedLanguages(req: Request, res: Response): Promise<void> {
    const translationService = serviceManager.getService('translation');
    const languages = await translationService.getSupportedLanguages();
    
    res.json({ success: true, languages });
  }

  // Payment handlers
  private static async createSquareCustomer(req: Request, res: Response): Promise<void> {
    validateRequired(req.body, ['email', 'firstName', 'lastName']);
    
    const squareService = serviceManager.getService('square');
    const customer = await squareService.createCustomer(req.body);
    
    res.json({ success: true, customer });
  }

  private static async createSubscription(req: Request, res: Response): Promise<void> {
    validateRequired(req.body, ['customerId', 'planId']);
    
    const squareService = serviceManager.getService('square');
    const subscription = await squareService.createSubscription(req.body);
    
    res.json({ success: true, subscription });
  }

  private static async getSubscription(req: Request, res: Response): Promise<void> {
    const subscriptionId = req.params.id;
    
    const squareService = serviceManager.getService('square');
    const subscription = await squareService.getSubscription(subscriptionId);
    
    res.json({ success: true, subscription });
  }

  private static async pauseSubscription(req: Request, res: Response): Promise<void> {
    const subscriptionId = req.params.id;
    
    const squareService = serviceManager.getService('square');
    const subscription = await squareService.pauseSubscription(subscriptionId);
    
    res.json({ success: true, subscription });
  }

  private static async resumeSubscription(req: Request, res: Response): Promise<void> {
    const subscriptionId = req.params.id;
    
    const squareService = serviceManager.getService('square');
    const subscription = await squareService.resumeSubscription(subscriptionId);
    
    res.json({ success: true, subscription });
  }

  private static async cancelSubscription(req: Request, res: Response): Promise<void> {
    const subscriptionId = req.params.id;
    
    const squareService = serviceManager.getService('square');
    const result = await squareService.cancelSubscription(subscriptionId);
    
    res.json({ success: true, result });
  }

  // Emergency management handlers
  private static async getEmergencyEvents(req: Request, res: Response): Promise<void> {
    const patientId = validatePatientId(req.params.id);
    const events = await storage.getEmergencyEventsByPatient(patientId);
    res.json({ success: true, events });
  }

  private static async createEmergencyEvent(req: Request, res: Response): Promise<void> {
    const patientId = validatePatientId(req.params.id);
    validateRequired(req.body, ['eventType', 'severity']);
    
    const eventData = { ...req.body, patientId, status: 'active' };
    const event = await storage.createEmergencyEvent(eventData);
    
    res.status(201).json({ success: true, event });
  }

  private static async acknowledgeEmergency(req: Request, res: Response): Promise<void> {
    const eventId = parseInt(req.params.id);
    const userId = req.body.userId || 1; // Default for now
    
    const event = await storage.acknowledgeEmergency(eventId, userId);
    res.json({ success: true, event });
  }

  private static async resolveEmergency(req: Request, res: Response): Promise<void> {
    const eventId = parseInt(req.params.id);
    
    const event = await storage.resolveEmergency(eventId);
    res.json({ success: true, event });
  }

  // Cognitive activity handlers
  private static async getCognitiveActivities(req: Request, res: Response): Promise<void> {
    const patientId = validatePatientId(req.params.id);
    const activities = await storage.getCognitiveActivitiesByPatient(patientId);
    res.json({ success: true, activities });
  }

  private static async createCognitiveActivity(req: Request, res: Response): Promise<void> {
    const patientId = validatePatientId(req.params.id);
    validateRequired(req.body, ['activityType', 'difficulty']);
    
    const activityData = { ...req.body, patientId };
    const activity = await storage.createCognitiveActivity(activityData);
    
    res.status(201).json({ success: true, activity });
  }

  private static async getCognitiveProgress(req: Request, res: Response): Promise<void> {
    const patientId = validatePatientId(req.params.id);
    const progress = await storage.getCognitiveProgressByPatient(patientId);
    res.json({ success: true, progress });
  }

  private static async createCognitiveProgress(req: Request, res: Response): Promise<void> {
    const patientId = validatePatientId(req.params.id);
    validateRequired(req.body, ['assessmentDate']);
    
    const progressData = { ...req.body, patientId };
    const progress = await storage.createCognitiveProgress(progressData);
    
    res.status(201).json({ success: true, progress });
  }

  private static async healthPrediction(req: Request, res: Response): Promise<void> {
    const patientId = validatePatientId(req.body.patientId);
    
    // Get latest vital signs and medical history
    const vitalSigns = await storage.getLatestVitalSigns(patientId);
    const cognitiveProgress = await storage.getLatestCognitiveProgress(patientId);
    
    if (!vitalSigns) {
      res.status(400).json({ 
        success: false, 
        error: 'No vital signs data available for prediction' 
      });
      return;
    }
    
    const openaiService = serviceManager.getService('openai');
    const prediction = await openaiService.predictHealthEvents({
      vitalSigns,
      cognitiveProgress,
      patientId
    });
    
    res.json({ success: true, prediction });
  }
}