/**
 * Centralized Database Management System
 * Resilient operations with connection pooling, transaction safety, and error recovery
 */

import { Pool } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import * as schema from '@shared/schema';
import { eq, desc, and, or } from 'drizzle-orm';
import { SecurityManager } from './security-manager';

export class DatabaseManager {
  private static instance: DatabaseManager;
  private db: any;
  private pool: Pool;
  private connectionAttempts = 0;
  private maxRetries = 3;

  private constructor() {
    if (!process.env.DATABASE_URL) {
      throw new Error('DATABASE_URL environment variable is required');
    }

    this.pool = new Pool({ 
      connectionString: process.env.DATABASE_URL,
      max: 20,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 5000,
    });

    this.db = drizzle({ client: this.pool, schema });
  }

  static getInstance(): DatabaseManager {
    if (!DatabaseManager.instance) {
      DatabaseManager.instance = new DatabaseManager();
    }
    return DatabaseManager.instance;
  }

  // Connection Management with Retry Logic
  private async withRetry<T>(operation: () => Promise<T>): Promise<T> {
    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        return await operation();
      } catch (error: any) {
        console.error(`Database operation failed (attempt ${attempt}/${this.maxRetries}):`, error.message);
        
        if (attempt === this.maxRetries) {
          throw new Error(`Database operation failed after ${this.maxRetries} attempts: ${error.message}`);
        }
        
        // Exponential backoff
        await new Promise(resolve => setTimeout(resolve, Math.pow(2, attempt) * 1000));
      }
    }
    throw new Error('Unexpected retry loop exit');
  }

  // Transaction Management
  private async executeTransaction<T>(callback: (tx: any) => Promise<T>): Promise<T> {
    return this.withRetry(async () => {
      return await this.db.transaction(callback);
    });
  }

  // Patient Management
  async getPatient(patientId: number): Promise<any> {
    return this.withRetry(async () => {
      const [patient] = await this.db
        .select()
        .from(schema.patients)
        .where(eq(schema.patients.id, patientId));
      return patient;
    });
  }

  async createPatient(patientData: any): Promise<any> {
    const validation = SecurityManager.validatePatientData(patientData);
    if (!validation.isValid) {
      throw new Error(`Invalid patient data: ${validation.errors.join(', ')}`);
    }

    return this.executeTransaction(async (tx) => {
      const [patient] = await tx
        .insert(schema.patients)
        .values({
          ...SecurityManager.sanitizeInput(patientData),
          createdAt: new Date(),
        })
        .returning();
      
      SecurityManager.auditLog('PATIENT_CREATED', 'system', patient.id.toString());
      return patient;
    });
  }

  // Vital Signs Management
  async getVitalSigns(patientId: number, limit = 50): Promise<any[]> {
    return this.withRetry(async () => {
      return await this.db
        .select()
        .from(schema.vitalSigns)
        .where(eq(schema.vitalSigns.patientId, patientId))
        .orderBy(desc(schema.vitalSigns.recordedAt))
        .limit(limit);
    });
  }

  async createVitalSigns(vitalData: any): Promise<any> {
    return this.executeTransaction(async (tx) => {
      const [vital] = await tx
        .insert(schema.vitalSigns)
        .values({
          ...SecurityManager.sanitizeInput(vitalData),
          recordedAt: new Date(),
        })
        .returning();
      
      SecurityManager.auditLog('VITAL_SIGNS_RECORDED', 'system', vitalData.patientId.toString());
      return vital;
    });
  }

  // Medication Management
  async getMedications(patientId: number): Promise<any[]> {
    return this.withRetry(async () => {
      return await this.db
        .select()
        .from(schema.medications)
        .where(eq(schema.medications.patientId, patientId));
    });
  }

  async createMedication(medicationData: any): Promise<any> {
    return this.executeTransaction(async (tx) => {
      const [medication] = await tx
        .insert(schema.medications)
        .values({
          ...SecurityManager.sanitizeInput(medicationData),
          createdAt: new Date(),
        })
        .returning();
      
      SecurityManager.auditLog('MEDICATION_ADDED', 'system', medicationData.patientId.toString());
      return medication;
    });
  }

  // Emergency Events Management
  async getEmergencyEvents(patientId: number): Promise<any[]> {
    return this.withRetry(async () => {
      return await this.db
        .select()
        .from(schema.emergencyEvents)
        .where(eq(schema.emergencyEvents.patientId, patientId))
        .orderBy(desc(schema.emergencyEvents.createdAt));
    });
  }

  async createEmergencyEvent(eventData: any): Promise<any> {
    return this.executeTransaction(async (tx) => {
      const [event] = await tx
        .insert(schema.emergencyEvents)
        .values({
          ...SecurityManager.sanitizeInput(eventData),
          createdAt: new Date(),
        })
        .returning();
      
      SecurityManager.auditLog('EMERGENCY_EVENT_CREATED', 'system', eventData.patientId.toString(), {
        eventType: eventData.eventType,
        severity: eventData.severity
      });
      
      return event;
    });
  }

  // Family Relationships Management
  async getFamilyRelationships(patientId: number): Promise<any[]> {
    return this.withRetry(async () => {
      return await this.db
        .select()
        .from(schema.familyRelationships)
        .where(eq(schema.familyRelationships.patientId, patientId));
    });
  }

  // Trial Analytics Management
  async createTrialAnalytics(trialData: any): Promise<any> {
    return this.executeTransaction(async (tx) => {
      const [trial] = await tx
        .insert(schema.trialAnalytics)
        .values({
          ...SecurityManager.sanitizeInput(trialData),
          createdAt: new Date(),
        })
        .returning();
      
      SecurityManager.auditLog('TRIAL_ANALYTICS_CREATED', 'system', undefined, {
        email: trialData.email,
        trialStatus: trialData.trialStatus
      });
      
      return trial;
    });
  }

  // User Management
  async getUser(userId: string): Promise<any> {
    return this.withRetry(async () => {
      const [user] = await this.db
        .select()
        .from(schema.users)
        .where(eq(schema.users.id, userId));
      return user;
    });
  }

  async createUser(userData: any): Promise<any> {
    return this.executeTransaction(async (tx) => {
      const [user] = await tx
        .insert(schema.users)
        .values({
          ...SecurityManager.sanitizeInput(userData),
          createdAt: new Date(),
        })
        .returning();
      
      SecurityManager.auditLog('USER_CREATED', user.id);
      return user;
    });
  }

  // Facility Management
  async getFacilities(): Promise<any[]> {
    return this.withRetry(async () => {
      return await this.db.select().from(schema.facilities);
    });
  }

  async createFacility(facilityData: any): Promise<any> {
    return this.executeTransaction(async (tx) => {
      const [facility] = await tx
        .insert(schema.facilities)
        .values({
          ...SecurityManager.sanitizeInput(facilityData),
          createdAt: new Date(),
        })
        .returning();
      
      SecurityManager.auditLog('FACILITY_CREATED', 'system', undefined, { facilityId: facility.id });
      return facility;
    });
  }

  // Health Check
  async healthCheck(): Promise<{ status: string; details: any }> {
    try {
      const start = Date.now();
      await this.db.select().from(schema.users).limit(1);
      const responseTime = Date.now() - start;
      
      return {
        status: 'healthy',
        details: {
          responseTime: `${responseTime}ms`,
          connectionPool: {
            total: this.pool.totalCount,
            idle: this.pool.idleCount,
            waiting: this.pool.waitingCount
          }
        }
      };
    } catch (error: any) {
      return {
        status: 'unhealthy',
        details: { error: error.message }
      };
    }
  }

  // Cleanup and Connection Management
  async closeConnections(): Promise<void> {
    try {
      await this.pool.end();
      console.log('Database connections closed successfully');
    } catch (error: any) {
      console.error('Error closing database connections:', error.message);
    }
  }
}

// Export singleton instance
export const dbManager = DatabaseManager.getInstance();