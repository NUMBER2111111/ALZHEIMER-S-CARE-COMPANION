import { OpenAIService } from '../services/openai';
import { EncryptionService } from '../services/encryption';
import { SquarePaymentService } from '../services/square-payments';
import { TranslationService } from '../services/translation';
import { VoiceService } from '../services/advanced-voice';
import { ThreatDetectionService } from '../services/advanced-threat-detection';

/**
 * Centralized service manager for dependency injection and lifecycle management
 * Ensures consistent initialization, error handling, and resource cleanup
 */
export class ServiceManager {
  private static instance: ServiceManager;
  private services: Map<string, any> = new Map();
  private initialized = false;

  private constructor() {}

  static getInstance(): ServiceManager {
    if (!ServiceManager.instance) {
      ServiceManager.instance = new ServiceManager();
    }
    return ServiceManager.instance;
  }

  async initialize(): Promise<void> {
    if (this.initialized) return;

    try {
      // Initialize core services with dependency order
      const encryptionService = new EncryptionService();
      this.services.set('encryption', encryptionService);

      const openaiService = new OpenAIService();
      this.services.set('openai', openaiService);

      const translationService = new TranslationService();
      this.services.set('translation', translationService);

      const voiceService = new VoiceService();
      this.services.set('voice', voiceService);

      const threatDetection = new ThreatDetectionService();
      this.services.set('threatDetection', threatDetection);

      const squareService = new SquarePaymentService();
      this.services.set('square', squareService);

      // Validate all services are properly initialized
      await this.validateServices();
      
      this.initialized = true;
      console.log('✅ All services initialized successfully');
    } catch (error) {
      console.error('❌ Service initialization failed:', error);
      throw new Error(`Service manager initialization failed: ${error.message}`);
    }
  }

  getService<T>(serviceName: string): T {
    if (!this.initialized) {
      throw new Error('ServiceManager not initialized. Call initialize() first.');
    }

    const service = this.services.get(serviceName);
    if (!service) {
      throw new Error(`Service '${serviceName}' not found`);
    }
    return service;
  }

  private async validateServices(): Promise<void> {
    const validationPromises = Array.from(this.services.entries()).map(
      async ([name, service]) => {
        try {
          if (service.healthCheck && typeof service.healthCheck === 'function') {
            await service.healthCheck();
          }
          return { name, status: 'healthy' };
        } catch (error) {
          console.warn(`⚠️  Service ${name} health check failed:`, error.message);
          return { name, status: 'degraded', error: error.message };
        }
      }
    );

    const results = await Promise.all(validationPromises);
    const unhealthyServices = results.filter(r => r.status === 'degraded');
    
    if (unhealthyServices.length > 0) {
      console.warn('Some services are running in degraded mode:', unhealthyServices);
    }
  }

  async shutdown(): Promise<void> {
    for (const [name, service] of this.services.entries()) {
      try {
        if (service.cleanup && typeof service.cleanup === 'function') {
          await service.cleanup();
        }
      } catch (error) {
        console.error(`Error shutting down ${name}:`, error);
      }
    }
    this.services.clear();
    this.initialized = false;
  }
}

export const serviceManager = ServiceManager.getInstance();