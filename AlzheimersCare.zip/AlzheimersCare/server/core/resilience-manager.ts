/**
 * Resilience and Fault Tolerance Management System
 * Circuit breakers, graceful degradation, and system recovery
 */

import { EventEmitter } from 'events';

export enum ServiceStatus {
  HEALTHY = 'healthy',
  DEGRADED = 'degraded',
  UNHEALTHY = 'unhealthy',
  CIRCUIT_OPEN = 'circuit_open'
}

export interface ServiceMetrics {
  successCount: number;
  failureCount: number;
  totalRequests: number;
  averageResponseTime: number;
  lastFailure?: Date;
  lastSuccess?: Date;
}

export class CircuitBreaker extends EventEmitter {
  private failureThreshold: number;
  private recoveryTimeout: number;
  private monitoringPeriod: number;
  private state: 'CLOSED' | 'OPEN' | 'HALF_OPEN' = 'CLOSED';
  private failureCount = 0;
  private lastFailureTime?: Date;
  private nextAttempt?: Date;

  constructor(
    private serviceName: string,
    options: {
      failureThreshold?: number;
      recoveryTimeout?: number;
      monitoringPeriod?: number;
    } = {}
  ) {
    super();
    this.failureThreshold = options.failureThreshold || 5;
    this.recoveryTimeout = options.recoveryTimeout || 60000; // 1 minute
    this.monitoringPeriod = options.monitoringPeriod || 300000; // 5 minutes
  }

  async execute<T>(operation: () => Promise<T>): Promise<T> {
    if (this.state === 'OPEN') {
      if (this.nextAttempt && Date.now() < this.nextAttempt.getTime()) {
        throw new Error(`Circuit breaker is OPEN for ${this.serviceName}`);
      } else {
        this.state = 'HALF_OPEN';
        this.emit('state_change', { service: this.serviceName, state: this.state });
      }
    }

    try {
      const result = await operation();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }

  private onSuccess(): void {
    this.failureCount = 0;
    if (this.state === 'HALF_OPEN') {
      this.state = 'CLOSED';
      this.emit('state_change', { service: this.serviceName, state: this.state });
      console.log(`Circuit breaker CLOSED for ${this.serviceName}`);
    }
  }

  private onFailure(): void {
    this.failureCount++;
    this.lastFailureTime = new Date();

    if (this.failureCount >= this.failureThreshold) {
      this.state = 'OPEN';
      this.nextAttempt = new Date(Date.now() + this.recoveryTimeout);
      this.emit('state_change', { service: this.serviceName, state: this.state });
      console.log(`Circuit breaker OPEN for ${this.serviceName}`);
    }
  }

  getState(): { state: string; failureCount: number; lastFailure?: Date } {
    return {
      state: this.state,
      failureCount: this.failureCount,
      lastFailure: this.lastFailureTime
    };
  }
}

export class ResilienceManager {
  private static instance: ResilienceManager;
  private circuitBreakers = new Map<string, CircuitBreaker>();
  private serviceMetrics = new Map<string, ServiceMetrics>();
  private healthCheckInterval?: NodeJS.Timeout;

  private constructor() {
    this.initializeCircuitBreakers();
    this.startHealthMonitoring();
  }

  static getInstance(): ResilienceManager {
    if (!ResilienceManager.instance) {
      ResilienceManager.instance = new ResilienceManager();
    }
    return ResilienceManager.instance;
  }

  private initializeCircuitBreakers(): void {
    // Database circuit breaker
    const dbCircuitBreaker = new CircuitBreaker('database', {
      failureThreshold: 3,
      recoveryTimeout: 30000
    });

    // OpenAI circuit breaker
    const aiCircuitBreaker = new CircuitBreaker('openai', {
      failureThreshold: 5,
      recoveryTimeout: 60000
    });

    // Square Pay circuit breaker
    const paymentCircuitBreaker = new CircuitBreaker('square-payment', {
      failureThreshold: 3,
      recoveryTimeout: 120000
    });

    // ElevenLabs voice circuit breakers
    const elevenLabsTtsCircuitBreaker = new CircuitBreaker('elevenlabs-tts', {
      failureThreshold: 5,
      recoveryTimeout: 30000
    });

    const elevenLabsVoicesCircuitBreaker = new CircuitBreaker('elevenlabs-voices', {
      failureThreshold: 3,
      recoveryTimeout: 60000
    });

    const elevenLabsUsageCircuitBreaker = new CircuitBreaker('elevenlabs-usage', {
      failureThreshold: 3,
      recoveryTimeout: 60000
    });

    this.circuitBreakers.set('database', dbCircuitBreaker);
    this.circuitBreakers.set('openai', aiCircuitBreaker);
    this.circuitBreakers.set('square-payment', paymentCircuitBreaker);
    this.circuitBreakers.set('elevenlabs-tts', elevenLabsTtsCircuitBreaker);
    this.circuitBreakers.set('elevenlabs-voices', elevenLabsVoicesCircuitBreaker);
    this.circuitBreakers.set('elevenlabs-usage', elevenLabsUsageCircuitBreaker);

    // Initialize metrics
    this.serviceMetrics.set('database', this.createEmptyMetrics());
    this.serviceMetrics.set('openai', this.createEmptyMetrics());
    this.serviceMetrics.set('square-payment', this.createEmptyMetrics());
    this.serviceMetrics.set('elevenlabs-tts', this.createEmptyMetrics());
    this.serviceMetrics.set('elevenlabs-voices', this.createEmptyMetrics());
    this.serviceMetrics.set('elevenlabs-usage', this.createEmptyMetrics());
  }

  private createEmptyMetrics(): ServiceMetrics {
    return {
      successCount: 0,
      failureCount: 0,
      totalRequests: 0,
      averageResponseTime: 0
    };
  }

  async executeWithCircuitBreaker<T>(
    serviceName: string,
    operation: () => Promise<T>
  ): Promise<T> {
    const circuitBreaker = this.circuitBreakers.get(serviceName);
    if (!circuitBreaker) {
      throw new Error(`No circuit breaker found for service: ${serviceName}`);
    }

    const startTime = Date.now();
    const metrics = this.serviceMetrics.get(serviceName)!;

    try {
      const result = await circuitBreaker.execute(operation);
      
      // Update success metrics
      const responseTime = Date.now() - startTime;
      metrics.successCount++;
      metrics.totalRequests++;
      metrics.lastSuccess = new Date();
      metrics.averageResponseTime = 
        (metrics.averageResponseTime * (metrics.totalRequests - 1) + responseTime) / metrics.totalRequests;

      return result;
    } catch (error) {
      // Update failure metrics
      metrics.failureCount++;
      metrics.totalRequests++;
      metrics.lastFailure = new Date();
      
      throw error;
    }
  }

  // Graceful degradation strategies
  async getDegradedResponse(serviceName: string, fallbackData?: any): Promise<any> {
    switch (serviceName) {
      case 'openai':
        return {
          success: false,
          message: 'AI service temporarily unavailable. Using cached responses.',
          fallback: true,
          data: fallbackData || { analysis: 'Service degraded - using basic processing' }
        };

      case 'square-payment':
        return {
          success: false,
          message: 'Payment processing temporarily unavailable. Please try again later.',
          fallback: true,
          retryAfter: 300000 // 5 minutes
        };

      case 'database':
        return {
          success: false,
          message: 'Database temporarily unavailable. Using cached data.',
          fallback: true,
          data: fallbackData || {}
        };

      default:
        return {
          success: false,
          message: `Service ${serviceName} temporarily unavailable.`,
          fallback: true
        };
    }
  }

  getServiceStatus(serviceName: string): ServiceStatus {
    const circuitBreaker = this.circuitBreakers.get(serviceName);
    const metrics = this.serviceMetrics.get(serviceName);

    if (!circuitBreaker || !metrics) {
      return ServiceStatus.UNHEALTHY;
    }

    const state = circuitBreaker.getState();
    
    if (state.state === 'OPEN') {
      return ServiceStatus.CIRCUIT_OPEN;
    }

    if (metrics.totalRequests === 0) {
      return ServiceStatus.HEALTHY;
    }

    const failureRate = metrics.failureCount / metrics.totalRequests;
    
    if (failureRate > 0.5) {
      return ServiceStatus.UNHEALTHY;
    } else if (failureRate > 0.1) {
      return ServiceStatus.DEGRADED;
    }

    return ServiceStatus.HEALTHY;
  }

  getSystemHealth(): {
    overallStatus: ServiceStatus;
    services: Record<string, { status: ServiceStatus; metrics: ServiceMetrics; circuitState: any }>;
  } {
    const services: Record<string, any> = {};
    let healthyServices = 0;
    let totalServices = 0;

    for (const [serviceName] of this.circuitBreakers) {
      const status = this.getServiceStatus(serviceName);
      const metrics = this.serviceMetrics.get(serviceName)!;
      const circuitBreaker = this.circuitBreakers.get(serviceName)!;

      services[serviceName] = {
        status,
        metrics,
        circuitState: circuitBreaker.getState()
      };

      if (status === ServiceStatus.HEALTHY) {
        healthyServices++;
      }
      totalServices++;
    }

    let overallStatus: ServiceStatus;
    const healthyRatio = healthyServices / totalServices;

    if (healthyRatio === 1) {
      overallStatus = ServiceStatus.HEALTHY;
    } else if (healthyRatio >= 0.5) {
      overallStatus = ServiceStatus.DEGRADED;
    } else {
      overallStatus = ServiceStatus.UNHEALTHY;
    }

    return { overallStatus, services };
  }

  private startHealthMonitoring(): void {
    this.healthCheckInterval = setInterval(() => {
      const health = this.getSystemHealth();
      
      if (health.overallStatus !== ServiceStatus.HEALTHY) {
        console.warn('[RESILIENCE] System health degraded:', health);
      }

      // Reset metrics periodically to prevent memory accumulation
      for (const [serviceName, metrics] of this.serviceMetrics) {
        if (metrics.totalRequests > 10000) {
          this.serviceMetrics.set(serviceName, this.createEmptyMetrics());
        }
      }
    }, 60000); // Check every minute
  }

  shutdown(): void {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
    }
  }
}

// Export singleton instance
export const resilienceManager = ResilienceManager.getInstance();