import type { Request, Response, NextFunction } from 'express';

export interface AppError extends Error {
  statusCode: number;
  isOperational: boolean;
}

export class DatabaseError extends Error implements AppError {
  statusCode = 500;
  isOperational = true;

  constructor(message: string, public originalError?: Error) {
    super(message);
    this.name = 'DatabaseError';
  }
}

export class ValidationError extends Error implements AppError {
  statusCode = 400;
  isOperational = true;

  constructor(message: string, public field?: string) {
    super(message);
    this.name = 'ValidationError';
  }
}

export class NotFoundError extends Error implements AppError {
  statusCode = 404;
  isOperational = true;

  constructor(resource: string) {
    super(`${resource} not found`);
    this.name = 'NotFoundError';
  }
}

export class AIServiceError extends Error implements AppError {
  statusCode = 503;
  isOperational = true;

  constructor(message: string, public service?: string) {
    super(message);
    this.name = 'AIServiceError';
  }
}

export function handleAsyncErrors(fn: Function) {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

export function globalErrorHandler(
  err: AppError,
  req: Request,
  res: Response,
  next: NextFunction
) {
  const { statusCode = 500, message, name } = err;

  console.error(`[${name}] ${message}`, {
    url: req.url,
    method: req.method,
    stack: err.stack,
  });

  res.status(statusCode).json({
    error: {
      name,
      message: err.isOperational ? message : 'Internal server error',
    },
  });
}

export function validateRequired(data: any, fields: string[]): void {
  for (const field of fields) {
    if (!data[field] && data[field] !== 0) {
      throw new ValidationError(`${field} is required`, field);
    }
  }
}

export function validatePatientId(patientId: any): number {
  const id = parseInt(patientId);
  if (isNaN(id) || id <= 0) {
    throw new ValidationError('Invalid patient ID', 'patientId');
  }
  return id;
}

export function withDatabaseErrorHandling<T>(operation: () => Promise<T>): Promise<T> {
  return operation().catch((error) => {
    console.error('Database operation failed:', error);
    throw new DatabaseError('Database operation failed', error);
  });
}

export function withAIServiceErrorHandling<T>(operation: () => Promise<T>, service: string): Promise<T> {
  return operation().catch((error) => {
    console.error(`AI service ${service} failed:`, error);
    throw new AIServiceError(`AI service ${service} temporarily unavailable`, service);
  });
}