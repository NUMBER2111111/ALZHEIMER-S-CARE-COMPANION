import {
  users,
  patients,
  facilities,
  familyRelationships,
  familyMemories,
  cognitiveActivities,
  activitySessions,
  cognitiveProgress,
  vitalSigns,
  medications,
  medicationLogs,
  gameActivities,
  emergencyEvents,
  moodEntries,
  companionResponses,
  type User,
  type InsertUser,
  type Patient,
  type InsertPatient,
  type Facility,
  type InsertFacility,
  type FamilyRelationship,
  type InsertFamilyRelationship,
  type FamilyMemory,
  type InsertFamilyMemory,
  type CognitiveActivity,
  type InsertCognitiveActivity,
  type ActivitySession,
  type InsertActivitySession,
  type CognitiveProgress,
  type InsertCognitiveProgress,
  type VitalSigns,
  type InsertVitalSigns,
  type Medication,
  type InsertMedication,
  type MedicationLog,
  type InsertMedicationLog,
  type GameActivity,
  type InsertGameActivity,
  type EmergencyEvent,
  type InsertEmergencyEvent,
  type MoodEntry,
  type InsertMoodEntry,
  type CompanionResponse,
  type InsertCompanionResponse,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, lt, gte } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUsersByType(userType: string): Promise<User[]>;

  // Patient operations
  getPatient(id: number): Promise<Patient | undefined>;
  createPatient(patient: InsertPatient): Promise<Patient>;
  getPatientsByFacility(facilityId: number): Promise<Patient[]>;

  // Facility operations
  getFacility(id: number): Promise<Facility | undefined>;
  createFacility(facility: InsertFacility): Promise<Facility>;
  getFacilities(): Promise<Facility[]>;

  // Family relationship operations
  createFamilyRelationship(relationship: InsertFamilyRelationship): Promise<FamilyRelationship>;
  getFamilyRelationshipsByPatient(patientId: number): Promise<FamilyRelationship[]>;
  getFamilyRelationshipsByMember(familyMemberId: number): Promise<FamilyRelationship[]>;

  // Family memory operations
  createFamilyMemory(memory: InsertFamilyMemory): Promise<FamilyMemory>;
  getFamilyMemoriesByPatient(patientId: number): Promise<FamilyMemory[]>;
  getFamilyMemory(id: number): Promise<FamilyMemory | undefined>;

  // Cognitive activity operations
  createCognitiveActivity(activity: InsertCognitiveActivity): Promise<CognitiveActivity>;
  getCognitiveActivitiesByPatient(patientId: number): Promise<CognitiveActivity[]>;
  getCognitiveActivity(id: number): Promise<CognitiveActivity | undefined>;

  // Activity session operations
  createActivitySession(session: InsertActivitySession): Promise<ActivitySession>;
  updateActivitySession(id: number, updates: Partial<ActivitySession>): Promise<ActivitySession>;
  getActivitySessionsByPatient(patientId: number): Promise<ActivitySession[]>;

  // Progress tracking operations
  createCognitiveProgress(progress: InsertCognitiveProgress): Promise<CognitiveProgress>;
  getCognitiveProgressByPatient(patientId: number): Promise<CognitiveProgress[]>;
  getLatestCognitiveProgress(patientId: number): Promise<CognitiveProgress | undefined>;

  // Emergency monitoring and vital signs operations
  createVitalSigns(vitalSigns: InsertVitalSigns): Promise<VitalSigns>;
  getVitalSignsByPatient(patientId: number): Promise<VitalSigns[]>;
  getLatestVitalSigns(patientId: number): Promise<VitalSigns | undefined>;
  getEmergencyAlerts(patientId?: number): Promise<VitalSigns[]>;

  // Medicine tracking operations
  createMedication(medication: InsertMedication): Promise<Medication>;
  getMedicationsByPatient(patientId: number): Promise<Medication[]>;
  updateMedication(id: number, updates: Partial<Medication>): Promise<Medication>;
  createMedicationLog(log: InsertMedicationLog): Promise<MedicationLog>;
  getMedicationLogsByPatient(patientId: number): Promise<MedicationLog[]>;
  getMissedMedications(patientId: number): Promise<MedicationLog[]>;

  // AI Gaming operations
  createGameActivity(activity: InsertGameActivity): Promise<GameActivity>;
  getGameActivitiesByPatient(patientId: number): Promise<GameActivity[]>;
  updateGameActivity(id: number, updates: Partial<GameActivity>): Promise<GameActivity>;
  getActiveGames(patientId: number): Promise<GameActivity[]>;

  // Emergency response operations
  createEmergencyEvent(event: InsertEmergencyEvent): Promise<EmergencyEvent>;
  getEmergencyEventsByPatient(patientId: number): Promise<EmergencyEvent[]>;
  getActiveEmergencies(facilityId?: number): Promise<EmergencyEvent[]>;
  acknowledgeEmergency(eventId: number, userId: number): Promise<EmergencyEvent>;
  resolveEmergency(eventId: number): Promise<EmergencyEvent>;

  // Subscription management operations
  updateUserSubscription(userId: number, updates: Partial<User>): Promise<User>;
  getUserSubscriptionStatus(userId: number): Promise<User | undefined>;
  getExpiredTrials(): Promise<User[]>;

  // Mood tracking operations
  createMoodEntry(moodEntry: InsertMoodEntry): Promise<MoodEntry>;
  getMoodEntriesByPatient(patientId: number, limit?: number): Promise<MoodEntry[]>;
  getLatestMoodEntry(patientId: number): Promise<MoodEntry | undefined>;
  getMoodTrends(patientId: number, days?: number): Promise<MoodEntry[]>;
  createCompanionResponse(response: InsertCompanionResponse): Promise<CompanionResponse>;
  getCompanionResponsesByMoodEntry(moodEntryId: number): Promise<CompanionResponse[]>;
  updateCompanionResponseDelivery(responseId: number, delivered: boolean, reaction?: string): Promise<CompanionResponse>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getUsersByType(userType: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.userType, userType));
  }

  // Patient operations
  async getPatient(id: number): Promise<Patient | undefined> {
    const [patient] = await db.select().from(patients).where(eq(patients.id, id));
    return patient;
  }

  async createPatient(insertPatient: InsertPatient): Promise<Patient> {
    const [patient] = await db.insert(patients).values(insertPatient).returning();
    return patient;
  }

  async getPatientsByFacility(facilityId: number): Promise<Patient[]> {
    return await db.select().from(patients).where(eq(patients.facilityId, facilityId));
  }

  // Facility operations
  async getFacility(id: number): Promise<Facility | undefined> {
    const [facility] = await db.select().from(facilities).where(eq(facilities.id, id));
    return facility;
  }

  async createFacility(insertFacility: InsertFacility): Promise<Facility> {
    const [facility] = await db.insert(facilities).values(insertFacility).returning();
    return facility;
  }

  async getFacilities(): Promise<Facility[]> {
    return await db.select().from(facilities);
  }

  // Family relationship operations
  async createFamilyRelationship(insertRelationship: InsertFamilyRelationship): Promise<FamilyRelationship> {
    const [relationship] = await db.insert(familyRelationships).values(insertRelationship).returning();
    return relationship;
  }

  async getFamilyRelationshipsByPatient(patientId: number): Promise<FamilyRelationship[]> {
    return await db.select().from(familyRelationships).where(eq(familyRelationships.patientId, patientId));
  }

  async getFamilyRelationshipsByMember(familyMemberId: number): Promise<FamilyRelationship[]> {
    return await db.select().from(familyRelationships).where(eq(familyRelationships.familyMemberId, familyMemberId));
  }

  // Family memory operations
  async createFamilyMemory(insertMemory: InsertFamilyMemory): Promise<FamilyMemory> {
    const [memory] = await db.insert(familyMemories).values(insertMemory).returning();
    return memory;
  }

  async getFamilyMemoriesByPatient(patientId: number): Promise<FamilyMemory[]> {
    return await db.select().from(familyMemories).where(eq(familyMemories.patientId, patientId));
  }

  async getFamilyMemory(id: number): Promise<FamilyMemory | undefined> {
    const [memory] = await db.select().from(familyMemories).where(eq(familyMemories.id, id));
    return memory;
  }

  // Cognitive activity operations
  async createCognitiveActivity(insertActivity: InsertCognitiveActivity): Promise<CognitiveActivity> {
    const [activity] = await db.insert(cognitiveActivities).values(insertActivity).returning();
    return activity;
  }

  async getCognitiveActivitiesByPatient(patientId: number): Promise<CognitiveActivity[]> {
    return await db.select().from(cognitiveActivities).where(eq(cognitiveActivities.patientId, patientId));
  }

  async getCognitiveActivity(id: number): Promise<CognitiveActivity | undefined> {
    const [activity] = await db.select().from(cognitiveActivities).where(eq(cognitiveActivities.id, id));
    return activity;
  }

  // Activity session operations
  async createActivitySession(insertSession: InsertActivitySession): Promise<ActivitySession> {
    const [session] = await db.insert(activitySessions).values(insertSession).returning();
    return session;
  }

  async updateActivitySession(id: number, updates: Partial<ActivitySession>): Promise<ActivitySession> {
    const [session] = await db
      .update(activitySessions)
      .set(updates)
      .where(eq(activitySessions.id, id))
      .returning();
    return session;
  }

  async getActivitySessionsByPatient(patientId: number): Promise<ActivitySession[]> {
    return await db
      .select()
      .from(activitySessions)
      .where(eq(activitySessions.patientId, patientId))
      .orderBy(desc(activitySessions.startedAt));
  }

  // Progress tracking operations
  async createCognitiveProgress(insertProgress: InsertCognitiveProgress): Promise<CognitiveProgress> {
    const [progress] = await db.insert(cognitiveProgress).values(insertProgress).returning();
    return progress;
  }

  async getCognitiveProgressByPatient(patientId: number): Promise<CognitiveProgress[]> {
    return await db
      .select()
      .from(cognitiveProgress)
      .where(eq(cognitiveProgress.patientId, patientId))
      .orderBy(desc(cognitiveProgress.assessmentDate));
  }

  async getLatestCognitiveProgress(patientId: number): Promise<CognitiveProgress | undefined> {
    const [progress] = await db
      .select()
      .from(cognitiveProgress)
      .where(eq(cognitiveProgress.patientId, patientId))
      .orderBy(desc(cognitiveProgress.assessmentDate))
      .limit(1);
    return progress;
  }

  // Emergency monitoring and vital signs operations
  async createVitalSigns(insertVitalSigns: InsertVitalSigns): Promise<VitalSigns> {
    const [vital] = await db.insert(vitalSigns).values(insertVitalSigns).returning();
    return vital;
  }

  async getVitalSignsByPatient(patientId: number): Promise<VitalSigns[]> {
    return await db
      .select()
      .from(vitalSigns)
      .where(eq(vitalSigns.patientId, patientId))
      .orderBy(desc(vitalSigns.createdAt));
  }

  async getLatestVitalSigns(patientId: number): Promise<VitalSigns | undefined> {
    const [vital] = await db
      .select()
      .from(vitalSigns)
      .where(eq(vitalSigns.patientId, patientId))
      .orderBy(desc(vitalSigns.createdAt))
      .limit(1);
    return vital;
  }

  async getEmergencyAlerts(patientId?: number): Promise<VitalSigns[]> {
    if (patientId) {
      return await db
        .select()
        .from(vitalSigns)
        .where(and(eq(vitalSigns.isEmergencyAlert, true), eq(vitalSigns.patientId, patientId)))
        .orderBy(desc(vitalSigns.createdAt));
    }
    
    return await db
      .select()
      .from(vitalSigns)
      .where(eq(vitalSigns.isEmergencyAlert, true))
      .orderBy(desc(vitalSigns.createdAt));
  }

  // Medicine tracking operations
  async createMedication(insertMedication: InsertMedication): Promise<Medication> {
    const [medication] = await db.insert(medications).values([insertMedication]).returning();
    return medication;
  }

  async getMedicationsByPatient(patientId: number): Promise<Medication[]> {
    return await db
      .select()
      .from(medications)
      .where(and(eq(medications.patientId, patientId), eq(medications.isActive, true)))
      .orderBy(desc(medications.createdAt));
  }

  async updateMedication(id: number, updates: Partial<Medication>): Promise<Medication> {
    const [medication] = await db
      .update(medications)
      .set(updates)
      .where(eq(medications.id, id))
      .returning();
    return medication;
  }

  async createMedicationLog(insertLog: InsertMedicationLog): Promise<MedicationLog> {
    const [log] = await db.insert(medicationLogs).values(insertLog).returning();
    return log;
  }

  async getMedicationLogsByPatient(patientId: number): Promise<MedicationLog[]> {
    return await db
      .select()
      .from(medicationLogs)
      .where(eq(medicationLogs.patientId, patientId))
      .orderBy(desc(medicationLogs.scheduledTime));
  }

  async getMissedMedications(patientId: number): Promise<MedicationLog[]> {
    return await db
      .select()
      .from(medicationLogs)
      .where(and(
        eq(medicationLogs.patientId, patientId),
        eq(medicationLogs.status, 'missed')
      ))
      .orderBy(desc(medicationLogs.scheduledTime));
  }

  // AI Gaming operations
  async createGameActivity(insertActivity: InsertGameActivity): Promise<GameActivity> {
    const [activity] = await db.insert(gameActivities).values(insertActivity).returning();
    return activity;
  }

  async getGameActivitiesByPatient(patientId: number): Promise<GameActivity[]> {
    return await db
      .select()
      .from(gameActivities)
      .where(eq(gameActivities.patientId, patientId))
      .orderBy(desc(gameActivities.startTime));
  }

  async updateGameActivity(id: number, updates: Partial<GameActivity>): Promise<GameActivity> {
    const [activity] = await db
      .update(gameActivities)
      .set(updates)
      .where(eq(gameActivities.id, id))
      .returning();
    return activity;
  }

  async getActiveGames(patientId: number): Promise<GameActivity[]> {
    return await db
      .select()
      .from(gameActivities)
      .where(and(
        eq(gameActivities.patientId, patientId),
        eq(gameActivities.status, 'in_progress')
      ))
      .orderBy(desc(gameActivities.startTime));
  }

  // Emergency response operations
  async createEmergencyEvent(insertEvent: InsertEmergencyEvent): Promise<EmergencyEvent> {
    const [event] = await db.insert(emergencyEvents).values([insertEvent]).returning();
    return event;
  }

  async getEmergencyEventsByPatient(patientId: number): Promise<EmergencyEvent[]> {
    return await db
      .select()
      .from(emergencyEvents)
      .where(eq(emergencyEvents.patientId, patientId))
      .orderBy(desc(emergencyEvents.createdAt));
  }

  async getActiveEmergencies(facilityId?: number): Promise<EmergencyEvent[]> {
    if (facilityId) {
      const results = await db
        .select({
          id: emergencyEvents.id,
          patientId: emergencyEvents.patientId,
          eventType: emergencyEvents.eventType,
          severity: emergencyEvents.severity,
          description: emergencyEvents.description,
          vitalSignsId: emergencyEvents.vitalSignsId,
          medicationLogId: emergencyEvents.medicationLogId,
          location: emergencyEvents.location,
          responseActions: emergencyEvents.responseActions,
          status: emergencyEvents.status,
          acknowledgedBy: emergencyEvents.acknowledgedBy,
          acknowledgedAt: emergencyEvents.acknowledgedAt,
          resolvedAt: emergencyEvents.resolvedAt,
          notificationsSent: emergencyEvents.notificationsSent,
          createdAt: emergencyEvents.createdAt,
        })
        .from(emergencyEvents)
        .innerJoin(patients, eq(emergencyEvents.patientId, patients.id))
        .where(and(
          eq(emergencyEvents.status, 'active'),
          eq(patients.facilityId, facilityId)
        ))
        .orderBy(desc(emergencyEvents.createdAt));
    }

    return await db
      .select()
      .from(emergencyEvents)
      .where(eq(emergencyEvents.status, 'active'))
      .orderBy(desc(emergencyEvents.createdAt));
  }

  async acknowledgeEmergency(eventId: number, userId: number): Promise<EmergencyEvent> {
    const [event] = await db
      .update(emergencyEvents)
      .set({
        status: 'acknowledged',
        acknowledgedBy: userId,
        acknowledgedAt: new Date(),
      })
      .where(eq(emergencyEvents.id, eventId))
      .returning();
    return event;
  }

  async resolveEmergency(eventId: number): Promise<EmergencyEvent> {
    const [event] = await db
      .update(emergencyEvents)
      .set({
        status: 'resolved',
        resolvedAt: new Date(),
      })
      .where(eq(emergencyEvents.id, eventId))
      .returning();
    return event;
  }

  // Subscription management operations
  async updateUserSubscription(userId: number, updates: Partial<User>): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set({
        ...updates,
        updatedAt: new Date()
      })
      .where(eq(users.id, userId))
      .returning();

    if (!updatedUser) {
      throw new Error('User not found');
    }

    return updatedUser;
  }

  async getUserSubscriptionStatus(userId: number): Promise<User | undefined> {
    const user = await db
      .select()
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);

    return user[0];
  }

  async getExpiredTrials(): Promise<User[]> {
    const now = new Date();
    return await db
      .select()
      .from(users)
      .where(
        and(
          eq(users.subscriptionStatus, 'trial'),
          lt(users.trialEndDate, now)
        )
      );
  }

  // Mood tracking operations
  async createMoodEntry(insertMoodEntry: InsertMoodEntry): Promise<MoodEntry> {
    const [moodEntry] = await db
      .insert(moodEntries)
      .values(insertMoodEntry)
      .returning();
    return moodEntry;
  }

  async getMoodEntriesByPatient(patientId: number, limit: number = 30): Promise<MoodEntry[]> {
    const entries = await db
      .select()
      .from(moodEntries)
      .where(eq(moodEntries.patientId, patientId))
      .orderBy(desc(moodEntries.createdAt))
      .limit(limit);
    return entries;
  }

  async getLatestMoodEntry(patientId: number): Promise<MoodEntry | undefined> {
    const [entry] = await db
      .select()
      .from(moodEntries)
      .where(eq(moodEntries.patientId, patientId))
      .orderBy(desc(moodEntries.createdAt))
      .limit(1);
    return entry;
  }

  async getMoodTrends(patientId: number, days: number = 7): Promise<MoodEntry[]> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const entries = await db
      .select()
      .from(moodEntries)
      .where(
        and(
          eq(moodEntries.patientId, patientId),
          gte(moodEntries.createdAt, startDate)
        )
      )
      .orderBy(desc(moodEntries.createdAt));
    return entries;
  }

  async createCompanionResponse(insertResponse: InsertCompanionResponse): Promise<CompanionResponse> {
    const [response] = await db
      .insert(companionResponses)
      .values(insertResponse)
      .returning();
    return response;
  }

  async getCompanionResponsesByMoodEntry(moodEntryId: number): Promise<CompanionResponse[]> {
    const responses = await db
      .select()
      .from(companionResponses)
      .where(eq(companionResponses.moodEntryId, moodEntryId))
      .orderBy(desc(companionResponses.createdAt));
    return responses;
  }

  async updateCompanionResponseDelivery(responseId: number, delivered: boolean, reaction?: string): Promise<CompanionResponse> {
    const updateData: any = {
      wasDelivered: delivered,
      deliveredAt: delivered ? new Date() : null,
    };
    if (reaction) {
      updateData.patientReaction = reaction;
    }

    const [response] = await db
      .update(companionResponses)
      .set(updateData)
      .where(eq(companionResponses.id, responseId))
      .returning();
    return response;
  }

  // Trial user management for Stripe subscriptions
  private trialUsers: any[] = [];

  async createTrialUser(trialData: any): Promise<any> {
    const trialUser = {
      id: Date.now(),
      ...trialData,
      createdAt: new Date()
    };
    this.trialUsers.push(trialUser);
    return trialUser;
  }

  async updateTrialUserStatus(subscriptionId: string, status: string): Promise<void> {
    const trialIndex = this.trialUsers.findIndex(t => t.subscriptionId === subscriptionId);
    if (trialIndex !== -1) {
      this.trialUsers[trialIndex].status = status;
      this.trialUsers[trialIndex].updatedAt = new Date();
    }
  }

  async getTrialUser(customerId: string): Promise<any> {
    return this.trialUsers.find(t => t.customerId === customerId);
  }
}

export const storage = new DatabaseStorage();
