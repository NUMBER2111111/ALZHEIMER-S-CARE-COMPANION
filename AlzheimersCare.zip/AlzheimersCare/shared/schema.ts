import { pgTable, text, serial, integer, boolean, timestamp, jsonb, varchar, index, decimal, date } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Users table - family members, admins, and patients
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  userType: varchar("user_type").notNull(), // 'family', 'admin', 'patient'
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  
  // Subscription and billing fields
  squareCustomerId: varchar("square_customer_id"),
  subscriptionId: varchar("subscription_id"),
  subscriptionStatus: varchar("subscription_status").default("trial"), // 'trial', 'active', 'past_due', 'canceled'
  trialStartDate: timestamp("trial_start_date"),
  trialEndDate: timestamp("trial_end_date"),
  subscriptionStartDate: timestamp("subscription_start_date"),
  nextBillingDate: timestamp("next_billing_date"),
  planType: varchar("plan_type").default("care-companion"), // 'care-companion'
  monthlyPrice: integer("monthly_price").default(4999), // Price in cents ($49.99)
});

// Trial Analytics table - comprehensive tracking of trial signups and conversions
export const trialAnalytics = pgTable("trial_analytics", {
  id: serial("id").primaryKey(),
  email: varchar("email").notNull(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  phoneNumber: varchar("phone_number"),
  
  // Trial tracking
  trialStartDate: timestamp("trial_start_date").defaultNow(),
  trialEndDate: timestamp("trial_end_date"),
  trialStatus: varchar("trial_status").default("active"), // 'active', 'converted', 'expired', 'cancelled'
  
  // Conversion tracking
  convertedToSubscription: boolean("converted_to_subscription").default(false),
  conversionDate: timestamp("conversion_date"),
  subscriptionDuration: integer("subscription_duration"), // days subscribed
  
  // Usage analytics
  loginCount: integer("login_count").default(0),
  featuresUsed: jsonb("features_used"), // track which features were accessed
  sessionDuration: integer("session_duration").default(0), // total minutes
  lastActivityDate: timestamp("last_activity_date"),
  
  // Traffic source
  referralSource: varchar("referral_source"), // 'organic', 'google-ads', 'facebook', 'direct'
  utmSource: varchar("utm_source"),
  utmMedium: varchar("utm_medium"),
  utmCampaign: varchar("utm_campaign"),
  
  // Device/location info
  userAgent: text("user_agent"),
  ipAddress: varchar("ip_address"),
  country: varchar("country"),
  city: varchar("city"),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Daily Analytics Summary table for performance
export const dailyAnalytics = pgTable("daily_analytics", {
  id: serial("id").primaryKey(),
  date: date("date").notNull(),
  
  // Trial metrics
  trialsStarted: integer("trials_started").default(0),
  trialsConverted: integer("trials_converted").default(0),
  trialsExpired: integer("trials_expired").default(0),
  trialsCancelled: integer("trials_cancelled").default(0),
  
  // Revenue metrics
  newSubscriptions: integer("new_subscriptions").default(0),
  totalRevenue: integer("total_revenue").default(0), // in cents
  averageSessionDuration: integer("average_session_duration").default(0),
  
  // Traffic metrics
  totalVisitors: integer("total_visitors").default(0),
  organicTraffic: integer("organic_traffic").default(0),
  paidTraffic: integer("paid_traffic").default(0),
  
  createdAt: timestamp("created_at").defaultNow(),
});

// Patients table - Alzheimer's patients receiving care
export const patients = pgTable("patients", {
  id: serial("id").primaryKey(),
  firstName: varchar("first_name").notNull(),
  lastName: varchar("last_name").notNull(),
  dateOfBirth: timestamp("date_of_birth"),
  medicalInfo: jsonb("medical_info"), // medications, conditions, etc.
  emergencyInfo: jsonb("emergency_info"), // emergency contacts, preferences
  facilityId: integer("facility_id"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Care facilities
export const facilities = pgTable("facilities", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  address: text("address"),
  contactInfo: jsonb("contact_info"),
  adminUserId: integer("admin_user_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Family relationships with security hierarchy
export const familyRelationships = pgTable("family_relationships", {
  id: serial("id").primaryKey(),
  familyMemberId: integer("family_member_id").notNull(),
  patientId: integer("patient_id").notNull(),
  relationship: varchar("relationship").notNull(), // 'son', 'daughter', 'spouse', etc.
  responsibilityLevel: varchar("responsibility_level").notNull(), // 'primary', 'secondary', 'support'
  isPrimaryContact: boolean("is_primary_contact").default(false),
  canAccessMedical: boolean("can_access_medical").default(false),
  securityLevel: varchar("security_level").default("standard"), // 'primary', 'restricted', 'locked_out'
  isLockedOut: boolean("is_locked_out").default(false),
  lockedOutBy: integer("locked_out_by").references(() => users.id),
  lockedOutAt: timestamp("locked_out_at"),
  lockedOutReason: text("locked_out_reason"),
  encryptionKeyId: varchar("encryption_key_id"), // Reference to encryption key for secure communications
  primaryPassword: varchar("primary_password"), // Hashed password for primary family member authentication
  passwordExpiresAt: timestamp("password_expires_at"), // Password expiration for security
  lastSecurityCheck: timestamp("last_security_check"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Family memories - photos, stories, etc.
export const familyMemories = pgTable("family_memories", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull(),
  familyMemberId: integer("family_member_id").notNull(),
  memoryType: varchar("memory_type").notNull(), // 'photo', 'story', 'video'
  title: varchar("title"),
  description: text("description"),
  content: jsonb("content"), // file paths, story text, etc.
  metadata: jsonb("metadata"), // AI analysis results, tags, etc.
  createdAt: timestamp("created_at").defaultNow(),
});

// AI-generated cognitive activities
export const cognitiveActivities = pgTable("cognitive_activities", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull(),
  activityType: varchar("activity_type").notNull(), // 'memory_recall', 'recognition', 'conversation'
  title: varchar("title").notNull(),
  description: text("description"),
  content: jsonb("content"), // activity data, questions, media, etc.
  difficulty: varchar("difficulty").notNull(), // 'easy', 'medium', 'hard'
  estimatedDuration: integer("estimated_duration"), // in minutes
  sourceMemoryId: integer("source_memory_id"), // reference to family memory used
  createdAt: timestamp("created_at").defaultNow(),
});

// Activity sessions - when patients complete activities
export const activitySessions = pgTable("activity_sessions", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull(),
  activityId: integer("activity_id").notNull(),
  startedAt: timestamp("started_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  successRate: decimal("success_rate", { precision: 5, scale: 2 }), // percentage
  responseData: jsonb("response_data"), // detailed responses for analysis
  aiAnalysis: jsonb("ai_analysis"), // AI assessment of performance
});

// Progress tracking
export const cognitiveProgress = pgTable("cognitive_progress", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull(),
  assessmentDate: timestamp("assessment_date").defaultNow(),
  memoryRecall: decimal("memory_recall", { precision: 5, scale: 2 }),
  recognition: decimal("recognition", { precision: 5, scale: 2 }),
  attention: decimal("attention", { precision: 5, scale: 2 }),
  overallScore: decimal("overall_score", { precision: 5, scale: 2 }),
  notes: text("notes"),
  aiInsights: jsonb("ai_insights"),
});

// Emergency monitoring and vital signs
export const vitalSigns = pgTable("vital_signs", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").references(() => patients.id).notNull(),
  deviceId: varchar("device_id", { length: 255 }), // fitness device identifier
  heartRate: integer("heart_rate"),
  bloodPressureSystolic: integer("blood_pressure_systolic"),
  bloodPressureDiastolic: integer("blood_pressure_diastolic"),
  oxygenSaturation: integer("oxygen_saturation"),
  temperature: decimal("temperature", { precision: 4, scale: 1 }),
  stepsCount: integer("steps_count"),
  sleepDuration: integer("sleep_duration"), // in minutes
  isEmergencyAlert: boolean("is_emergency_alert").default(false),
  alertType: varchar("alert_type", { length: 100 }), // fall, irregular_heartbeat, etc.
  location: jsonb("location").$type<{ latitude: number; longitude: number }>(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Medicine tracking and dispensement
export const medications = pgTable("medications", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").references(() => patients.id).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  dosage: varchar("dosage", { length: 255 }).notNull(),
  frequency: varchar("frequency", { length: 100 }).notNull(), // daily, twice_daily, etc.
  timeSlots: jsonb("time_slots").$type<string[]>(), // ["08:00", "20:00"]
  prescribedBy: varchar("prescribed_by", { length: 255 }),
  instructions: text("instructions"),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  isActive: boolean("is_active").default(true),
  emergencyContact: varchar("emergency_contact", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow(),
});

export const medicationLogs = pgTable("medication_logs", {
  id: serial("id").primaryKey(),
  medicationId: integer("medication_id").references(() => medications.id).notNull(),
  patientId: integer("patient_id").references(() => patients.id).notNull(),
  scheduledTime: timestamp("scheduled_time").notNull(),
  actualTime: timestamp("actual_time"),
  status: varchar("status", { length: 50 }).notNull(), // taken, missed, delayed, refused
  dispenserConfirmed: boolean("dispenser_confirmed").default(false),
  notes: text("notes"),
  emergencyTriggered: boolean("emergency_triggered").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// AI Gaming and Interactive Activities
export const gameActivities = pgTable("game_activities", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").references(() => patients.id).notNull(),
  gameType: varchar("game_type", { length: 100 }).notNull(), // chess, cards, memory_games, etc.
  gameName: varchar("game_name", { length: 255 }).notNull(),
  difficulty: varchar("difficulty", { length: 50 }).notNull(), // easy, medium, hard
  gameState: jsonb("game_state"), // current board state, cards, etc.
  playerMoves: jsonb("player_moves").$type<any[]>(),
  aiMoves: jsonb("ai_moves").$type<any[]>(),
  status: varchar("status", { length: 50 }).notNull(), // in_progress, completed, paused
  startTime: timestamp("start_time").defaultNow(),
  endTime: timestamp("end_time"),
  cognitiveScore: integer("cognitive_score"), // 0-100 based on performance
  engagementLevel: integer("engagement_level"), // 0-100
  createdAt: timestamp("created_at").defaultNow(),
});

// Emergency response system
export const emergencyEvents = pgTable("emergency_events", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").references(() => patients.id).notNull(),
  eventType: varchar("event_type", { length: 100 }).notNull(), // fall, medical, medication_missed, etc.
  severity: varchar("severity", { length: 50 }).notNull(), // low, medium, high, critical
  description: text("description"),
  vitalSignsId: integer("vital_signs_id").references(() => vitalSigns.id),
  medicationLogId: integer("medication_log_id").references(() => medicationLogs.id),
  location: jsonb("location").$type<{ latitude: number; longitude: number }>(),
  responseActions: jsonb("response_actions").$type<string[]>(),
  status: varchar("status", { length: 50 }).notNull(), // active, acknowledged, resolved
  acknowledgedBy: integer("acknowledged_by").references(() => users.id),
  acknowledgedAt: timestamp("acknowledged_at"),
  resolvedAt: timestamp("resolved_at"),
  notificationsSent: jsonb("notifications_sent").$type<string[]>(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Secure communication encryption keys
export const encryptionKeys = pgTable("encryption_keys", {
  id: serial("id").primaryKey(),
  keyId: varchar("key_id").unique().notNull(),
  userId: integer("user_id").references(() => users.id),
  facilityId: integer("facility_id").references(() => facilities.id),
  keyType: varchar("key_type").notNull(), // 'family_medical', 'admin_communication', 'medication_data'
  encryptedKey: text("encrypted_key").notNull(), // AES-256 encrypted key
  keyHash: varchar("key_hash").notNull(), // SHA-256 hash for verification
  isActive: boolean("is_active").default(true),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Secure communication logs for audit
export const secureMessageLogs = pgTable("secure_message_logs", {
  id: serial("id").primaryKey(),
  fromUserId: integer("from_user_id").references(() => users.id).notNull(),
  toUserId: integer("to_user_id").references(() => users.id),
  toFacilityId: integer("to_facility_id").references(() => facilities.id),
  messageType: varchar("message_type").notNull(), // 'medical_request', 'admin_communication', 'medication_change'
  encryptedContent: text("encrypted_content").notNull(),
  encryptionKeyId: varchar("encryption_key_id").references(() => encryptionKeys.keyId).notNull(),
  isBlocked: boolean("is_blocked").default(false),
  blockedBy: integer("blocked_by").references(() => users.id),
  blockedReason: text("blocked_reason"),
  sentAt: timestamp("sent_at").defaultNow(),
  readAt: timestamp("read_at"),
});

// Family lockout audit trail
export const familyLockoutLogs = pgTable("family_lockout_logs", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").references(() => patients.id).notNull(),
  primaryFamilyId: integer("primary_family_id").references(() => users.id).notNull(),
  lockedOutFamilyId: integer("locked_out_family_id").references(() => users.id).notNull(),
  lockoutType: varchar("lockout_type").notNull(), // 'medical_access', 'communication', 'full_lockout'
  reason: text("reason").notNull(),
  isActive: boolean("is_active").default(true),
  unlockCode: varchar("unlock_code"), // Emergency unlock code for administrators
  createdAt: timestamp("created_at").defaultNow(),
  expiresAt: timestamp("expires_at"),
});



// Relations
export const usersRelations = relations(users, ({ many }) => ({
  familyRelationships: many(familyRelationships),
  familyMemories: many(familyMemories),
}));

export const patientsRelations = relations(patients, ({ one, many }) => ({
  facility: one(facilities, {
    fields: [patients.facilityId],
    references: [facilities.id],
  }),
  familyRelationships: many(familyRelationships),
  familyMemories: many(familyMemories),
  cognitiveActivities: many(cognitiveActivities),
  activitySessions: many(activitySessions),
  cognitiveProgress: many(cognitiveProgress),
  vitalSigns: many(vitalSigns),
  medications: many(medications),
  medicationLogs: many(medicationLogs),
  gameActivities: many(gameActivities),
  emergencyEvents: many(emergencyEvents),
  moodEntries: many(moodEntries),
  companionResponses: many(companionResponses),
}));

export const facilitiesRelations = relations(facilities, ({ one, many }) => ({
  adminUser: one(users, {
    fields: [facilities.adminUserId],
    references: [users.id],
  }),
  patients: many(patients),
}));

export const familyRelationshipsRelations = relations(familyRelationships, ({ one }) => ({
  familyMember: one(users, {
    fields: [familyRelationships.familyMemberId],
    references: [users.id],
  }),
  patient: one(patients, {
    fields: [familyRelationships.patientId],
    references: [patients.id],
  }),
}));

export const familyMemoriesRelations = relations(familyMemories, ({ one, many }) => ({
  patient: one(patients, {
    fields: [familyMemories.patientId],
    references: [patients.id],
  }),
  familyMember: one(users, {
    fields: [familyMemories.familyMemberId],
    references: [users.id],
  }),
  cognitiveActivities: many(cognitiveActivities),
}));

export const cognitiveActivitiesRelations = relations(cognitiveActivities, ({ one, many }) => ({
  patient: one(patients, {
    fields: [cognitiveActivities.patientId],
    references: [patients.id],
  }),
  sourceMemory: one(familyMemories, {
    fields: [cognitiveActivities.sourceMemoryId],
    references: [familyMemories.id],
  }),
  activitySessions: many(activitySessions),
}));

export const activitySessionsRelations = relations(activitySessions, ({ one }) => ({
  patient: one(patients, {
    fields: [activitySessions.patientId],
    references: [patients.id],
  }),
  activity: one(cognitiveActivities, {
    fields: [activitySessions.activityId],
    references: [cognitiveActivities.id],
  }),
}));

export const cognitiveProgressRelations = relations(cognitiveProgress, ({ one }) => ({
  patient: one(patients, {
    fields: [cognitiveProgress.patientId],
    references: [patients.id],
  }),
}));

// New table relations
export const vitalSignsRelations = relations(vitalSigns, ({ one }) => ({
  patient: one(patients, {
    fields: [vitalSigns.patientId],
    references: [patients.id],
  }),
}));

export const medicationsRelations = relations(medications, ({ one, many }) => ({
  patient: one(patients, {
    fields: [medications.patientId],
    references: [patients.id],
  }),
  medicationLogs: many(medicationLogs),
}));

export const medicationLogsRelations = relations(medicationLogs, ({ one }) => ({
  medication: one(medications, {
    fields: [medicationLogs.medicationId],
    references: [medications.id],
  }),
  patient: one(patients, {
    fields: [medicationLogs.patientId],
    references: [patients.id],
  }),
}));

export const gameActivitiesRelations = relations(gameActivities, ({ one }) => ({
  patient: one(patients, {
    fields: [gameActivities.patientId],
    references: [patients.id],
  }),
}));

export const emergencyEventsRelations = relations(emergencyEvents, ({ one }) => ({
  patient: one(patients, {
    fields: [emergencyEvents.patientId],
    references: [patients.id],
  }),
  vitalSigns: one(vitalSigns, {
    fields: [emergencyEvents.vitalSignsId],
    references: [vitalSigns.id],
  }),
  medicationLog: one(medicationLogs, {
    fields: [emergencyEvents.medicationLogId],
    references: [medicationLogs.id],
  }),
  acknowledgedByUser: one(users, {
    fields: [emergencyEvents.acknowledgedBy],
    references: [users.id],
  }),
}));

// Lost Items table - AirTag and item tracking system
export const lostItems = pgTable("lost_items", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").references(() => patients.id),
  itemName: varchar("item_name").notNull(),
  itemType: varchar("item_type").notNull(), // 'keys', 'wallet', 'phone', 'medication', 'glasses', 'jewelry', 'clothing', 'documents', 'other'
  itemDescription: text("item_description"),
  airtagId: varchar("airtag_id"), // Apple AirTag identifier
  isAirtagConnected: boolean("is_airtag_connected").default(false),
  lastKnownLocation: jsonb("last_known_location"), // {lat, lng, address, timestamp}
  currentLocation: jsonb("current_location"), // {lat, lng, address, timestamp}
  itemStatus: varchar("item_status").default("active"), // 'active', 'lost', 'found', 'inactive'
  lostDate: timestamp("lost_date"),
  foundDate: timestamp("found_date"),
  searchRadius: integer("search_radius").default(100), // meters
  notificationEnabled: boolean("notification_enabled").default(true),
  familyNotified: boolean("family_notified").default(false),
  itemImage: varchar("item_image"), // photo of the item
  itemValue: integer("item_value"), // estimated value in cents
  priority: varchar("priority").default("medium"), // 'low', 'medium', 'high', 'critical'
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Item Location History table - tracking movement patterns
export const itemLocationHistory = pgTable("item_location_history", {
  id: serial("id").primaryKey(),
  itemId: integer("item_id").references(() => lostItems.id),
  location: jsonb("location").notNull(), // {lat, lng, address, accuracy}
  batteryLevel: integer("battery_level"), // AirTag battery percentage
  signalStrength: integer("signal_strength"), // Bluetooth signal strength
  detectedBy: varchar("detected_by"), // 'airtag', 'family_phone', 'finder_network'
  movementSpeed: decimal("movement_speed", { precision: 5, scale: 2 }), // km/h
  isStationary: boolean("is_stationary").default(true),
  recordedAt: timestamp("recorded_at").defaultNow(),
});

// Item Search Events table - tracking search activities
export const itemSearchEvents = pgTable("item_search_events", {
  id: serial("id").primaryKey(),
  itemId: integer("item_id").references(() => lostItems.id),
  searchedBy: integer("searched_by").references(() => users.id),
  searchType: varchar("search_type").notNull(), // 'manual', 'automated', 'family_initiated', 'geofence_trigger'
  searchLocation: jsonb("search_location"), // where the search was initiated from
  searchRadius: integer("search_radius").default(100), // meters
  itemFound: boolean("item_found").default(false),
  foundLocation: jsonb("found_location"),
  searchDuration: integer("search_duration"), // minutes
  notificationsSent: integer("notifications_sent").default(0),
  searchStatus: varchar("search_status").default("active"), // 'active', 'completed', 'abandoned'
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Relations for AirTag mapping system
export const lostItemsRelations = relations(lostItems, ({ one, many }) => ({
  patient: one(patients, {
    fields: [lostItems.patientId],
    references: [patients.id],
  }),
  locationHistory: many(itemLocationHistory),
  searchEvents: many(itemSearchEvents),
}));

export const itemLocationHistoryRelations = relations(itemLocationHistory, ({ one }) => ({
  item: one(lostItems, {
    fields: [itemLocationHistory.itemId],
    references: [lostItems.id],
  }),
}));

export const itemSearchEventsRelations = relations(itemSearchEvents, ({ one }) => ({
  item: one(lostItems, {
    fields: [itemSearchEvents.itemId],
    references: [lostItems.id],
  }),
  searcher: one(users, {
    fields: [itemSearchEvents.searchedBy],
    references: [users.id],
  }),
}));

// Type definitions for AirTag mapping system
export const insertLostItemSchema = createInsertSchema(lostItems);
export const insertItemLocationHistorySchema = createInsertSchema(itemLocationHistory);
export const insertItemSearchEventSchema = createInsertSchema(itemSearchEvents);

export type LostItem = typeof lostItems.$inferSelect;
export type InsertLostItem = z.infer<typeof insertLostItemSchema>;
export type ItemLocationHistory = typeof itemLocationHistory.$inferSelect;
export type InsertItemLocationHistory = z.infer<typeof insertItemLocationHistorySchema>;
export type ItemSearchEvent = typeof itemSearchEvents.$inferSelect;
export type InsertItemSearchEvent = z.infer<typeof insertItemSearchEventSchema>;

// Mood tracking tables
export const moodEntries = pgTable("mood_entries", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull().references(() => patients.id),
  moodState: varchar("mood_state").notNull(), // 'excellent', 'good', 'neutral', 'anxious', 'sad', 'frustrated', 'confused', 'angry'
  energyLevel: integer("energy_level").notNull(), // 1-10 scale
  anxietyLevel: integer("anxiety_level").notNull(), // 1-10 scale
  socialEngagement: integer("social_engagement").notNull(), // 1-10 scale
  cognitiveClarity: integer("cognitive_clarity").notNull(), // 1-10 scale
  physicalComfort: integer("physical_comfort").notNull(), // 1-10 scale
  notes: text("notes"),
  contextualFactors: jsonb("contextual_factors"), // weather, time of day, recent events, medications
  createdAt: timestamp("created_at").defaultNow(),
});

export const companionResponses = pgTable("companion_responses", {
  id: serial("id").primaryKey(),
  moodEntryId: integer("mood_entry_id").notNull().references(() => moodEntries.id),
  patientId: integer("patient_id").notNull().references(() => patients.id),
  responseType: varchar("response_type").notNull(), // 'empathetic', 'encouraging', 'suggestion', 'emergency_alert'
  responseText: text("response_text").notNull(),
  empathyLevel: integer("empathy_level").notNull(), // 1-10 scale for compassion intensity
  suggestedActions: jsonb("suggested_actions"), // Array of recommended activities or interventions
  personalityTraits: jsonb("personality_traits"), // Companion personality customization
  userReaction: varchar("user_reaction"), // 'helpful', 'neutral', 'unhelpful', 'ignored'
  emergencyKeywordsDetected: jsonb("emergency_keywords_detected"), // Array of concerning phrases
  confidenceScore: decimal("confidence_score", { precision: 3, scale: 2 }), // AI confidence in response appropriateness
  createdAt: timestamp("created_at").defaultNow(),
});

export const moodTrends = pgTable("mood_trends", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull().references(() => patients.id),
  trendPeriod: varchar("trend_period").notNull(), // 'daily', 'weekly', 'monthly'
  averageMoodScore: varchar("average_mood_score"),
  moodVariability: varchar("mood_variability"),
  dominantMood: varchar("dominant_mood"),
  improvementAreas: jsonb("improvement_areas"),
  wellnessRecommendations: jsonb("wellness_recommendations"),
  trendsAnalysis: jsonb("trends_analysis"), // AI-generated insights about patterns
  calculatedAt: timestamp("calculated_at").defaultNow(),
});

// Global Deterioration Scale (GDS) Cognitive Assessments
export const cognitiveAssessments = pgTable("cognitive_assessments", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull().references(() => patients.id),
  assessorId: integer("assessor_id").references(() => users.id),
  assessmentType: varchar("assessment_type").notNull().default("GDS"), // 'GDS', 'MMSE', 'MoCA'
  gdsStage: integer("gds_stage"), // 1-7 based on Global Deterioration Scale
  cognitiveScore: integer("cognitive_score"), // 0-100 cognitive performance score
  functionalScore: integer("functional_score"), // 0-100 functional ability score
  responses: jsonb("responses"), // Assessment question responses
  recommendations: text("recommendations").array(), // Clinical recommendations
  riskFactors: text("risk_factors").array(), // Identified risk factors
  nextAssessmentDate: timestamp("next_assessment_date"),
  aiInsights: jsonb("ai_insights"), // AI-generated insights and analysis
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const moodEntriesRelations = relations(moodEntries, ({ one, many }) => ({
  patient: one(patients, {
    fields: [moodEntries.patientId],
    references: [patients.id],
  }),
  companionResponses: many(companionResponses),
}));

export const companionResponsesRelations = relations(companionResponses, ({ one }) => ({
  moodEntry: one(moodEntries, {
    fields: [companionResponses.moodEntryId],
    references: [moodEntries.id],
  }),
  patient: one(patients, {
    fields: [companionResponses.patientId],
    references: [patients.id],
  }),
}));

export const moodTrendsRelations = relations(moodTrends, ({ one }) => ({
  patient: one(patients, {
    fields: [moodTrends.patientId],
    references: [patients.id],
  }),
}));

export const cognitiveAssessmentsRelations = relations(cognitiveAssessments, ({ one }) => ({
  patient: one(patients, {
    fields: [cognitiveAssessments.patientId],
    references: [patients.id],
  }),
  assessor: one(users, {
    fields: [cognitiveAssessments.assessorId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPatientSchema = createInsertSchema(patients).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  dateOfBirth: z.string().transform((str) => str ? new Date(str) : null).optional(),
});

export const insertFacilitySchema = createInsertSchema(facilities).omit({
  id: true,
  createdAt: true,
});

export const insertFamilyRelationshipSchema = createInsertSchema(familyRelationships).omit({
  id: true,
  createdAt: true,
});

export const insertFamilyMemorySchema = createInsertSchema(familyMemories).omit({
  id: true,
  createdAt: true,
});

export const insertCognitiveActivitySchema = createInsertSchema(cognitiveActivities).omit({
  id: true,
  createdAt: true,
});

export const insertActivitySessionSchema = createInsertSchema(activitySessions).omit({
  id: true,
  startedAt: true,
});

export const insertCognitiveProgressSchema = createInsertSchema(cognitiveProgress).omit({
  id: true,
  assessmentDate: true,
});

// New table insert schemas
export const insertVitalSignsSchema = createInsertSchema(vitalSigns).omit({
  id: true,
  createdAt: true,
});

export const insertMedicationSchema = createInsertSchema(medications).omit({
  id: true,
  createdAt: true,
});

export const insertMedicationLogSchema = createInsertSchema(medicationLogs).omit({
  id: true,
  createdAt: true,
});

export const insertGameActivitySchema = createInsertSchema(gameActivities).omit({
  id: true,
  startTime: true,
  createdAt: true,
}).extend({
  status: z.string().default('in_progress'),
});

export const insertEmergencyEventSchema = createInsertSchema(emergencyEvents).omit({
  id: true,
  createdAt: true,
});

export const insertMoodEntrySchema = createInsertSchema(moodEntries).omit({
  id: true,
  createdAt: true,
});

export const insertCompanionResponseSchema = createInsertSchema(companionResponses).omit({
  id: true,
  createdAt: true,
});

export const insertMoodTrendSchema = createInsertSchema(moodTrends).omit({
  id: true,
  calculatedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Patient = typeof patients.$inferSelect;
export type InsertPatient = z.infer<typeof insertPatientSchema>;
export type Facility = typeof facilities.$inferSelect;
export type InsertFacility = z.infer<typeof insertFacilitySchema>;
export type FamilyRelationship = typeof familyRelationships.$inferSelect;
export type InsertFamilyRelationship = z.infer<typeof insertFamilyRelationshipSchema>;
export type FamilyMemory = typeof familyMemories.$inferSelect;
export type InsertFamilyMemory = z.infer<typeof insertFamilyMemorySchema>;
export type CognitiveActivity = typeof cognitiveActivities.$inferSelect;
export type InsertCognitiveActivity = z.infer<typeof insertCognitiveActivitySchema>;
export type ActivitySession = typeof activitySessions.$inferSelect;
export type InsertActivitySession = z.infer<typeof insertActivitySessionSchema>;
export type CognitiveProgress = typeof cognitiveProgress.$inferSelect;
export type InsertCognitiveProgress = z.infer<typeof insertCognitiveProgressSchema>;

// New types for emergency monitoring, medicine tracking, and AI gaming
export type VitalSigns = typeof vitalSigns.$inferSelect;
export type InsertVitalSigns = z.infer<typeof insertVitalSignsSchema>;
export type Medication = typeof medications.$inferSelect;
export type InsertMedication = z.infer<typeof insertMedicationSchema>;
export type MedicationLog = typeof medicationLogs.$inferSelect;
export type InsertMedicationLog = z.infer<typeof insertMedicationLogSchema>;
export type GameActivity = typeof gameActivities.$inferSelect;
export type InsertGameActivity = z.infer<typeof insertGameActivitySchema>;
export type EmergencyEvent = typeof emergencyEvents.$inferSelect;
export type InsertEmergencyEvent = z.infer<typeof insertEmergencyEventSchema>;
export type MoodEntry = typeof moodEntries.$inferSelect;
export type InsertMoodEntry = z.infer<typeof insertMoodEntrySchema>;
export type CompanionResponse = typeof companionResponses.$inferSelect;
export type InsertCompanionResponse = z.infer<typeof insertCompanionResponseSchema>;
export type MoodTrend = typeof moodTrends.$inferSelect;
export type InsertMoodTrend = z.infer<typeof insertMoodTrendSchema>;

// Cognitive Assessment Types
export type CognitiveAssessment = typeof cognitiveAssessments.$inferSelect;
export type InsertCognitiveAssessment = typeof cognitiveAssessments.$inferInsert;
